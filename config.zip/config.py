from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
db = SQLAlchemy()  # ✅ Define db before using it

class Config:
    """Configuration for the PostgreSQL database."""
    SQLALCHEMY_DATABASE_URI = 'postgresql://postgres:123456@localhost:5432/test'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

# Apply configuration
app.config.from_object(Config)

# Initialize SQLAlchemy with the app
db.init_app(app)

# Create database tables within the app context
with app.app_context():
    db.create_all()

import smtplib

SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
MAIL_USE_TLS = True
MAIL_USE_SSL = False
USERNAME = "pravesh.kagalbot@kirloskar.com"
PASSWORD = "qmzm kdgr npzn dliu"
MAIL_DEFAULT_SENDER = "pravesh.kagalbot@kirloskar.com"
# SMTP_SERVER = "smtp.gmail.com"
# SMTP_PORT = 587
# USERNAME = "samu275001@gmail.com"
# PASSWORD = "gncn ubpu ghon pgiq"
# MAIL_DEFAULT_SENDER = "samrud.ravan@catnipit.com"

try:
    server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
    server.starttls()
    server.login(USERNAME, PASSWORD)
    print("✅ SMTP connection successful!")
    server.quit()
except Exception as e:
    print("❌ SMTP connection error:", str(e))

if __name__ == '__main__':
    app.run(debug=True)
