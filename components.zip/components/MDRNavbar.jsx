import { Button } from 'antd'
import React from 'react'
import { Link } from 'react-router'
import { DashboardOutlined } from '@ant-design/icons';

const MDRNavbar = () => {
    const handleOnClick = () => {
        localStorage.removeItem('dataStored')
        localStorage.removeItem('vehicleNumber')
        localStorage.removeItem('gate-form')
    }
    return (
        <div className='w-full h-20 px-5 md:px-0 md:w-[85%] flex justify-between items-center mx-auto'>
            <img src='/logo.jpg' className='h-20' />
            <h3 className=' text-[#1d998b] text-2xl'>
                Material Discrepancy Report
            </h3>
    
            <Link to="/MasterLayout" className='text-xl bg-white border border-2 flex gap-3 h-14 w-18 rounded-full items-center justify-center px-4 hover:shadow-md transition-all'><p>Home</p><DashboardOutlined /></Link>




        </div>
    )
}

export default MDRNavbar