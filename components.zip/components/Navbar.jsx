import { Button } from 'antd'
import React from 'react'
import { Link } from 'react-router'
import { SearchOutlined } from '@ant-design/icons';

const Navbar = () => {
    const handleOnClick = () => {
        localStorage.removeItem('dataStored')
        localStorage.removeItem('vehicleNumber')
        localStorage.removeItem('gate-form')
    }
    
    return (
        <div className='w-full px-5 md:px-0 md:w-[85%] flex justify-between mx-auto'>
            <img src='/logo.jpg' className='h-20' />
            {/* <Link to="/search">
                <Button type="default" icon={<SearchOutlined />} iconPosition='end' variant="solid" className='h-12  bg-[#1d998b] !text-white mt-4 hover:!bg-[#1d998b] hover:border-none' onClick={handleOnClick} >
                    Vehicle Search
                </Button>
            </Link> */}
             

        </div>
        
    )
}

export default Navbar