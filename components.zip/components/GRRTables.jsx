import React from "react";
import { Button, Table, Popconfirm } from "antd";
import { PlusOutlined, DeleteOutlined } from "@ant-design/icons";

const GRRTables = ({
  itemRows, setItemRows,
  taxRows, setTaxRows,
  taxRateRows, setTaxRateRows,
  handleAddRow,
  handleDelete,
  handleSaveRow,
  setShowTables,
  onSubmit,
  EditableRow,
  EditableCell
}) => {
  const createColumns = (columns, rows, setRows) =>
    columns.map(col => col.editable ? {
      ...col,
      onCell: record => ({
        record,
        editable: true,
        dataIndex: col.dataIndex,
        title: col.title,
        handleSave: row => handleSaveRow(row, rows, setRows),
      }),
    } : col);

  const itemColumns = createColumns([
    { title: "Sr. No", render: (_, __, index) => index + 1 },
    { title: "Part Number", dataIndex: "partNumber", editable: true },
    { title: "Description", dataIndex: "description", editable: true },
    { title: "Quantity", dataIndex: "quantity", editable: true },
    { title: "UOM", dataIndex: "uom", editable: true },
    { title: "Secondary Quantity", dataIndex: "secondaryQty", editable: true },
    { title: "Secondary UOM", dataIndex: "secondaryUom", editable: true },
    { title: "Destination Type", dataIndex: "destinationType", editable: true },
    { title: "Item", dataIndex: "item", editable: true },
    { title: "Rev", dataIndex: "rev", editable: true },
    {
      title: "Action",
      render: (_, record) => (
        <Popconfirm title="Delete?" onConfirm={() => handleDelete(record.key, setItemRows)}>
          <DeleteOutlined className="text-red-500 cursor-pointer" />
        </Popconfirm>
      ),
    },
  ], itemRows, setItemRows);

  const taxColumns = createColumns([
    { title: "Line Number", dataIndex: "lineNumber", editable: true },
    { title: "Document Type", dataIndex: "documentType", editable: true },
    { title: "Document Number", dataIndex: "documentNumber", editable: true },
    { title: "Document Line", dataIndex: "documentLine", editable: true },
    { title: "Shipment", dataIndex: "shipment", editable: true },
    { title: "Tax Category", dataIndex: "taxCategory", editable: true },
    { title: "Line Amount", dataIndex: "lineAmount", editable: true },
    { title: "Tax Amount", dataIndex: "taxAmount", editable: true },
    { title: "Line Total", dataIndex: "lineTotal", editable: true },
    { title: "HSN Code", dataIndex: "hsnCode", editable: true },
    { title: "Item", dataIndex: "item", editable: true },
    { title: "Item Description", dataIndex: "itemDescription", editable: true },
    { title: "Quantity", dataIndex: "quantity", editable: true },
    { title: "Price", dataIndex: "price", editable: true },
    { title: "Assessable Price List", dataIndex: "assessablePriceList", editable: true },
    {
      title: "Action",
      render: (_, record) => (
        <Popconfirm title="Delete?" onConfirm={() => handleDelete(record.key, setTaxRows)}>
          <DeleteOutlined className="text-red-500 cursor-pointer" />
        </Popconfirm>
      ),
    },
  ], taxRows, setTaxRows);

  const taxRateColumns = createColumns([
    { title: "Sr. No", render: (_, __, index) => index + 1 },
    { title: "Tax Rate Name", dataIndex: "taxRateName", editable: true },
    { title: "Tax Conversion Type", dataIndex: "taxConversionType", editable: true },
    { title: "Currency", dataIndex: "currency", editable: true },
    { title: "Tax Rate %", dataIndex: "taxRatePercent", editable: true },
    { title: "Recoverable Amount", dataIndex: "recoverableAmount", editable: true },
    { title: "Recoverable", dataIndex: "recoverable", editable: true },
    { title: "Party Name", dataIndex: "partyName", editable: true },
    { title: "Party Site", dataIndex: "partySite", editable: true },
    { title: "Functional Tax Amount", dataIndex: "functionalTaxAmount", editable: true },
    {
      title: "Action",
      render: (_, record) => (
        <Popconfirm title="Delete?" onConfirm={() => handleDelete(record.key, setTaxRateRows)}>
          <DeleteOutlined className="text-red-500 cursor-pointer" />
        </Popconfirm>
      ),
    },
  ], taxRateRows, setTaxRateRows);

  return (
    <>
      <h3 className="text-lg font-semibold mt-10 mb-2">Item Details</h3>
      <Button onClick={() => handleAddRow(setItemRows)} icon={<PlusOutlined />} className="mb-2">Add Row</Button>
      <Table
        components={{ body: { row: EditableRow, cell: EditableCell } }}
        bordered
        dataSource={itemRows}
        columns={itemColumns}
        rowClassName={() => "editable-row"}
        pagination={false}
        scroll={{ x: true }}
      />

      <h3 className="text-lg font-semibold mt-10 mb-2">Tax Details</h3>
      <Button onClick={() => handleAddRow(setTaxRows)} icon={<PlusOutlined />} className="mb-2">Add Row</Button>
      <Table
        components={{ body: { row: EditableRow, cell: EditableCell } }}
        bordered
        dataSource={taxRows}
        columns={taxColumns}
        rowClassName={() => "editable-row"}
        pagination={false}
        scroll={{ x: true }}
      />

      <h3 className="text-lg font-semibold mt-10 mb-2">Tax Rate Details</h3>
      <Button onClick={() => handleAddRow(setTaxRateRows)} icon={<PlusOutlined />} className="mb-2">Add Row</Button>
      <Table
        components={{ body: { row: EditableRow, cell: EditableCell } }}
        bordered
        dataSource={taxRateRows}
        columns={taxRateColumns}
        rowClassName={() => "editable-row"}
        pagination={false}
        scroll={{ x: true }}
      />

      <div className="mt-10 text-center space-x-4">
        <Button onClick={() => setShowTables(false)}>Back</Button>
        <Button type="primary" onClick={onSubmit} className="bg-[#1d998b]">Submit GRR</Button>
      </div>
    </>
  );
};

export default GRRTables;
