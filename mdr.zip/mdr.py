# from flask import Flask, request, jsonify
# from flask_cors import CORS
# from flask_mail import Mail, Message
# from fpdf import FPDF
# from config import Config
# from models import MdrDetails, MdrMaster, db, DockInOutMaster,DockInOutDetails
# # from models import ClosingMdr
# from datetime import datetime
# # from pdf_generator import generate_mdr_pdf
# import json
# import os
# import re
# import smtplib
# import traceback
# from email.mime.text import MIMEText
# from email.mime.multipart import MIMEMultipart
# from email.mime.base import MIMEBase
# from email.mime.application import MIMEApplication
# from email import encoders
# from config import MAIL_DEFAULT_SENDER, SMTP_SERVER, SMTP_PORT, USERNAME, PASSWORD

# from flask import send_file
# import pandas as pd
# from io import BytesIO
# import io
# from sqlalchemy.orm import joinedload
# from sqlalchemy import func, or_

# from flask import Flask, request, jsonify
# from flask_cors import CORS


 
# # import smtplib
 
# # SMTP_SERVER = "smtp.gmail.com"
# # SMTP_PORT = 587
# # USERNAME = "samu275001@gmail.com"
# # PASSWORD = "gncn ubpu ghon pgiq"
# # MAIL_DEFAULT_SENDER = "samrud.ravan@catnipit.com"
 
# # try:
# #     server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
# #     server.starttls()
# #     server.login(USERNAME, PASSWORD)
# #     print("✅ SMTP connection successful!")
# #     server.quit()
# # except Exception as e:
# #     print("❌ SMTP connection error:", str(e))
 
 
# app = Flask(__name__)
# app.config.from_object(Config)
# CORS(app)
# # CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=True)
# CORS(app, resources={r"/*": {"origins": "http://localhost:5173"}})  # ✅
# db.init_app(app)
# mail = Mail(app)
 
 
# UPLOAD_FOLDER = "mdr/"  # Directory to store images
# os.makedirs(UPLOAD_FOLDER, exist_ok=True)  # Ensure folder exists
 
# def parse_date(date_str):
#     if date_str:
#         try:
#             return datetime.strptime(date_str, "%Y-%m-%d").date()
#         except ValueError as e:
#             print("Date Parsing Error:", e)
#             return None
#     return None
 
 
# @app.route("/submit_mdr", methods=["POST"])
# def submit_mdr():
#     try:
       
#         # Get form fields
#         invoice_number = request.form.get("invoice_number")
#         mdr_number = request.form.get("mdr_number")
#         email_id_to = request.form.get("email_id_to")  # Required
#         email_id_to_logistics = request.form.get("email_id_to_logistics")  # Required
#         email_id_cc = request.form.get("email_id_cc", "")  # Optional
#         print("mdr_number:", mdr_number)
#         grr_date = parse_date(request.form.get("grr_date", ""))
#         print("GRR date:",grr_date)
#         invoice_date = parse_date(request.form.get("invoice_date", ""))
#         mdr_date = parse_date(request.form.get("mdr_date", ""))
#         count = 1
        
#         email_pattern = r"[^@]+@[^@]+\.[^@]+"
#         for email_field in [email_id_to, email_id_to_logistics,email_id_cc]:
#             for email in email_field.split(","):
#                 if email.strip() and not re.match(email_pattern, email.strip()):
#                     raise ValueError(f"Invalid email format: {email.strip()}")

#          # ✅ Check if the same mdr_number exists for another record
#         duplicate_mdr = MdrMaster.query.filter(
#             MdrMaster.mdr_number == mdr_number,
#             # MdrMaster.invoice_number != invoice_number  # not the same record
#         ).first()

#         if duplicate_mdr:
#             return jsonify({"error": f"MDR number '{mdr_number}' already exists."}), 409
        

       
#         # Process uploaded images
#         received_images = []
#         if "received_images" in request.files:
#             files = request.files.getlist("received_images")  # Get multiple files
#             count = 1
#             for file in files:
#                 filename = f"{mdr_number}_{count}_{file.filename}"
#                 file_path = os.path.join(UPLOAD_FOLDER, filename)
#                 file.save(file_path)  # Save image to server
#                 received_images.append(file_path)
#                 count += 1
 
#         print("Received images:", received_images)  # Debugging
 
#         if not mdr_number or not invoice_number:
#             return jsonify({"error": "mdr number and invoice number required"}), 404
       
#         # existing_mdr = MdrMaster.query.filter_by(invoice_number=invoice_number).first()
#         existing_mdr = MdrMaster.query.filter_by(mdr_number=mdr_number).first()

 
#         if existing_mdr:
#             existing_mdr.mdr_number = mdr_number
#             existing_mdr.invoice_number = invoice_number
#             existing_mdr.grr_date = grr_date
#             existing_mdr.invoice_date = invoice_date
#             existing_mdr.mdr_date = mdr_date
#             existing_mdr.vendor_code = request.form.get("vendor_code")
#             existing_mdr.vendor_name = request.form.get("vendor_name")
#             existing_mdr.transporter_name = request.form.get("transporter_name")
#             existing_mdr.vehicle_number = request.form.get("vehicle_number")
#             existing_mdr.mdr_raised_as = request.form.get("mdr_raised_as")
#             existing_mdr.grr_mtn_sticker_number = request.form.get("grr_mtn_sticker_number")
#             existing_mdr.lr_field = request.form.get("lr_field")
#             existing_mdr.grr_number = request.form.get("grr_number")
#             existing_mdr.prepared_by = request.form.get("prepared_by")
#             existing_mdr.mdr_remarks_1 = request.form.get("mdr_remarks_1")
#             existing_mdr.mdr_remarks_2 = request.form.get("mdr_remarks_2")
#             existing_mdr.unloading_location = request.form.get("unloading_location")
#             existing_mdr.email_id_cc =email_id_cc
#             existing_mdr.email_id_to = email_id_to
#             existing_mdr.email_id_to_logistics = email_id_to_logistics

 
#         else:
#             new_mdr = MdrMaster(
#                 invoice_number=invoice_number,
#                 grr_date=grr_date,
#                 invoice_date=invoice_date,
#                 mdr_number=mdr_number,
#                 mdr_date=mdr_date,
#                 vendor_code=request.form.get("vendor_code"),
#                 vendor_name=request.form.get("vendor_name"),
#                 transporter_name=request.form.get("transporter_name"),
#                 vehicle_number=request.form.get("vehicle_number"),
#                 mdr_raised_as=request.form.get("mdr_raised_as"),
#                 grr_mtn_sticker_number=request.form.get("grr_mtn_sticker_number"),
#                 lr_field=request.form.get("lr_field"),
#                 grr_number=request.form.get("grr_number"),
#                 prepared_by=request.form.get("prepared_by"),
#                 mdr_remarks_1=request.form.get("mdr_remarks_1"),
#                 mdr_remarks_2=request.form.get("mdr_remarks_2"),
#                 unloading_location=request.form.get("unloading_location"),
#                 email_id_cc=email_id_cc,
#                 email_id_to=email_id_to,
#                 email_id_to_logistics=email_id_to_logistics,

#             )
#             db.session.add(new_mdr)
 
#         db.session.commit()
 
#         mdr_details_list = request.form.get("tableData", "[]")
#         try:
#             mdr_details_list = json.loads(mdr_details_list)
#         except json.JSONDecodeError:
#             return jsonify({"error": "Invalid tableData format"}), 400
       
       
#         MdrDetails.query.filter_by(mdr_number=mdr_number).delete()
#         for detail in mdr_details_list:
#                 new_detail = MdrDetails(
#                     mdr_number=mdr_number,
#                     invoice_number=invoice_number,
#                     invoice_date=invoice_date,
#                     item_code=detail.get("item_code"),
#                     item_description=detail.get("item_description"),
#                     item_quantity_actual=detail.get("item_quantity_actual"),
#                     quantity_as_per_challan=detail.get("quantity_as_per_challan"),
#                     excess_shortfall_quantity=detail.get("excess_shortfall_quantity"),
#                     number_of_boxes_lr=detail.get("number_of_boxes_lr"),
#                     number_of_boxes_lr_recieved=detail.get("number_of_boxes_lr_recieved"),
#                     # unit_of_measurement=detail.get("unit_of_measurement"),
#                     remarks_1=detail.get("mdr_remarks_1"),
#                 )
#                 db.session.add(new_detail)
 
#         db.session.commit()
 
#         count = 1
 
#         return jsonify({"message": "MDR record processed successfully", "mdr_number": mdr_number}), 201
 
#     except Exception as e:
#         db.session.rollback()
#         print("Error:", str(e))
#         return jsonify({"error": str(e)}), 500


# @app.route("/get_message_id_by_mdr", methods=["GET"])
# def get_message_id_by_mdr():
#     mdr_number = request.args.get("mdr_number")
#     print("🔍 Looking up Message-ID for MDR:", mdr_number)
#     if not mdr_number:
#         return jsonify({"error": "mdr_number required"}), 400
#     mdr = MdrMaster.query.filter_by(mdr_number=mdr_number).first()
#     if mdr and mdr.original_message_id:
#         print("✅ Found original_message_id:", mdr.original_message_id)
#         return jsonify({"message_id": mdr.original_message_id}), 200
#     return jsonify({"error": "Message ID not found"}), 404


# from email.utils import make_msgid
# # @app.route('/send_mdr_email', methods=['POST'])
# # def send_email():
# #     try:
# #         # ✅ Get data from multipart/form-data
# #         email_id_to = request.form.getlist("email_id_to")
# #         email_id_to_logistics = request.form.getlist("email_id_to_logistics")
# #         email_id_cc = request.form.getlist("email_id_cc")
# #         subject = request.form.get("subject", "MDR Submission")
# #         body_text = request.form.get("body", "")
# #         screenshot_file = request.files.get("screenshot")
# #         uploaded_images = request.files.getlist("images")

# #         print("📩 Received email request:")
# #         print("To:", email_id_to)
# #         print("To Logistics:", email_id_to_logistics)
# #         print("CC:", email_id_cc)
# #         print("Subject:", subject)
# #         for img in uploaded_images:
# #          print("Uploaded image:", img.filename)

# #         # ✅ Clean email lists
# #         to_recipients = [email.strip() for email in email_id_to if email.strip()]
# #         to_logistics_recipients = [email.strip() for email in email_id_to_logistics if email.strip()]
# #         cc_recipients = [email.strip() for email in email_id_cc if email.strip()]

# #         # ✅ Email validation
# #         email_pattern = r"[^@]+@[^@]+\.[^@]+"
# #         if not to_recipients or not all(re.match(email_pattern, email) for email in to_recipients):
# #             return jsonify({"error": "Valid recipient email(s) required"}), 400

# #         # ✅ Extract MDR details
# #         invoice_number = re.search(r"Invoice Number:\s*(\d+)", body_text)
# #         # mdr_number = re.search(r"MDR Number:\s*(\d+)", body_text)
# #         grr_number = re.search(r"GRR Number:\s*([\w-]+)", body_text)
# #         grr_date = re.search(r"GRR Date:\s*(.+)", body_text)
# #         invoice_date = re.search(r"Invoice Date:\s*(.+)", body_text)
# #         mdr_date = re.search(r"MDR Date:\s*(.+)", body_text)
# #         vehicle_number = re.search(r"Vehicle Number:\s*(.+)", body_text)
# #         supplier_name = re.search(r"Supplier Name:\s*(.+)", body_text)
# #         table_data_match = re.search(r"Table Data:\s*(\[[\s\S]*?\]|\{[\s\S]*?\})", body_text)
# #         mdr_number_match = re.search(r"MDR (?:No|Number):\s*([A-Za-z0-9\-\/]+)", body_text)
# #         mdr_number = mdr_number_match.group(1).strip() if mdr_number_match else None


# #         # ✅ Fallbacks
# #         invoice_number = invoice_number.group(1) if invoice_number else "Unknown"
# #         # mdr_number = mdr_number.group(1) if mdr_number else "Unknown"
# #         # mdr_number = mdr_number.group(1).strip() if mdr_number else None
# #         grr_number = grr_number.group(1) if grr_number else "Unknown"
# #         grr_date = grr_date.group(1).strip() if grr_date else "Unknown"
# #         invoice_date = invoice_date.group(1).strip() if invoice_date else "Unknown"
# #         mdr_date = mdr_date.group(1).strip() if mdr_date else "Unknown"
# #         vehicle_number = vehicle_number.group(1).strip() if vehicle_number else "Unknown"
# #         supplier_name = supplier_name.group(1).strip() if supplier_name else "Unknown"
        
# #         message_id = make_msgid()
       
# #         if mdr_number != "Unknown":
# #             try:
# #                 mdr = MdrMaster.query.filter_by(mdr_number=mdr_number).first()
# #                 if mdr:
# #                     mdr.original_message_id = message_id
# #                     db.session.commit()
# #                     print(f"✅ Message-ID saved to DB for {mdr_number}: {message_id}")
# #             except Exception as e:
# #                 print(f"❌ Failed to save Message-ID for {mdr_number}: {e}")  
                          
# #         # ✅ Merge fields into each row of table
# #         if table_data_match:
# #             try:
# #                 table_data_json = table_data_match.group(1)
# #                 table_data = json.loads(table_data_json)
# #                 print("✅ Extracted Table Data:", table_data)

# #                 mdr_fields = {
# #                     "invoice_number": invoice_number,
# #                     "mdr_number": mdr_number,
# #                     "grr_number": grr_number,
# #                     "grr_date":grr_date,
# #                     "invoice_date": invoice_date,
# #                     "mdr_date": mdr_date,
# #                     "vehicle_number": vehicle_number,
# #                     "supplier_name": supplier_name,
# #                 }

# #                 merged_columns = [
# #                     "invoice_number", "mdr_number", "grr_number", "grr_date","invoice_date", "mdr_date",
# #                     "vehicle_number", "supplier_name",
# #                     "srno", "item_code", "item_description", "quantity_as_per_challan",
# #                     "item_quantity_actual", "excess_shortfall_quantity",
# #                     "number_of_boxes_lr", "number_of_boxes_lr_recieved", "mdr_remarks_1"
# #                 ]

# #                 column_headers = {
# #                     "invoice_number": "Invoice No.",
# #                     "mdr_number": "MDR No.",
# #                     "grr_number": "GRR No.",
# #                     "grr_date":"GRR Date",
# #                     "invoice_date": "Invoice Date",
# #                     "mdr_date": "MDR Date",
# #                     "vehicle_number": "Vehicle No.",
# #                     "supplier_name": "Supplier",
# #                     "srno": "Sr. No.",
# #                     "item_code": "Item Code",
# #                     "item_description": "Description",
# #                     "quantity_as_per_challan": "Challan Qty",
# #                     "item_quantity_actual": "Actual Qty",
# #                     "excess_shortfall_quantity": "Excess/Shortfall Qty",
# #                     "number_of_boxes_lr": "Boxes (LR)",
# #                     "number_of_boxes_lr_recieved": "Boxes Received",
# #                     "mdr_remarks_1": "MDR Remarks"
# #                 }

# #                 # ✅ Build single scrollable table with merged data
# #                 if isinstance(table_data, list) and len(table_data) > 0:
# #                     headers = "".join(f"<th>{column_headers[col]}</th>" for col in merged_columns)
# #                     rows = ""
# #                     for row in table_data:
# #                         full_row = {**mdr_fields, **row}
# #                         rows += "<tr>" + "".join(f"<td>{full_row.get(col, '')}</td>" for col in merged_columns) + "</tr>"

# #                     table_data_html = f"""
# #                     <div style="max-height: 400px; overflow: auto; border: 1px solid #ccc;">
# #                       <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
# #                         <thead>
# #                           <tr style="background-color: #f2f2f2;">{headers}</tr>
# #                         </thead>
# #                         <tbody>{rows}</tbody>
# #                       </table>
# #                     </div>
# #                     """
# #                 else:
# #                     table_data_html = "<p>No table rows to display</p>"

# #             except json.JSONDecodeError as e:
# #                 print("❌ JSON Decode Error:", e)
# #                 table_data_html = "<p>Invalid JSON in table data</p>"
# #         else:
# #             print("❌ No table data found")
# #             table_data_html = "<p>No table data</p>"

# #         # ✅ Compose email body
# #         subject = f"MDR Submission - {mdr_number}"
# #         body = f"""
# #         <html>
# #           <body>
# #             <p>Dear User,</p>
# #             <p>Your MDR has been successfully submitted.</p>
# #             <p><strong>Discrepancy Table:</strong></p>
# #             {table_data_html}
# #             <p>Please find the attached MDR preview.</p>
# #             <p>
# #       <a href="https://your-backend.com/api/email-accept?mdrId=12345" 
# #         style="padding: 10px 20px; background-color: #28a745; color: white; text-decoration: none; border-radius: 4px;">
# #         Accept
# #       </a>

# #     </p>
# #           </body>
# #         </html>
# #         """

# #         # ✅ Email
# #         msg = MIMEMultipart()
# #         msg["Message-ID"] = message_id
# #         msg["From"] = MAIL_DEFAULT_SENDER
# #         msg["To"] = ", ".join(to_recipients)
# #         msg["Cc"] = ", ".join(cc_recipients)
# #         msg["Subject"] = subject
# #         msg.attach(MIMEText(body, "html"))

# #         # ✅ Attach screenshot
# #         if screenshot_file:
# #             screenshot_data = screenshot_file.read()
# #             image_part = MIMEApplication(screenshot_data, _subtype="png")
# #             image_part.add_header('Content-Disposition', 'attachment', filename="mdr_screenshot.png")
# #             msg.attach(image_part)
        
# #         # ✅ Attach uploaded images
# #         for idx, image_file in enumerate(uploaded_images):
# #             image_data = image_file.read()
# #             image_part = MIMEApplication(image_data)
# #             image_part.add_header(
# #                 'Content-Disposition',
# #                 'attachment',
# #                 filename=image_file.filename or f"image_{idx + 1}.png"
# #             )
# #             msg.attach(image_part)

# #         all_recipients = to_recipients + cc_recipients + to_logistics_recipients

# #         with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
# #             server.starttls()
# #             server.login(USERNAME, PASSWORD)
# #             server.sendmail(MAIL_DEFAULT_SENDER, all_recipients, msg.as_string())

# #         print("✅ Email sent successfully")
# #         return jsonify({"message": "Email sent successfully","message_id": message_id}), 200

# #     except Exception as e:
# #         print("❌ Email sending error:", str(e))
# #         return jsonify({"error": str(e)}), 500

# @app.route('/send_mdr_email', methods=['POST'])
# def send_email():
#     try:
#         # ✅ Get data from multipart/form-data
#         email_id_to = request.form.get("email_id_to") or ""
#         email_id_to_logistics = request.form.get("email_id_to_logistics") or ""
#         email_id_cc = request.form.get("email_id_cc") or ""
#         subject = request.form.get("subject", "MDR Submission")
#         body_text = request.form.get("body", "")
#         screenshot_file = request.files.get("screenshot")
#         uploaded_images = request.files.getlist("images")

#         print("📩 Received email request:")
#         print("To:", email_id_to)
#         print("To Logistics:", email_id_to_logistics)
#         print("CC:", email_id_cc)
#         for img in uploaded_images:
#             print("Uploaded image:", img.filename)

#         # ✅ Clean email lists
#         to_recipients = [email.strip() for email in email_id_to if email.strip()]
#         to_logistics_recipients = [email.strip() for email in email_id_to_logistics if email.strip()]
#         cc_recipients = [email.strip() for email in email_id_cc if email.strip()]

#         # ✅ Email validation
#         email_pattern = r"[^@]+@[^@]+\.[^@]+"
#         if not to_recipients or not all(re.match(email_pattern, email) for email in to_recipients):
#             return jsonify({"error": "Valid recipient email(s) required"}), 400

#         # ✅ Extract MDR details
#         invoice_number_match = re.search(r"Invoice Number:\s*(.+)", body_text)
#         grr_number_match = re.search(r"GRR Number:\s*(.+)", body_text)
#         grr_date = re.search(r"GRR Date:\s*(.+)", body_text)
#         invoice_date = re.search(r"Invoice Date:\s*(.+)", body_text)
#         mdr_date = re.search(r"MDR Date:\s*(.+)", body_text)
#         vehicle_number = re.search(r"Vehicle Number:\s*(.+)", body_text)
#         supplier_name = re.search(r"Supplier Name:\s*(.+)", body_text)
#         table_data_match = re.search(r"Table Data:\s*(\[[\s\S]*?\]|\{[\s\S]*?\})", body_text)
#         mdr_number_match = re.search(r"MDR (?:No|Number):\s*([A-Za-z0-9\-\/]+)", body_text)
#         mdr_number = mdr_number_match.group(1).strip() if mdr_number_match else None

#         # ✅ Fallbacks
#         invoice_number = invoice_number_match.group(1).strip() if invoice_number_match else "Unknown"
#         grr_number = grr_number_match.group(1).strip() if grr_number_match else "Unknown"
#         grr_date = grr_date.group(1).strip() if grr_date else "Unknown"
#         invoice_date = invoice_date.group(1).strip() if invoice_date else "Unknown"
#         mdr_date = mdr_date.group(1).strip() if mdr_date else "Unknown"
#         vehicle_number = vehicle_number.group(1).strip() if vehicle_number else "Unknown"
#         supplier_name = supplier_name.group(1).strip() if supplier_name else "Unknown"

#         message_id = make_msgid()

#         if mdr_number != "Unknown":
#             try:
#                 mdr = MdrMaster.query.filter_by(mdr_number=mdr_number).first()
#                 if mdr:
#                     mdr.original_message_id = message_id
#                     db.session.commit()
#                     print(f"✅ Message-ID saved to DB for {mdr_number}: {message_id}")
#             except Exception as e:
#                 print(f"❌ Failed to save Message-ID for {mdr_number}: {e}")  

#         # ✅ Merge fields into each row of table
#         if table_data_match:
#             try:
#                 table_data_json = table_data_match.group(1)
#                 table_data = json.loads(table_data_json)
#                 print("✅ Extracted Table Data:", table_data)

#                 invoice_list = [i.strip() for i in invoice_number.split(",")]
#                 grr_list = [g.strip() for g in grr_number.split(",")]

#                 mdr_fields = {
#                     "mdr_number": mdr_number,
#                     "grr_date": grr_date,
#                     "invoice_date": invoice_date,
#                     "mdr_date": mdr_date,
#                     "vehicle_number": vehicle_number,
#                     "supplier_name": supplier_name,
#                 }

#                 merged_columns = [
#                     "invoice_number", "mdr_number", "grr_number", "grr_date", "invoice_date", "mdr_date",
#                     "vehicle_number", "supplier_name",
#                     "srno", "item_code", "item_description", "quantity_as_per_challan",
#                     "item_quantity_actual", "excess_shortfall_quantity",
#                     "number_of_boxes_lr", "number_of_boxes_lr_recieved", "mdr_remarks_1"
#                 ]

#                 column_headers = {
#                     "invoice_number": "Invoice No.",
#                     "mdr_number": "MDR No.",
#                     "grr_number": "GRR No.",
#                     "grr_date": "GRR Date",
#                     "invoice_date": "Invoice Date",
#                     "mdr_date": "MDR Date",
#                     "vehicle_number": "Vehicle No.",
#                     "supplier_name": "Supplier",
#                     "srno": "Sr. No.",
#                     "item_code": "Item Code",
#                     "item_description": "Description",
#                     "quantity_as_per_challan": "Challan Qty",
#                     "item_quantity_actual": "Actual Qty",
#                     "excess_shortfall_quantity": "Excess/Shortfall Qty",
#                     "number_of_boxes_lr": "Boxes (LR)",
#                     "number_of_boxes_lr_recieved": "Boxes Received",
#                     "mdr_remarks_1": "MDR Remarks"
#                 }

#                 # ✅ Build HTML table
#                 if isinstance(table_data, list) and len(table_data) > 0:
#                     headers = "".join(f"<th>{column_headers[col]}</th>" for col in merged_columns)
#                     rows = ""
#                     for idx, row in enumerate(table_data):
#                         full_row = {**mdr_fields, **row}
#                         full_row["invoice_number"] = invoice_list[idx] if idx < len(invoice_list) else "-"
#                         full_row["grr_number"] = grr_list[idx] if idx < len(grr_list) else "-"
#                         rows += "<tr>" + "".join(f"<td>{full_row.get(col, '')}</td>" for col in merged_columns) + "</tr>"

#                     table_data_html = f"""
#                     <div style="max-height: 400px; overflow: auto; border: 1px solid #ccc;">
#                       <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
#                         <thead>
#                           <tr style="background-color: #f2f2f2;">{headers}</tr>
#                         </thead>
#                         <tbody>{rows}</tbody>
#                       </table>
#                     </div>
#                     """
#                 else:
#                     table_data_html = "<p>No table rows to display</p>"

#             except json.JSONDecodeError as e:
#                 print("❌ JSON Decode Error:", e)
#                 table_data_html = "<p>Invalid JSON in table data</p>"
#         else:
#             print("❌ No table data found")
#             table_data_html = "<p>No table data</p>"

#         # ✅ Compose HTML email body
#         subject = f"MDR Submission - {mdr_number}"
#         body = f"""
#         <html>
#           <body>
#             <p>Dear User,</p>
#             <p>Your MDR has been successfully submitted.</p>
#             <p><strong>Discrepancy Table:</strong></p>
#             {table_data_html}
#             <p>Please find the attached MDR preview.</p>
#             <p>
#               <a href="https://your-backend.com/api/email-accept?mdrId={mdr_number}" 
#                  style="padding: 10px 20px; background-color: #28a745; color: white; text-decoration: none; border-radius: 4px;">
#                 Accept
#               </a>
#             </p>
#           </body>
#         </html>
#         """

#         # ✅ Prepare Email
#         msg = MIMEMultipart()
#         msg["Message-ID"] = message_id
#         msg["From"] = MAIL_DEFAULT_SENDER
#         msg["To"] = ", ".join(to_recipients)
#         msg["Cc"] = ", ".join(cc_recipients)
#         msg["Subject"] = subject
#         msg.attach(MIMEText(body, "html"))

#         # ✅ Attach screenshot
#         if screenshot_file:
#             screenshot_data = screenshot_file.read()
#             image_part = MIMEApplication(screenshot_data, _subtype="png")
#             image_part.add_header('Content-Disposition', 'attachment', filename="mdr_screenshot.png")
#             msg.attach(image_part)

#         # ✅ Attach uploaded images
#         for idx, image_file in enumerate(uploaded_images):
#             image_data = image_file.read()
#             image_part = MIMEApplication(image_data)
#             image_part.add_header('Content-Disposition', 'attachment', filename=image_file.filename or f"image_{idx + 1}.png")
#             msg.attach(image_part)

#         # ✅ Send email
#         all_recipients = to_recipients + cc_recipients + to_logistics_recipients
#         with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
#             server.starttls()
#             server.login(USERNAME, PASSWORD)
#             server.sendmail(MAIL_DEFAULT_SENDER, all_recipients, msg.as_string())

#         print("✅ Email sent successfully")
#         return jsonify({"message": "Email sent successfully", "message_id": message_id}), 200

#     except Exception as e:
#         print("❌ Email sending error:", str(e))
#         return jsonify({"error": str(e)}), 500


# # Get mdr data
# @app.route("/get_all_mdr_data", methods=["GET"])
# def get_all_mdr_data():
#     try:
#         mdr_records = MdrMaster.query.all()

#         result = []
#         for mdr in mdr_records:
#             # Fetch corresponding details
#             details = MdrDetails.query.filter_by(mdr_number=mdr.mdr_number).all()
#             for detail in details:
#                 row = {
#                     "mdr_number": mdr.mdr_number,
#                     "invoice_number": mdr.invoice_number,
#                     "invoice_date": mdr.invoice_date.strftime("%Y-%m-%d") if mdr.invoice_date else None,
#                     "mdr_date": mdr.mdr_date.strftime("%Y-%m-%d") if mdr.mdr_date else None,
#                     "vendor_code": mdr.vendor_code,
#                     "vendor_name": mdr.vendor_name,
#                     "transporter_name": mdr.transporter_name,
#                     "vehicle_number": mdr.vehicle_number,
#                     "mdr_raised_as": mdr.mdr_raised_as,
#                     "grr_mtn_sticker_number": mdr.grr_mtn_sticker_number,
#                     "lr_field": mdr.lr_field,
#                     "grr_number": mdr.grr_number,
#                     "prepared_by": mdr.prepared_by,
#                     "mdr_remarks_1": mdr.mdr_remarks_1,
#                     "mdr_remarks_2": mdr.mdr_remarks_2,
#                     "unloading_location": mdr.unloading_location,
#                     "email_id_cc": mdr.email_id_cc,
#                     "email_id_to": mdr.email_id_to,
#                     "email_id_to_logistics": mdr.email_id_to_logistics,
#                     # Detail fields:
#                     "item_code": detail.item_code,
#                     "item_description": detail.item_description,
#                     "item_quantity_actual": detail.item_quantity_actual,
#                     "quantity_as_per_challan": detail.quantity_as_per_challan,
#                     "excess_shortfall_quantity": detail.excess_shortfall_quantity,
#                     "number_of_boxes_lr": detail.number_of_boxes_lr,
#                     "number_of_boxes_lr_recieved": detail.number_of_boxes_lr_recieved,
#                     "remarks_1": detail.remarks_1,
#                 }
#                 result.append(row)

#         return jsonify(result), 200

#     except Exception as e:
#         print("Error fetching flattened MDR data:", e)
#         return jsonify({"error": "Failed to fetch MDR data"}), 500

# # remainder_email
# @app.route('/send_mdr_remainder_email', methods=['POST'])
# def send_remainder_email():
#     try:
#         # ✅ Get data from multipart/form-data
#         email_id_to = request.form.getlist("email_id_to")
#         email_id_to_logistics = request.form.getlist("email_id_to_logistics")
#         email_id_cc = request.form.getlist("email_id_cc")
#         subject = request.form.get("subject", "MDR Reminder")
#         body = request.form.get("body", "")
#         original_message_id = request.form.get("original_message_id")
#         print("id:",original_message_id)

#         print("📩 Received email request:")
#         print("To:", email_id_to)
#         print("To Logistics:", email_id_to_logistics)
#         print("CC:", email_id_cc)
#         print("Subject:", subject)
#         print("Body:", body)

#         # ✅ Clean email lists
#         to_recipients = [email.strip() for email in email_id_to if email.strip()]
#         to_logistics_recipients = [email.strip() for email in email_id_to_logistics if email.strip()]
#         cc_recipients = [email.strip() for email in email_id_cc if email.strip()]

#         # ✅ Validate at least one recipient
#         email_pattern = r"[^@]+@[^@]+\.[^@]+"
#         if not to_recipients or not all(re.match(email_pattern, email) for email in to_recipients):
#             return jsonify({"error": "Valid recipient email(s) required"}), 400

#         # ✅ Compose the email
#         msg = MIMEMultipart()
#         msg["From"] = MAIL_DEFAULT_SENDER
#         msg["To"] = ", ".join(to_recipients)
#         msg["Cc"] = ", ".join(cc_recipients)
#         msg["Subject"] = subject
#         msg.attach(MIMEText(body, "plain"))
        
#         if original_message_id:
#             msg.add_header("In-Reply-To", original_message_id)
#             msg.add_header("References", original_message_id)

#         all_recipients = to_recipients + cc_recipients + to_logistics_recipients

#         # ✅ Send the email
#         with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
#             server.starttls()
#             server.login(USERNAME, PASSWORD)
#             server.sendmail(MAIL_DEFAULT_SENDER, all_recipients, msg.as_string())

#         print("✅ Reminder email sent successfully")
#         return jsonify({"message": "Reminder email sent successfully"}), 200

#     except Exception as e:
#         print("❌ Email sending error:", str(e))
#         return jsonify({"error": str(e)}), 500
    

# # @app.route('/save_closing_mdr', methods=['POST'])
# # def save_closing_mdr():
# #     try:
# #         data = request.json
# #         records = data if isinstance(data, list) else [data]
# #         print("📦 Payload received:", data)
        
# #         for data in records:   
# #          if not data or data.get("status") != "Completed":
# #             return jsonify({"error": "Only completed MDR rows can be saved."}), 400

# #         # Parse completed_date
# #         completed_date = None
# #         if data.get("completed_date"):
# #             completed_date = datetime.strptime(data["completed_date"], "%Y-%m-%d").date()

# #         # Construct ClosingMdr object
# #         closing = ClosingMdr(
# #             mdr_number = data.get("mdr_number"),
# #             mdr_date = data.get("mdr_date"),
# #             invoice_number = data.get("invoice_number"),
# #             invoice_date = data.get("invoice_date"),
# #             grr_number = data.get("grr_mtn_sticker_number") or "NA",
# #             unloading_location = data.get("unloading_location") or "NA",
# #             mdr_raised_as = data.get("mdr_raised_as") or "NA",
# #             transporter_name = data.get("transporter_name") or "NA",
# #             vendor_code = data.get("vendor_code") or "NA",
# #             lr_docket_no = data.get("lr_docket_no") or data.get("lr_field") or "NA",
# #             supplier_name = data.get("supplier_name") or data.get("vendor_name") or "NA",
# #             vehicle_number = data.get("vehicle_number") or "NA",
# #             email_to_buyer = data.get("email_id_to") or "NA",
# #             item_code = data.get("item_code"),
# #             item_description = data.get("item_description") or "NA",
# #             challan_qty = data.get("quantity_as_per_challan") or "0",
# #             actual_qty = data.get("item_quantity_actual") or "0",
# #             shortfall_qty = data.get("shortfall_qty") or data.get("excess_shortfall_quantity") or "0",
# #             boxex_lr = data.get("boxex_lr") or data.get("number_of_boxes_lr") or "0",
# #             boxes_received = data.get("boxes_received") or data.get("number_of_boxes_lr_recieved") or "0",
# #             remarks = data.get("remarks") or data.get("remarks_1") or "NA",
# #             closing_mdr_no = data.get("closing_mdr_no"),
# #             completed_date = completed_date,
# #             age_days = data.get("age_days") or 0,
# #             close_reason = data.get("close_reason"),
# #             document_no = data.get("document_no"),
# #             debit_to = data.get("debit_to") or "NA",
# #             debited_amount = data.get("debited_amount") or "0",
# #             debit_note_no_transporter = data.get("debit_note_no_transporter") or "NA",
# #             series_no_1 = data.get("series_no_1") or "NA",
# #             nfa_1 = data.get("nfa_days_1") or "NA",
# #             series_2 = data.get("series_no_2") or "NA",
# #             nfa_2 = data.get("nfa_days_2") or "NA",
# #             rdn_no = data.get("rdn_no") or "NA",
# #             debit_note_no_supplier = data.get("debit_note_no") or "NA",
# #             credit_note_no_supplier = data.get("credit_note_no") or "NA",
# #             debit_note_no = data.get("debit_note_no") or "NA",
# #             status = "Completed"
# #         )

# #         db.session.add(closing)
# #         db.session.commit()

# #         return jsonify({"message": "✅ Closing MDR saved successfully!"}), 200

# #     except Exception as e:
# #         db.session.rollback()
# #         print("❌ Backend Error:\n", traceback.format_exc())  # full traceback
# #         return jsonify({"error": f"❌ Error saving data: {str(e)}"}), 500

# @app.route('/save_closing_mdr', methods=['POST'])
# def save_closing_mdr():
#     try:
#         data = request.get_json()
#         if not data:
#             return jsonify({"error": "No data received"}), 400

#         records = data if isinstance(data, list) else [data]
#         inserted = []

#         for row in records:
#             if row.get("status") != "Completed":
#                 continue  # Only save completed records

#             mdr_number = row.get("mdr_number")
#             item_code = row.get("item_code")
#             if not mdr_number or not item_code:
#                 continue

#             # Skip if already saved
#             existing = ClosingMdr.query.filter_by(mdr_number=mdr_number, item_code=item_code).first()
#             if existing:
#                 continue

#             # Parse completed_date if string
#             completed_date = None
#             if row.get("completed_date"):
#                 try:
#                     completed_date = datetime.strptime(row["completed_date"], "%Y-%m-%d").date()
#                 except Exception:
#                     pass

#             closing = ClosingMdr(
#                 mdr_number=mdr_number,
#                 mdr_date=row.get("mdr_date"),
#                 invoice_number=row.get("invoice_number"),
#                 invoice_date=row.get("invoice_date"),
#                 grr_number=row.get("grr_mtn_sticker_number") or " ",
#                 unloading_location=row.get("unloading_location") or " ",
#                 mdr_raised_as=row.get("mdr_raised_as") or " ",
#                 transporter_name=row.get("transporter_name") or " ",
#                 vendor_code=row.get("vendor_code") or " ",
#                 lr_docket_no=row.get("lr_docket_no") or row.get("lr_field") or " ",
#                 supplier_name=row.get("supplier_name") or row.get("vendor_name") or " ",
#                 vehicle_number=row.get("vehicle_number") or " ",
#                 email_to_buyer=row.get("email_id_to") or " ",
#                 item_code=item_code,
#                 item_description=row.get("item_description") or " ",
#                 challan_qty=row.get("quantity_as_per_challan") or " ",
#                 actual_qty=row.get("item_quantity_actual") or " ",
#                 shortfall_qty=row.get("shortfall_qty") or row.get("excess_shortfall_quantity") or " ",
#                 boxex_lr=row.get("boxex_lr") or row.get("number_of_boxes_lr") or " ",
#                 boxes_received=row.get("boxes_received") or row.get("number_of_boxes_lr_recieved") or " ",
#                 remarks=row.get("remarks") or row.get("remarks_1") or " ",
#                 closing_mdr_no=row.get("closing_mdr_no"),
#                 completed_date=completed_date,
#                 # age_days=row.get("age_days") or 0,
#                 age_days = row.get("age_days") or 0,   # ✅ ADD THIS LINE
#                 non_working_days=row.get("non_working_days") or 0,
#                 close_reason=row.get("close_reason"),
#                 document_no=row.get("document_no"),
#                 debit_to=row.get("debit_to") or " ",
#                 debited_amount=row.get("debited_amount") or " ",
#                 debit_note_no_transporter=row.get("debit_note_no_transporter") or " ",
#                 series_no_1=row.get("series_no_1") or " ",
#                 nfa_1=row.get("nfa_days_1") or " ",
#                 # series_2=row.get("series_no_2") or "NA",
#                 # nfa_2=row.get("nfa_days_2") or "NA",
#                 rdn_no=row.get("rdn_no") or " ",
#                 debit_note_no_supplier=row.get("debit_note_no_supplier") or row.get("debit_note_no") or " ",
#                 credit_note_no_supplier=row.get("credit_note_no") or " ",
#                 debit_note_no=row.get("debit_note_no") or " ",
#                 status="Completed"
#             )
#             inserted.append(closing)

#         if inserted:
#             db.session.bulk_save_objects(inserted)
#             db.session.commit()

#         return jsonify({"message": f"✅ {len(inserted)} MDR record(s) saved."}), 200

#     except Exception as e:
#         db.session.rollback()
#         import traceback
#         print("❌ Error saving data:\n", traceback.format_exc())
#         return jsonify({"error": f"❌ Server error: {str(e)}"}), 500
    
    
# @app.route('/get_completed_closing_mdrs', methods=['GET'])
# def get_completed_closing_mdrs():
#     try:
#         records = ClosingMdr.query.all()
#         result = [r.to_dict() for r in records]
#         return jsonify(result), 200
#     except Exception as e:
#         return jsonify({"error": f"❌ Error fetching completed MDRs: {str(e)}"}), 500
    

# @app.route("/export_completed_mdr", methods=["GET"])
# def export_mdr_excel():
#     try:
#         from_date = request.args.get("from_date")
#         to_date = request.args.get("to_date")

#         if not from_date or not to_date:
#             return jsonify({"error": "Both from_date and to_date are required."}), 400

#         from_dt = datetime.strptime(from_date, "%Y-%m-%d").date()
#         to_dt = datetime.strptime(to_date, "%Y-%m-%d").date()

#         # Filter completed MDRs within date range
#         records = ClosingMdr.query.filter(
#             ClosingMdr.completed_date >= from_dt,
#             ClosingMdr.completed_date <= to_dt
#         ).all()

#         if not records:
#             return jsonify({"error": "No data found for given date range"}), 404

#         # Convert to DataFrame
#         data = [r.to_dict() for r in records]
#         df = pd.DataFrame(data)

#         # Create Excel file in memory
#         output = BytesIO()
#         df.to_excel(output, index=False)
#         output.seek(0)

#         return send_file(
#             output,
#             download_name=f"MDR_Report_{from_date}_to_{to_date}.xlsx",
#             as_attachment=True,
#             mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
#         )

#     except Exception as e:
#         print("❌ Excel Export Error:", str(e))
#         return jsonify({"error": str(e)}), 500
    

# @app.route("/export_mdr_data", methods=["GET"])
# def export_mdr_data():
#     try:
#         from_date = request.args.get("from_date")
#         to_date = request.args.get("to_date")

#         if not from_date or not to_date:
#             return jsonify({"error": "Both from_date and to_date are required."}), 400

#         from_dt = datetime.strptime(from_date, "%Y-%m-%d").date()
#         to_dt = datetime.strptime(to_date, "%Y-%m-%d").date()

#         # Query MdrMaster with joined mdr_details
#         records = (
#             db.session.query(MdrMaster)
#             .options(joinedload(MdrMaster.mdr_details))  # Correct attribute!
#             .filter(func.DATE(MdrMaster.mdr_date) >= from_dt,
#                     func.DATE(MdrMaster.mdr_date) <= to_dt)
#             .all()
#         )

#         if not records:
#             return jsonify({"error": "No data found for given date range"}), 404

#         # Flatten master and details
#         data = []
#         for master in records:
#             master_dict = master.to_dict()
#             for detail in master.mdr_details:  # Use correct relationship name
#                 if detail.invoice_number == master.invoice_number:
#                     detail_dict = detail.to_dict()
#                     combined = {**master_dict, **detail_dict}
#                     data.append(combined)
#             if not master.mdr_details:
#                 # If no details, add master record alone
#                 data.append(master_dict)

#         # Convert to DataFrame and Excel
#         df = pd.DataFrame(data)
#         output = BytesIO()
#         df.to_excel(output, index=False)
#         output.seek(0)

#         return send_file(
#             output,
#             download_name=f"MDR_Report_{from_date}_to_{to_date}.xlsx",
#             as_attachment=True,
#             mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
#         )

#     except Exception as e:
#         import traceback
#         print("❌ MDR Excel Export Error:", str(e))
#         traceback.print_exc()
#         return jsonify({"error": str(e)}), 500




# # api for getting data of mdr_number for qr code
# @app.route("/mdr/print/<int:mdr_number>", methods=["GET"])
# def get_mdr_by_number(mdr_number):
#     try:
#         print(f"Trying to fetch MDR with number: {mdr_number}")

#         # Convert mdr_number to string for the query
#         mdr = MdrMaster.query.filter_by(mdr_number=str(mdr_number)).first()
#         if not mdr:
#             print("MDR not found")
#             return jsonify({"error": "MDR not found"}), 404

#         details = MdrDetails.query.filter_by(mdr_number=str(mdr_number)).all()

#         result = []
#         for detail in details:
#             row = {
#                 "mdr_number": mdr.mdr_number,
#                 "invoice_number": mdr.invoice_number,
#                 "grr_date": mdr.grr_date.strftime("%Y-%m-%d") if mdr.grr_date else None,
#                 "invoice_date": mdr.invoice_date.strftime("%Y-%m-%d") if mdr.invoice_date else None,
#                 "mdr_date": mdr.mdr_date.strftime("%Y-%m-%d") if mdr.mdr_date else None,
#                 "vendor_code": mdr.vendor_code,
#                 "vendor_name": mdr.vendor_name,
#                 "transporter_name": mdr.transporter_name,
#                 "vehicle_number": mdr.vehicle_number,
#                 "mdr_raised_as": mdr.mdr_raised_as,
#                 "grr_mtn_sticker_number": mdr.grr_mtn_sticker_number,
#                 "lr_field": mdr.lr_field,
#                 "grr_number": mdr.grr_number,
#                 "prepared_by": mdr.prepared_by,
#                 "mdr_remarks_1": mdr.mdr_remarks_1,
#                 "mdr_remarks_2": mdr.mdr_remarks_2,
#                 "unloading_location": mdr.unloading_location,
#                 "email_id_cc": mdr.email_id_cc,
#                 "email_id_to": mdr.email_id_to,
#                 "email_id_to_logistics": mdr.email_id_to_logistics,
#                 "item_code": detail.item_code,
#                 "item_description": detail.item_description,
#                 "item_quantity_actual": detail.item_quantity_actual,
#                 "quantity_as_per_challan": detail.quantity_as_per_challan,
#                 "excess_shortfall_quantity": detail.excess_shortfall_quantity,
#                 "number_of_boxes_lr": detail.number_of_boxes_lr,
#                 "number_of_boxes_lr_recieved": detail.number_of_boxes_lr_recieved,
#                 "remarks_1": detail.remarks_1,
#             }
#             result.append(row)

#         return jsonify(result), 200

#     except Exception as e:
#         import traceback
#         print("❌ Exception occurred:", e)
#         traceback.print_exc()
#         return jsonify({"error": "Failed to fetch MDR data"}), 500


# # API for QR scan view: returns only MDR number and unloading location
# @app.route("/mdr/scan/<int:mdr_number>", methods=["GET"])
# def get_mdr_scan_info(mdr_number):
#     try:
#         print(f"Fetching scan info for MDR number: {mdr_number}")
#         mdr = MdrMaster.query.filter_by(mdr_number=str(mdr_number)).first()

#         if not mdr:
#             return jsonify({"error": "MDR not found"}), 404

#         return jsonify({
#             "mdr_number": mdr.mdr_number,
#             "unloading_location": mdr.unloading_location
#         }), 200

#     except Exception as e:
#         import traceback
#         print("❌ Exception occurred:", e)
#         traceback.print_exc()
#         return jsonify({"error": "Failed to fetch scan data"}), 500


# # /////////
# @app.route("/api/closingMDR", methods=["GET"])
# def get_closing_mdr():
#     try:
#         # mdr_records = MdrMaster.query.all()
#         # all_details = MdrDetails.query.all()
#         mdr_records = MdrMaster.query.order_by(MdrMaster.mdr_number.asc()).all()

#         all_details = MdrDetails.query.order_by(MdrDetails.mdr_number.asc()).all()

#         mdr_remark_map = {}
#         referenced_numbers = set()
 
#         # Step 1: Build map and collect referenced MDR numbers from remarks
#         for detail in all_details:
#             mdr_no = detail.mdr_number
#             remark = detail.remarks_1 or ""
 
#             # Add to remark map
#             mdr_remark_map.setdefault(str(mdr_no), []).append(remark)
 
#             # Extract numbers from remark
#             matches = re.findall(r"\b(\d+)\b", remark)
#             referenced_numbers.update(matches)
 
#         completed_mdrs = set(referenced_numbers)  # Based on references
 
#         for mdr_no, remarks in mdr_remark_map.items():
#             for remark in remarks:
#                 matches = re.findall(r"\b(\d+)\b", remark)
#                 if any(match in referenced_numbers for match in matches):
#                     completed_mdrs.add(mdr_no)
 
#         # Step 3: Assemble response
#         response_data = []
 
#         for master in mdr_records:
#             mdr_no = str(master.mdr_number)
#             details = MdrDetails.query.filter_by(mdr_number=master.mdr_number).all()
 
#             detail_data = [
#                 {
#                     "item_code": d.item_code,
#                     "item_description": d.item_description,
#                     "item_quantity_actual": d.item_quantity_actual,
#                     "quantity_as_per_challan": d.quantity_as_per_challan,
#                     "excess_shortfall_quantity": d.excess_shortfall_quantity,
#                     "number_of_boxes_lr": d.number_of_boxes_lr,
#                     "number_of_boxes_lr_recieved": d.number_of_boxes_lr_recieved,
#                     "remarks_1": d.remarks_1,
#                 }
#                 for d in details
#             ]
 
#             status = "Completed" if mdr_no in completed_mdrs else "Pending"
 
#             response_data.append({
#                 "mdr_number": master.mdr_number,
#                 "invoice_number": master.invoice_number,
#                 "invoice_date": master.invoice_date.strftime("%Y-%m-%d") if master.invoice_date else None,
#                 "mdr_date": master.mdr_date.strftime("%Y-%m-%d") if master.mdr_date else None,
#                 # "sub_mdr_number":master.sub_mdr_number,
#                 "vendor_name": master.vendor_name,
#                 "transporter_name": master.transporter_name,
#                 "vehicle_number": master.vehicle_number,
#                 "vendor_code": master.vendor_code,
#                 "grr_mtn_sticker_number": master.grr_mtn_sticker_number,
#                 "lr_field": master.lr_field,
#                 "unloading_location": master.unloading_location,
#                 "email_id_to": master.email_id_to,
#                 "email_id_to_logistics": master.email_id_to_logistics,
#                 "email_id_cc": master.email_id_cc,
#                 "details": detail_data,
#                 "status": status
#             })
 
#         return jsonify(response_data), 200
 
#     except Exception as e:
#         print("❌ Error in get_closing_mdr:", str(e))
#         return jsonify({"error": "Failed to fetch Closing MDRs"}), 500
    
    

# # @app.route("/export_dock_data", methods=["GET"])
# # def export_dock_data():
# #     try:
# #         from_date = request.args.get("from_date")
# #         to_date = request.args.get("to_date")

# #         if not from_date or not to_date:
# #             return jsonify({"error": "Both from_date and to_date are required."}), 400

# #         from_dt = datetime.strptime(from_date, "%Y-%m-%d").date()
# #         to_dt = datetime.strptime(to_date, "%Y-%m-%d").date()

# #         # Query masters with joined details
# #         records = (
# #             db.session.query(DockInOutMaster)
# #             .join(DockInOutMaster.dock_details)
# #             .options(joinedload(DockInOutMaster.dock_details))
# #             .filter(
# #                 func.DATE(DockInOutDetails.start_time) >= from_dt,
# #                 func.DATE(DockInOutDetails.end_time) <= to_dt
# #             )
# #             .all()
# #         )

# #         if not records:
# #             return jsonify({"error": "No data found for given date range"}), 404

# #         # Build clean combined rows
# #         data = []
# #         for master in records:
# #             for detail in master.dock_details:
# #                 # Explicit filtering inside loop
# #                 if detail.start_time and detail.end_time and \
# #                    from_dt <= detail.start_time.date() <= to_dt and \
# #                    from_dt <= detail.end_time.date() <= to_dt:

# #                     row = {
# #                         "Gate Entry No": master.gate_entry_number,
# #                         "Trip ID": master.trip_id,
# #                         "Vehicle No": master.vehicle_number,
# #                         "Transporter Name": master.transporter_name,
# #                         "GRR Status": master.grr_status,
# #                         "Total Invoices": master.total_invoices,
# #                         "Loading/Unloading": master.loading_unloading,
# #                         "Material Category": master.material_category,
# #                         "Docked Location (Master)": master.docked_location,

# #                         # "Docked Location (Detail)": detail.docked_location,
# #                         "Dock Invoice": detail.dock_location_invoice,
# #                         "Start Time": detail.start_time.strftime("%Y-%m-%d %H:%M:%S") if detail.start_time else None,
# #                         "End Time": detail.end_time.strftime("%Y-%m-%d %H:%M:%S") if detail.end_time else None,
# #                         "Docked Duration": detail.docked_duration,
# #                         "Remarks": detail.remarks,
# #                     }
# #                     data.append(row)

# #         if not data:
# #             return jsonify({"error": "No detail records found for given date range"}), 404

# #         # Export to Excel
# #         df = pd.DataFrame(data)
# #         output = BytesIO()
# #         df.to_excel(output, index=False)
# #         output.seek(0)

# #         return send_file(
# #             output,
# #             download_name=f"Dock_Report_{from_date}_to_{to_date}.xlsx",
# #             as_attachment=True,
# #             mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
# #         )

# #     except Exception as e:
# #         import traceback
# #         print("❌ Dock Excel Export Error:", str(e))
# #         traceback.print_exc()
# #         return jsonify({"error": str(e)}), 500

# @app.route("/export_dock_data", methods=["GET"])
# def export_dock_data():
#     try:
#         from_date = request.args.get("from_date")
#         to_date = request.args.get("to_date")

#         if not from_date or not to_date:
#             return jsonify({"error": "Both from_date and to_date are required."}), 400

#         from_dt = datetime.strptime(from_date, "%Y-%m-%d").date()
#         to_dt = datetime.strptime(to_date, "%Y-%m-%d").date()

#         # Query with correct filter
#         records = (
#             db.session.query(DockInOutMaster)
#             .join(DockInOutMaster.dock_details)
#             .options(joinedload(DockInOutMaster.dock_details))
#             .filter(
#                 or_(
#                     func.DATE(DockInOutDetails.start_time).between(from_dt, to_dt),
#                     func.DATE(DockInOutDetails.end_time).between(from_dt, to_dt)
#                 )
#             )
#             .all()
#         )

#         if not records:
#             return jsonify({"error": "No data found for given date range"}), 404

#         data = []
#         for master in records:
#             for detail in master.dock_details:
#                 if detail.start_time or detail.end_time:
#                     start_date = detail.start_time.date() if detail.start_time else None
#                     end_date = detail.end_time.date() if detail.end_time else None

#                     if (
#                         (start_date and from_dt <= start_date <= to_dt)
#                         or (end_date and from_dt <= end_date <= to_dt)
#                     ):
#                         row = {
#                             "Gate Entry No.": master.gate_entry_number,
#                             "Trip ID": master.trip_id,
#                             "Vehicle No.": master.vehicle_number,
#                             "Transporter": master.transporter_name,
#                             "GRR Status": master.grr_status,
#                             "Total Invoices": master.total_invoices,
#                             "Loading/Unloading": master.loading_unloading,
#                             # "Material Category": detail.material_category or master.material_category,
#                             "Docked Location": detail.docked_location,
#                             "Dock Location Invoice": detail.dock_location_invoice,
#                             "Start Time": detail.start_time.strftime("%Y-%m-%d %H:%M:%S") if detail.start_time else "",
#                             "End Time": detail.end_time.strftime("%Y-%m-%d %H:%M:%S") if detail.end_time else "",
#                             "Docked Duration": detail.docked_duration,
#                             "Remarks": detail.remarks,
#                             # "User Dock-In": detail.user_dockin,
#                             # "User Dock-Out": detail.user_dockout,
#                         }
#                         data.append(row)

#         if not data:
#             return jsonify({"error": "No detail records found for given date range"}), 404

#         df = pd.DataFrame(data)
#         output = BytesIO()
#         df.to_excel(output, index=False)
#         output.seek(0)

#         return send_file(
#             output,
#             download_name=f"Dock_Report_{from_date}_to_{to_date}.xlsx",
#             as_attachment=True,
#             mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
#         )

#     except Exception as e:
#         import traceback
#         traceback.print_exc()
#         return jsonify({"error": str(e)}), 500

 

   
# @app.route("/", methods=["GET"])
# def new():
#     return jsonify({'data': "hello world"})
 
# with app.app_context():
#     db.create_all()
 
# if __name__ == "__main__":
#     with app.app_context():
#         db.create_all()
# app.run(debug=True, host="0.0.0.0", port=5100)  # Remove ssl_context
 
# if __name__ == '__main__':
#     app.run(debug=True)

 
 
 # mdr.py
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from flask_mail import Mail, Message
from fpdf import FPDF
from config import Config
from models import MdrDetails, MdrMaster,ClosingMDRStatus, db,DockInOutMaster, DockInOutDetails
from datetime import datetime
# from pdf_generator import generate_mdr_pdf
import json
from sqlalchemy import func
import re
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.base import MIMEBase
from email import encoders
from sqlalchemy import func
from sqlalchemy.orm import joinedload
import pandas as pd
from io import BytesIO
from email.utils import make_msgid


 
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
USERNAME = "pravesh.kagalbot@kirloskar.com"
PASSWORD = "qmzm kdgr npzn dliu"
MAIL_DEFAULT_SENDER = "pravesh.kagalbot@kirloskar.com"
 
try:
    server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
    server.starttls()
    server.login(USERNAME, PASSWORD)
    print("✅ SMTP connection successful!")
    server.quit()
except Exception as e:
    print("❌ SMTP connection error:", str(e))

app = Flask(__name__)
app.config.from_object(Config)
CORS(app)
db.init_app(app)
mail = Mail(app)

UPLOAD_FOLDER = "mdr/"  # Directory to store images
os.makedirs(UPLOAD_FOLDER, exist_ok=True)  # Ensure folder exists

def parse_date(date_str):
    if date_str:
        try:
            return datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError as e:
            print("Date Parsing Error:", e)
            return None
    return None


@app.route("/submit_mdr", methods=["POST"])
def submit_mdr():
    try:
        
        # Get form fields
        invoice_number = request.form.get("invoice_number")
        mdr_number = request.form.get("mdr_number")
        email_id_to = request.form.get("email_id_to")  # Required
        email_id_to_logistic = request.form.get("email_id_to_logistic")  # Required
        email_id_cc = request.form.get("email_id_cc", "")  # Optional
        print("mdr_number:", mdr_number)
        invoice_date = parse_date(request.form.get("invoice_date", ""))
        mdr_date = parse_date(request.form.get("mdr_date", ""))
        sub_mdr_number = request.form.get('sub_mdr_number')
        print("sub mdr no:",sub_mdr_number)
        # user_mdr=request.form.get("userMdr","")
        # print("user:",user_Mdr)
        print("email to:",email_id_to)
        print("email cc:",email_id_cc)
        print("email logistic:", email_id_to_logistic)
 
        count = 1
        
        # Process uploaded images
        received_images = []
        if "received_images" in request.files:
            files = request.files.getlist("received_images")  # Get multiple files
            count = 1
            for file in files:
                filename = f"{mdr_number}_{count}_{file.filename}"
                file_path = os.path.join(UPLOAD_FOLDER, filename)
                file.save(file_path)  # Save image to server
                received_images.append(file_path)
                count += 1


        print("Received images:", received_images)  # Debugging

        field_limits = {
            "invoice_number": 500,
            "mdr_number": 50,
            "vendor_code": 20,
            "vendor_name": 100,
            "transporter_name": 50,
            "vehicle_number": 50,
            "mdr_raised_as": 50,
            "grr_mtn_sticker_number": 500,
            "lr_field": 100,
            "unloading_location": 100,
            "mdr_remarks_1": 200,
            "email_id_cc": 500,
            "email_id_to": 500,
            "email_id_to_logistic": 500
        }

        if not mdr_number or not invoice_number:
            return jsonify({"error": "mdr number and invoice number required"}), 404
        
        for field, max_length in field_limits.items():
            value = request.form.get(field)
            if value and len(value) > max_length:
                return jsonify({"error": f"{field.replace('_', ' ').title()} exceeds max length of {max_length} characters."}), 400

        vehicle_number = request.form.get("vehicle_number")
        if vehicle_number:
            # Regular expression to ensure 10 alphanumeric characters, with at least one letter and one number
            if not re.match(r"^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z0-9 ]{1,20}$", vehicle_number):
                return jsonify({"error": "Vehicle number must be exactly 10 characters, containing both letters and numbers."}), 400

        existing_mdr = MdrMaster.query.filter_by(mdr_number=mdr_number).first()
        if existing_mdr:
            return jsonify({"error": "MDR Number already exists. Try a different number."}), 400

        received_images = []
        categories = ["invoice", "lr", "other"]
        for category in categories:
            if f"received_images_{category}" in request.files:
                files = request.files.getlist(f"received_images_{category}")
                for file in files:
                    filename = f"{mdr_number}_{category}_{count}_{file.filename}"
                    file_path = os.path.join(UPLOAD_FOLDER, filename)
                    file.save(file_path)
                    received_images.append(file_path)
                    count += 1
        
        # existing_mdr = MdrMaster.query.filter_by(invoice_number=invoice_number).first()
        existing_mdr = MdrMaster.query.filter_by(mdr_number=mdr_number).first()


        if existing_mdr:
            existing_mdr.mdr_number = mdr_number
            existing_mdr.sub_mdr_number = int(sub_mdr_number) if sub_mdr_number else 1
            existing_mdr.invoice_date = invoice_date
            existing_mdr.mdr_date = mdr_date
            existing_mdr.vendor_code = request.form.get("vendor_code")
            existing_mdr.vendor_name = request.form.get("vendor_name")
            existing_mdr.transporter_name = request.form.get("transporter_name")
            existing_mdr.vehicle_number = request.form.get("vehicle_number")
            existing_mdr.mdr_raised_as = request.form.get("mdr_raised_as")
            existing_mdr.grr_mtn_sticker_number = request.form.get("grr_mtn_sticker_number")
            existing_mdr.lr_field = request.form.get("lr_field")
            existing_mdr.grr_number = request.form.get("grr_number")
            existing_mdr.prepared_by = request.form.get("prepared_by")
            existing_mdr.mdr_remarks_1 = request.form.get("mdr_remarks_1")
            existing_mdr.mdr_remarks_2 = request.form.get("mdr_remarks_2")
            existing_mdr.unloading_location = request.form.get("unloading_location")
            # existing_mdr.user_mdr = request.form.get("userMdr")
            existing_mdr.email_id_cc =email_id_cc
            existing_mdr.email_id_to = email_id_to
            existing_mdr.email_id_to_logistic = email_id_to_logistic

        else:
            new_mdr = MdrMaster(
                invoice_number=invoice_number,
                invoice_date=invoice_date,
                mdr_number=mdr_number,
                mdr_date=mdr_date,
                vendor_code=request.form.get("vendor_code"),
                vendor_name=request.form.get("vendor_name"),
                transporter_name=request.form.get("transporter_name"),
                vehicle_number=request.form.get("vehicle_number"),
                mdr_raised_as=request.form.get("mdr_raised_as"),
                grr_mtn_sticker_number=request.form.get("grr_mtn_sticker_number"),
                lr_field=request.form.get("lr_field"),
                grr_number=request.form.get("grr_number"),
                prepared_by=request.form.get("prepared_by"),
                mdr_remarks_1=request.form.get("mdr_remarks_1"),
                mdr_remarks_2=request.form.get("mdr_remarks_2"),
                unloading_location=request.form.get("unloading_location"),
                # user_mdr=request.form.get("userMdr"),
                email_id_cc=email_id_cc,
                email_id_to=email_id_to,
                email_id_to_logistic=email_id_to_logistic,
                sub_mdr_number=int(sub_mdr_number) if sub_mdr_number else 1,
            )
            db.session.add(new_mdr)

        db.session.commit()

        mdr_details_list = request.form.get("tableData", "[]")
        try:
            mdr_details_list = json.loads(mdr_details_list)
        except json.JSONDecodeError:
            return jsonify({"error": "Invalid tableData format"}), 400


        # send_mdr_email(email_id_to, email_id_cc, invoice_number, mdr_number)

        # # Process MDR table data
        # MdrDetails.query.filter_by(mdr_number=mdr_number).delete()

        # mdr_details_list = request.form.get("tableData")
        # if mdr_details_list:
        #     mdr_details_list = json.loads(mdr_details_list)  # Convert JSON string to dictionary
        MdrDetails.query.filter_by(mdr_number=mdr_number).delete()
        for detail in mdr_details_list:
                new_detail = MdrDetails(
                    mdr_number=mdr_number,
                    invoice_number=invoice_number,
                    invoice_date=invoice_date,
                    item_code=detail.get("item_code"),
                    item_description=detail.get("item_description"),
                    item_quantity_actual=detail.get("item_quantity_actual"),
                    quantity_as_per_challan=detail.get("quantity_as_per_challan"),
                    excess_shortfall_quantity=detail.get("excess_shortfall_quantity"),
                    uom=detail.get("uom"),
                    number_of_boxes_lr=detail.get("no_of_boxes"),
                    number_of_boxes_lr_recieved=detail.get("recieved"),
                    mdr_remarks_1=detail.get("mdr_remarks_1"),
                )
                db.session.add(new_detail)

        db.session.commit()

        count = 1

        return jsonify({"message": "MDR record processed successfully", "mdr_number": mdr_number}), 201

    except Exception as e:
        db.session.rollback()
        print("Error:", str(e))
        return jsonify({"error": str(e)}), 500

@app.route('/send_mdr_email', methods=['POST'])
def send_email():
    try:
        # ✅ Get data from multipart/form-data
        email_id_to = request.form.getlist("email_id_to")
        email_id_to_logistic= request.form.getlist("email_id_to_logistic")
        email_id_cc = request.form.getlist("email_id_cc")
        subject = request.form.get("subject", "MDR Intimation For Approval")
        body_text = request.form.get("body", "")
        screenshot_file = request.files.get("screenshot")
        # uploaded_images = request.files.getlist("images")
        uploadedImages = []
        for key in request.files:
             if key.startswith("received_images_"):
                files = request.files.getlist(key)
                uploadedImages.extend(files)

        print(f"All request.files keys: {list(request.files.keys())}")

                

 
        print("📩 Received email request:")
        print("To Buyer:", email_id_to)
        print("To Logistic:", email_id_to_logistic)
        print("CC:", email_id_cc)
        print("Subject:", subject)
        print("Body:", body_text)
 
        # ✅ Clean email lists
        to_recipients = [email.strip() for email in email_id_to if email.strip()]
        toLogistic_recipients = [email.strip() for email in email_id_to_logistic if email.strip()]
        cc_recipients = [email.strip() for email in email_id_cc if email.strip()]
 
        # ✅ Email validation
        email_pattern = r"[^@]+@[^@]+\.[^@]+"
        if not to_recipients or not all(re.match(email_pattern, email) for email in to_recipients):
            return jsonify({"error": "Valid recipient email(s) required"}), 400
       
        if not toLogistic_recipients or not all(re.match(email_pattern, email) for email in toLogistic_recipients):
            return jsonify({"error": "Valid recipient email(s) required"}), 400
 

        invoice_number = re.search(r"Invoice Number:\s*(\d+)", body_text)
        # mdr_number = re.search(r"MDR Number:\s*(\d+)", body_text)
        mdr_number = re.search(r"MDR Number:\s*([\w-]+)", body_text)
        grr_number = re.search(r"GRR Number:\s*([\w-]+)", body_text)
        invoice_date = re.search(r"Invoice Date:\s*(.+)", body_text)
        mdr_date = re.search(r"MDR Date:\s*(.+)", body_text)
        vehicle_number = re.search(r"Vehicle Number:\s*(.+)", body_text)
        supplier_name = re.search(r"Supplier Name:\s*(.+)", body_text)
        table_data_match = re.search(r"Table Data:\s*(\[[\s\S]*?\]|\{[\s\S]*?\})", body_text)

        invoice_number = invoice_number.group(1) if invoice_number else "Unknown"
        mdr_number = mdr_number.group(1) if mdr_number else "Unknown"
        grr_number = grr_number.group(1) if grr_number else "Unknown"
        invoice_date = invoice_date.group(1).strip() if invoice_date else "Unknown"
        mdr_date = mdr_date.group(1).strip() if mdr_date else "Unknown"
        vehicle_number = vehicle_number.group(1).strip() if vehicle_number else "Unknown"
        supplier_name = supplier_name.group(1).strip() if supplier_name else "Unknown"

        if mdr_number != "Unknown":
            try:
                mdr = MdrMaster.query.filter_by(mdr_number=mdr_number).first()
                if mdr:
                    mdr.original_message_id = message_id
                    db.session.commit()
                    print(f"✅ Message-ID saved to DB for {mdr_number}: {message_id}")
            except Exception as e:
                print(f"❌ Failed to save Message-ID for {mdr_number}: {e}")

        #  Merge fields into each row of table
        if table_data_match:
            try:
                table_data_json = table_data_match.group(1)
                table_data = json.loads(table_data_json)
                print("✅ Extracted Table Data:", table_data)

                mdr_fields = {
                    "invoice_number": invoice_number,
                    "mdr_number": mdr_number,
                    "grr_number": grr_number,
                    "invoice_date": invoice_date,
                    "mdr_date": mdr_date,
                    "vehicle_number": vehicle_number,
                    "supplier_name": supplier_name,
                }

                merged_columns = [
                    "srno", "grr_number",  "invoice_number","invoice_date", "mdr_number", "mdr_date",
                    "vehicle_number", "supplier_name",
                    "item_code", "item_description", "quantity_as_per_challan",
                    "item_quantity_actual", "excess_shortfall_quantity",
                    "number_of_boxes_lr", "number_of_boxes_lr_recieved", "mdr_remarks_1"
                ]

                column_headers = {
                    "srno": "Sr. No.",
                    "grr_number": "GRR No.",
                    "invoice_number": "Invoice No.",
                    "invoice_date": "Invoice Date",
                    "mdr_number": "MDR No.",
                    "mdr_date": "MDR Date",
                    "vehicle_number": "Vehicle No.",               
                    "supplier_name": "Supplier",                   
                    "item_code": "Item Code",
                    "item_description": "Description",
                    "quantity_as_per_challan": "Challan Qty",
                    "item_quantity_actual": "Actual Qty",
                    "excess_shortfall_quantity": "Excess/Shortfall Qty",
                    "number_of_boxes_lr": "Boxes (LR)",
                    "number_of_boxes_lr_recieved": "Boxes Received",
                    "mdr_remarks_1": "MDR Remarks"
                }

                # ✅ Build single scrollable table with merged data
                if isinstance(table_data, list) and len(table_data) > 0:
                    headers = "".join(f"<th>{column_headers[col]}</th>" for col in merged_columns)
                    rows = ""
                    for row in table_data:
                        full_row = {**mdr_fields, **row}
                        rows += "<tr>" + "".join(f"<td>{full_row.get(col, '')}</td>" for col in merged_columns) + "</tr>"

                    table_data_html = f"""
                    <div style="max-height: 400px; overflow: auto; border: 1px solid #ccc;">
                      <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
                        <thead>
                          <tr style="background-color: #f2f2f2;">{headers}</tr>
                        </thead>
                        <tbody>{rows}</tbody>
                      </table>
                    </div>
                    """
                else:
                    table_data_html = "<p>No table rows to display</p>"

            except json.JSONDecodeError as e:
                print("❌ JSON Decode Error:", e)
                table_data_html = "<p>Invalid JSON in table data</p>"
        else:
            print("❌ No table data found")
            table_data_html = "<p>No table data</p>"

        # ✅ Compose email body
        subject = f"MDR Intimation For Approval - {mdr_number}"
        body = f"""
        <html>
          <body>
            <p>Dear User,</p>
            <p>Your MDR has been successfully submitted.</p>
            <p><strong>Discrepancy Table:</strong></p>
            {table_data_html}
            <p>Please find the attached MDR preview.</p>
            <p style="background-color: yellow;">
             Note: This is a system-generated email. Please do not reply to this message.
            </p>

          </body>
        </html>
        """

 
        # ✅ Create email
        msg = MIMEMultipart()
        message_id = make_msgid()
        msg["Message-ID"] = message_id

        msg["From"] = MAIL_DEFAULT_SENDER
        msg["To"] = ", ".join(to_recipients + toLogistic_recipients)
        # msg["To Logistic"] = ", ".join(toLogistic_recipients)
        msg["Cc"] = ", ".join(cc_recipients)
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "html"))
 
        # ✅ Attach screenshot
        if screenshot_file:
            screenshot_data = screenshot_file.read()
            image_part = MIMEApplication(screenshot_data, _subtype="png")
            image_part.add_header('Content-Disposition', 'attachment', filename="mdr_screenshot.png")
            msg.attach(image_part)

       
        for idx, image_file in enumerate(uploadedImages):
            image_data = image_file.read()
            image_part = MIMEApplication(image_data)
            image_part.add_header(
                'Content-Disposition',
                'attachment',
                filename=image_file.filename or f"image_{idx + 1}.png"
            )
            msg.attach(image_part)  # ✅ ATTACH inside the loop

 
        all_recipients = to_recipients + cc_recipients + toLogistic_recipients
 
        # ✅ Send the email
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(USERNAME, PASSWORD)
            server.sendmail(MAIL_DEFAULT_SENDER, all_recipients, msg.as_string())
 
        print("✅ Email sent successfully")
        return jsonify({"message": "Email sent successfully","message_id": message_id}), 200
 
    except Exception as e:
        print("❌ Email sending error:", str(e))
        return jsonify({"error": str(e)}), 500



@app.route('/get_latest_submdr_number', methods=['GET'])
def get_latest_submdr_number():
    unloading_location = request.args.get('unloading_location', '').strip().lower()
    print("Fetching for unloading_location:", repr(unloading_location))

    try:
        latest_record = (
            MdrMaster.query
            .filter(
                func.lower(func.trim(MdrMaster.unloading_location)) == unloading_location,
                MdrMaster.sub_mdr_number != None
            )
            .order_by(MdrMaster.sub_mdr_number.desc())
            .first()
        )

        if latest_record:
            print(f"✅ Found: {latest_record.unloading_location} → {latest_record.sub_mdr_number}")
            latest_sub_mdr = latest_record.sub_mdr_number
        else:
            print("⚠️ No record found for unloading_location:", unloading_location)
            latest_sub_mdr = 0

        return jsonify({
            "latest_sub_mdr_number": latest_sub_mdr
        })

    except Exception as e:
        print("❌ Error fetching Sub-MDR No:", e)
        return jsonify({"error": "Server Error"}), 500

# closing mdr backend
@app.route("/closingMDR", methods=["GET"])
def get_closing_mdr():
    try:
        mdr_records = MdrMaster.query.all()
        response_data = []
 
        for master in mdr_records:
            detail_rows = MdrDetails.query.filter_by(mdr_number=master.mdr_number).all()
 
            for d in detail_rows:
                response_data.append({
                    "mdr_number": master.mdr_number,
                    "invoice_number": master.invoice_number,
                    "invoice_date": master.invoice_date.strftime("%Y-%m-%d") if master.invoice_date else None,
                    "mdr_date": master.mdr_date.strftime("%Y-%m-%d") if master.mdr_date else None,
                    "sub_mdr_number": master.sub_mdr_number,
                    "vendor_name": master.vendor_name,
                    "transporter_name": master.transporter_name,
                    "vehicle_number": master.vehicle_number,
                    "vendor_code": master.vendor_code,
                    "grr_mtn_sticker_number": master.grr_mtn_sticker_number,
                    "lr_field": master.lr_field,
                    "unloading_location": master.unloading_location,
                    "email_id_to": master.email_id_to,
                    "email_id_to_logistic": master.email_id_to_logistic,
                    "email_id_cc": master.email_id_cc,
                    "item_code": d.item_code,
                    "item_description": d.item_description,
                    "item_quantity_actual": d.item_quantity_actual,
                    "quantity_as_per_challan": d.quantity_as_per_challan,
                    "excess_shortfall_quantity": d.excess_shortfall_quantity,
                    "number_of_boxes_lr": d.number_of_boxes_lr,
                    "number_of_boxes_lr_recieved": d.number_of_boxes_lr_recieved,
                    "mdr_remarks_1": d.mdr_remarks_1
                })
 
        return jsonify(response_data), 200
        # print(unloading_location);
        print ("hello",flush=True)
        print(mdr_records)
        print(response_data)
 
    except Exception as e:
        print("❌ Error in get_closing_mdr:", str(e))
        return jsonify({"error": "Failed to fetch Closing MDRs"}), 500


# remainder_email
@app.route('/send_mdr_remainder_email', methods=['POST'])
def send_remainder_email():
    try:
        # ✅ Get data from multipart/form-data
        # email_id_to = request.form.getlist("email_id_to")
        email_id_to = request.form.get("email_id_to") or ""
        email_id_to_logistic = request.form.getlist("email_id_to_logistic")
        email_id_cc = request.form.getlist("email_id_cc")
        subject = request.form.get("subject", "MDR Reminder")
        body = request.form.get("body", "")
        original_message_id = request.form.get("original_message_id") 


        print("📩 Received email request:")
        print("To:", email_id_to)
        print("To Logistics:", email_id_to_logistic)
        print("CC:", email_id_cc)
        print("Subject:", subject)
        print("Body:", body)

        # ✅ Clean email lists
        # to_recipients = [email.strip() for email in email_id_to if email.strip()]
        to_recipients = [email.strip() for email in (email_id_to or "").split(",") if email.strip()]
        to_logistic_recipients = [email.strip() for email in email_id_to_logistic if email.strip()]
        cc_recipients = [email.strip() for email in email_id_cc if email.strip()]

        # ✅ Validate at least one recipient
        email_pattern = r"[^@]+@[^@]+\.[^@]+"
        if not to_recipients or not all(re.match(email_pattern, email) for email in to_recipients):
            return jsonify({"error": "Valid recipient email(s) required"}), 400

        # ✅ Compose the email
        msg = MIMEMultipart()
        msg["From"] = MAIL_DEFAULT_SENDER
        msg["To"] = ", ".join(to_recipients)
        msg["Cc"] = ", ".join(cc_recipients)
        msg["Subject"] = subject
        msg.attach(MIMEText(body, 'html', 'utf-8'))

        if original_message_id:
            msg.add_header("In-Reply-To", original_message_id)
            msg.add_header("References", original_message_id)

        all_recipients = to_recipients + cc_recipients + to_logistic_recipients

        # ✅ Send the email
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(USERNAME, PASSWORD)
            server.sendmail(MAIL_DEFAULT_SENDER, all_recipients, msg.as_string())

        print("✅ Reminder email sent successfully")
        return jsonify({"message": "Reminder email sent successfully"}), 200

    except Exception as e:
        print("❌ Email sending error:", str(e))
        return jsonify({"error": str(e)}), 500

# @app.route('/save_closing_mdr_status', methods=['POST'])
# def save_closing_mdr_status():
#     try:
#         # Get JSON data from the request
#         data = request.get_json()

#         for item in data:
#             mdr_number = item.get('mdr_number')
#             if not mdr_number:
#                 continue  # skip if no MDR number

#             # Check if a record with this MDR number already exists
#             # existing_record = ClosingMDRStatus.query.filter_by(mdr_number=mdr_number).first()
#             item_code = item.get('item_code')
#             existing_record = ClosingMDRStatus.query.filter_by(mdr_number=mdr_number, item_code=item_code).first()


#             if existing_record:
#                 # If it exists, update only fields that are part of the model
#                 for field, value in item.items():
#                     if hasattr(existing_record, field):
#                         setattr(existing_record, field, value)
#             else:
#                 # If not exists, create new record using only model-valid fields
#                 new_record = ClosingMDRStatus(**{
#                     key: value for key, value in item.items()
#                     if hasattr(ClosingMDRStatus, key)
#                 })
#                 db.session.add(new_record)

#         # Save changes to the database
#         db.session.commit()

#         return jsonify({"message": "✅ Closing MDR saved successfully"}), 200

#     except Exception as e:
#         print("❌ Error in saving Closing MDR:", e)
#         db.session.rollback()
#         return jsonify({"error": str(e)}), 500


@app.route('/get_completed_closing_mdrs', methods=['GET'])
def get_completed_closing_mdrs():
    try:
        records = ClosingMDRStatus.query.all()
        result = [r.to_dict() for r in records]
        return jsonify(result), 200
    except Exception as e:
        print("❌ Backend error in /get_completed_closing_mdrs:", e)
        return jsonify({"error": f"❌ Error fetching completed MDRs: {str(e)}"}), 500

 
@app.route("/export_mdr_data", methods=["GET"])
def export_mdr_data():
    try:
        from_date = request.args.get("from_date")
        to_date = request.args.get("to_date")
 
        if not from_date or not to_date:
            return jsonify({"error": "Both from_date and to_date are required."}), 400
 
        from_dt = datetime.strptime(from_date, "%Y-%m-%d").date()
        to_dt = datetime.strptime(to_date, "%Y-%m-%d").date()
 
        # Query MdrMaster with joined MdrDetails
        records = (
            db.session.query(MdrMaster)
            .options(joinedload(MdrMaster.mdr_details))
            .filter(MdrMaster.mdr_date >= from_dt, MdrMaster.mdr_date <= to_dt)
            .all()
        )
 
        if not records:
            return jsonify({"error": "No data found for given date range"}), 404
 
        # Flatten master and details
        data = []
        for master in records:
            master_dict = master.to_dict()
            for detail in master.mdr_details:
                detail_dict = detail.to_dict()
                combined = {**master_dict, **detail_dict}
                data.append(combined)
            if not master.mdr_details:
                data.append(master_dict)
 
        # Convert to DataFrame
        df = pd.DataFrame(data)
        # Optional: Replace nested lists (e.g., mdr_details) if needed
        if "mdr_details" in df.columns:
            df = df.drop(columns=["mdr_details"])
 
        # Create Excel file
        output = BytesIO()
        df.to_excel(output, index=False)
        output.seek(0)
 
        return send_file(
            output,
            download_name=f"MDR_Report_{from_date}_to_{to_date}.xlsx",
            as_attachment=True,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )
 
    except Exception as e:
        import traceback
        print("❌ MDR Excel Export Error:", str(e))
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

@app.route('/get_mdr_by_number', methods=['GET'])
def get_mdr_by_number():
    mdr_number = request.args.get('mdr_number')
    if not mdr_number:
        return jsonify({"error": "MDR number is required"}), 400

    try:
        # mdr_master = MdrMaster.query.filter_by(mdr_number=mdr_number).first()
        mdr_master = MdrMaster.query.filter(func.lower(MdrMaster.mdr_number) == mdr_number.lower()).first()
        if not mdr_master:
            return jsonify({"error": "MDR not found"}), 404

        # mdr_details = MdrDetails.query.filter_by(mdr_number=mdr_number).all()
        mdr_details = MdrDetails.query.filter(func.lower(MdrDetails.mdr_number) == mdr_number.lower()).all()

        details_data = [
            {
                "srno": idx + 1,
                "item_code": d.item_code,
                "item_description": d.item_description,
                "item_quantity_actual": d.item_quantity_actual,
                "quantity_as_per_challan": d.quantity_as_per_challan,
                "excess_shortfall_quantity": d.excess_shortfall_quantity,
                "no_of_boxes": d.number_of_boxes_lr,
                "recieved": d.number_of_boxes_lr_recieved,
                "mdr_remarks_1": d.mdr_remarks_1,
                "uom": d.uom,
            }
            for idx, d in enumerate(mdr_details)
        ]

        return jsonify({
            "invoice_number": mdr_master.invoice_number,
            "invoice_date": mdr_master.invoice_date.strftime("%Y-%m-%d") if mdr_master.invoice_date else None,
            "mdr_number": mdr_master.mdr_number,
            "mdr_date": mdr_master.mdr_date.strftime("%Y-%m-%d") if mdr_master.mdr_date else None,
            "vendor_code": mdr_master.vendor_code,
            "vendor_name": mdr_master.vendor_name,
            "transporter_name": mdr_master.transporter_name,
            "vehicle_number": mdr_master.vehicle_number,
            "mdr_raised_as": mdr_master.mdr_raised_as,
            "grr_mtn_sticker_number": mdr_master.grr_mtn_sticker_number,
            "lr_field": mdr_master.lr_field,
            "grr_number": mdr_master.grr_number,
            "prepared_by": mdr_master.prepared_by,
            "mdr_remarks_1": mdr_master.mdr_remarks_1,
            "mdr_remarks_2": mdr_master.mdr_remarks_2,
            "unloading_location": mdr_master.unloading_location,
            "email_id_cc": mdr_master.email_id_cc,
            "email_id_to": mdr_master.email_id_to,
            "email_id_to_logistic": mdr_master.email_id_to_logistic,
            "sub_mdr_number": mdr_master.sub_mdr_number,
            "tableData": details_data,
            "received_images": {"invoice": [], "lr": [], "other": []},
        }), 200

    except Exception as e:
        print("Error in get_mdr_by_number:", e)
        return jsonify({"error": "Internal server error"}), 500

@app.route("/mdr/scan/<int:mdr_number>", methods=["GET"])
def get_mdr_scan_info(mdr_number):
    try:
        print(f"Fetching scan info for MDR number: {mdr_number}")
        mdr = MdrMaster.query.filter_by(mdr_number=str(mdr_number)).first()
 
        if not mdr:
            return jsonify({"error": "MDR not found"}), 404
 
        return jsonify({
            "mdr_number": mdr.mdr_number,
            "unloading_location": mdr.unloading_location
        }), 200
 
    except Exception as e:
        import traceback
        print("❌ Exception occurred:", e)
        traceback.print_exc()
        return jsonify({"error": "Failed to fetch scan data"}), 500
    
@app.route("/get_message_id_by_mdr", methods=["GET"])
def get_message_id_by_mdr():
    mdr_number = request.args.get("mdr_number")
    if not mdr_number:
        return jsonify({"error": "mdr_number required"}), 400
    mdr = MdrMaster.query.filter_by(mdr_number=mdr_number).first()
    if mdr and mdr.original_message_id:
        return jsonify({"message_id": mdr.original_message_id}), 200
    return jsonify({"error": "Message ID not found"}), 404


@app.route("/export_completed_mdr", methods=["GET"])
def export_mdr_excel():
    try:
        from_date = request.args.get("from_date")
        to_date = request.args.get("to_date")

        if not from_date or not to_date:
            return jsonify({"error": "Both from_date and to_date are required."}), 400

        from_dt = datetime.strptime(from_date, "%Y-%m-%d").date()
        to_dt = datetime.strptime(to_date, "%Y-%m-%d").date()

        # Filter completed MDRs within date range
        records = ClosingMDRStatus.query.filter(
            ClosingMDRStatus.completed_date >= from_dt,
            ClosingMDRStatus.completed_date <= to_dt
        ).all()

        if not records:
            return jsonify({"error": "No data found for given date range"}), 404

        # Convert to DataFrame
        data = [r.to_dict() for r in records]
        df = pd.DataFrame(data)

        # Create Excel file in memory
        output = BytesIO()
        df.to_excel(output, index=False)
        output.seek(0)

        return send_file(
            output,
            download_name=f"MDR_Report_{from_date}_to_{to_date}.xlsx",
            as_attachment=True,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

    except Exception as e:
        print("❌ Excel Export Error:", str(e))
        return jsonify({"error": str(e)}), 500
    
@app.route("/get_all_mdr_data", methods=["GET"])
def get_all_mdr_data():
    try:
        mdr_records = MdrMaster.query.all()

        result = []
        for mdr in mdr_records:
            # Fetch corresponding details
            details = MdrDetails.query.filter_by(mdr_number=mdr.mdr_number).all()
            for detail in details:
                row = {
                    "mdr_number": mdr.mdr_number,
                    "invoice_number": mdr.invoice_number,
                    "invoice_date": mdr.invoice_date.strftime("%Y-%m-%d") if mdr.invoice_date else None,
                    "mdr_date": mdr.mdr_date.strftime("%Y-%m-%d") if mdr.mdr_date else None,
                    "vendor_code": mdr.vendor_code,
                    "vendor_name": mdr.vendor_name,
                    "transporter_name": mdr.transporter_name,
                    "vehicle_number": mdr.vehicle_number,
                    "mdr_raised_as": mdr.mdr_raised_as,
                    "grr_mtn_sticker_number": mdr.grr_mtn_sticker_number,
                    "lr_field": mdr.lr_field,
                    "grr_number": mdr.grr_number,
                    "prepared_by": mdr.prepared_by,
                    "mdr_remarks_1": mdr.mdr_remarks_1,
                    "mdr_remarks_2": mdr.mdr_remarks_2,
                    "unloading_location": mdr.unloading_location,
                    "email_id_cc": mdr.email_id_cc,
                    "email_id_to": mdr.email_id_to,
                    "email_id_to_logistics": mdr.email_id_to_logistic,
                    # Detail fields:
                    "item_code": detail.item_code,
                    "item_description": detail.item_description,
                    "item_quantity_actual": detail.item_quantity_actual,
                    "quantity_as_per_challan": detail.quantity_as_per_challan,
                    "excess_shortfall_quantity": detail.excess_shortfall_quantity,
                    "number_of_boxes_lr": detail.number_of_boxes_lr,
                    "number_of_boxes_lr_recieved": detail.number_of_boxes_lr_recieved,
                    "remarks_1": detail.mdr_remarks_1,
                }
                result.append(row)

        return jsonify(result), 200

    except Exception as e:
        print("Error fetching flattened MDR data:", e)
        return jsonify({"error": "Failed to fetch MDR data"}), 500

# @app.route('/save_closing_mdr', methods=['POST'])
# def save_closing_mdr():
#     try:
#         data = request.get_json()
#         if not data:
#             return jsonify({"error": "No data received"}), 400

#         records = data if isinstance(data, list) else [data]
#         inserted = []

#         for row in records:
#             if row.get("status") != "Completed":
#                 continue  # Only save completed records

#             mdr_number = row.get("mdr_number")
#             item_code = row.get("item_code")
#             if not mdr_number or not item_code:
#                 continue

#             # Skip if already saved
#             existing = ClosingMDRStatus.query.filter_by(mdr_number=mdr_number, item_code=item_code).first()
#             if existing:
#                 continue

#             # Parse completed_date if string
#             completed_date = None
#             if row.get("completed_date"):
#                 try:
#                     completed_date = datetime.strptime(row["completed_date"], "%Y-%m-%d").date()
#                 except Exception:
#                     pass

#             closing = ClosingMDRStatus(
#                 mdr_number=mdr_number,
#                 mdr_date=row.get("mdr_date"),
#                 invoice_number=row.get("invoice_number"),
#                 invoice_date=row.get("invoice_date"),
#                 grr_number=row.get("grr_mtn_sticker_number") or " ",
#                 unloading_location=row.get("unloading_location") or " ",
#                 mdr_raised_as=row.get("mdr_raised_as") or " ",
#                 transporter_name=row.get("transporter_name") or " ",
#                 vendor_code=row.get("vendor_code") or " ",
#                 lr_docket_no=row.get("lr_docket_no") or row.get("lr_field") or " ",
#                 supplier_name=row.get("supplier_name") or row.get("vendor_name") or " ",
#                 vehicle_number=row.get("vehicle_number") or " ",
#                 email_to_buyer=row.get("email_id_to") or " ",
#                 item_code=item_code,
#                 item_description=row.get("item_description") or " ",
#                 challan_qty=row.get("quantity_as_per_challan") or " ",
#                 actual_qty=row.get("item_quantity_actual") or " ",
#                 shortfall_qty=row.get("shortfall_qty") or row.get("excess_shortfall_quantity") or " ",
#                 boxex_lr=row.get("boxex_lr") or row.get("number_of_boxes_lr") or " ",
#                 boxes_received=row.get("boxes_received") or row.get("number_of_boxes_lr_recieved") or " ",
#                 remarks=row.get("remarks") or row.get("remarks_1") or " ",
#                 closing_mdr_no=row.get("closing_mdr_no"),
#                 completed_date=completed_date,
#                 # age_days=row.get("age_days") or 0,
#                 age_days = row.get("age_days") or 0,   # ✅ ADD THIS LINE
#                 non_working_days=row.get("non_working_days") or 0,
#                 close_reason=row.get("close_reason"),
#                 document_no=row.get("document_no"),
#                 debit_to=row.get("debit_to") or " ",
#                 debited_amount=row.get("debited_amount") or " ",
#                 debit_note_no_transporter=row.get("debit_note_no_transporter") or " ",
#                 series_no_1=row.get("series_no_1") or " ",
#                 nfa_1=row.get("nfa_days_1") or " ",
#                 # series_2=row.get("series_no_2") or "NA",
#                 # nfa_2=row.get("nfa_days_2") or "NA",
#                 rdn_no=row.get("rdn_no") or " ",
#                 debit_note_no_supplier=row.get("debit_note_no_supplier") or row.get("debit_note_no") or " ",
#                 credit_note_no_supplier=row.get("credit_note_no") or " ",
#                 debit_note_no=row.get("debit_note_no") or " ",
#                 status="Completed"
#             )
#             inserted.append(closing)

#         if inserted:
#             db.session.bulk_save_objects(inserted)
#             db.session.commit()

#         return jsonify({"message": f"✅ {len(inserted)} MDR record(s) saved."}), 200

#     except Exception as e:
#         db.session.rollback()
#         import traceback
#         print("❌ Error saving data:\n", traceback.format_exc())
#         return jsonify({"error": f"❌ Server error: {str(e)}"}), 500

from datetime import datetime
from flask import request, jsonify

@app.route('/save_closing_mdr', methods=['POST'])
def save_closing_mdr():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data received"}), 400

        records = data if isinstance(data, list) else [data]
        saved_count = 0

        for row in records:

            # Save ONLY completed MDRs
            if row.get("status") != "Completed":
                continue

            mdr_number = row.get("mdr_number")
            item_code = row.get("item_code")

            if not mdr_number or not item_code:
                continue

            # Parse completed_date safely
            completed_date = None
            if row.get("completed_date"):
                try:
                    completed_date = datetime.fromisoformat(
                        row["completed_date"].split("T")[0]
                    ).date()
                except Exception:
                    completed_date = None

            existing = ClosingMDRStatus.query.filter_by(
                mdr_number=mdr_number,
                item_code=item_code
            ).first()

            # ---------------- UPDATE ----------------
            if existing:
                existing.invoice_number = row.get("invoice_number")
                existing.invoice_date = row.get("invoice_date")
                existing.vendor_code = row.get("vendor_code")
                existing.vendor_name = row.get("vendor_name")
                existing.transporter_name = row.get("transporter_name")
                existing.vehicle_number = row.get("vehicle_number")
                existing.mdr_date = row.get("mdr_date")
                existing.grr_mtn_sticker_number = row.get("grr_mtn_sticker_number")
                existing.lr_field = row.get("lr_field")
                existing.unloading_location = row.get("unloading_location")
                existing.email_id_to = row.get("email_id_to")
                existing.email_id_cc = row.get("email_id_cc")
                existing.email_id_to_logistic = row.get("email_id_to_logistics")
                existing.item_description = row.get("item_description")
                existing.item_quantity_actual = row.get("item_quantity_actual")
                existing.quantity_as_per_challan = row.get("quantity_as_per_challan")
                existing.excess_shortfall_quantity = row.get("excess_shortfall_quantity")
                existing.number_of_boxes_lr = row.get("number_of_boxes_lr")
                existing.number_of_boxes_lr_recieved = row.get("number_of_boxes_lr_recieved")
                existing.mdr_remarks_1 = row.get("remarks_1")
                existing.closing_mdr_no = row.get("closing_mdr_no")
                existing.completed_date = completed_date
                existing.age = int(row.get("age_days", existing.age or 0))
                existing.close_reason = (
                    row.get("other_close_reason")
                    if row.get("close_reason") == "Other"
                    else row.get("close_reason")
                )
                existing.document_no = row.get("document_no")
                existing.debit_to = row.get("debit_to")
                existing.debited_amount = row.get("debited_amount")
                existing.debit_note_no_supplier = row.get("debit_note_no_supplier")
                existing.series_no_1 = row.get("series_no_1")
                existing.nfa_days_1 = row.get("nfa_days_1")
                existing.rdn_no = row.get("rdn_no")
                existing.debit_note_no_transporter = row.get("debit_note_no_transporter")
                existing.credit_note_no = row.get("credit_note_no")
                existing.debit_note = row.get("debit_note")
                existing.status = "Completed"

                saved_count += 1
                continue

            # ---------------- INSERT ----------------
            closing = ClosingMDRStatus(
                mdr_number=mdr_number,
                item_code=item_code,
                invoice_number=row.get("invoice_number"),
                invoice_date=row.get("invoice_date"),
                vendor_code=row.get("vendor_code"),
                vendor_name=row.get("vendor_name"),
                transporter_name=row.get("transporter_name"),
                vehicle_number=row.get("vehicle_number"),
                mdr_date=row.get("mdr_date"),
                grr_mtn_sticker_number=row.get("grr_mtn_sticker_number"),
                lr_field=row.get("lr_field"),
                unloading_location=row.get("unloading_location"),
                email_id_to=row.get("email_id_to"),
                email_id_cc=row.get("email_id_cc"),
                email_id_to_logistic=row.get("email_id_to_logistics"),
                item_description=row.get("item_description"),
                item_quantity_actual=row.get("item_quantity_actual"),
                quantity_as_per_challan=row.get("quantity_as_per_challan"),
                excess_shortfall_quantity=row.get("excess_shortfall_quantity"),
                number_of_boxes_lr=row.get("number_of_boxes_lr"),
                number_of_boxes_lr_recieved=row.get("number_of_boxes_lr_recieved"),
                mdr_remarks_1=row.get("remarks_1"),
                closing_mdr_no=row.get("closing_mdr_no"),
                completed_date=completed_date,
                age=int(row.get("age_days", 0)),
                close_reason=row.get("close_reason"),
                document_no=row.get("document_no"),
                debit_to=row.get("debit_to"),
                debited_amount=row.get("debited_amount"),
                debit_note_no_supplier=row.get("debit_note_no_supplier"),
                series_no_1=row.get("series_no_1"),
                nfa_days_1=row.get("nfa_days_1"),
                rdn_no=row.get("rdn_no"),
                debit_note_no_transporter=row.get("debit_note_no_transporter"),
                credit_note_no=row.get("credit_note_no"),
                debit_note=row.get("debit_note"),
                status="Completed"
            )

            db.session.add(closing)
            saved_count += 1

        db.session.commit()

        return jsonify({"message": f"✅ {saved_count} MDR record(s) saved."}), 200

    except Exception as e:
        db.session.rollback()
        import traceback
        print("❌ Error saving Closing MDR:\n", traceback.format_exc())
        return jsonify({"error": str(e)}), 500

    
@app.route("/", methods=["GET"])
def new():
    return jsonify({'data': "hello world"})

with app.app_context():
    db.create_all()

# if __name__ == "__main__":
#     with app.app_context():
#         db.create_all()
#     app.run(debug=True, host="0.0.0.0", port=5200, ssl_context=("certificate.crt", "private.key")) #port 5200
# ===================== Vehicle Standard Master API =====================

# ------------------------Reports-----------------
from models import VehicleStandardMaster

@app.route('/api/vehicle_standard', methods=['GET'])
def get_vehicle_standard():
    try:
        records = VehicleStandardMaster.query.all()
        data = [
            {
                "id": r.id,
                "plant_location": r.plant_location,
                "status": r.status,
                "vehicle_type": r.vehicle_type,
                "unload": r.unload,
                "category": r.category,
                "standard_time_minutes": r.standard_time_minutes,
                "standard_weight": r.standard_weight,
            }
            for r in records
        ]
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/save_vehicle_standard', methods=['POST'])
def save_vehicle_standard():
    try:
        records = request.get_json()

        if not isinstance(records, list):
            return jsonify({"error": "Expected a list of records"}), 400

        for item in records:
            record_id = item.get("id")

            if record_id:
                record = VehicleStandardMaster.query.get(record_id)
                if record:
                    # Update existing record
                    record.plant_location = item.get("plant_location")
                    record.status = item.get("status")
                    record.vehicle_type = item.get("vehicle_type")
                    record.unload = item.get("unload")
                    record.category = item.get("category")
                    record.standard_time_minutes = item.get("standard_time_minutes")
                    record.standard_weight = item.get("standard_weight")
                else:
                    # ID provided but not found → create new
                    new_rec = VehicleStandardMaster(
                        plant_location=item.get("plant_location"),
                        status=item.get("status"),
                        vehicle_type=item.get("vehicle_type"),
                        unload=item.get("unload"),
                        category=item.get("category"),
                        standard_time_minutes=item.get("standard_time_minutes"),
                        standard_weight=item.get("standard_weight")
                    )
                    db.session.add(new_rec)
            else:
                # New record (no ID)
                new_rec = VehicleStandardMaster(
                    plant_location=item.get("plant_location"),
                    status=item.get("status"),
                    vehicle_type=item.get("vehicle_type"),
                    unload=item.get("unload"),
                    category=item.get("category"),
                    standard_time_minutes=item.get("standard_time_minutes"),
                    standard_weight=item.get("standard_weight")
                )
                db.session.add(new_rec)

        db.session.commit()
        return jsonify({"message": "Vehicle Standard data saved successfully!"}), 200

    except Exception as e:
        db.session.rollback()
        print("❌ Backend Error:", e)  # <— helpful debug line
        return jsonify({"error": str(e)}), 500


@app.route("/get_all_dock_data", methods=["GET"])
def get_all_dock_data():
    try:
        records = db.session.query(DockInOutMaster).all()

        final_data = []
        for master in records:
            # fetch matching rows from details table
            details = DockInOutDetails.query.filter_by(gate_entry_number=master.gate_entry_number).all()

            master_dict = master.to_dict()

            detail_rows = [d.to_dict() for d in details]

            final_data.append({
                "master": master_dict,
                "details": detail_rows
            })

        return jsonify(final_data), 200

    except Exception as e:
        print("❌ Error:", str(e))
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
app.run(debug=True, host="0.0.0.0", port=5100)  # Remove ssl_context
 
if __name__ == '__main__':
    app.run(debug=True)


