import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
// import { backend_link } from "./backend_link";
// import "./SearchPage.css";

const SearchResultsPage = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const gateEntryNumber = state?.gateEntryNumber;

  useEffect(() => {
    const fetchData = async () => {
      if (!gateEntryNumber) return;
      setLoading(true);
      setError(null);
      try {
        const response = await axios.get(
          backend_link + "/search_gate_entry_invoices",
          { params: { gate_entry_number: gateEntryNumber } }
        );
        console.log(response.data)
        setData(response.data);
      } catch (err) {
        console.error(err);
        setError("Error fetching data");
      }
      setLoading(false);
    };

    fetchData();
  }, [gateEntryNumber]);

  const handleCreateGRR = (shipmentNo, invoiceNo, invoiceDate) => {
    navigate("/grr", {
      state: {
        shipmentNo,
        invoiceNo,
        invoiceDate,
        gateEntryNumber,
      },
    });
  };

  return (
    <div className="search-container">
      <h2 className="search-title">Search Results</h2>

      {loading && <p className="search-loading">Loading...</p>}
      {error && <p className="search-error">{error}</p>}

      {data.length > 0 ? (
        <table className="search-table">
          <thead>
            <tr>
              <th>Shipment No</th>
              <th>Invoice No</th>
              <th>Invoice Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {data.map((entry, index) => (
              <tr key={index}>
                <td>{entry.shipment_number}</td>
                <td>{entry.invoice_number}</td>
                <td>{entry.invoice_date}</td>
                <td>
                  <button
                    className="search-create-grr"
                    onClick={() =>
                      handleCreateGRR(
                        entry.shipment_number,
                        entry.invoice_number,
                        entry.invoice_date
                      )
                    }
                  >
                    Create GRR
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        !loading && <p>No results found.</p>
      )}
    </div>
  );
};

export default SearchResultsPage;
