import React, { useEffect, useState } from "react";
import QRCode from "qrcode";
import { Card, Typography, Spin } from "antd";

const { Paragraph } = Typography;

const QRDisplay = ({ url }) => {
  const [qrImageUrl, setQrImageUrl] = useState("");

  useEffect(() => {
    QRCode.toDataURL(url)
      .then(setQrImageUrl)
      .catch(console.error);
  }, [url]);

  return (
    <Card title="Scan This QR Code" style={{ width: 320, textAlign: "center", margin: "auto" }}>
      {qrImageUrl ? (
        <img src={qrImageUrl} alt="QR Code" style={{ width: 200, height: 200 }} />
      ) : (
        <Spin />
      )}
      <Paragraph copyable style={{ marginTop: 16 }}>{url}</Paragraph>
    </Card>
  );
};

export default QRDisplay;
