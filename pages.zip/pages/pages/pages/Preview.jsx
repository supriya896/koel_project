import React, { useState, useRef, useEffect } from 'react'
import { useReactToPrint } from "react-to-print";
import { useLocation, useNavigate } from 'react-router'
import Navbar from '../components/Navbar'
import { Button, ConfigProvider, Divider, Form, Input, InputNumber, Modal, Select, Space } from 'antd'
import { ArrowRightOutlined, CheckOutlined, CloseOutlined, PrinterOutlined, RobotOutlined } from '@ant-design/icons';
import { RuleObject } from "antd/lib/form";
import './preview.css';

const Preview = () => {
    const location = useLocation()
    const { data } = location.state


    const Navigate = useNavigate()
    const contentRef = useRef(null); // Correctly define the reference for printing.

    const reactToPrintFn = useReactToPrint({ contentRef });
    useEffect(() => {
        localStorage.removeItem("gate-form")
        localStorage.removeItem("vehicleNumber")
    }, [])

    return (
        <>
            <Navbar />
            <div className='w-[90%] flex justify-end mt-10'>
                <Button type="primary" onClick={reactToPrintFn} className='h-10 !bg-[#c47c5c] font-semibold' icon={<PrinterOutlined />} iconPosition='end'>
                    Print
                </Button>
            </div>

            <div ref={contentRef} className='min-h-[80vh] w-[85%] bg-gray-100 mx-auto rounded-xl mt-5 px-10 pt-10 pb-2 mb-10'>
                <Form
                    name="basic"
                    initialValues={data}
                    disabled={true}
                    autoComplete="off"
                    labelCol={{
                        span: 24,
                    }}
                    wrapperCol={{
                        span: 44,
                    }}
                >
                    <div className='w-full flex gap-10'>
                        <Form.Item label="Vehicle Number" name="vehicleNumber" labelCol={{ span: 24 }}>
                            <Input value={data.vehicleNumber} disabled className='h-10' />
                        </Form.Item>
                        <Form.Item label="Vechile Status" labelCol={{ span: 24 }} name="vehicleStatus" rules={[{ required: true, message: 'Please select a value!' }]}>
                            <Select
                                className='h-10 !w-[255px] !border-none'
                                placeholder="Choose"
                                value={data.vehicleStatus}
                                options={[
                                    {
                                        value: 'loadingofmaterials',
                                        label: 'Loading of materials',
                                    },
                                    {
                                        value: 'unloadingofmaterials',
                                        label: 'Unloading of materials',
                                    },
                                ]}
                            />
                        </Form.Item>
                    </div>
                    <div className='w-full flex gap-10'>
                        <Form.Item className='w-[30%]' label="Gate Entry Number" name="gateEntryNumber" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' value={data.gateEntryNumber} />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="Gate Entry Status" name="gateEntryStatus" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' value={data.gateEntryStatus} />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="In Date & Time" name="inDate" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' value={data.inDate} />
                        </Form.Item>
                    </div>
                    <div className='w-full flex gap-10'>
                        <Form.Item className='w-[30%]' label="Transporter Name" name="transporterName" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' value={data.transporterName} />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="Vehicle Type" name="vehicleType" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' value={data.vehicleType} />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="PUC Status" name="pucStatus" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' value={data.pucStatus} />
                        </Form.Item>
                    </div>
                    <div className='w-full flex gap-10'>
                        <Form.Item className='w-[30%]' label="LR Number" name="lrNumber" labelCol={{ span: 24 }} rules={[{ required: false, message: 'Please enter a value!' }]}>
                            <Input className='h-10' value={data.lrNumber} />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="LR Date" name="lrDate" labelCol={{ span: 24 }} rules={[{ required: false, message: 'Please enter a value!' }]}>
                            <Input className='h-10' value={data.lrDate} />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="Driver Name" name="driverName" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' value={data.driverName} />
                        </Form.Item>
                    </div>
                    <div className='w-full flex gap-10'>
                        <Form.Item className='w-[30%]' label="Driver Mobile Number" name="driverNumber" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Phone number needs to be 10 digits!' }]}>
                            <Input className='!h-10' maxLength={10} value={data.driverNumber} />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="License Number" name="licenseNumber" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' value={data.licenseNumber} />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="No of Persons" name="noOfPersons" labelCol={{ span: 24 }} rules={[{ required: false, message: 'Please enter a value!' }]}>
                            <Input className='h-10' value={data.noOfPersons} />
                        </Form.Item>
                    </div>
                    <div className='w-full flex gap-10'>
                        <Form.Item className='w-[30%]' label="Number of Invoices" name="invoices" labelCol={{ span: 24 }} rules={[{ required: false, message: 'Please enter a value!' }]}>
                            <Input className='h-10' value={data.invoices} />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="Remarks" name="remarks" labelCol={{ span: 24 }} rules={[{ required: false, message: 'Please enter a value!' }]}>
                            <Input className='h-10' value={data.remarks} />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="Out Date" name="outDate" labelCol={{ span: 24 }} rules={[{ required: false, message: 'Please enter a value!' }]}>
                            <Input className='h-10' value={data.outDate} />
                        </Form.Item>
                    </div>
                    <Divider />
                </Form>

            </div>


        </>
    )
}

export default Preview