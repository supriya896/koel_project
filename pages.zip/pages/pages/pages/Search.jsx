import React, { useEffect, useState } from "react";
import { Button, Input, Select, List } from "antd";
import { SearchOutlined, SyncOutlined } from "@ant-design/icons";
import { useNavigate } from "react-router";

const Search = () => {
    const [loading, setLoading] = useState(false);
    const [query, setQuery] = useState("");
    const [gate, setGate] = useState("gatein");
    const [suggestions, setSuggestions] = useState([]);
    const Navigate = useNavigate();


    // Example list of vehicle numbers
    const vehicleNumbers = [
        "1234",
        "4567",
        "7890",
        "4568",
        "8901",
        "2345",
        "4123",
    ];

    const handleSubmit = () => {
        setLoading(true);
        setTimeout(() => {
            setLoading(false);
            localStorage.setItem("vehicleNumber", query);
            setQuery("");
            setSuggestions([]); // Clear suggestions
            Navigate("/gate-entry");
        }, 2000);
    };

    const handleInputChange = (e) => {
        const input = e.target.value;
        setQuery(input);

        if (input) {
            const filteredSuggestions = vehicleNumbers
                .filter((num) => num.includes(input)) // Matches input
                .sort((a, b) => {
                    // Prioritize starting matches
                    if (a.startsWith(input) && !b.startsWith(input)) return -1;
                    if (!a.startsWith(input) && b.startsWith(input)) return 1;
                    return 0;
                });

            setSuggestions(filteredSuggestions);
        } else {
            setSuggestions([]);
        }
    };

    const handleSuggestionClick = (suggestion) => {
        setQuery(suggestion);
        setSuggestions([]); // Clear suggestions on click
    };

    return (
        <div className="flex flex-col justify-center items-center min-h-screen gap-10">
            <img src="/logo.jpg" className="h-24" alt="Logo" />
            <div className="bg-[#FAFAFA] flex flex-col lg:flex-row justify-center items-center py-20 px-5 md:px-10 lg:px-16 rounded-xl gap-4 w-[80%]">
                <div className="relative w-full lg:w-[50%]">
                    <Input
                        size="large"
                        placeholder="Search vehicle number"
                        prefix={<SearchOutlined />}
                        className="h-16 w-full border-none shadow"
                        value={query}
                        onChange={handleInputChange}
                    />
                    {suggestions.length > 0 && (
                        <div className="absolute top-20 bg-white rounded-lg shadow-lg w-full max-h-48 overflow-y-auto z-10">
                            <List
                                dataSource={suggestions}
                                renderItem={(item) => (
                                    <List.Item
                                        className="cursor-pointer hover:bg-gray-100 !px-4 py-2"
                                        onClick={() => handleSuggestionClick(item)}
                                    >
                                        {item}
                                    </List.Item>
                                )}
                            />
                        </div>
                    )}
                </div>
                <Select
                    defaultValue={gate}
                    className="h-16 w-full lg:w-[15%] !border-none"
                    onChange={(value) => setGate(value)}
                    options={[
                        {
                            value: "gatein",
                            label: "Gate In",
                        },
                        {
                            value: "gateout",
                            label: "Gate Out",
                        },
                    ]}
                />
                <Button
                    color="default"
                    variant="solid"
                    className="h-16 w-full lg:w-[15%] flex items-center justify-center !bg-[#1d998b] font-semibold"
                    onClick={handleSubmit}
                    loading={
                        loading && {
                            icon: <SyncOutlined spin />,
                        }
                    }
                    iconPosition="end"
                >
                    Search
                </Button>
            </div>
        </div>
    );
};

export default Search;
