
// src/pages/ClosingMDR.jsx
import React, { useEffect, useState, useMemo } from 'react'; // Added useMemo
import { useLocation, useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { message } from 'antd';
import { DatePicker, Table, Typography, Tag, Input, Space, Select, Button, Spin, Tooltip } from 'antd'; // Added Tooltip
import dayjs from 'dayjs';
// Import the helpers (adjust path as needed)
import { calculateMdrCompletionStatuses, parseDiscrepancy } from '../utils/mdrUtils';

const { Title, Text } = Typography; // Added Text

const getDiscrepancyStatusForFilter = (record) => {
  let hasShortage = false;
  let hasExcess = false;
  let hasQualitative = false;

  if (record.details && Array.isArray(record.details)) {
    record.details.forEach((item) => {
      const discrepancy = parseDiscrepancy(item.excess_shortfall_quantity);
      if (discrepancy.type === 'shortage') hasShortage = true;
      else if (discrepancy.type === 'excess') hasExcess = true;
      else if (discrepancy.type === 'qualitative') hasQualitative = true;

      if (!hasQualitative) { // Avoid redundant checks if already found
          if (item.mdr_remarks_1 && item.mdr_remarks_1.toLowerCase().includes('quality')) {
              hasQualitative = true;
          } else if (item.remarks && item.remarks.toLowerCase().includes('quality')) {
              hasQualitative = true;
          }
      }
    });
  }
  return { hasShortage, hasExcess, hasQualitative };
};

const ClosingMDR = () => {
  const [mdrData, setMdrData] = useState([]); 
  const [mdrCompletionStatusMap, setMdrCompletionStatusMap] = useState(new Map());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null); 
  const [searchText, setSearchText] = useState("");
  const [vendorCodeSearch, setVendorCodeSearch] = useState("");
  const [mdrStatusFilter, setMdrStatusFilter] = useState("All");
  const location = useLocation();
  const navigate = useNavigate();

  // Parse search parameters from URL query string only once using useMemo
  const { searchQuery, searchStatus } = useMemo(() => {
      const queryParams = new URLSearchParams(location.search);
      return {
          searchQuery: queryParams.get('q') || '',
          searchStatus: queryParams.get('status') || 'All'
      };
  }, [location.search]);

  const handlePendingClick = (record) => {
    console.log("Pending clicked for MDR:", record.mdr_number);
    sendReminderEmail(record);
  };

  const sendReminderEmail = async (record) => {
      let originalMessageID = "";
      try {
    const msgRes = await axios.get("http://localhost:5100/get_message_id_by_mdr", {
      params: { mdr_number: record.mdr_number }
    });
    originalMessageID = msgRes.data.message_id;
    console.log("✅ Fetched original Message-ID:", originalMessageID);
  } catch (err) {
    console.warn("⚠️ Message-ID not found for this MDR");
  }
      const emailToArray = record.email_id_to?.split(/[\s,]+/).filter(Boolean) || [];
      const emailCcArray = record.email_id_cc?.split(/[\s,]+/).filter(Boolean) || [];
      const emailToLogisticsArray = record.email_id_to_logistics?.split(/[\s,]+/).filter(Boolean) || [];
    
      const emailFormData = new FormData();
      emailToArray.forEach((email) => emailFormData.append("email_id_to", email));
      emailToLogisticsArray.forEach((email) => emailFormData.append("email_id_to_logistics", email));
      emailCcArray.forEach((email) => emailFormData.append("email_id_cc", email));
    
      emailFormData.append("subject", `Reminder: MDR Pending - ${record.mdr_number}`);
      emailFormData.append(
        "body",
        `This is a reminder that the following MDR is pending:\n\n` +
        `MDR Number: ${record.mdr_number}\n` +
        `Invoice Number: ${record.invoice_number}\n` +
        `Invoice Date: ${record.invoice_date}\n` +
        `MDR Date: ${record.mdr_date}\n` +
        `GRR Number: ${record.grr_mtn_sticker_number}\n` +
        `Vehicle Number: ${record.vehicle_number}\n` +
        `Supplier Name: ${record.vendor_name}\n` +
        `Item Code: ${record.item_code}\n` +
        `Description: ${record.item_description}`
      );
    
    if (originalMessageID) {
    emailFormData.append("original_message_id", originalMessageID);
  }
  
      try {
        await axios.post("http://localhost:5100/send_mdr_remainder_email", emailFormData, {
          headers: { "Content-Type": "multipart/form-data" },
        });
        message.success("✅ Reminder email sent successfully!");
      } catch (error) {
        console.error("❌ Failed to send email:", error);
        message.error("Failed to send reminder email.");
      }
    };
  
  // --- useEffect for fetching data AND calculating statuses ---
  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    setError(null);
  
    axios.get("http://localhost:5100/api/closingMDR")
      .then((res) => {
        if (!isMounted) return;
        const data = Array.isArray(res.data) ? res.data : [res.data];
        const statuses = calculateMdrCompletionStatuses(data);
        setMdrCompletionStatusMap(statuses);
  
        //  Flatten master + details
        const flattenedData = [];
        data.forEach(record => {
          const details = Array.isArray(record.details) ? record.details : [{}];
          details.forEach(detail => {
            flattenedData.push({
              ...record,
              ...detail,
              computed_status: statuses.get(record.mdr_number) || "Pending",
              detail_key: `${record.mdr_number}_${detail.item_code || 'no-code'}`
            });
          });
        });
  
        setMdrData(flattenedData);
        console.log("data:",flattenedData);
        setLoading(false);
      })
      .catch((err) => {
        if (!isMounted) return;
        console.error("Error fetching MDR data:", err);
        setError("Failed to fetch MDR data. Please try again later.");
        setMdrData([]);
        setMdrCompletionStatusMap(new Map());
        setLoading(false);
      });
  
    return () => {
      isMounted = false;
    };
  }, []);
  

  // --- Client-side filtering logic using useMemo for performance ---
//   const filteredData = useMemo(() => {
//     if (mdrData.length === 0) return [];
  
//     console.log(`Filtering ${mdrData.length} items with query: '${searchQuery}', status: '${searchStatus}', MDR: '${searchText}', VendorCode: '${vendorCodeSearch}'`);
  
//     const filtered = mdrData.filter((item) => {
//       const matchesVendorName =
//         !searchQuery || item.vendor_name?.toLowerCase().includes(searchQuery.toLowerCase());
  
//       const matchesMDRSearch =
//         !searchText || item.mdr_number?.toLowerCase().includes(searchText.toLowerCase());
  
//       const matchesVendorCodeSearch =
//         !vendorCodeSearch || item.vendor_code?.toLowerCase().includes(vendorCodeSearch.toLowerCase());
  
//       if (!matchesVendorName || !matchesMDRSearch || !matchesVendorCodeSearch) return false;
  
//       // 4. Filter by discrepancy type
//       let matchesStatus = true;
//       if (searchStatus !== "All") {
//         const { hasShortage, hasExcess, hasQualitative } = getDiscrepancyStatusForFilter(item);
//         if (searchStatus === "Shortage") matchesStatus = hasShortage;
//         else if (searchStatus === "Excess") matchesStatus = hasExcess;
//         else if (searchStatus === "Qualitative") matchesStatus = hasQualitative;
//         else matchesStatus = false;
//       }
  
//       return matchesStatus;
//     });
  
//     console.log("Filtered Data Length:", filtered.length);
//     return filtered;
//   }, [mdrData, searchQuery, searchStatus, searchText, vendorCodeSearch]);

const filteredData = useMemo(() => {
    if (mdrData.length === 0) return [];
  
    console.log(`Filtering ${mdrData.length} items with:
      Vendor Name: '${searchQuery}',
      MDR Number: '${searchText}',
      Vendor Code: '${vendorCodeSearch}',
      Discrepancy Type: '${searchStatus}',
      Status: '${mdrStatusFilter}'`);
  
    const filtered = mdrData.filter((item) => {

      const matchesVendorName =
        !searchQuery || item.vendor_name?.toLowerCase().includes(searchQuery.toLowerCase());
  
      const matchesMDRSearch =
        !searchText || item.mdr_number?.toLowerCase().includes(searchText.toLowerCase());
  
      const matchesVendorCodeSearch =
        !vendorCodeSearch || item.vendor_code?.toLowerCase().includes(vendorCodeSearch.toLowerCase());
  
      let matchesDiscrepancyType = true;
      if (searchStatus !== "All") {
        const { hasShortage, hasExcess, hasQualitative } = getDiscrepancyStatusForFilter(item);
        if (searchStatus === "Shortage") matchesDiscrepancyType = hasShortage;
        else if (searchStatus === "Excess") matchesDiscrepancyType = hasExcess;
        else if (searchStatus === "Qualitative") matchesDiscrepancyType = hasQualitative;
        else matchesDiscrepancyType = false;
      }
  
      // 5. Filter by MDR status (Pending / Completed)
      const matchesMdrStatus =
        mdrStatusFilter === "All" ||
        item.computed_status?.toLowerCase().trim() === mdrStatusFilter.toLowerCase()
        console.log(`Item MDR: ${item.mdr_number}, Status: ${item.computed_status}`); 

            return (
        matchesVendorName &&
        matchesMDRSearch &&
        matchesVendorCodeSearch &&
        matchesDiscrepancyType &&
        matchesMdrStatus
      );
    });
  
    console.log("Filtered Data Length:", filtered.length);
    return filtered;
  }, [mdrData, searchQuery, searchStatus, searchText, vendorCodeSearch, mdrStatusFilter]);
 
  const columns = [
    {
      title: "Sr No",
      key: "sr_no",
      width: 80,
      render: (_text, _record, index) => index + 1,
      fixed: "left",
    },

    {
      title: "MDR No",
      dataIndex: "mdr_number",
      key: "mdr_number",
      fixed: "left",
      width: 120,
    },
    {
      title: "MDR Date",
      dataIndex: "mdr_date",
      key: "mdr_date",
      render: (date) => (date ? dayjs(date).format("YYYY-MM-DD") : "-"),
      width: 120,
    },
    {
      title: "Invoice No",
      dataIndex: "invoice_number",
      key: "invoice_number",
      width: 150,
    },
    {
      title: "Invoice Date",
      dataIndex: "invoice_date",
      key: "invoice_date",
      render: (date) => (date ? dayjs(date).format("YYYY-MM-DD") : "-"),
      width: 120,
    },
    // {
    //   title: "Sub MDR No",
    //   dataIndex: "sub_mdr_number",
    //   key: "sub_mdr_number",
    //   width: 120,
    // },
    {
      title: "Vendor Name",
      dataIndex: "vendor_name",
      key: "vendor_name",
      width: 200,
    },
    {
      title: "Vendor Code",
      dataIndex: "vendor_code",
      key: "vendor_code",
      width: 120,
    },
    {
      title: "Transporter",
      dataIndex: "transporter_name",
      key: "transporter_name",
      width: 150,
    },
    {
      title: "Vehicle No",
      dataIndex: "vehicle_number",
      key: "vehicle_number",
      width: 120,
    },
    {
      title: "GRR/MTN",
      dataIndex: "grr_mtn_sticker_number",
      key: "grr_mtn_sticker_number",
      width: 150,
    },
    { title: "LR Field", dataIndex: "lr_field", key: "lr_field", width: 100 },
    {
      title: "Unloading Location",
      dataIndex: "unloading_location",
      key: "unloading_location",
      width: 150,
    },
    {
      title: "Buyer Email",
      dataIndex: "email_id_to",
      key: "email_id_to",
      render: (text) => (text ? <Tag color="blue">{text}</Tag> : "-"),
      width: 200,
    },
    // { title: "Logistics Email", dataIndex: "email_id_to_logistic", key: "email_id_to_logistic", render: (text) => text ? <Tag color="purple">{text}</Tag> : '-', width: 200 },
    // { title: "Email CC", dataIndex: "email_id_cc", key: "email_id_cc", render: (text) => text ? <Tag color="orange">{text}</Tag> : '-', width: 200 },

    // Detail Columns
    { title: "Part No", dataIndex: "item_code", key: "item_code", width: 120 },
    {
      title: "Material Desc",
      dataIndex: "item_description",
      key: "item_description",
      width: 200,
    },
    {
      title: "Qty /Challan",
      dataIndex: "quantity_as_per_challan",
      key: "quantity_as_per_challan",
      width: 120,
    },
    {
      title: "Qty Received",
      dataIndex: "item_quantity_actual",
      key: "item_quantity_actual",
      width: 120,
    },
    {
      title: "Discrepancy",
      dataIndex: "excess_shortfall_quantity",
      key: "excess_shortfall_quantity",
      width: 120,
    },
    { title: "UOM", dataIndex: "uom", key: "uom", width: 100 },
    {
      title: "Boxes /LR",
      dataIndex: "number_of_boxes_lr",
      key: "number_of_boxes_lr",
      width: 100,
    },
    {
      title: "Boxes Recvd",
      dataIndex: "number_of_boxes_lr_recieved",
      key: "number_of_boxes_lr_recieved",
      width: 120,
    },
    {
      title: "Remarks",
      dataIndex: ["details", 0, "remarks_1"],
      render: (text, record) => {
        const remarks = record.details?.[0]?.remarks_1;
        return <span>{remarks || "-"}</span>;
      },
    },
    {
      title: "Status (Completion)",
      key: "completionStatus",
      fixed: "right",
      width: 120,
      render: (_, record) => {
        const status =
          mdrCompletionStatusMap.get(record.mdr_number) || "Pending";
        const statusColor = status === "Completed" ? "green" : "orange";
        const tooltipText =
          status === "Pending"
            ? "Pending: Contains unmatched shortages"
            : "Completed: All shortages (if any) are matched by excesses";
        return (
          <Tooltip title={tooltipText}>
            <Tag color={statusColor}>{status}</Tag>
          </Tooltip>
        );
      },
    },
    {
      title: "Actions",
      key: "actions",
      fixed: "right",
      width: 150,
      render: (_, record) => {
        const completionStatus =
          mdrCompletionStatusMap.get(record.mdr_number) || "Pending";
        const isCompleted = completionStatus === "Completed";
        return (
          <Button
            onClick={() => handlePendingClick(record)}
            disabled={isCompleted}
            size="small"
            type="primary"
            style={{ opacity: isCompleted ? 0.6 : 1 }}
          >
            Send Reminder
          </Button>
        );
      },
    },
  ];


  const renderAppliedFilters = () => {
      const filters = [];
      if (searchQuery) filters.push(`Search Term: "${searchQuery}"`);
      if (searchStatus !== 'All') filters.push(`Discrepancy: ${searchStatus}`);
  };

  return (
    <div style={{ padding: "20px 40px" }}>
      {" "}
      <Space
        style={{
          marginBottom: 16,
          display: "flex",
          justifyContent: "space-between",
          flexWrap: "wrap",
        }}
      >
        <Title level={3} style={{ margin: 0 }}>
          Closing MDR Results
        </Title>
        {/* Ensure this Link points to the correct search page route in App.js */}
        <Link to="/closingMDRSearch">
          <Button>Back to Search</Button>
        </Link>
      </Space>
      <div style={{ marginBottom: "20px", display: "flex", gap: "16px" }}>
        <input
          type="text"
          placeholder="Search by MDR Number"
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          style={{
            padding: "8px",
            width: "300px",
            borderRadius: "5px",
            border: "1px solid #ccc",
          }}
        />
        <input
          type="text"
          placeholder="Search by Vendor Code"
          value={vendorCodeSearch}
          onChange={(e) => setVendorCodeSearch(e.target.value)}
          style={{
            padding: "8px",
            width: "300px",
            borderRadius: "5px",
            border: "1px solid #ccc",
          }}
        />
        <select
          value={mdrStatusFilter}
          onChange={(e) => setMdrStatusFilter(e.target.value)}
          style={{
            padding: "8px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            marginLeft: "10px",
          }}
        >
          <option value="All">All Status</option>
          <option value="Pending">Pending</option>
          <option value="Completed">Completed</option>
        </select>
      </div>
      {renderAppliedFilters()} {/* Display the applied filters */}
      {/* --- Content Display --- */}
      {loading && (
        <div style={{ textAlign: "center", padding: "50px" }}>
          <Spin size="large" />
        </div>
      )}
      {!loading && error && (
        <div style={{ textAlign: "center", padding: "30px", color: "red" }}>
          <Text type="danger">{error}</Text>
        </div>
      )}
      {!loading && !error && (
        <Table
          columns={columns}
          dataSource={filteredData} 
          rowKey="mdr_number" 
          pagination={{
            pageSize: 10,
            showSizeChanger: true,
            pageSizeOptions: ["10", "20", "50"],
          }} 
          scroll={{ x: "max-content" }} 
          bordered
          size="middle" 
        />
      )}
    </div>
  );
};

export default ClosingMDR;