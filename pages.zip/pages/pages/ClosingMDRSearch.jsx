// // import React, { useState } from 'react';
// // import { useNavigate } from 'react-router-dom';
// // import { Input, Select, Button, Form, Space, Typography } from 'antd';

// // const { Title } = Typography;
// // const { Option } = Select;

// // const ClosingMDRSearch = () => {
// //   const [supplierName, setSupplierName] = useState('');
// //   const [vendorCode, setVendorCode] = useState('');
// //   const [statusFilter, setStatusFilter] = useState('All'); // All, Shortage, Excess, Qualitative
// //   const navigate = useNavigate();

// //   const handleSearch = () => {
// //     // Construct query parameters
// //     const queryParams = new URLSearchParams();
// //     if (supplierName) queryParams.set('supplierName', supplierName);
// //     if (vendorCode) queryParams.set('vendorCode', vendorCode);
// //     if (statusFilter !== 'All') queryParams.set('status', statusFilter);

// //     // Navigate to the results page with query parameters
// //     navigate(`/closingMDR/results?${queryParams.toString()}`);
// //   };

// //   return (
// //     <div style={{ padding: '40px', maxWidth: '600px', margin: 'auto' }}>
// //       <Title level={3} style={{ textAlign: 'center', marginBottom: '30px' }}>
// //         Search Closing MDR
// //       </Title>
// //       <Form layout="vertical" onFinish={handleSearch}>
// //         <Form.Item label="Supplier Name">
// //           <Input
// //             placeholder="Enter Supplier Name"
// //             value={supplierName}
// //             onChange={(e) => setSupplierName(e.target.value)}
// //           />
// //         </Form.Item>

// //         <Form.Item label="Vendor Code">
// //           <Input
// //             placeholder="Enter Vendor Code"
// //             value={vendorCode}
// //             onChange={(e) => setVendorCode(e.target.value)}
// //           />
// //         </Form.Item>

// //         <Form.Item label="Discrepancy Status">
// //           <Select
// //             value={statusFilter}
// //             onChange={(value) => setStatusFilter(value)}
// //           >
// //             <Option value="All">All</Option>
// //             <Option value="Shortage">Shortage</Option>
// //             <Option value="Excess">Excess</Option>
// //             <Option value="Qualitative">Qualitative Issue</Option>
// //             {/* Add more specific statuses if needed */}
// //           </Select>
// //         </Form.Item>

// //         <Form.Item>
// //           <Button type="primary" htmlType="submit" block>
// //             Search MDRs
// //           </Button>
// //         </Form.Item>
// //       </Form>
// //     </div>
// //   );
// // };

// // export default ClosingMDRSearch;

// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import { Input, Select, Button, Form, Space, Typography } from 'antd';
// import { SearchOutlined } from '@ant-design/icons'; // Import search icon

// // Assuming you have a logo component or image path
// // import KirloskarLogo from './path/to/kirloskar-logo.png';

// const { Title } = Typography;
// const { Option } = Select;

// const ClosingMDRSearch = () => {
//   // We'll keep searching by Supplier Name and Status, but visually adapt
//   const [searchTerm, setSearchTerm] = useState(''); // Use a general search term input visually
//   const [statusFilter, setStatusFilter] = useState('All'); // Keep status filter
//   const navigate = useNavigate();

//   const handleSearch = () => {
//     const queryParams = new URLSearchParams();

//     // Use the single search term to filter by 'supplierName' in this case
//     // Modify this if the single input should search other/multiple fields
//     if (searchTerm.trim()) {
//       queryParams.set('supplierName', searchTerm.trim());
//     }

//     if (statusFilter !== 'All') {
//       queryParams.set('status', statusFilter);
//     }

//     // Navigate to the results page
//     // Ensure this path '/closing-mdr/results' matches your App.js route definition
//     navigate(`/closing-mdr/results?${queryParams.toString()}`);
//   };

//   return (
//     // Outer container for centering and padding
//     <div style={{ padding: '40px 20px', maxWidth: '900px', margin: 'auto', textAlign: 'center' }}>

//       {/* Placeholder for the Logo */}
//       <div style={{ marginBottom: '40px' }}>
//         {/* Replace with your actual logo component or img tag */}
//         {/* <img src={KirloskarLogo} alt="Kirloskar Logo" style={{ height: '40px' }} /> */}
//          <Typography.Text strong style={{ fontSize: '30px', color: '#008080' /* Teal-like color */ }}>
//            {/* Placeholder Text Logo - replace with image if available */}
//            k<span style={{color: '#ffA500'}}>•</span>rloskar
//          </Typography.Text>
//       </div>

//       {/* Form handles the submission logic */}
//       <Form onFinish={handleSearch}>
//         {/* Space provides horizontal layout and spacing */}
//         <Space align="center" size="middle" style={{ display: 'flex', justifyContent: 'center' }}>

//           {/* Single Search Input */}
//           <Form.Item noStyle> {/* noStyle removes default Form.Item margins/label */}
//             <Input
//               style={{ width: '350px' }} // Adjust width as needed
//               size="large" // Make input larger like the image
//               placeholder="Search by Supplier Name..." // Placeholder reflects current search logic
//               value={searchTerm}
//               onChange={(e) => setSearchTerm(e.target.value)}
//               prefix={<SearchOutlined style={{ color: 'rgba(0,0,0,.25)' }} />} // Add search icon
//               allowClear
//             />
//           </Form.Item>

//           {/* Status Filter Dropdown */}
//           <Form.Item noStyle>
//             <Select
//               style={{ width: '200px' }} // Adjust width as needed
//               size="large" // Make select larger
//               value={statusFilter}
//               onChange={(value) => setStatusFilter(value)}
//             >
//               {/* Keep your relevant status options */}
//               <Option value="All">All Statuses</Option>
//               <Option value="Shortage">Shortage</Option>
//               <Option value="Excess">Excess</Option>
//               <Option value="Qualitative">Qualitative Issue</Option>
//               {/* <Option value="Gate In">Gate In</Option> */} {/* Example if needed */}
//             </Select>
//           </Form.Item>

//           {/* Search Button */}
//           <Form.Item noStyle>
//             <Button
//               type="primary"
//               htmlType="submit"
//               size="large" // Make button larger
//               style={{
//                  backgroundColor: '#20B2AA', // Teal color matching image button
//                  borderColor: '#20B2AA',
//                 //  width: '120px' // Optional: set fixed width
//                 }}
//             >
//               Search
//             </Button>
//           </Form.Item>

//         </Space>
//       </Form>
//     </div>
//   );
// };

// export default ClosingMDRSearch;
// src/pages/ClosingMDRSearch.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Input, Select, Button, Form, Space, Typography } from 'antd';
import { SearchOutlined } from '@ant-design/icons';

// import KirloskarLogo from './path/to/kirloskar-logo.png'; // Your logo import

const { Title } = Typography;
const { Option } = Select;

const ClosingMDRSearch = () => {
  const [searchTerm, setSearchTerm] = useState(''); // Single input for searching Vendor Name or Code
  const [statusFilter, setStatusFilter] = useState('All'); // Filter by type of discrepancy
  const navigate = useNavigate();

  const handleSearch = () => {
    const queryParams = new URLSearchParams();

    // Send the single search term as a general query 'q'
    if (searchTerm.trim()) {
      queryParams.set('q', searchTerm.trim());
    }

    // Send the status filter (Shortage, Excess, Qualitative, All)
    if (statusFilter !== 'All') {
      queryParams.set('status', statusFilter);
    }

    // Navigate to the results page (ensure route exists in App.js)
    navigate(`/closingMDR/results?${queryParams.toString()}`);
  };

  return (
    <div style={{ padding: '40px 20px', maxWidth: '900px', margin: 'auto', textAlign: 'center' }}>

      {/* Logo Placeholder */}
      <div style={{ marginBottom: '40px' }}>
         <Typography.Text strong style={{ fontSize: '30px', color: '#008080' }}>
           k<span style={{color: '#ffA500'}}>•</span>rloskar
         </Typography.Text>
      </div>

      {/* Form */}
      <Form onFinish={handleSearch}>
        <Space align="center" size="middle" style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap' }}> {/* Added flexWrap */}

          {/* Single Search Input */}
          <Form.Item noStyle>
            <Input
              style={{ minWidth: '300px', flexGrow: 1 }} // Allow shrinking/growing
              size="large"
              placeholder="Search Supplier Name or Vendor Code..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              prefix={<SearchOutlined style={{ color: 'rgba(0,0,0,.25)' }} />}
              allowClear
            />
          </Form.Item>

          {/* Status Filter Dropdown */}
          <Form.Item noStyle>
            <Select
              style={{ minWidth: '180px' }} // Allow shrinking
              size="large"
              value={statusFilter}
              onChange={(value) => setStatusFilter(value)}
            >
              <Option value="All">All Discrepancies</Option>
              <Option value="Shortage">Contains Shortage</Option>
              <Option value="Excess">Contains Excess</Option>
              <Option value="Qualitative">Contains Qualitative</Option>
            </Select>
          </Form.Item>

          {/* Search Button */}
          <Form.Item noStyle>
            <Button
              type="primary"
              htmlType="submit"
              size="large"
              style={{ backgroundColor: '#20B2AA', borderColor: '#20B2AA' }}
            >
              Search
            </Button>
          </Form.Item>

        </Space>
      </Form>
       <p style={{ textAlign: 'center', marginTop: '15px', color: '#777' }}>
          Search for MDRs by supplier/vendor and filter by discrepancy type.
       </p>
    </div>
  );
};

export default ClosingMDRSearch;