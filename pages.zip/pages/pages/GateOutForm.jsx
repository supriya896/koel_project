import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router";
import axios from "axios";
// import Navbar from "../components/GateOutNav";


import {
  Button,
  ConfigProvider,
  Divider,
  Form,
  Input,
  
  InputNumber,
  Modal,
  Select,
  Space,
} from "antd";
import {
  ArrowRightOutlined,
  CheckOutlined,
  CloseOutlined,
  RobotOutlined,
} from "@ant-design/icons";
import { RuleObject } from "antd/lib/form";
// import { BACKEND_URL } from "../config";
import Alert from "antd/lib/alert/Alert";

const messages = [
  "Processing...",
  "Submitting to ERP",
  "Please wait, almost there...",
  "Finalizing process..."
];  
const LoadingAnimation = ({ submitLoading, completed, step }) => {
  return (
    <div className="flex items-center justify-center text-black">
      {submitLoading ? (
        <div className="flex items-center gap-4 h-full text-3xl">
          <Loader2 className="animate-spin" size={40} />
          {messages[step]}
        </div>
      ) : (
        <div className="text-4xl font-bold flex items-center gap-2">
          {completed ? "Process Completed" : "Process Failed"}
          <CheckCircle className="text-green-500" size={40} />
        </div>
      )}
    </div>
  );
}; 
// import { CheckCircle, Loader2 } from "lucide-react";


const GateEntryForm = ({ params }) => {
  const location = useLocation();
  const [data,setData]= useState()
  const [form] = Form.useForm();
  const [vehicleNumber, setvehicleNumber] = useState(
    localStorage.getItem("vehicleNumber")
  );
  const rawData = localStorage.getItem("vehicleData");
  const vehicleData = rawData ? JSON.parse(rawData) : {};
  const { gate_entry_number } = location.state || {};
  console.log(gate_entry_number)
  // const statusMapping = {
  //   Unloading: "unloadingofmaterials",
  //   Loading: "loadingofmaterials",
  // };  
  const parsedUserData = JSON.parse(localStorage.getItem("userData"));
  console.log("user:", parsedUserData?.username);
  const [userData, setUserData] = useState(parsedUserData);

  const [vehicleStatus, setVehicleStatus] = useState(
    data?.vehicleStatus || vehicleData?.loading_unloading || ""
  );
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [checkValues, setCheckValues] = useState([]);
  const [invoices, setInvoices] = useState();
  const [submitLoading,setSumbitLoading] = useState(false)
  const [completed, setCompleted] = useState(false);
  const [step, setStep] = useState(0);
  const allData = data
    ? data
    : {
      vehicleNumber: vehicleData.vehicle_number,
      driverName: vehicleData.driver_name,
      driverNumber: vehicleData.driver_mobile_number,
      gateEntryNumber: "",
      gateEntryStatus: "",
      inDate: "",
      invoices: "",
      licenseNumber: vehicleData.dl_number,
      lrDate: "",
      lrNumber: "",
      noOfPersons: vehicleData.num_of_people,
      outDate: "",
      pucStatus: vehicleData.puc_status,
      remarks: vehicleData.remarks,
      transporterName: vehicleData.transporter_name,
      vehicleStatus: vehicleData.loading_unloading,
      vehicleType: vehicleData.vehicle_type,
      tripId: vehicleData.trip_id,
    };
  // console.log(allData)
  const [finalData, setFinalData] = useState({})

  const getVehicleData = async () =>{
    try {
      const response = await axios.get(
        `https://192.168.62.199:5100/get_gate_out_document`,
        {
          params: { gate_entry_number: gate_entry_number }, 
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("call",response.data);

      const fetchedData = response?.data?.data;

      if (!fetchedData) {
        console.error("No data found in API response.");
        return;
      }
  
      // Update form and state
      setData(fetchedData);
      form.setFieldsValue(fetchedData);
  
      // Set finalData with relevant fields from API response
      setFinalData({
        vehicleNumber: fetchedData.vehicle_number || "",
        driverName: fetchedData.driver_name || "",
        driverNumber: fetchedData.driver_mobile_number || "",
        gateEntryNumber: fetchedData.gate_entry_number || "",
        gateEntryStatus: fetchedData.gate_entry_status || "",
        inDate: fetchedData.gate_entry_in_time || "",
        invoices: fetchedData.invoices || "",
        licenseNumber: fetchedData.dl_number || "",
        lrDate: fetchedData.lr_date || "",
        lrNumber: fetchedData.lr_number || "",
        noOfPersons: fetchedData.num_of_people || "",
        outDate: fetchedData.out_date || "",
        pucStatus: fetchedData.puc_status || "",
        remarks: fetchedData.remarks || "",
        transporterName: fetchedData.transporter_name || fetchedData.other_transporter_name || "",
        vehicleStatus: fetchedData.loading_unloading || "",
        vehicleType: fetchedData.vehicle_type || "",
        tripId: fetchedData.trip_id || "",
        
      });
      setVehicleStatus(fetchedData.loading_unloading || "");
           
    } catch (err) {
      console.error("Failed to fetch vehicle data:", err.message);
    }
  };
  useEffect(() => {
    getVehicleData()
    if (localStorage.getItem("gate-data")) {
      let data = JSON.parse(localStorage.getItem("gate-data"));
      setData(data);
    }
  }, []);
  // console.log("LOCATION STATE:", location.state);
  const Navigate = useNavigate();

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleOk = () => {
    setIsModalOpen(false);
    if (vehicleStatus.toLowerCase() === "loading") {
      handleUnloadingSubmit(checkValues); // pass current form values
    } else {
      handleLoadingSubmit(checkValues); // pass current form values
    }
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const validatePhoneNumber = async (_, value) => {
    if (!value || /^\d{10}$/.test(value)) {
      return Promise.resolve();
    }
    return Promise.reject(new Error("Phone number must be exactly 10 digits"));
  };
  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === 'Enter') {
        if (isModalOpen) {
          if (vehicleStatus.toLowerCase() === "loading") {
            handleLoadingSubmit();
          } else {
            handleUnloadingSubmit();
          }
        } else {
          form.submit();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isModalOpen, form]);


  const onFinishHandler = (values) => {
    console.log("Success:", values);

    let finalDataForm = {
      vehicleNumber: vehicleNumber,
      driverName: values.driverName,
      driverNumber: values.driverNumber,
      gateEntryNumber: values.gateEntryNumber,
      gateEntryStatus: values.gateEntryStatus,
      inDate: values.inDate,
      invoices: values.invoices,
      licenseNumber: values.licenseNumber,
      lrDate: values.lrDate,
      lrNumber: values.lrNumber,
      noOfPersons: values.noOfPersons,
      outDate: values.outDate,
      pucStatus: values.pucStatus,
      remarks: values.remarks,
      transporterName: values.transporterName,
      vehicleStatus: values.vehicleStatus,
      vehicleType: values.vehicleType,
      tripId: allData.tripId,
      userGateOut: parsedUserData?.username,
    };
    setFinalData(finalDataForm);

    setCheckValues(values);
    setInvoices(values.invoices);
    showModal();
  };
  const onFinishFailedHandler = (errorInfo) => {
    console.log("Failed:", errorInfo);

 const mergedData = {
      ...data,       // existing data from API/localStorage
      ...finalData,  // overwritten or updated form values
    };
    

  };
  const handleLoadingSubmit = () => {
    const values = form.getFieldsValue();  // ✅ latest values directly from form
    
    const sanitizedValues = Object.fromEntries(
      Object.entries(values).map(([key, value]) => [key, value === undefined ? null : value])
    );
  console.log("check",values)
    const mergedData = {
      ...data,                  // existing data from API/localStorage
      ...sanitizedValues,    
      userGateOut: parsedUserData?.username             // latest form values
    };
  
    localStorage.setItem("gate-data", JSON.stringify(mergedData));
  
    Navigate("/gate-out-invoice", {
      state: {
        invoice: sanitizedValues.invoices ?? null,   // Use fresh invoice values
        data: mergedData,
      },
    });
  };
 
    
  const handleUnloadingSubmit = async () => {
    const values = form.getFieldsValue(); // ✅ get latest form values
    const sanitizedValues = Object.fromEntries(
      Object.entries(values).map(([key, value]) => [key, value === undefined ? null : value])
    );
    const mergedData = {
      ...data,
      ...sanitizedValues,
      userGateOut: parsedUserData?.username 
    };
    console.log("mergedData: ", mergedData);

    try {
      const validationResponse = await axios.post("https://192.168.62.199:5100/gateout_invoices", {
        trip_id: mergedData.trip_id,
        gate_entry_number: mergedData.gate_entry_number,
        invoices: mergedData.invoices,
        loading_unloading: mergedData.loading_unloading
      });
  
      console.log("🔍 Invoice Validation Response:", validationResponse.data);
  
      // If invoice count mismatch or trip not found, handle it
      if (validationResponse.data.error) {
        alert(`❌ Invoice Validation Failed: ${validationResponse.data.error}`);
        return;
      }
    } catch (error) {
      console.error("❌ Invoice Validation Error:", error);
      if (error.response?.data?.error) {
        alert(`Invoice Validation Failed: ${error.response.data.error}`);
      } else {
        alert("Failed to validate invoices. Please try again.");
      }
      return;
    }
  
    setSumbitLoading(true);
  
    setInterval(() => {
      setStep((prev) => (prev < messages.length - 1 ? prev + 1 : prev));
    }, 8500);
  
    try {
      if (!mergedData || Object.keys(mergedData).length === 0) {
        console.error("Error: No data to send.");
        alert("Error: No data provided. Please fill in all required fields.");
        return;
      }
  
      console.log("🚀 Sending Data:", mergedData);
  
      // Create FormData object
      let formData = new FormData();
      formData.append("json", JSON.stringify(mergedData));
  
      // API URL for unloading (replace with your actual endpoint)
      const API_URL = "https://192.168.62.200:5200/trigger-bot-gateout"; // Example URL
  
      // Make POST request
      const response = await axios.post(API_URL, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
        timeout: 300000, // 5 minutes timeout
      });
  
      console.log("✅ API Response:", response.data);
  
      // Attach response values to mergedData if needed
      // mergedData.gateOutNumber = response.data.gate_entry_number?.trim();
      mergedData.gate_entry_status = response.data.gate_entry_status?.trim();
      mergedData.outDate = response.data.out_date?.trim();
  
      // Handle backend errors
      if (response.data.error) {
        console.error("🚨 Backend Error:", response.data.error);
        alert(`Error: ${response.data.error}`);
        setSumbitLoading(false);
        return;
      }
  
      // ✅ Success
      console.log("Unload bot executed successfully!");
      setSumbitLoading(false);
      setCompleted(true);
      Navigate("/gate-out-preview", { replace: true, state: { data: mergedData } });
  
    } catch (error) {
      // Handle errors
      if (error.code === "ECONNABORTED") {
        console.error("⏳ Request Timeout:", error.message);
        alert("Request Timeout: The server took too long to respond. Please try again.");
      } else if (error.response) {
        console.error("❌ Server Error:", error.response.status, error.response.data);
        alert(`Error ${error.response.status}: ${error.response.data.error || "Something went wrong!"}`);
      } else if (error.request) {
        console.error("📡 No Response from Server:", error.request);
        alert("Error: No response from server. Please check your network connection.");
      } else {
        console.error("⚠️ Unexpected Error:", error.message);
        alert(`Unexpected Error: ${error.message}`);
      }
      setSumbitLoading(false);
    }
  };
  

  const fieldTitles = {
    driverName: "Driver Name",
    driverNumber: "Driver Number",
    gateEntryNumber: "Gate Entry Number",
    gateEntryStatus: "Gate Entry Status",
    inDate: "In Date",
    invoices: "Invoices",
    licenseNumber: "License Number",
    lrDate: "LR Date",
    lrNumber: "LR Number",
    noOfPersons: "Number of Persons",
    outDate: "Out Date",
    pucStatus: "PUC Status",
    remarks: "Remarks",
    transporterName: "Transporter Name",
    vehicleStatus: "Vehicle Status",
    vehicleType: "Vehicle Type",
  };


  const callBotAPI = async () => {
    console.log(finalData);
  };


  return (
    <>
      <Navbar />
      <div className="min-h-[80vh] w-[85%] bg-gray-100 mx-auto rounded-xl mt-10 px-10 pt-10 pb-2 mb-10">
        {data ?  
        <>
      
        <Form
          form={form}
          name="basic"
          initialValues={data}
          onFinish={onFinishHandler}
          onFinishFailed={onFinishFailedHandler}
          autoComplete="off"
          labelCol={{
            span: 24,
          }}
          wrapperCol={{
            span: 44,
          }}
        >
          <div className="w-full flex gap-10">
            <Form.Item
              label="Vehicle Number"
              name="vehicle_number"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              <Input  className="h-10" disabled />
            </Form.Item>
            <Form.Item label="Vehicle Status" name="loading_unloading" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
              <Input className='h-10' onChange={(val) => setVehicleStatus(val.target.value)} value={vehicleStatus} disabled />
            </Form.Item>
            <Form.Item label="Trip ID" name="trip_id" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
              <Input className='h-10' onChange={(val) => setVehicleStatus(val.target.value)} value={vehicleStatus} disabled />
            </Form.Item>

          </div>
          <div className="w-full flex gap-10">
            <Form.Item
              className="w-[30%]"
              label="Gate Entry Number - to be filled by bot"
              name="gate_entry_number"
              labelCol={{ span: 24 }}
              rules={[
                {
                  required:
                    vehicleStatus.toLowerCase() === "unloading" || "loading" ? false : true,
                  message: "Please enter a value!",
                },
              ]}
            >
              <Input className="h-10" disabled />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="Gate Entry Status - to be filled by bot"
              name="gate_entry_status"
              labelCol={{ span: 24 }}
              rules={[
                {
                  required:
                    vehicleStatus.toLowerCase() === "unloading" || "loading" ? false : true,
                  message: "Please enter a value!",
                },
              ]}
            >
              <Input className="h-10" disabled />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="In Date & Time - to be filled by bot"
              name="gate_entry_in_time"
              labelCol={{ span: 24 }}
              rules={[
                {
                  required: false,
                  message: "Please enter a value!",
                },
              ]}
            >
              <Input className="h-10" disabled/>
            </Form.Item>
          </div>
          <div className="w-full flex gap-10">
            <Form.Item
              className="w-[30%]"
              label="Transporter Name"
              name="transporter_name"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              <Input className="h-10" disabled />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="Vehicle Type"
              name="vehicle_type"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              <Input className="h-10" disabled />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="PUC Status"
              name="puc_status"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              <Input className="h-10" disabled/>
            </Form.Item>
          </div>
          <div className="w-full flex gap-10">
            <Form.Item
              className="w-[30%]"
              label="LR Number"
              name="lrNumber"
              labelCol={{ span: 24 }}
              rules={[{ required: false, message: "Please enter a value!" }]}
            >
              <Input className="h-10" disabled />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="LR Date"
              name="lrDate"
              labelCol={{ span: 24 }}
              rules={[{ required: false, message: "Please enter a value!" }]}
            >
              <Input className="h-10" disabled />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="Driver Name"
              name="driver_name"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              <Input className="h-10" disabled />
            </Form.Item>
          </div>
          <div className="w-full flex gap-10">
            <Form.Item
              className="w-[30%]"
              label="Driver Mobile Number"
              name="driver_mobile_number"
              labelCol={{ span: 24 }}
              rules={[
                {
                  required: true,
                  message: "Phone number needs to be 10 digits!",
                },
                { validator: validatePhoneNumber },
              ]}
            >
              <Input className="!h-10" maxLength={10}  disabled/>
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="License Number"
              name="dl_number"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              <Input className="h-10" disabled/>
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="No of Persons"
              name="num_of_people"
              labelCol={{ span: 24 }}
              rules={[{ required: false, message: "Please enter a value!" }]}
            >
              <Input className="h-10"  disabled/>
            </Form.Item>
          </div>
          <div className="w-full flex gap-10">
            <Form.Item
              className="w-[30%]"
              label="Number of Invoices"
              name="invoices"
              labelCol={{ span: 24 }}
              rules={[
                {
                  required:
                    vehicleStatus.toLowerCase() === "loading" ? true : false,
                  message: "Please enter a value!",
                },
              ]}
            >
              <Input className="h-10 w-[100%]"
              disabled={vehicleStatus?.toLowerCase() === "unloading"} />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="Remarks"
              name="remarks"
              labelCol={{ span: 24 }}
              rules={[{ required: false, message: "Please enter a value!" }]}
            >
              <Input className="h-10" />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="Out Date - to be filled by bot"
              name="outDate"
              labelCol={{ span: 24 }}
              rules={[{ required: false, message: "Please enter a value!" }]}
            >
              <Input className="h-10"  disabled />
            </Form.Item>
          </div>
          <Divider />
          <Form.Item>
            <Space>
              {vehicleStatus.toLowerCase() === "unloading" || vehicleStatus == "" ? (
                <>
                  <Button
                    type="primary"
                    htmlType="submit"
                    className="h-10 !bg-[#1d998b] font-semibold"
                    icon={<CheckOutlined />}
                    iconPosition="end"
                  >
                    submit
                  </Button>
                </>
              ) : null}
              {vehicleStatus.toLowerCase() === "loading" && (
                <Button
                  type="primary"
                  htmlType="submit"
                  className="h-10 !bg-[#1d998b] font-semibold"
                  icon={<ArrowRightOutlined />}
                  iconPosition="end"
                >
                  Next
                </Button>
              )}
            </Space>
          </Form.Item>
        </Form>
</> :<p>loading...</p>
}
      </div>
      <ConfigProvider
        theme={{
          token: {
            Modal: {
              /* here is your component tokens */
              titleColor: "#1d998b",
              titleFontSize: 22,
            },
          },
        }}
      >
        <Modal
          title="Preview"
          open={isModalOpen}
          onOk={handleOk}
          onCancel={handleCancel}
          maskClosable={false}
          footer={null}
        >
          <Divider />
          <ul className="">
            {Object.entries(checkValues).map(([key, value]) => (
              <li key={key} className="mb-4">
                {value !== "" && (
                  <>
                    <strong>{fieldTitles[key] || key}: </strong>
                    {value === "unloading" ? "Unloading Of Materials" :
                      value === "loading" ? "Loading Of Materials" : value}
                  </>
                )}
              </li>
            ))}
          </ul>
          <Divider />
          <div className="w-full flex justify-end gap-6">
            <Button
              key="back"
              onClick={handleCancel}
              className="h-10"
              icon={<CloseOutlined />}
              iconPosition="end"
            >
              Cancel
            </Button>
            {vehicleStatus.toLowerCase() === "unloading" ? (
              <Button
                key="submit"
                type="primary"
                className="h-10 !bg-[#1d998b] font-semibold"
                icon={<CheckOutlined />}
                iconPosition="end"
                onClick={handleUnloadingSubmit}
              >
                Submit To Erp
              </Button>
            ) : (
              <Button
                type="primary"
                onClick={handleLoadingSubmit}
                className="h-10 !bg-[#1d998b] font-semibold"
                icon={<ArrowRightOutlined />}
                iconPosition="end"
              >
                Next
              </Button>
            )}
          </div>
        </Modal>
      </ConfigProvider>
      <Modal
                title=""
                centered={true}
                open={submitLoading}
                maskClosable={false}
                footer={null}
                closeIcon={null}
      >
        <LoadingAnimation submitLoading={submitLoading} completed={completed} step={step} />
      </Modal>
    </>
  );
};

export default GateEntryForm;
