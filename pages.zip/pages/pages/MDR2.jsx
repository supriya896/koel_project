import React, { useEffect, useState } from "react";
import { Table, Spin, message, Input, Modal, Button, DatePicker } from "antd";
import axios from "axios";
import dayjs from "dayjs";

const ClosingMDR = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [mdrNumberFilter, setMdrNumberFilter] = useState("");
  const [itemCodeFilter, setItemCodeFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [pagination, setPagination] = useState({ current: 1, pageSize: 7 });
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [exportModalVisible, setExportModalVisible] = useState(false);

  useEffect(() => {
    fetchMdrData();
  }, []);

  const handlePendingClick = (record) => {
    console.log("Pending clicked for MDR:", record.mdr_number);
    sendReminderEmail(record);
  };

  const handleMdrNumberFilterChange = (e) => {
    setMdrNumberFilter(e.target.value);
  };

  const handleItemCodeFilterChange = (e) => {
    setItemCodeFilter(e.target.value);
  };

  const handleExport = async () => {
    if (!fromDate || !toDate) {
      message.error("Please select both From and To dates.");
      return;
    }

    try {
      const response = await axios.get(
        "http://localhost:5100/export_completed_mdr",
        {
          // const response = await axios.get("http://localhost:5100/export_dock_data", {
          params: {
            from_date: dayjs(fromDate).format("YYYY-MM-DD"),
            to_date: dayjs(toDate).format("YYYY-MM-DD"),
          },
          responseType: "blob", // Required for downloading files
        }
      );

      const blob = new Blob([response.data], {
        type: response.headers["content-type"],
      });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "Completed_MDR_Export.xlsx";
      link.click();

      setExportModalVisible(false);
      setFromDate(null);
      setToDate(null);
      message.success("✅ Exported Successfully!");
    } catch (error) {
      console.error("❌ Export failed:", error);
      message.error("Failed to export data.");
    }
  };

  const filteredData = data.filter((record) => {
    const matchesMdr = record.mdr_number
      ?.toLowerCase()
      .includes(mdrNumberFilter.toLowerCase());
    const matchesItem = record.item_code
      ?.toLowerCase()
      .includes(itemCodeFilter.toLowerCase());
    const matchesStatus =
      statusFilter === "All" || record.status === statusFilter;

    return matchesMdr && matchesItem && matchesStatus;
  });

  const handleManualCloseReasonChange = (record, reason) => {
    const updatedData = data.map((item) =>
      item.mdr_number === record.mdr_number &&
      item.item_code === record.item_code
        ? { ...item, close_reason: reason }
        : item
    );
    setData(updatedData);
  };

  const handleCompletedDateChange = (record, newDate) => {
    console.log("Completed date changed:", {
      ...record,
      completed_date: newDate,
    });
    const updatedData = data.map((item) =>
      item.mdr_number === record.mdr_number &&
      item.item_code === record.item_code
        ? { ...item, completed_date: newDate }
        : item
    );
    setData(updatedData);
  };

  const calculateAgeInDays = (mdrDate, completedDate) => {
    if (!mdrDate || !completedDate) return "";
    const start = new Date(mdrDate);
    const end = new Date(completedDate);
    const diffTime = end - start;
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    return isNaN(diffDays) ? "" : diffDays;
  };

//   const sendCompletionEmail = async (record) => {
//   const emailToArray = record.email_id_to?.split(/[\s,]+/).filter(Boolean) || [];
//   const emailCcArray = record.email_id_cc?.split(/[\s,]+/).filter(Boolean) || [];
//   const emailToLogisticsArray = record.email_id_to_logistics?.split(/[\s,]+/).filter(Boolean) || [];

//   const emailFormData = new FormData();
//   emailToArray.forEach(email => emailFormData.append("email_id_to", email));
//   emailCcArray.forEach(email => emailFormData.append("email_id_cc", email));
//   emailToLogisticsArray.forEach(email => emailFormData.append("email_id_to_logistics", email));

//   emailFormData.append("subject", `MDR Completed - ${record.mdr_number}`);
//   emailFormData.append("body", 
//     `The following MDR has been marked as COMPLETED:\n\n` +
//     `MDR Number: ${record.mdr_number}\n` +
//     `Invoice Number: ${record.invoice_number}\n` +
//     `MDR Date: ${record.mdr_date}\n` +
//     `Completed Date: ${record.completed_date || new Date().toISOString().split("T")[0]}\n` +
//     `Item Code: ${record.item_code}\n` +
//     `Description: ${record.item_description}\n` +
//     `Action Taken: ${record.close_reason || "NA"}\n`
//   );

//   try {
//     await axios.post("http://localhost:5100/send_mdr_remainder_email", emailFormData, {
//       headers: { "Content-Type": "multipart/form-data" },
//     });
//     message.success(`📧 Completion email sent for ${record.mdr_number}`);
//   } catch (error) {
//     console.error("❌ Failed to send completion email:", error);
//     message.error(`Failed to send completion email for ${record.mdr_number}`);
//   }
// };


  // const fetchMdrData = async () => {
  //   setLoading(true);
  //   try {
  //     // Fetch original MDR records
  //     const response = await axios.get(
  //       "http://localhost:5100/get_all_mdr_data"
  //     );
  //     const allRecords = response.data;

  //     // Apply matching logic
  //     let processedData = matchMdrRecords(allRecords);

  //     // Fetch completed MDRs from DB
  //     const completedRes = await axios.get(
  //       "http://localhost:5100/get_completed_closing_mdrs"
  //     );
  //     const completedRecords = completedRes.data;

  //     // 🔥 Merge DB completed into processedData
  //     processedData = processedData.map((item) => {
  //       const match = completedRecords.find(
  //         (saved) =>
  //           saved.mdr_number === item.mdr_number &&
  //           saved.item_code?.trim() === item.item_code?.trim()
  //       );

  //       if (match) {
  //         return {
  //           ...item,
  //           ...match,
  //           status: "Completed",
  //           statusLocked: true,
  //         };
  //       }
  //       return item;
  //     });

  //     // 🔥 Identify NEW auto-completed rows not in DB
  //     const newlyCompletedRows = processedData.filter((row) => {
  //       return (
  //         row.status === "Completed" &&
  //         row.statusLocked &&
  //         !completedRecords.some(
  //           (saved) =>
  //             saved.mdr_number === row.mdr_number &&
  //             saved.item_code?.trim() === row.item_code?.trim()
  //         )
  //       );
  //     });

  //     // 🔥 Save only NEW ones
  //     if (newlyCompletedRows.length > 0) {
  //       try {
  //         const saveRes = await axios.post(
  //           "http://localhost:5100/save_closing_mdr",
  //           newlyCompletedRows
  //         );
  //         console.log("✅ Auto-saved completed MDRs:", saveRes.data);
  //       } catch (err) {
  //         console.error("❌ Failed to auto-save MDRs:", err);
  //       }
  //     }

  //     setData(processedData);
  //     console.log("✅ Final Processed MDR Data:", processedData);
  //   } catch (error) {
  //     console.error("❌ Error fetching MDR data:", error);
  //   } finally {
  //     setLoading(false);
  //   }
  // };


  const sendCompletionEmail = async (record) => {
  const emailToArray = record.email_id_to?.split(/[\s,]+/).filter(Boolean) || [];
  const emailCcArray = record.email_id_cc?.split(/[\s,]+/).filter(Boolean) || [];
  const emailToLogisticsArray = record.email_id_to_logistics?.split(/[\s,]+/).filter(Boolean) || [];

  const emailFormData = new FormData();
  emailToArray.forEach((email) => emailFormData.append("email_id_to", email));
  emailCcArray.forEach((email) => emailFormData.append("email_id_cc", email));
  emailToLogisticsArray.forEach((email) =>
    emailFormData.append("email_id_to_logistics", email)
  );

  emailFormData.append("subject", `MDR Completed - ${record.mdr_number}`);
  emailFormData.append(
    "body",
    `The following MDR has been marked as COMPLETED:\n\n` +
      `MDR Number: ${record.mdr_number}\n` +
      `Completed Against: ${record._matchedAgainst}\n` +
      `Item Code: ${record.item_code}\n` +
      `Description: ${record.item_description}\n` +
      `Completed Date: ${record.completed_date}\n`
  );

  try {
    await axios.post("http://localhost:5100/send_mdr_remainder_email", emailFormData, {
      headers: { "Content-Type": "multipart/form-data" },
    });
    message.success(`📧 Completion email sent for ${record.mdr_number}`);
  } catch (error) {
    console.error("❌ Email send failed:", error);
    message.error(`Email failed for ${record.mdr_number}`);
  }
};

const fetchMdrData = async () => {
  setLoading(true);
  try {
    const response = await axios.get("http://localhost:5100/get_all_mdr_data");
    const allRecords = response.data;

    const { processed, matchedToEmail } = matchMdrRecords(allRecords);

    const completedRes = await axios.get("http://localhost:5100/get_completed_closing_mdrs");
    const completedRecords = completedRes.data;

    const processedData = processed.map((item) => {
      const match = completedRecords.find(
        (saved) =>
          saved.mdr_number === item.mdr_number &&
          saved.item_code?.trim() === item.item_code?.trim()
      );

      if (match) {
        return {
          ...item,
          ...match,
          status: "Completed",
          statusLocked: true,
        };
      }
      return item;
    });

    const newlyCompletedRows = matchedToEmail.filter((row) => {
      return !completedRecords.some(
        (saved) =>
          saved.mdr_number === row.mdr_number &&
          saved.item_code?.trim() === row.item_code?.trim()
      );
    });

    if (newlyCompletedRows.length > 0) {
      try {
        await axios.post("http://localhost:5100/save_closing_mdr", newlyCompletedRows);
        console.log("✅ Saved auto-completed MDRs:", newlyCompletedRows);
      } catch (err) {
        console.error("❌ Save error:", err);
      }
    }

    // ✅ Only email the second MDR (not both)
    const emailedMDRs = JSON.parse(localStorage.getItem("emailedCompletedMDRs") || "[]");
    const newEmailed = [];

    for (const record of matchedToEmail) {
      const uniqueKey = `${record.mdr_number}-${record.item_code}`;
      if (!emailedMDRs.includes(uniqueKey)) {
        await sendCompletionEmail(record);  // email only the second
        newEmailed.push(uniqueKey);
      }
    }

    const updatedList = [...emailedMDRs, ...newEmailed];
    localStorage.setItem("emailedCompletedMDRs", JSON.stringify(updatedList));

    setData(processedData);
  } catch (error) {
    console.error("❌ fetchMdrData error:", error);
  } finally {
    setLoading(false);
  }
};



  // const matchMdrRecords = (records) => {
  //   // Extracts absolute quantity (e.g., "-20" becomes 20)
  //   const parseQty = (text) => {
  //     if (!text) return 0;
  //     const match = text.match(/-?\d+/);
  //     return match ? Math.abs(parseInt(match[0], 10)) : 0;
  //   };

  //   // Determines type based on keyword or sign
  //   const getType = (text) => {
  //     const trimmed = text?.trim().toLowerCase() || "";

  //     if (trimmed.includes("shortage")) return "shortage";
  //     if (trimmed.includes("excess")) return "excess";
  //     if (trimmed.startsWith("-")) return "shortage";
  //     if (trimmed.startsWith("+") || /^\d/.test(trimmed)) return "excess";

  //     return null;
  //   };

  //   const processed = records.map((r) => ({
  //     ...r,
  //     status: "Pending",
  //     statusLocked: false,
  //     closing_mdr_no: null,
  //   }));

  //   const matched = new Set();
  //   // const matchedToSave = [];

  //   for (let i = 0; i < processed.length; i++) {
  //     const a = processed[i];
  //     if (matched.has(a.mdr_number)) continue;

  //     const aQty = parseQty(a.excess_shortfall_quantity);
  //     const aType = getType(a.excess_shortfall_quantity);
  //     const aItem = a.item_code?.toLowerCase();
  //     const aPart = a.part_number?.toLowerCase();
  //     const aVendor = a.vendor_code?.toLowerCase();

  //     if (!aType || (!aItem && !aPart) || !aQty) continue;

  //     const match = processed.find((b) => {
  //       if (matched.has(b.mdr_number) || b.mdr_number === a.mdr_number)
  //         return false;

  //       const bQty = parseQty(b.excess_shortfall_quantity);
  //       const bType = getType(b.excess_shortfall_quantity);
  //       const bItem = b.item_code?.toLowerCase();
  //       const bPart = b.part_number?.toLowerCase();
  //       const bVendor = b.vendor_code?.toLowerCase();

  //       // Check item or part matches
  //       const itemOrPartMatch =
  //         (aItem && bItem && aItem === bItem) ||
  //         (aPart && bPart && aPart === bPart);

  //       // Vendor code matching condition:
  //       // Match if either vendor is missing OR both present and equal
  //       const vendorMatch = !aVendor || !bVendor || aVendor === bVendor;

  //       return (
  //         itemOrPartMatch &&
  //         vendorMatch &&
  //         aQty === bQty &&
  //         aType !== bType &&
  //         ((aType === "shortage" && bType === "excess") ||
  //           (aType === "excess" && bType === "shortage"))
  //       );
  //     });

  //     if (match) {
  //       const dateA = new Date(a.mdr_date);
  //       const dateB = new Date(match.mdr_date);
  //       const completedDate =
  //         isNaN(dateA) && isNaN(dateB)
  //           ? new Date().toISOString().split("T")[0]
  //           : dateA > dateB
  //           ? a.mdr_date
  //           : match.mdr_date;

  //       a.status = "Completed";
  //       a.statusLocked = true;
  //       a.completed_date = completedDate;
  //       a.closing_mdr_no = match.mdr_number;
  //       a.close_reason = "S/OFF";

  //       match.status = "Completed";
  //       match.statusLocked = true;
  //       match.completed_date = completedDate;
  //       match.closing_mdr_no = a.mdr_number;
  //       match.close_reason = "S/OFF";

  //       matched.add(a.mdr_number);
  //       matched.add(match.mdr_number);

  //       console.log(
  //         `✔ Matched: ${a.mdr_number} ↔ ${match.mdr_number} | Completed Date: ${completedDate}`
  //       );
  //     }
  //   }
  //   return processed;
  // };
const matchMdrRecords = (records) => {
  const parseQty = (text) => {
    if (!text) return 0;
    const match = text.match(/-?\d+/);
    return match ? Math.abs(parseInt(match[0], 10)) : 0;
  };

  const getType = (text) => {
    const trimmed = text?.trim().toLowerCase() || "";
    if (trimmed.includes("shortage")) return "shortage";
    if (trimmed.includes("excess")) return "excess";
    if (trimmed.startsWith("-")) return "shortage";
    if (trimmed.startsWith("+") || /^\d/.test(trimmed)) return "excess";
    return null;
  };

  const processed = records.map((r) => ({
    ...r,
    status: "Pending",
    statusLocked: false,
    closing_mdr_no: null,
  }));

  const matched = new Set();
  const matchedToEmail = [];

  for (let i = 0; i < processed.length; i++) {
    const a = processed[i];
    if (matched.has(a.mdr_number)) continue;

    const aQty = parseQty(a.excess_shortfall_quantity);
    const aType = getType(a.excess_shortfall_quantity);
    const aItem = a.item_code?.toLowerCase();
    const aPart = a.part_number?.toLowerCase();
    const aVendor = a.vendor_code?.toLowerCase();

    if (!aType || (!aItem && !aPart) || !aQty) continue;

    const match = processed.find((b) => {
      if (matched.has(b.mdr_number) || b.mdr_number === a.mdr_number) return false;

      const bQty = parseQty(b.excess_shortfall_quantity);
      const bType = getType(b.excess_shortfall_quantity);
      const bItem = b.item_code?.toLowerCase();
      const bPart = b.part_number?.toLowerCase();
      const bVendor = b.vendor_code?.toLowerCase();

      const itemOrPartMatch =
        (aItem && bItem && aItem === bItem) ||
        (aPart && bPart && aPart === bPart);

      const vendorMatch = !aVendor || !bVendor || aVendor === bVendor;

      return (
        itemOrPartMatch &&
        vendorMatch &&
        aQty === bQty &&
        aType !== bType &&
        ((aType === "shortage" && bType === "excess") ||
          (aType === "excess" && bType === "shortage"))
      );
    });

    if (match) {
      const dateA = new Date(a.mdr_date);
      const dateB = new Date(match.mdr_date);
      const completedDate =
        isNaN(dateA) && isNaN(dateB)
          ? new Date().toISOString().split("T")[0]
          : dateA > dateB
          ? a.mdr_date
          : match.mdr_date;

      a.status = "Completed";
      a.statusLocked = true;
      a.completed_date = completedDate;
      a.closing_mdr_no = match.mdr_number;
      a.close_reason = "S/OFF";

      match.status = "Completed";
      match.statusLocked = true;
      match.completed_date = completedDate;
      match.closing_mdr_no = a.mdr_number;
      match.close_reason = "S/OFF";

      matched.add(a.mdr_number);
      matched.add(match.mdr_number);

      // ✅ Email only the second one that completes the match
      const newer = new Date(a.mdr_date) > new Date(match.mdr_date) ? a : match;
      const older = newer === a ? match : a;

      newer._matchedAgainst = older.mdr_number;
      matchedToEmail.push(newer);
    }
  }

  return { processed, matchedToEmail };
};


  const handleStatusChange = async (record, newStatus) => {
    console.log("Status changed:", { ...record, newStatus });
    const today = new Date().toISOString().split("T")[0];

    const updatedData = data.map((item) => {
      if (
        item.mdr_number === record.mdr_number &&
        item.item_code === record.item_code
      ) {
        const updatedItem = {
          ...item,
          status: newStatus,
          rowDisabled: newStatus === "Completed", // 🔒 Disable row when completed
        };

        const age = calculateAgeInDays(record.mdr_date, record.completed_date);
        // console.log("Age:", {...updatedItem,age,});

        if (newStatus === "Completed" && !item.completed_date) {
          updatedItem.completed_date = today;
        }

        return updatedItem;
      }
      return item;
    });
    setData(updatedData);

    // ✅ Find the full updated row
    const fullRow = updatedData.find(
      (item) => item.mdr_number === record.mdr_number
      // item.item_code === record.item_code &&
      // item.vendor_code === record.vendor_code
    );

    const age = calculateAgeInDays(fullRow.mdr_date, fullRow.completed_date);
    const adjustedAge = Math.max(age - (fullRow.non_working_days || 0), 0);

    const payload = {
      ...fullRow,
      age_days: adjustedAge,
      status: newStatus,
    };
    console.log("data:", payload);

    if (newStatus === "Completed") {
      try {
        const response = await axios.post(
          "http://localhost:5100/save_closing_mdr",
          payload
        );
        console.log("✅ manually completed mdr saved:", response.data);
         // 🔔 Trigger email notification
        await sendCompletionEmail(fullRow);
      } catch (error) {
        console.error("❌ Error saving to closing MDR:", error);
      }
    }

    // console.log("✅ Full MDR row on status change:", { ...fullRow, age });
  };

  const sendReminderEmail = async (record) => {
    let originalMessageID = "";

    try {
      const msgRes = await axios.get(
        "http://localhost:5100/get_message_id_by_mdr",
        {
          params: { mdr_number: record.mdr_number },
        }
      );
      originalMessageID = msgRes.data.message_id;
      print("id:",originalMessageID)
    } catch (err) {
      console.warn("⚠️ Message-ID not found for this MDR");
    }

    const emailToArray =
      record.email_id_to?.split(/[\s,]+/).filter(Boolean) || [];
    const emailCcArray =
      record.email_id_cc?.split(/[\s,]+/).filter(Boolean) || [];
    const emailToLogisticsArray =
      record.email_id_to_logistics?.split(/[\s,]+/).filter(Boolean) || [];

    const emailFormData = new FormData();
    emailToArray.forEach((email) => emailFormData.append("email_id_to", email));
    emailToLogisticsArray.forEach((email) =>
      emailFormData.append("email_id_to_logistics", email)
    );
    emailCcArray.forEach((email) => emailFormData.append("email_id_cc", email));

    emailFormData.append(
      "subject",
      `Reminder: MDR Pending - ${record.mdr_number}`
    );
    emailFormData.append(
      "body",
      `This is a reminder that the following MDR is pending:\n\n` +
        `MDR Number: ${record.mdr_number}\n` +
        `Invoice Number: ${record.invoice_number}\n` +
        `Invoice Date: ${record.invoice_date}\n` +
        `MDR Date: ${record.mdr_date}\n` +
        `GRR Number: ${record.grr_mtn_sticker_number}\n` +
        `Vehicle Number: ${record.vehicle_number}\n` +
        `Supplier Name: ${record.vendor_name}\n` +
        `Item Code: ${record.item_code}\n` +
        `Description: ${record.item_description}`
    );

    if (originalMessageID) {
      emailFormData.append("original_message_id", originalMessageID);
    }

    try {
      await axios.post(
        "http://localhost:5100/send_mdr_remainder_email",
        emailFormData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );
      message.success("✅ Reminder email sent successfully!");
    } catch (error) {
      console.error("❌ Failed to send email:", error);
      message.error("Failed to send reminder email.");
    }
  };

  //   const sendReminderEmail = async (record) => {
  //   const subject = `MDR Intimation For Approval - ${record.mdr_number}`;
  //   let originalMessageID = "";

  //   try {
  //     const msgRes = await axios.get("http://localhost:5100/get_message_id_by_mdr", {
  //       params: { mdr_number: record.mdr_number }
  //     });
  //     originalMessageID = msgRes.data.message_id;
  //   } catch (err) {
  //     console.warn("⚠️ Message-ID not found for this MDR");
  //   }

  //   const emailFormData = new FormData();
  //   emailFormData.append("subject", subject);
  //   emailFormData.append("body", `
  //     <p>This is a reminder for MDR:</p>
  //     <ul>
  //       <li><strong>MDR No:</strong> ${record.mdr_number}</li>
  //       <li><strong>Invoice No:</strong> ${record.invoice_number}</li>
  //       ...
  //     </ul>`);

  //   record.email_id_to?.split(/[,\s]+/).forEach(email => emailFormData.append("email_id_to", email));
  //   record.email_id_cc?.split(/[,\s]+/).forEach(email => emailFormData.append("email_id_cc", email));
  //   record.email_id_to_logistics?.split(/[,\s]+/).forEach(email => emailFormData.append("email_id_to_logistics", email));

  //   if (originalMessageID) {
  //     emailFormData.append("original_message_id", originalMessageID);
  //   }

  //   try {
  //     await axios.post("http://localhost:5100/send_mdr_remainder_email", emailFormData);
  //     message.success("✅ Reminder sent as reply!");
  //   } catch (e) {
  //     message.error("❌ Failed to send reminder.");
  //   }
  // };

  const columns = [
    {
      title: "Sr No",
      key: "sr_no",
      fixed: "left",
      render: (_, __, index) =>
        (pagination.current - 1) * pagination.pageSize + index + 1,
    },
    {
      title: "MDR Number",
      dataIndex: "mdr_number",
      key: "mdr_number",
      fixed: "left",
    },
    { title: "MDR Date", dataIndex: "mdr_date", key: "mdr_date" },
    {
      title: "Invoice Number",
      dataIndex: "invoice_number",
      key: "invoice_number",
    },
    { title: "Invoice Date", dataIndex: "invoice_date", key: "invoice_date" },
    {
      title: "GRR Number",
      dataIndex: "grr_mtn_sticker_number",
      key: "grr_mtn_sticker_number",
    },
    {
      title: "Unloading Location",
      dataIndex: "unloading_location",
      key: "unloading_location",
    },
    {
      title: "MDR Raised As",
      dataIndex: "mdr_raised_as",
      key: "mdr_raised_as",
    },
    {
      title: "Transporter Name",
      dataIndex: "transporter_name",
      key: "transporter_name",
    },
    { title: "Vendor No", dataIndex: "vendor_code", key: "vendor_code" },
    { title: "LR/Docket No", dataIndex: "lr_field", key: "lr_field" },
    { title: "Supplier Name", dataIndex: "vendor_name", key: "vendor_name" },
    { title: "Vehicle No", dataIndex: "vehicle_number", key: "vehicle_number" },
    { title: "Email To Buyer", dataIndex: "email_id_to", key: "email_id_to" },
    { title: "Item Code", dataIndex: "item_code", key: "item_code" },
    {
      title: "Description",
      dataIndex: "item_description",
      key: "item_description",
    },
    {
      title: "Qty Challan",
      dataIndex: "quantity_as_per_challan",
      key: "quantity_as_per_challan",
    },
    {
      title: "Actual Qty",
      dataIndex: "item_quantity_actual",
      key: "item_quantity_actual",
    },
    {
      title: "Shortfall",
      dataIndex: "excess_shortfall_quantity",
      key: "excess_shortfall_quantity",
    },
    {
      title: "Boxes LR",
      dataIndex: "number_of_boxes_lr",
      key: "number_of_boxes_lr",
    },
    {
      title: "Boxes Received",
      dataIndex: "number_of_boxes_lr_recieved",
      key: "number_of_boxes_lr_recieved",
    },
    // {
    //   title: "Remarks",
    //   dataIndex: "remarks_1",
    //   key: "remarks_1",
    // },
    {
      title: "Remarks",
      dataIndex: "remarks_1",
      key: "remarks_1",
      width: 300,
      render: (text) => (
        <div
          style={{
            whiteSpace: "normal",
            wordWrap: "break-word",
            overflowWrap: "break-word",
            maxWidth: "300px",
          }}
        >
          {text || "NA"} {/* Fallback if text is empty */}
        </div>
      ),
    },
    {
      title: "Closing MDR No",
      key: "closing_mdr_no",
      render: (_, record) => (
        <Input
          value={record.closing_mdr_no || ""}
          onChange={(e) => {
            const updated = data.map((item) =>
              item.mdr_number === record.mdr_number &&
              item.item_code === record.item_code
                ? { ...item, closing_mdr_no: e.target.value }
                : item
            );
            setData(updated);
          }}
          placeholder="Enter MDR No"
          disabled={record.rowDisabled || record.statusLocked}
          style={{
            width: "140px",
            borderRadius: "5px",
          }}
        />
      ),
    },
    {
      title: "Completed Date",
      dataIndex: "completed_date",
      key: "completed_date",
      render: (_, record) => (
        <input
          type="date"
          value={record.completed_date || ""}
          disabled={record.rowDisabled}
          onChange={(e) => handleCompletedDateChange(record, e.target.value)}
          style={{
            padding: "5px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "140px",
          }}
        />
      ),
    },
    // {
    //   title: "Age (Days)",
    //   dataIndex: "age",
    //   key: "age",
    //   render: (_, record) => (
    //     <span>
    //       {calculateAgeInDays(record.mdr_date, record.completed_date)}
    //     </span>
    //   ),
    // },
    //     {
    //   title: "Age (Days)",
    //   dataIndex: "age",
    //   key: "age",
    //   render: (_, record) => {
    //     const age = calculateAgeInDays(record.mdr_date, record.completed_date);
    //     const adjustedAge = Math.max(age - (record.non_working_days || 0), 0);
    //     return <span>{adjustedAge}</span>;
    //   }
    // },
    {
      title: "Age (Days)",
      dataIndex: "age",
      key: "age",
      render: (_, record) => {
        const dbAge = record.age_days;
        const calculatedAge = calculateAgeInDays(
          record.mdr_date,
          record.completed_date
        );
        const adjustedAge = Math.max(
          calculatedAge - (record.non_working_days || 0),
          0
        );

        return (
          <span>
            {dbAge !== undefined && dbAge !== null ? dbAge : adjustedAge}
          </span>
        );
      },
    },
    {
      title: "Non-Working Days",
      dataIndex: "non_working_days",
      key: "non_working_days",
      render: (_, record) => (
        <input
          type="number"
          min={0}
          value={record.non_working_days || ""}
          disabled={record.statusLocked}
          onChange={(e) => {
            const updatedData = data.map((item) =>
              item.mdr_number === record.mdr_number &&
              item.item_code === record.item_code
                ? { ...item, non_working_days: parseInt(e.target.value, 10) }
                : item
            );
            setData(updatedData);
          }}
          style={{
            padding: "5px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "100px",
          }}
        />
      ),
    },
    {
      title: "Action Taken",
      dataIndex: "action_taken",
      key: "action_taken",
      render: (text, record) => (
        <select
          value={record.close_reason || ""}
          disabled={record.rowDisabled}
          onChange={(e) =>
            handleManualCloseReasonChange(record, e.target.value)
          }
          style={{
            padding: "5px 10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "150px",
            backgroundColor: "#f9f9f9",
            cursor: "pointer",
          }}
        >
          <option value="">-- Select --</option>
          <option value="RTV">RTV</option>
          <option value="Send Back">Send Back</option>
          <option value="Debit">Debit</option>
          <option value="S/OFF">S/OFF</option>
        </select>
      ),
    },
    {
      title: "Document No.",
      dataIndex: "document_no",
      key: "document_no",
      render: (_, record) => (
        <input
          type="text"
          value={record.document_no || ""}
          disabled={record.rowDisabled}
          onChange={(e) => {
            const updated = data.map((item) =>
              item.mdr_number === record.mdr_number &&
              item.item_code === record.item_code
                ? { ...item, document_no: e.target.value }
                : item
            );
            setData(updated);
          }}
          style={{
            padding: "5px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "140px",
          }}
        />
      ),
    },
    {
      title: "Debit To",
      dataIndex: "debit_to",
      key: "debit_to",
      render: (_, record) => (
        <input
          type="text"
          value={record.debit_to || ""}
          disabled={record.rowDisabled}
          onChange={(e) => {
            const updated = data.map((item) =>
              item.mdr_number === record.mdr_number &&
              item.item_code === record.item_code
                ? { ...item, debit_to: e.target.value }
                : item
            );
            setData(updated);
          }}
          style={{
            padding: "5px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "140px",
          }}
        />
      ),
    },
    {
      title: "Debited Amount",
      dataIndex: "debited_amount",
      key: "debited_amount",
      render: (_, record) => (
        <input
          type="text"
          value={record.debited_amount || ""}
          disabled={record.rowDisabled}
          onChange={(e) => {
            const updated = data.map((item) =>
              item.mdr_number === record.mdr_number &&
              item.item_code === record.item_code
                ? { ...item, debited_amount: e.target.value }
                : item
            );
            setData(updated);
          }}
          style={{
            padding: "5px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "140px",
          }}
        />
      ),
    },
    {
      title: "Debit Note No (Transporter)",
      dataIndex: "debit_note_no_transporter",
      key: "debit_note_no_transporter",
      render: (_, record) => (
        <input
          type="text"
          value={record.debit_note_no_transporter || ""}
          disabled={record.rowDisabled}
          onChange={(e) => {
            const updated = data.map((item) =>
              item.mdr_number === record.mdr_number &&
              item.item_code === record.item_code
                ? { ...item, debit_note_no_transporter: e.target.value }
                : item
            );
            setData(updated);
          }}
          style={{
            padding: "5px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "140px",
          }}
        />
      ),
    },
    {
      title: "Series No.",
      dataIndex: "series_no_1",
      key: "series_no_1",
      render: (_, record) => (
        <input
          type="text"
          value={record.series_no_1 || ""}
          disabled={record.rowDisabled}
          onChange={(e) => {
            const updated = data.map((item) =>
              item.mdr_number === record.mdr_number &&
              item.item_code === record.item_code
                ? { ...item, series_no_1: e.target.value }
                : item
            );
            setData(updated);
          }}
          style={{
            padding: "5px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "140px",
          }}
        />
      ),
    },
    {
      title: "NFA More Than 8 Days",
      dataIndex: "nfa_days_1",
      key: "nfa_days_1",
      render: (_, record) => (
        <input
          type="text"
          value={record.nfa_days_1 || ""}
          disabled={record.rowDisabled}
          onChange={(e) => {
            const updated = data.map((item) =>
              item.mdr_number === record.mdr_number &&
              item.item_code === record.item_code
                ? { ...item, nfa_days_1: e.target.value }
                : item
            );
            setData(updated);
          }}
          style={{
            padding: "5px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "140px",
          }}
        />
      ),
    },
    // {
    //   title: "Series No.",
    //   dataIndex: "series_no_2",
    //   key: "series_no_2",
    //   render: (_, record) => (
    //     <input
    //       type="text"
    //       value={record.series_no_2 || ""}
    //       disabled={record.rowDisabled}
    //       onChange={(e) => {
    //         const updated = data.map((item) =>
    //           item.mdr_number === record.mdr_number && item.item_code === record.item_code
    //             ? { ...item, series_no_2: e.target.value }
    //             : item
    //         );
    //         setData(updated);
    //       }}
    //       style={{
    //         padding: "5px",
    //         borderRadius: "5px",
    //         border: "1px solid #ccc",
    //         width: "140px",
    //       }}
    //     />
    //   ),
    // },
    // {
    //   title: "NFA More Than 8 Days",
    //   dataIndex: "nfa_days_2",
    //   key: "nfa_days_2",
    //   render: (_, record) => (
    //     <input
    //       type="text"
    //       value={record.nfa_days_2 || ""}
    //       disabled={record.rowDisabled}
    //       onChange={(e) => {
    //         const updated = data.map((item) =>
    //           item.mdr_number === record.mdr_number && item.item_code === record.item_code
    //             ? { ...item, nfa_days_2: e.target.value }
    //             : item
    //         );
    //         setData(updated);
    //       }}
    //       style={{
    //         padding: "5px",
    //         borderRadius: "5px",
    //         border: "1px solid #ccc",
    //         width: "140px",
    //       }}
    //     />
    //   ),
    // },
    {
      title: "RDN No.",
      dataIndex: "rdn_no",
      key: "rdn_no",
      render: (_, record) => (
        <input
          type="text"
          value={record.rdn_no || ""}
          disabled={record.rowDisabled}
          onChange={(e) => {
            const updated = data.map((item) =>
              item.mdr_number === record.mdr_number &&
              item.item_code === record.item_code
                ? { ...item, rdn_no: e.target.value }
                : item
            );
            setData(updated);
          }}
          style={{
            padding: "5px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "140px",
          }}
        />
      ),
    },
    {
      title: "Debit Note No. (Supplier)",
      dataIndex: "debit_note_no",
      key: "debit_note_no",
      render: (_, record) => (
        <input
          type="text"
          value={record.debit_note_no || ""}
          disabled={record.rowDisabled}
          onChange={(e) => {
            const updated = data.map((item) =>
              item.mdr_number === record.mdr_number &&
              item.item_code === record.item_code
                ? { ...item, debit_note_no: e.target.value }
                : item
            );
            setData(updated);
          }}
          style={{
            padding: "5px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "140px",
          }}
        />
      ),
    },
    {
      title: "Credit Note No. (Supplier)",
      dataIndex: "credit_note_no",
      key: "credit_note_no",
      render: (_, record) => (
        <input
          type="text"
          value={record.credit_note_no || ""}
          disabled={record.rowDisabled}
          onChange={(e) => {
            const updated = data.map((item) =>
              item.mdr_number === record.mdr_number &&
              item.item_code === record.item_code
                ? { ...item, credit_note_no: e.target.value }
                : item
            );
            setData(updated);
          }}
          style={{
            padding: "5px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "140px",
          }}
        />
      ),
    },
    {
      title: "Debit Note / D Note Number",
      dataIndex: "debit_note",
      key: "debit_note",
      render: (_, record) => (
        <input
          type="text"
          value={record.debit_note || ""}
          disabled={record.rowDisabled}
          onChange={(e) => {
            const updated = data.map((item) =>
              item.mdr_number === record.mdr_number &&
              item.item_code === record.item_code
                ? { ...item, debit_note: e.target.value }
                : item
            );
            setData(updated);
          }}
          style={{
            padding: "5px",
            borderRadius: "5px",
            border: "1px solid #ccc",
            width: "140px",
          }}
        />
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      fixed: "right",
      render: (text, record) => (
        <select
          value={record.status}
          disabled={record.statusLocked}
          onChange={(e) => handleStatusChange(record, e.target.value)}
          style={{
            backgroundColor:
              record.status === "Completed" ? "#52c41a" : "#ff4d4f",
            color: "white",
            border: "none",
            padding: "5px 10px",
            borderRadius: "5px",
            cursor: record.statusLocked ? "not-allowed" : "pointer",
          }}
        >
          <option value="Pending">Pending</option>
          <option value="Completed">Completed</option>
        </select>
      ),
    },

    {
      title: "Action",
      dataIndex: "action",
      key: "action",
      fixed: "right",
      render: (_, record) => (
        <div>
          <button
            onClick={() => handlePendingClick(record)}
            disabled={record.status === "Completed"}
            style={{
              backgroundColor: "#1890ff", // 🔵 Ant Design blue
              color: "white",
              border: "none",
              padding: "5px 10px",
              borderRadius: "5px",
              cursor: record.status === "Completed" ? "not-allowed" : "pointer",
              opacity: record.status === "Completed" ? 0.5 : 1,
            }}
          >
            Remainder
          </button>
        </div>
      ),
    },
  ];

  return (
    <div
      style={{
        maxWidth: "1600px",
        margin: "0 auto",
        padding: "20px 40px", // gives space on both sides
      }}
    >
      <div style={{ display: "flex", gap: "8px", marginBottom: 16 }}>
        <Input
          placeholder="Search MDR Number"
          value={mdrNumberFilter}
          onChange={handleMdrNumberFilterChange}
          style={{
            width: "400px",
            padding: "10px",
            borderRadius: "8px",
            border: "1px solid #ccc",
          }}
        />
        <Input
          placeholder="Search Item Code"
          value={itemCodeFilter}
          onChange={handleItemCodeFilterChange}
          style={{
            width: "400px",
            padding: "10px",
            borderRadius: "8px",
            border: "1px solid #ccc",
          }}
        />
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          style={{
            width: "160px",
            padding: "8px",
            borderRadius: "6px",
            border: "1px solid #ccc",
          }}
        >
          <option value="All">All Status</option>
          <option value="Pending">Pending</option>
          <option value="Completed">Completed</option>
        </select>
        <Button
          style={{
            backgroundColor: "#d9d9d9",
            border: "1px solid #ccc",
            color: "#000",
            width: "160px",
            height: "50px",
          }}
          onClick={() => setExportModalVisible(true)}
        >
          Export to Excel
        </Button>

        <Modal
          title="Export Completed MDRs"
          open={exportModalVisible}
          onOk={handleExport}
          onCancel={() => setExportModalVisible(false)}
          okText="Export"
        >
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <label>From Date:</label>
            <DatePicker
              value={fromDate}
              onChange={(date) => setFromDate(date)}
              format="YYYY-MM-DD"
            />
            <label>To Date:</label>
            <DatePicker
              value={toDate}
              onChange={(date) => setToDate(date)}
              format="YYYY-MM-DD"
            />
          </div>
        </Modal>
      </div>
      <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}></div>

      {loading ? (
        <Spin />
      ) : (
        <Table
          columns={columns}
          dataSource={filteredData}
          pagination={{
            ...pagination,
            onChange: (page, pageSize) =>
              setPagination({ current: page, pageSize }),
          }}
          scroll={{ x: "max-content" }}
          bordered
          size="middle"
        />
      )}
    </div>
  );
};

export default ClosingMDR;
