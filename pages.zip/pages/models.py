# from datetime import datetime, timedelta
# import json
# from werkzeug.security import generate_password_hash, check_password_hash
# from flask_sqlalchemy import SQLAlchemy
# from sqlalchemy import event, ForeignKey
# from sqlalchemy.dialects.postgresql import JSON
# import pytz

# db = SQLAlchemy()

# # Timezone for India
# IST = pytz.timezone('Asia/Kolkata')

# def get_ist_time():
#     return datetime.now(pytz.utc).astimezone(IST)

# # User Model
# class User(db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     username = db.Column(db.String(80), unique=True, nullable=False)
#     password_hash = db.Column(db.String(512), nullable=False)
#     is_locked = db.Column(db.Boolean, default=False)
#     failed_attempts = db.Column(db.Integer, default=0)
#     lockout_time = db.Column(db.DateTime, nullable=True)
#     role = db.Column(db.String(1), default='b')  # 's' for superadmin, 'b' for business user

#     def set_password(self, password):
#         self.password_hash = generate_password_hash(password)

#     def check_password(self, password):
#         return check_password_hash(self.password_hash, password)

#     def lock_account(self):
#         """Lock the account and set the lockout time to 15 minutes from now."""
#         self.is_locked = True
#         self.lockout_time = get_ist_time() + timedelta(minutes=1)
#         self.failed_attempts = 0
#         db.session.commit()

#     def unlock_account(self):
#         """Unlock the account if the lockout time has passed."""
#         if self.is_locked and self.lockout_time:
#             lockout_time_aware = self.lockout_time.astimezone(pytz.UTC)  # Convert lockout_time to UTC if it's naive
#             current_time = get_ist_time()  # Get the current IST time (timezone-aware)

#             # Now we can safely compare both timezone-aware datetimes
#             if current_time > lockout_time_aware:
#                 self.is_locked = False
#                 self.lockout_time = None
#                 self.failed_attempts = 0
#                 db.session.commit()


# # Document Model
# class Document(db.Model):
#     __tablename__ = 'document'
    
#     Trip_id = db.Column(db.String(20), primary_key=True, unique=True)
#     timestamp = db.Column(db.DateTime, default=get_ist_time)
#     driver_mobile_number = db.Column(db.String(20), nullable=True)
    
#     # Foreign key for vehicle_number (linked to master_vehicle)
#     vehicle_number = db.Column(db.String(50), ForeignKey('master_vehicle.vehicle_number'), nullable=False)
    
#     # Foreign key for driver_license_number (linked to master_driver)
#     driver_license_number = db.Column(db.String(50), ForeignKey('master_driver.driver_license_number'), nullable=True)
    
#     extracted_text_vehicle = db.Column(JSON, nullable=False)
#     extracted_text_driver = db.Column(JSON, nullable=True)
    
#     num_of_people = db.Column(db.String(50), default=0)
#     loading_or_unloading = db.Column(db.String(50), nullable=True)
#     vehicle_type = db.Column(db.String(50), nullable=True)
#     transporter_name = db.Column(db.String(50), nullable=True)
#     other_transporter_name = db.Column(db.String(120), nullable=True)
#     green_channel = db.Column(db.Boolean, default=False, nullable=True)
#     vehicle_status = db.Column(db.String(50), default="entered", nullable=True)
#     vehicle_doc_remark = db.Column(db.String(500), nullable=True)
#     puc_validity = db.Column(db.DateTime, nullable=True)
#     insurance_validity = db.Column(db.DateTime, nullable=True)
#     license_validity = db.Column(db.DateTime, nullable=True)
#     gate_entry_number = db.Column(db.String(50), nullable=True)
#     gate_exit_status = db.Column(db.String(50), nullable=True)
#     is_puc_valid = db.Column(db.String(10), nullable=True)

#     # Relationship to MasterVehicle and MasterDriver models
#     vehicle = db.relationship('MasterVehicle', backref='documents', lazy=True)
#     driver = db.relationship('MasterDriver', backref='documents', lazy=True)
#     gate_entries = db.relationship('GateEntryDetails', backref='document', lazy=True, cascade="all, delete-orphan")
    
#     def to_dict(self):
#         return {
#             'Trip_id': self.Trip_id,
#             'timestamp': self.timestamp.strftime('%Y-%m-%d %H:%M:%S') if self.timestamp else None,
#             'vehicle_number': self.vehicle_number,
#             'driver_license_number': self.driver_license_number,
#             'extracted_text_vehicle': self.extracted_text_vehicle,
#             'extracted_text_driver': self.extracted_text_driver,
#             'num_of_people': self.num_of_people,
#             'loading_or_unloading': self.loading_or_unloading,
#             'vehicle_type': self.vehicle_type,
#             'transporter_name': self.transporter_name,
#             'other_transporter_name': self.other_transporter_name,
#             'green_channel': self.green_channel,
#             'vehicle_status': self.vehicle_status,
#             'vehicle_doc_remark': self.vehicle_doc_remark,
#             'puc_validity': self.puc_validity,
#             'insurance_validity': self.insurance_validity,
#             'license_validity': self.license_validity,
#             'gate_entry_number': self.gate_entry_number,
#             'is_puc_valid': self.is_puc_valid,
#         }

# # MasterVehicle Model
# class MasterVehicle(db.Model):
#     __tablename__ = 'master_vehicle'
    
#     id = db.Column(db.Integer, primary_key=True, autoincrement=True)
#     vehicle_number = db.Column(db.String(50), unique=True, nullable=False)
#     extracted_text_vehicle = db.Column(JSON, nullable=False)
#     folder_path_vehicle = db.Column(db.String(255), nullable=True)
#     green_channel = db.Column(db.Boolean, default=False, nullable=False)
#     vehicle_doc_remark = db.Column(db.String(500), nullable=True)
#     puc_validity = db.Column(db.DateTime, nullable=True)
#     insurance_validity = db.Column(db.DateTime, nullable=True)


#     def to_dict(self):
#     # If extracted_text_vehicle is already a dictionary, no need to load it again
#         extracted_text_vehicle = self.extracted_text_vehicle
#         if isinstance(self.extracted_text_vehicle, str):
#             extracted_text_vehicle = json.loads(self.extracted_text_vehicle)

#         return {
#             'vehicle_number': self.vehicle_number,
#             'extracted_text_vehicle': extracted_text_vehicle,
#             'folder_path_vehicle': self.folder_path_vehicle,
#             'green_channel': self.green_channel,
#             'vehicle_doc_remark': self.vehicle_doc_remark,
#             'puc_validity': self.puc_validity,
#             'insurance_validity': self.insurance_validity,
#             # Add other relevant fields here
#         }

# # MasterDriver Model
# from sqlalchemy import func  # Import func to use for default timestamp

# class MasterDriver(db.Model):
#     __tablename__ = 'master_driver'
    
#     id = db.Column(db.Integer, primary_key=True, autoincrement=True)
#     driver_mobile_number = db.Column(db.String(50), nullable=False)
#     driver_license_number = db.Column(db.String(50), unique=True, nullable=False)
#     driver_vehicle_number = db.Column(db.String(50), nullable=False)
#     extracted_text_driver = db.Column(JSON, nullable=False)
#     folder_path_driver = db.Column(db.String(255), nullable=True)
#     license_validity = db.Column(db.DateTime, nullable=True)
    
#     # Add created_at and updated_at columns
#     created_at = db.Column(db.DateTime, default=func.now(), nullable=False)
#     updated_at = db.Column(db.DateTime, default=func.now(), onupdate=func.now(), nullable=False)

#     def to_dict(self):
#         extracted_text_driver = self.extracted_text_driver
#         if isinstance(self.extracted_text_driver, str):
#             extracted_text_driver = json.loads(self.extracted_text_driver)
#         return {
#             'id': self.id,
#             'driver_mobile_number': self.driver_mobile_number,
#             'driver_license_number': self.driver_license_number,
#             'driver_vehicle_number': self.driver_vehicle_number,
#             'extracted_text_driver': extracted_text_driver,
#             'folder_path_driver': self.folder_path_driver,
#             'license_validity': self.license_validity,
#             'created_at': self.created_at,  # Include created_at in the dictionary
#             'updated_at': self.updated_at,   # Include updated_at in the dictionary
#         }

    
    
# class TripStatus(db.Model):
#     __tablename__ = 'trip_status'
    
#     id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    
#     # Foreign key linking to Document table (Trip_id)
#     trip_id = db.Column(db.String(20), db.ForeignKey('document.Trip_id'), nullable=False)
#     vehicle_number = db.Column(db.String(20), nullable=False)
#     driver_mobile_number = db.Column(db.String(50),nullable=False)
#     driver_license_number = db.Column(db.String(50),nullable=False)
    
#     location = db.Column(db.String(255), nullable=False)
#     time = db.Column(db.DateTime, default=get_ist_time)  # Timestamp of status entry
#     duration_in = db.Column(db.DateTime, nullable=True)  # This will now be populated with the previous entry's time
#     remark = db.Column(db.String(255), nullable=True)
    
    

    
#     # Relationship with the Document model (One-to-Many)
#     document = db.relationship('Document', backref='trip_status', lazy=True)

#     @property
#     def duration(self):
#         """Calculates the duration between the current 'time' and the previous 'time' for the same trip and vehicle."""
#         # Get the previous entry for the same trip_id and vehicle_number, ordered by time (descending)
#         previous_status = db.session.query(TripStatus)\
#             .filter(TripStatus.trip_id == self.trip_id)\
#             .filter(TripStatus.vehicle_number == self.vehicle_number)\
#             .filter(TripStatus.id < self.id)\
#             .order_by(TripStatus.time.desc())\
#             .first()

#         # If there's no previous status entry, return None (or "00:00:00" if preferred)
#         if not previous_status:
#             return "00:00:00"

#         # Calculate the time difference between current time and previous time
#         time_difference = self.time - previous_status.time

#         # Convert the time difference into total seconds
#         total_seconds = time_difference.total_seconds()

#         # Calculate hours, minutes, and seconds
#         hours, remainder = divmod(total_seconds, 3600)
#         minutes, seconds = divmod(remainder, 60)

#         # Return the formatted time difference as hh:mm:ss
#         return f"{int(hours):02}:{int(minutes):02}:{int(seconds):02}"


   
    
# class LorryReciept(db.Model):
#     __tablename__ = 'lorry_receipt'
    
#     id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    
#     # Foreign key linking to Document table (Trip_id)
#     trip_id = db.Column(db.String(20), ForeignKey('document.Trip_id'), nullable=False)
    
#     invoice_number = db.Column(db.String(255), nullable=False)
    
#     grr_number  = db.Column(db.String(255), nullable=False)
    
#     # Relationship with the Document model (One-to-Many)
#     document = db.relationship('Document', backref='lorry_receipt', lazy=True)
    
# class InvoiceDetails(db.Model):
#     __tablename__ = 'invoice_details'
#     id = db.Column(db.Integer, primary_key=True)
#     item_code = db.Column(db.String(50))
#     item_description = db.Column(db.String(1000))
#     item_quantity = db.Column(db.Integer)
#     item_rate = db.Column(db.Float)
#     item_amount = db.Column(db.Float)
#     hsn_scn = db.Column(db.String(50))
#     po_number = db.Column(db.String(50))
    
#     # Foreign key referencing only `invoice_no` in `MasterInvoice`
#     invoice_no = db.Column(db.String(50), db.ForeignKey('master_invoice.invoice_no'))
    
#     # Establish relationship with `MasterInvoice`
#     invoice = db.relationship('MasterInvoice', backref='invoice_details', lazy=True)

# # Updated MasterInvoice Model
# class MasterInvoice(db.Model):
#     __tablename__ = 'master_invoice'
#     id = db.Column(db.Integer, primary_key=True)
#     po_number = db.Column(db.String(50))
#     po_date = db.Column(db.Date)
#     invoice_no = db.Column(db.String(50), unique=True)
#     invoice_date = db.Column(db.Date)
#     hsn_scn = db.Column(db.String(10))
#     total = db.Column(db.Float)
#     quantity = db.Column(db.Integer)
#     cgst_amount = db.Column(db.Float)
#     cgst_rate = db.Column(db.Float)
#     igst_amount = db.Column(db.Float)
#     igst_rate = db.Column(db.Float)
#     sgst_amount = db.Column(db.Float)
#     sgst_rate = db.Column(db.Float)
#     part_no = db.Column(db.String(50))
#     vendor_name = db.Column(db.String(255))
#     vendor_code = db.Column(db.String(50))

#     # Relationship, using string-based reference
#     # invoice_details = db.relationship('InvoiceDetails', backref='master_invoice', lazy=True)
    
# class MasterVendor(db.Model): 
#     __tablename__ = 'vendor_master'
#     id = db.Column(db.Integer, autoincrement = True)
#     vendor_code = db.Column(db.String(20), primary_key = True, nullable = False)
#     vendor_name = db.Column(db.String(80), nullable = False)
#     location = db.Column(db.String(80), nullable=True)
    
#     def to_dict(self):
#         return {
#             'vendor_code': self.vendor_code,
#             'vendor_name': self.vendor_name,
#             'location': self.location,
#             # Add other relevant fields here
#         }
    
# class GateEntryDetails(db.Model):
#     __tablename__ = 'gate_entry_detail'

#     id = db.Column(db.Integer, autoincrement=True, primary_key=True)
#     gate_entry_number = db.Column(db.String(50), nullable=False)
#     shipment_number = db.Column(db.String(50), nullable=False)
#     invoice_number = db.Column(db.String(50), nullable=True)
#     vendor_code = db.Column(db.String(20), nullable=True)
#     vendor_name = db.Column(db.String(20), nullable=True)
#     invoice_date = db.Column(db.String(10), nullable=True)

#     # Foreign Key linking to Document table (one document can have multiple gate entries)
#     document_trip_id = db.Column(db.String(20), ForeignKey('document.Trip_id'), nullable=False)

#     def to_dict(self):
#         return {
#             'id': self.id,
#             'gate_entry_number': self.gate_entry_number,
#             'shipment_number': self.shipment_number,
#             'invoice_number': self.invoice_number,
#             'vendor_code': self.vendor_code,
#             'vendor_name': self.vendor_name,
#             'invoice_date': self.invoice_date,
#             'document_trip_id': self.document_trip_id
#         }
    
# class MdrMaster(db.Model):
#     __tablename__ = 'mdr_master'

#     id = db.Column(db.Integer, autoincrement=True, primary_key=True)
#     invoice_number = db.Column(db.String(50), nullable=False)
#     invoice_date = db.Column(db.Date, nullable=True)  # Changed to Date type
#     vendor_code = db.Column(db.String(20), nullable=True)
#     vendor_name = db.Column(db.String(50), nullable=True)
#     transporter_name = db.Column(db.String(50), nullable=True)
#     vehicle_number = db.Column(db.String(50), nullable=True)
#     mdr_number = db.Column(db.String(50), nullable=False, unique=True)  # Ensure uniqueness for FK reference
#     mdr_raised_as = db.Column(db.String(50), nullable=True)
#     mdr_date = db.Column(db.Date, nullable=True)  # Changed to Date type
#     grr_mtn_sticker_number = db.Column(db.String(50), nullable=True)
#     lr_field = db.Column(db.String(50), nullable=True)
#     grr_number = db.Column(db.String(50), nullable=True)
#     unloading_location = db.Column(db.String(100), nullable=True)
#     prepared_by = db.Column(db.String(50), nullable=True)
#     mdr_remarks_1 = db.Column(db.String(200), nullable=True)
#     mdr_remarks_2 = db.Column(db.String(200), nullable=True)
#     email_id_cc = db.Column(db.String(50), nullable=True)
#     email_id_to = db.Column(db.String(50), nullable=True)
#     original_message_id = db.Column(db.String(100), nullable=True) 


#     # Relationship with MdrDetails
#     mdr_details = db.relationship('MdrDetails', backref='mdr_master', lazy=True, cascade="all, delete-orphan")

#     def to_dict(self):
#         return {
#             "id": self.id,
#             "invoice_number": self.invoice_number,
#             "invoice_date": self.invoice_date.isoformat() if self.invoice_date else None,
#             "vendor_code": self.vendor_code,
#             "vendor_name": self.vendor_name,
#             "transporter_name": self.transporter_name,
#             "vehicle_number": self.vehicle_number,
#             "mdr_number": self.mdr_number,
#             "mdr_raised_as": self.mdr_raised_as,
#             "mdr_date": self.mdr_date.isoformat() if self.mdr_date else None,
#             "grr_mtn_sticker_number": self.grr_mtn_sticker_number,
#             "unloading_location": self.unloading_location,
#             "lr_field": self.lr_field,
#             "grr_number": self.grr_number,
#             "prepared_by": self.prepared_by,
#             "mdr_remarks_1": self.mdr_remarks_1,
#             "mdr_remarks_2": self.mdr_remarks_2,
#             "email_id_cc": self.email_id_cc,
#             "email_id_to": self.email_id_to,
#             "original_message_id": self.original_message_id,
#             "mdr_details": [detail.to_dict() for detail in self.mdr_details] if self.mdr_details else []
#         }

# class MdrDetails(db.Model):
#     __tablename__ = 'mdr_details'

#     id = db.Column(db.Integer, autoincrement=True, primary_key=True)  # Added primary key
#     mdr_number = db.Column(db.String(50), ForeignKey('mdr_master.mdr_number'), nullable=False)
#     invoice_number = db.Column(db.String(20), nullable=True)
#     invoice_date = db.Column(db.Date, nullable=True)  # Changed to Date type
#     item_code = db.Column(db.String(20), nullable=True)
#     item_description = db.Column(db.String(200), nullable=True)
#     item_quantity_actual = db.Column(db.String(10), nullable=True)
#     quantity_as_per_challan = db.Column(db.String(10), nullable=True)
#     excess_shortfall_quantity = db.Column(db.String(10), nullable=True)
#     number_of_boxes_lr = db.Column(db.String(20), nullable=True)
#     number_of_boxes_lr_recieved = db.Column(db.String(20), nullable=True)

#     def to_dict(self):
#         return {
#             "id": self.id,
#             "mdr_number": self.mdr_number,
#             "invoice_number": self.invoice_number,
#             "invoice_date": self.invoice_date.isoformat() if self.invoice_date else None,
#             "item_code": self.item_code,
#             "item_description": self.item_description,
#             "item_quantity_actual": self.item_quantity_actual,
#             "quantity_as_per_challan": self.quantity_as_per_challan,
#             "excess_shortfall_quantity": self.excess_shortfall_quantity,
#             "number_of_boxes_lr": self.number_of_boxes_lr,
#             "number_of_boxes_lr_recieved": self.number_of_boxes_lr_recieved,
#         }

# class DockInOutMaster(db.Model):
#     __tablename__ = "dock_in_out_master"

#     id = db.Column(db.Integer, primary_key=True, autoincrement=True)
#     gate_entry_number = db.Column(db.String(50), unique=True, nullable=False)  # Unique gate entry
#     vehicle_number = db.Column(db.String(50), nullable=True)
#     trip_id = db.Column(db.String(50), unique=True, nullable=True)  # Make trip_id unique
#     transporter_name = db.Column(db.String(50), nullable=True)
#     grr_status = db.Column(db.String(50), nullable=True)
#     total_invoices = db.Column(db.Integer, nullable=True)
#     loading_unloading = db.Column(db.String(50), nullable=True)
#     material_category = db.Column(db.String(100), nullable=True)
#     docked_location = db.Column(db.String(50), nullable=True)

#     # One-to-many relationship (DockInOutMaster → DockInOutDetails)
#     dock_details = db.relationship("DockInOutDetails", backref="dock_master", lazy="dynamic", cascade="all, delete-orphan")

#     def to_dict(self):
#         return {
#             "id": self.id,
#             "gate_entry_number": self.gate_entry_number,
#             "vehicle_number": self.vehicle_number,
#             "trip_id": self.trip_id,
#             "transporter_name": self.transporter_name,
#             "grr_status": self.grr_status,
#             "total_invoices": self.total_invoices,
#             "loading_unloading": self.loading_unloading,
#             "material_category": self.material_category,
#             "docked_location": self.docked_location,
#             "dock_details": [detail.to_dict() for detail in self.dock_details],  # Fetch all related details
#         }


# class DockInOutDetails(db.Model):
#     __tablename__ = "dock_in_out_details"

#     id = db.Column(db.Integer, primary_key=True, autoincrement=True)
#     gate_entry_number = db.Column(db.String(50), nullable=False)  # Foreign Key
#     vehicle_number = db.Column(db.String(50), nullable=True)
#     trip_id = db.Column(db.String(50), db.ForeignKey("dock_in_out_master.trip_id"), nullable=True)  # Foreign Key
#     docked_location = db.Column(db.String(50), nullable=False)  # E.g., "EStore"
#     dock_location_invoice = db.Column(db.String(50), nullable=True)
#     start_time = db.Column(db.Time, nullable=True)  # Time when dock-in happens
#     end_time = db.Column(db.Time, nullable=True)  # Time when dock-out happens
#     docked_duration = db.Column(db.String(20), nullable=True, default="-")  # Time spent docked
#     remarks = db.Column(db.String(255), nullable=True)

#     def to_dict(self):
#         return {
#             "id": self.id,
#             "gate_entry_number": self.gate_entry_number,
#             "vehicle_number": self.vehicle_number,
#             "trip_id": self.trip_id,
#             "docked_location": self.docked_location,
#             "dock_location_invoice": self.dock_location_invoice,
#             "start_time": self.start_time.strftime("%H:%M:%S") if self.start_time else None,
#             "end_time": self.end_time.strftime("%H:%M:%S") if self.end_time else None,
#             "docked_duration": self.docked_duration,
#             "remarks": self.remarks,
#         }

    
# class OpenASN(db.Model):
#     __tablename__ = 'open_asn'

#     org_name = db.Column(db.String(255), nullable=False)
#     location_code = db.Column(db.String(100), nullable=False)
#     vendor_code = db.Column(db.Integer, nullable=False)
#     vendor_name = db.Column(db.String(255), nullable=False)
#     vsc = db.Column(db.BigInteger, nullable=False)
#     po_dt = db.Column(db.String(50), nullable=False)  # Consider converting to DATE
#     po_buyer_name = db.Column(db.String(255), nullable=False)
#     po_buyer_email = db.Column(db.String(255), nullable=False)
#     shipment_num = db.Column(db.String(255),primary_key=True, nullable=False)
#     challan_date = db.Column(db.String(50), nullable=False)  # Consider converting to DATE
#     pending_days = db.Column(db.String(50), nullable=False)  # Convert to Integer if necessary
#     item = db.Column(db.String(100), nullable=False)
#     item_desc = db.Column(db.Text, nullable=False)
#     asn_qty = db.Column(db.Integer, nullable=False)
#     base_val = db.Column(db.Numeric(12,2), nullable=False)
#     item_type = db.Column(db.String(100), nullable=False)
#     default_subinventory = db.Column(db.String(255), nullable=True)
#     hazard_class = db.Column(db.String(100), nullable=True)
#     tax_percent = db.Column(db.Float, nullable=True)
#     tax_category_name = db.Column(db.String(255), nullable=True)
#     invoice_value = db.Column(db.Numeric(12,2), nullable=False)

#     def to_dict(self):
#         return {
#             "org_name": self.org_name,
#             "location_code": self.location_code,
#             "vendor_code": self.vendor_code,
#             "vendor_name": self.vendor_name,
#             "vsc": self.vsc,
#             "po_dt": self.po_dt,
#             "po_buyer_name": self.po_buyer_name,
#             "po_buyer_email": self.po_buyer_email,
#             "shipment_num": self.shipment_num,
#             "challan_date": self.challan_date,
#             "pending_days": self.pending_days,
#             "item": self.item,
#             "item_desc": self.item_desc,
#             "asn_qty": self.asn_qty,
#             "base_val": float(self.base_val),  # Convert to float for JSON serialization
#             "item_type": self.item_type,
#             "default_subinventory": self.default_subinventory,
#             "hazard_class": self.hazard_class,
#             "tax_percent": self.tax_percent,
#             "tax_category_name": self.tax_category_name,
#             "invoice_value": float(self.invoice_value),  # Convert to float for JSON serialization
#         }

    
    
    
# # vehicle = MasterVehicle.query.filter_by(vehicle_number='XYZ123').first()
# # vehicle_documents = vehicle.documents  # Access all related documents

# # driver = MasterDriver.query.filter_by(driver_license_number='DL123456').first()
# # driver_documents = driver.documents  # Access all related documents

# # Query all trip statuses for a specific document:
# # document = Document.query.filter_by(Trip_id='TRIP123').first()
# # statuses = document.trip_statuses  # Access all related trip statuses

# # Calculate the duration for a specific trip status:
# # trip_status = TripStatus.query.filter_by(id=1).first()
# # duration_in_hours = trip_status.duration  # Access the calculated duration

# # Fetch document and its related gate entries
# # doc = Document.query.filter_by(Trip_id="TRIP123").first()
# # print(doc.to_dict())  # This will include gate entry details as well



from datetime import datetime, timedelta
import json
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import event, ForeignKey
from sqlalchemy.dialects.postgresql import JSON
import pytz

db = SQLAlchemy()

# Timezone for India
IST = pytz.timezone('Asia/Kolkata')

def get_ist_time():
    return datetime.now(pytz.utc).astimezone(IST)

# User Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(512), nullable=False)
    is_locked = db.Column(db.Boolean, default=False)
    failed_attempts = db.Column(db.Integer, default=0)
    lockout_time = db.Column(db.DateTime, nullable=True)
    role = db.Column(db.String(1), default='b')  # 's' for superadmin, 'b' for business user

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def lock_account(self):
        """Lock the account and set the lockout time to 15 minutes from now."""
        self.is_locked = True
        self.lockout_time = get_ist_time() + timedelta(minutes=1)
        self.failed_attempts = 0
        db.session.commit()

    def unlock_account(self):
        """Unlock the account if the lockout time has passed."""
        if self.is_locked and self.lockout_time:
            lockout_time_aware = self.lockout_time.astimezone(pytz.UTC)  # Convert lockout_time to UTC if it's naive
            current_time = get_ist_time()  # Get the current IST time (timezone-aware)

            # Now we can safely compare both timezone-aware datetimes
            if current_time > lockout_time_aware:
                self.is_locked = False
                self.lockout_time = None
                self.failed_attempts = 0
                db.session.commit()


# Document Model
class Document(db.Model):
    __tablename__ = 'document'
    
    Trip_id = db.Column(db.String(20), primary_key=True, unique=True)
    timestamp = db.Column(db.DateTime, default=get_ist_time)
    driver_mobile_number = db.Column(db.String(20), nullable=True)
    
    # Foreign key for vehicle_number (linked to master_vehicle)
    vehicle_number = db.Column(db.String(50), ForeignKey('master_vehicle.vehicle_number'), nullable=False)
    
    # Foreign key for driver_license_number (linked to master_driver)
    driver_license_number = db.Column(db.String(50), ForeignKey('master_driver.driver_license_number'), nullable=True)
    
    extracted_text_vehicle = db.Column(JSON, nullable=False)
    extracted_text_driver = db.Column(JSON, nullable=True)
    
    num_of_people = db.Column(db.String(50), default=0)
    loading_or_unloading = db.Column(db.String(50), nullable=True)
    vehicle_type = db.Column(db.String(50), nullable=True)
    transporter_name = db.Column(db.String(50), nullable=True)
    other_transporter_name = db.Column(db.String(120), nullable=True)
    green_channel = db.Column(db.Boolean, default=False, nullable=True)
    vehicle_status = db.Column(db.String(50), default="entered", nullable=True)
    vehicle_doc_remark = db.Column(db.String(500), nullable=True)
    puc_validity = db.Column(db.DateTime, nullable=True)
    insurance_validity = db.Column(db.DateTime, nullable=True)
    license_validity = db.Column(db.DateTime, nullable=True)
    gate_entry_number = db.Column(db.String(50), nullable=True)
    gate_entry_in_time = db.Column(db.String(50), nullable=True)
    gate_entry_status = db.Column(db.String(50), nullable=True)
    gate_entry_out_time = db.Column(db.String(50), nullable=True)
    gate_exit_status = db.Column(db.String(50), nullable=True)
    gate_entry_remarks = db.Column(db.String(200), nullable=False)
    is_puc_valid = db.Column(db.String(10), nullable=True)

    # Relationship to MasterVehicle and MasterDriver models
    vehicle = db.relationship('MasterVehicle', backref='documents', lazy=True)
    driver = db.relationship('MasterDriver', backref='documents', lazy=True)
    gate_entries = db.relationship('GateEntryDetails', backref='document', lazy=True, cascade="all, delete-orphan")
    
    def to_dict(self):
        return {
            'Trip_id': self.Trip_id,
            'timestamp': self.timestamp.strftime('%Y-%m-%d %H:%M:%S') if self.timestamp else None,
            'vehicle_number': self.vehicle_number,
            'driver_license_number': self.driver_license_number,
            'extracted_text_vehicle': self.extracted_text_vehicle,
            'extracted_text_driver': self.extracted_text_driver,
            'num_of_people': self.num_of_people,
            'loading_or_unloading': self.loading_or_unloading,
            'vehicle_type': self.vehicle_type,
            'transporter_name': self.transporter_name,
            'other_transporter_name': self.other_transporter_name,
            'green_channel': self.green_channel,
            'vehicle_status': self.vehicle_status,
            'vehicle_doc_remark': self.vehicle_doc_remark,
            'puc_validity': self.puc_validity,
            'insurance_validity': self.insurance_validity,
            'license_validity': self.license_validity,
            'gate_entry_number': self.gate_entry_number,
            'gate_entry_in_time': self.gate_entry_in_time,
            'gate_entry_status': self.gate_entry_status,
            'gate_entry_out_time': self.gate_entry_out_time,
            'gate_entry_remarks': self.gate_entry_remarks,
            'gate_exit_status': self.gate_exit_status,
            'is_puc_valid': self.is_puc_valid,
        }

# MasterVehicle Model
class MasterVehicle(db.Model):
    __tablename__ = 'master_vehicle'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vehicle_number = db.Column(db.String(50), unique=True, nullable=False)
    extracted_text_vehicle = db.Column(JSON, nullable=False)
    folder_path_vehicle = db.Column(db.String(255), nullable=True)
    green_channel = db.Column(db.Boolean, default=False, nullable=False)
    vehicle_doc_remark = db.Column(db.String(500), nullable=True)
    puc_validity = db.Column(db.DateTime, nullable=True)
    insurance_validity = db.Column(db.DateTime, nullable=True)


    def to_dict(self):
    # If extracted_text_vehicle is already a dictionary, no need to load it again
        extracted_text_vehicle = self.extracted_text_vehicle
        if isinstance(self.extracted_text_vehicle, str):
            extracted_text_vehicle = json.loads(self.extracted_text_vehicle)

        return {
            'vehicle_number': self.vehicle_number,
            'extracted_text_vehicle': extracted_text_vehicle,
            'folder_path_vehicle': self.folder_path_vehicle,
            'green_channel': self.green_channel,
            'vehicle_doc_remark': self.vehicle_doc_remark,
            'puc_validity': self.puc_validity,
            'insurance_validity': self.insurance_validity,
            # Add other relevant fields here
        }

# MasterDriver Model
from sqlalchemy import func  # Import func to use for default timestamp

class MasterDriver(db.Model):
    __tablename__ = 'master_driver'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    driver_mobile_number = db.Column(db.String(50), nullable=False)
    driver_license_number = db.Column(db.String(50), unique=True, nullable=False)
    driver_vehicle_number = db.Column(db.String(50), nullable=False)
    extracted_text_driver = db.Column(JSON, nullable=False)
    folder_path_driver = db.Column(db.String(255), nullable=True)
    license_validity = db.Column(db.DateTime, nullable=True)
    
    # Add created_at and updated_at columns
    created_at = db.Column(db.DateTime, default=func.now(), nullable=False)
    updated_at = db.Column(db.DateTime, default=func.now(), onupdate=func.now(), nullable=False)

    def to_dict(self):
        extracted_text_driver = self.extracted_text_driver
        if isinstance(self.extracted_text_driver, str):
            extracted_text_driver = json.loads(self.extracted_text_driver)
        return {
            'id': self.id,
            'driver_mobile_number': self.driver_mobile_number,
            'driver_license_number': self.driver_license_number,
            'driver_vehicle_number': self.driver_vehicle_number,
            'extracted_text_driver': extracted_text_driver,
            'folder_path_driver': self.folder_path_driver,
            'license_validity': self.license_validity,
            'created_at': self.created_at,  # Include created_at in the dictionary
            'updated_at': self.updated_at,   # Include updated_at in the dictionary
        }

    
    
class TripStatus(db.Model):
    __tablename__ = 'trip_status'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    
    # Foreign key linking to Document table (Trip_id)
    trip_id = db.Column(db.String(20), db.ForeignKey('document.Trip_id'), nullable=False)
    vehicle_number = db.Column(db.String(20), nullable=False)
    driver_mobile_number = db.Column(db.String(50),nullable=False)
    driver_license_number = db.Column(db.String(50),nullable=False)
    
    location = db.Column(db.String(255), nullable=False)
    time = db.Column(db.DateTime, default=get_ist_time)  # Timestamp of status entry
    duration_in = db.Column(db.DateTime, nullable=True)  # This will now be populated with the previous entry's time
    remark = db.Column(db.String(255), nullable=True)
    
    

    
    # Relationship with the Document model (One-to-Many)
    document = db.relationship('Document', backref='trip_status', lazy=True)

    @property
    def duration(self):
        """Calculates the duration between the current 'time' and the previous 'time' for the same trip and vehicle."""
        # Get the previous entry for the same trip_id and vehicle_number, ordered by time (descending)
        previous_status = db.session.query(TripStatus)\
            .filter(TripStatus.trip_id == self.trip_id)\
            .filter(TripStatus.vehicle_number == self.vehicle_number)\
            .filter(TripStatus.id < self.id)\
            .order_by(TripStatus.time.desc())\
            .first()

        # If there's no previous status entry, return None (or "00:00:00" if preferred)
        if not previous_status:
            return "00:00:00"

        # Calculate the time difference between current time and previous time
        time_difference = self.time - previous_status.time

        # Convert the time difference into total seconds
        total_seconds = time_difference.total_seconds()

        # Calculate hours, minutes, and seconds
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)

        # Return the formatted time difference as hh:mm:ss
        return f"{int(hours):02}:{int(minutes):02}:{int(seconds):02}"


   
    
class LorryReciept(db.Model):
    __tablename__ = 'lorry_receipt'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    
    # Foreign key linking to Document table (Trip_id)
    trip_id = db.Column(db.String(20), ForeignKey('document.Trip_id'), nullable=False)
    
    invoice_number = db.Column(db.String(255), nullable=False)
    
    grr_number  = db.Column(db.String(255), nullable=False)
    
    # Relationship with the Document model (One-to-Many)
    document = db.relationship('Document', backref='lorry_receipt', lazy=True)
    
class InvoiceDetails(db.Model):
    __tablename__ = 'invoice_details'
    id = db.Column(db.Integer, primary_key=True)
    item_code = db.Column(db.String(50))
    item_description = db.Column(db.String(1000))
    item_quantity = db.Column(db.Integer)
    item_rate = db.Column(db.Float)
    item_amount = db.Column(db.Float)
    hsn_scn = db.Column(db.String(50))
    po_number = db.Column(db.String(50))
    
    # Foreign key referencing only `invoice_no` in `MasterInvoice`
    invoice_no = db.Column(db.String(50), db.ForeignKey('master_invoice.invoice_no'))
    
    # Establish relationship with `MasterInvoice`
    invoice = db.relationship('MasterInvoice', backref='invoice_details', lazy=True)

# Updated MasterInvoice Model
class MasterInvoice(db.Model):
    __tablename__ = 'master_invoice'
    id = db.Column(db.Integer, primary_key=True)
    po_number = db.Column(db.String(50))
    po_date = db.Column(db.Date)
    invoice_no = db.Column(db.String(50), unique=True)
    invoice_date = db.Column(db.Date)
    hsn_scn = db.Column(db.String(10))
    total = db.Column(db.Float)
    quantity = db.Column(db.Integer)
    cgst_amount = db.Column(db.Float)
    cgst_rate = db.Column(db.Float)
    igst_amount = db.Column(db.Float)
    igst_rate = db.Column(db.Float)
    sgst_amount = db.Column(db.Float)
    sgst_rate = db.Column(db.Float)
    part_no = db.Column(db.String(50))
    vendor_name = db.Column(db.String(255))
    vendor_code = db.Column(db.String(50))

    # Relationship, using string-based reference
    # invoice_details = db.relationship('InvoiceDetails', backref='master_invoice', lazy=True)
    
class MasterVendor(db.Model): 
    __tablename__ = 'vendor_master'
    id = db.Column(db.Integer, autoincrement = True)
    vendor_code = db.Column(db.String(20), primary_key = True, nullable = False)
    vendor_name = db.Column(db.String(80), nullable = False)
    location = db.Column(db.String(80), nullable=True)
    
    def to_dict(self):
        return {
            'vendor_code': self.vendor_code,
            'vendor_name': self.vendor_name,
            'location': self.location,
            # Add other relevant fields here
        }
    
class GateEntryDetails(db.Model):
    __tablename__ = 'gate_entry_detail'

    id = db.Column(db.Integer, autoincrement=True, primary_key=True)
    gate_entry_number = db.Column(db.String(50), nullable=False)
    shipment_number = db.Column(db.String(50), nullable=False)
    invoice_number = db.Column(db.String(50), nullable=True)
    vendor_code = db.Column(db.String(20), nullable=True)
    vendor_name = db.Column(db.String(20), nullable=True)
    invoice_date = db.Column(db.String(10), nullable=True)

    # Foreign Key linking to Document table (one document can have multiple gate entries)
    document_trip_id = db.Column(db.String(20), ForeignKey('document.Trip_id'), nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'gate_entry_number': self.gate_entry_number,
            'shipment_number': self.shipment_number,
            'invoice_number': self.invoice_number,
            'vendor_code': self.vendor_code,
            'vendor_name': self.vendor_name,
            'invoice_date': self.invoice_date,
            'document_trip_id': self.document_trip_id
        }
    
class GateOutDetails(db.Model):
    __tablename__ = 'gate_out_detail'

    id = db.Column(db.Integer, autoincrement=True, primary_key=True)
    gate_entry_number = db.Column(db.String(50), nullable=False)
    invoice_number = db.Column(db.String(50), nullable=True)

    # Foreign Key linking to Document table (one document can have multiple gate entries)
    document_trip_id = db.Column(db.String(20), ForeignKey('document.Trip_id'), nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'gate_entry_number': self.gate_entry_number,
            'invoice_number': self.invoice_number,
            'document_trip_id': self.document_trip_id
        }
    
class MdrMaster(db.Model):
    __tablename__ = 'mdr_master'

    id = db.Column(db.Integer, autoincrement=True, primary_key=True)
    invoice_number = db.Column(db.String(500), nullable=False)
    invoice_date = db.Column(db.Date, nullable=True)  # Changed to Date type
    vendor_code = db.Column(db.String(50), nullable=True)
    vendor_name = db.Column(db.String(100), nullable=True)
    transporter_name = db.Column(db.String(50), nullable=True)
    vehicle_number = db.Column(db.String(50), nullable=True)
    mdr_number = db.Column(db.String(50), nullable=False, unique=True)  # Ensure uniqueness for FK reference
    mdr_raised_as = db.Column(db.String(50), nullable=True)
    mdr_date = db.Column(db.Date, nullable=True)  # Changed to Date type
    grr_mtn_sticker_number = db.Column(db.String(500), nullable=True)
    lr_field = db.Column(db.String(100), nullable=True)
    grr_number = db.Column(db.String(100), nullable=True)
    unloading_location = db.Column(db.String(100), nullable=True)
    prepared_by = db.Column(db.String(50), nullable=True)
    mdr_remarks_1 = db.Column(db.String(200), nullable=True)
    mdr_remarks_2 = db.Column(db.String(200), nullable=True)
    email_id_cc = db.Column(db.String(500), nullable=True)
    email_id_to = db.Column(db.String(500), nullable=True)
    email_id_to_logistic = db.Column(db.String(500), nullable=True)
    # user_mdr = db.Column(db.String(50), nullable=True)
    sub_mdr_number=db.Column(db.Integer)
    original_message_id = db.Column(db.String(200), nullable=True)



    # Relationship with MdrDetails
    mdr_details = db.relationship('MdrDetails', backref='mdr_master', lazy=True, cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "id": self.id,
            "invoice_number": self.invoice_number,
            "invoice_date": self.invoice_date.isoformat() if self.invoice_date else None,
            "vendor_code": self.vendor_code,
            "vendor_name": self.vendor_name,
            "transporter_name": self.transporter_name,
            "vehicle_number": self.vehicle_number,
            "mdr_number": self.mdr_number,
            "mdr_raised_as": self.mdr_raised_as,
            "mdr_date": self.mdr_date.isoformat() if self.mdr_date else None,
            "grr_mtn_sticker_number": self.grr_mtn_sticker_number,
            "unloading_location": self.unloading_location,
            "lr_field": self.lr_field,
            "grr_number": self.grr_number,
            "prepared_by": self.prepared_by,
            "mdr_remarks_1": self.mdr_remarks_1,
            "mdr_remarks_2": self.mdr_remarks_2,
            "email_id_cc": self.email_id_cc,
            "email_id_to": self.email_id_to,
            "email_id_to_logistic": self.email_id_to_logistic,
            "sub_mdr_number":self.sub_mdr_number,

            "mdr_details": [detail.to_dict() for detail in self.mdr_details] if self.mdr_details else []
        }

class MdrDetails(db.Model):
    __tablename__ = 'mdr_details'

    id = db.Column(db.Integer, autoincrement=True, primary_key=True)  # Added primary key
    mdr_number = db.Column(db.String(50), ForeignKey('mdr_master.mdr_number'), nullable=False)
    invoice_number = db.Column(db.String(500), nullable=True)
    invoice_date = db.Column(db.Date, nullable=True)  # Changed to Date type
    item_code = db.Column(db.String(100), nullable=True)
    item_description = db.Column(db.String(200), nullable=True)
    item_quantity_actual = db.Column(db.String(10), nullable=True)
    quantity_as_per_challan = db.Column(db.String(10), nullable=True)
    uom = db.Column(db.String(50), nullable=True)
    excess_shortfall_quantity = db.Column(db.String(100), nullable=True)
    number_of_boxes_lr = db.Column(db.String(20), nullable=True)
    number_of_boxes_lr_recieved = db.Column(db.String(20), nullable=True)
    mdr_remarks_1=db.Column(db.String(200), nullable=True)

    def to_dict(self):
        return {
            "id": self.id,
            "mdr_number": self.mdr_number,
            "invoice_number": self.invoice_number,
            "invoice_date": self.invoice_date.isoformat() if self.invoice_date else None,
            "item_code": self.item_code,
            "item_description": self.item_description,
            "item_quantity_actual": self.item_quantity_actual,
            "quantity_as_per_challan": self.quantity_as_per_challan,
            "excess_shortfall_quantity": self.excess_shortfall_quantity,
            "uom": self.uom,
            "number_of_boxes_lr": self.number_of_boxes_lr,
            "number_of_boxes_lr_recieved": self.number_of_boxes_lr_recieved,
            "mdr_remarks_1": self.mdr_remarks_1,
        }
        


class ClosingMDRStatus(db.Model):
    __tablename__ = "closing_mdr_status"
 
    id = db.Column(db.Integer, primary_key=True)
    mdr_number = db.Column(db.String(100), nullable=False)
    item_code = db.Column(db.String(100), nullable=False)
 
    # ✅ Composite Unique Constraint
    __table_args__ = (
        db.UniqueConstraint('mdr_number', 'item_code', name='uq_mdr_item'),
    )
 
    invoice_number = db.Column(db.String(500))
    invoice_date = db.Column(db.Date)
    vendor_code = db.Column(db.String(100))
    vendor_name = db.Column(db.String(500))
    transporter_name = db.Column(db.String(100))
    vehicle_number = db.Column(db.String(100))
    mdr_date = db.Column(db.Date)
    grr_mtn_sticker_number = db.Column(db.String(100))
    lr_field = db.Column(db.String(100))
    unloading_location = db.Column(db.String(100))
    sub_mdr_number = db.Column(db.Integer)
    email_id_cc = db.Column(db.String(500))
    email_id_to = db.Column(db.String(500))
    email_id_to_logistic = db.Column(db.String(500))
    item_description = db.Column(db.Text)
    item_quantity_actual = db.Column(db.String(100))
    quantity_as_per_challan = db.Column(db.String(100))
    excess_shortfall_quantity = db.Column(db.String(100))
    number_of_boxes_lr = db.Column(db.String(100))
    number_of_boxes_lr_recieved = db.Column(db.String(100))
    mdr_remarks_1 = db.Column(db.String(500))
    closing_mdr_no = db.Column(db.String(100))
    completed_date = db.Column(db.Date)
    age = db.Column(db.Integer)
    close_reason = db.Column(db.String(200))
    document_no = db.Column(db.String(200))
    debit_to = db.Column(db.String(200))
    debited_amount = db.Column(db.Float)
    debit_note_no_supplier = db.Column(db.String(200))
    series_no_1 = db.Column(db.String(200))
    nfa_days_1 = db.Column(db.String(200))
    # series_no_2 = db.Column(db.String(200))
    # nfa_days_2 = db.Column(db.String(200))
    rdn_no = db.Column(db.String(200))
    debit_note_no_transporter = db.Column(db.String(200))
    credit_note_no = db.Column(db.String(200))
    debit_note = db.Column(db.String(200))
    status = db.Column(db.String(100))
 
    def to_dict(self):
        return {
            "mdr_number": self.mdr_number,
            "item_code": self.item_code,
            "invoice_number": self.invoice_number,
            "invoice_date": self.invoice_date,
            "vendor_code": self.vendor_code,
            "vendor_name": self.vendor_name,
            "transporter_name": self.transporter_name,
            "vehicle_number": self.vehicle_number,
            "mdr_date": self.mdr_date,
            "grr_mtn_sticker_number": self.grr_mtn_sticker_number,
            "lr_field": self.lr_field,
            "unloading_location": self.unloading_location,
            "sub_mdr_number": self.sub_mdr_number,
            "email_id_cc": self.email_id_cc,
            "email_id_to": self.email_id_to,
            "email_id_to_logistic": self.email_id_to_logistic,
            "item_description": self.item_description,
            "item_quantity_actual": self.item_quantity_actual,
            "quantity_as_per_challan": self.quantity_as_per_challan,
            "excess_shortfall_quantity": self.excess_shortfall_quantity,
            "number_of_boxes_lr": self.number_of_boxes_lr,
            "number_of_boxes_lr_recieved": self.number_of_boxes_lr_recieved,
            "mdr_remarks_1": self.mdr_remarks_1,
            "closing_mdr_no": self.closing_mdr_no,
            "status": self.status,
            "completed_date": self.completed_date,
            "age": self.age,
            "close_reason": self.close_reason,
            "document_no": self.document_no,
            "debit_to": self.debit_to,
            "debited_amount": self.debited_amount,
            "debit_note_no_supplier": self.debit_note_no_supplier,
            "series_no_1": self.series_no_1,
            "nfa_days_1": self.nfa_days_1,
            # "series_no_2": self.series_no_2,
            # "nfa_days_2": self.nfa_days_2,
            "rdn_no": self.rdn_no,
            "debit_note_no_transporter": self.debit_note_no_transporter,
            "credit_note_no": self.credit_note_no,
            "debit_note": self.debit_note
        }
 


class DockInOutMaster(db.Model):
    __tablename__ = "dock_in_out_master"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    gate_entry_number = db.Column(db.String(50), unique=True, nullable=False)  # Unique gate entry
    vehicle_number = db.Column(db.String(50), nullable=True)
    trip_id = db.Column(db.String(50), unique=True, nullable=True)  # Make trip_id unique
    transporter_name = db.Column(db.String(50), nullable=True)
    grr_status = db.Column(db.String(50), nullable=True)
    total_invoices = db.Column(db.Integer, nullable=True)
    loading_unloading = db.Column(db.String(50), nullable=True)
    material_category = db.Column(db.String(100), nullable=True)
    docked_location = db.Column(db.String(50), nullable=True)

    # One-to-many relationship (DockInOutMaster → DockInOutDetails)
    dock_details = db.relationship("DockInOutDetails", backref="dock_master", lazy="dynamic", cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "id": self.id,
            "gate_entry_number": self.gate_entry_number,
            "vehicle_number": self.vehicle_number,
            "trip_id": self.trip_id,
            "transporter_name": self.transporter_name,
            "grr_status": self.grr_status,
            "total_invoices": self.total_invoices,
            "loading_unloading": self.loading_unloading,
            "material_category": self.material_category,
            "docked_location": self.docked_location,
            "dock_details": [detail.to_dict() for detail in self.dock_details],  # Fetch all related details
        }


class DockInOutDetails(db.Model):
    __tablename__ = "dock_in_out_details"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    gate_entry_number = db.Column(db.String(50), nullable=False)  # Foreign Key
    vehicle_number = db.Column(db.String(50), nullable=True)
    trip_id = db.Column(db.String(50), db.ForeignKey("dock_in_out_master.trip_id"), nullable=True)  # Foreign Key
    docked_location = db.Column(db.String(50), nullable=False)  # E.g., "EStore"
    dock_location_invoice = db.Column(db.String(50), nullable=True)
    start_time = db.Column(db.Time, nullable=True)  # Time when dock-in happens
    end_time = db.Column(db.Time, nullable=True)  # Time when dock-out happens
    docked_duration = db.Column(db.String(20), nullable=True, default="-")  # Time spent docked
    remarks = db.Column(db.String(255), nullable=True)

    def to_dict(self):
        return {
            "id": self.id,
            "gate_entry_number": self.gate_entry_number,
            "vehicle_number": self.vehicle_number,
            "trip_id": self.trip_id,
            "docked_location": self.docked_location,
            "dock_location_invoice": self.dock_location_invoice,
            "start_time": self.start_time.strftime("%H:%M:%S") if self.start_time else None,
            "end_time": self.end_time.strftime("%H:%M:%S") if self.end_time else None,
            "docked_duration": self.docked_duration,
            "remarks": self.remarks,
        }

    
class OpenASN(db.Model):
    __tablename__ = 'open_asn'

    org_name = db.Column(db.String(255), nullable=False)
    location_code = db.Column(db.String(100), nullable=False)
    vendor_code = db.Column(db.Integer, nullable=False)
    vendor_name = db.Column(db.String(255), nullable=False)
    vsc = db.Column(db.BigInteger, nullable=False)
    po_dt = db.Column(db.String(50), nullable=False)  # Consider converting to DATE
    po_buyer_name = db.Column(db.String(255), nullable=False)
    po_buyer_email = db.Column(db.String(255), nullable=False)
    shipment_num = db.Column(db.String(255),primary_key=True, nullable=False)
    challan_date = db.Column(db.String(50), nullable=False)  # Consider converting to DATE
    pending_days = db.Column(db.String(50), nullable=False)  # Convert to Integer if necessary
    item = db.Column(db.String(100), nullable=False)
    item_desc = db.Column(db.Text, nullable=False)
    asn_qty = db.Column(db.Integer, nullable=False)
    base_val = db.Column(db.Numeric(12,2), nullable=False)
    item_type = db.Column(db.String(100), nullable=False)
    default_subinventory = db.Column(db.String(255), nullable=True)
    hazard_class = db.Column(db.String(100), nullable=True)
    tax_percent = db.Column(db.Float, nullable=True)
    tax_category_name = db.Column(db.String(255), nullable=True)
    invoice_value = db.Column(db.Numeric(12,2), nullable=False)

    def to_dict(self):
        return {
            "org_name": self.org_name,
            "location_code": self.location_code,
            "vendor_code": self.vendor_code,
            "vendor_name": self.vendor_name,
            "vsc": self.vsc,
            "po_dt": self.po_dt,
            "po_buyer_name": self.po_buyer_name,
            "po_buyer_email": self.po_buyer_email,
            "shipment_num": self.shipment_num,
            "challan_date": self.challan_date,
            "pending_days": self.pending_days,
            "item": self.item,
            "item_desc": self.item_desc,
            "asn_qty": self.asn_qty,
            "base_val": float(self.base_val),  # Convert to float for JSON serialization
            "item_type": self.item_type,
            "default_subinventory": self.default_subinventory,
            "hazard_class": self.hazard_class,
            "tax_percent": self.tax_percent,
            "tax_category_name": self.tax_category_name,
            "invoice_value": float(self.invoice_value),  # Convert to float for JSON serialization
        }

    
    
    
# vehicle = MasterVehicle.query.filter_by(vehicle_number='XYZ123').first()
# vehicle_documents = vehicle.documents  # Access all related documents

# driver = MasterDriver.query.filter_by(driver_license_number='DL123456').first()
# driver_documents = driver.documents  # Access all related documents

# Query all trip statuses for a specific document:
# document = Document.query.filter_by(Trip_id='TRIP123').first()
# statuses = document.trip_statuses  # Access all related trip statuses

# Calculate the duration for a specific trip status:
# trip_status = TripStatus.query.filter_by(id=1).first()
# duration_in_hours = trip_status.duration  # Access the calculated duration

# Fetch document and its related gate entries
# doc = Document.query.filter_by(Trip_id="TRIP123").first()
# print(doc.to_dict())  # This will include gate entry details as well


