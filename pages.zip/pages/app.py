from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS  # ✅ Enable CORS
from config import Config
from models import User, Document  # ✅ Import models

app = Flask(__name__)
CORS(app)  # ✅ Enable CORS for frontend access

# Load configurations
app.config.from_object(Config)

# Initialize Database
db = SQLAlchemy(app)

# Example API Route
@app.route('/api/data', methods=['GET'])
def get_data():
    return jsonify({"message": "API is working!"})


if __name__ == '__main__':
    app.run(debug=True)
