import React, { useState } from "react";
import axios from "axios";
import * as XLSX from "xlsx";

const BASE_URL = "https://koelpravesh.kirloskar.com:5300";

const HourlyLoadingUnloading = () => {
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);

  // 🔍 Fetch Report
  const handleSearch = async () => {
    if (!fromDate || !toDate) {
      alert("Please select From Date and To Date");
      return;
    }

    try {
      setLoading(true);
      const response = await axios.get(
        `${BASE_URL}/api/report/hourly-loading-unloading`,
        {
          params: {
            from_date: fromDate,
            to_date: toDate,
          },
        }
      );

      setData(response.data.data || []);
    } catch (error) {
      console.error(error);
      alert("Failed to load report");
    } finally {
      setLoading(false);
    }
  };

  // 📤 Export to Excel
  const handleExport = () => {
    if (!data.length) {
      alert("No data to export");
      return;
    }

    const exportData = data.map((row) => ({
      Date: `${fromDate} to ${toDate}`,
      Time: row.time,
      "IN Vehicle": row.in_vehicle,
      "OUT Vehicle": row.out_vehicle,
      "Loading / Unloading": row.type,
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Hourly Report");

    XLSX.writeFile(
      workbook,
      `Hourly_Loading_Unloading_${fromDate}_to_${toDate}.xlsx`
    );
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ textAlign: "center", marginBottom: "20px" }}>
        Hourly Loading / Unloading Report
      </h2>

      {/* 🔎 Filters */}
      <div
        style={{
          display: "flex",
          gap: "15px",
          justifyContent: "center",
          marginBottom: "20px",
        }}
      >
        <div>
          <label>From Date</label>
          <br />
          <input
            type="date"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
          />
        </div>

        <div>
          <label>To Date</label>
          <br />
          <input
            type="date"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
          />
        </div>

        <div style={{ marginTop: "22px" }}>
          <button onClick={handleSearch}>Search</button>
        </div>

        <div style={{ marginTop: "22px" }}>
          <button onClick={handleExport}>Export</button>
        </div>
      </div>

      {/* ⏳ Loader */}
      {loading && <p style={{ textAlign: "center" }}>Loading report...</p>}

      {/* 📊 Table */}
      {!loading && data.length > 0 && (
        <table
          border="1"
          cellPadding="8"
          cellSpacing="0"
          style={{ width: "100%", textAlign: "center" }}
        >
          <thead style={{ backgroundColor: "#9acd32" }}>
            <tr>
              <th>Date</th>
              <th>Time</th>
              <th>IN Vehicle</th>
              <th>OUT Vehicle</th>
              <th>Loading / Unloading</th>
            </tr>
          </thead>
          <tbody>
            {data.map((row, index) => (
              <tr key={index}>
                <td>{fromDate}</td>
                <td>{row.time}</td>
                <td>{row.in_vehicle}</td>
                <td>{row.out_vehicle}</td>
                <td>{row.type}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {!loading && data.length === 0 && (
        <p style={{ textAlign: "center" }}>No data found</p>
      )}
    </div>
  );
};

export default HourlyLoadingUnloading;
