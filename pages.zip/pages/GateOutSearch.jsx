import React, { useEffect, useState } from "react";
import { Button, Input, Select, List, Table } from "antd";
import { SearchOutlined, SyncOutlined,DashboardOutlined } from "@ant-design/icons";
import { useNavigate,Link } from "react-router";
import axios from "axios"; 


const SearchTable = () => {
    const [searchText, setSearchText] = useState('');
    const [gateOutData, setGateOutData] = useState([]); // Initialize with an empty array
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        localStorage.removeItem('gate-data')
        const fetchGateOutDetails = async () => {
            setLoading(true);
            setError(null);

            try {
                const response = await axios.get("https://192.168.62.199:5100/get_gate_out_details");
                const contentType = response.headers['content-type'];

                if (contentType && contentType.includes('application/json')) {
                    console.log("API Response:", response.data);
                    if (response.data?.gate_out) {
                        setGateOutData(response.data.gate_out); // Store the data if it's present
                    } else {
                        setError("No gate out details found.");
                    }
                } else {
                    throw new Error("Unexpected response format");
                }
            } catch (err) {
                setError("Failed to fetch gate out details");
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        fetchGateOutDetails();

    }, []);

    //Gateout Logic
    const handleGateOut = async (record) =>{
          console.log("Navigating with:", record.gate_entry_number);
        navigate('/gate-out',{ state:{"gate_entry_number":record.gate_entry_number}})
    }

    // Define filteredData based on searchText and gateOutData
    const filteredData = gateOutData.filter(item =>
        item.vehicle_number.toLowerCase().includes(searchText) ||
        item.gate_entry_number.toLowerCase().includes(searchText)
    );
    

    const columns = [
        {
            title: 'Gate Entry Number',
            dataIndex: 'gate_entry_number',
            key: 'gate_entry_number',
        },
        {
            title: 'Gate Entry Status',
            dataIndex: 'gate_entry_status',
            key: 'gate_entry_status',
        },
        {
            title: 'Trip ID',
            dataIndex: 'trip_id',
            key: 'trip_id',
        },
        {
            title: 'Vehicle No.',
            dataIndex: 'vehicle_number',
            key: 'vehicle_number',
        },
        {
            title: 'Action',
            dataIndex: 'action',
            render: (_, record) => (
                <Button 
                    type="primary" 
                    className="h-10 !bg-[#1d998b] font-semibold" 
                    onClick={() => handleGateOut(record)}
                >
                    Gate Out
                </Button>
            ),
        },
    ];

    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>{error}</div>;
    }



    
    return (
        <>
       <div className="w-[80%] flex justify-between items-center mx-auto relative">
            {/* Logo on the Left */}
            <img src="/logo.jpg" className="h-24" alt="Logo" />

            {/* Home Link on the Right */}
            <Link to="/dashboard" 
                className="text-xl bg-white border-2 flex gap-3 h-14 w-28 rounded-full items-center justify-center px-4 hover:shadow-md transition-all">
                <p>Home</p><DashboardOutlined />
            </Link>
        </div>
        
            {/* Outer white background container */}
            <div className="flex justify-center mt-10 h-auto pb-10 bg-white px-10 ">
                {/* Gray background form container */}
                <div className=" w-[85%] bg-gray-200 rounded-xl px-10 pt-10 pb-5 mb-10">
                    {/* Search Box */}
                    <div className="flex flex-col items-right gap-5 w-[70%]">
                        <div className="w-[60%] mb-6">
                            <Input
                                placeholder="Search by Vehicle or Gate Entry Number"
                                className="w-[60%] p-2"
                                onChange={(e) => setSearchText(e.target.value.toLowerCase())}
                                prefix={<SearchOutlined />}
                            />
                        </div>
                    </div>
    
                    {/* Table inside form */}
                    <Table 
                        bordered
                        dataSource={filteredData} 
                        columns={columns} 
                        pagination={false} 
                        className="h-[50vh] overflow-y-scroll bg-gray-100"
                        rowKey="trip_id"
                    />
                </div>
            </div>
        </>
    );
    
};

export default SearchTable;
