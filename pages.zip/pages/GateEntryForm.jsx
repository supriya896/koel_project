import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router'
import Navbar from '../components/Navbar'
import { Button, ConfigProvider, Divider, Form, Input, InputNumber, Modal, Select, Space } from 'antd'
import { ArrowRightOutlined, CheckOutlined, CloseOutlined, RobotOutlined } from '@ant-design/icons';
import { RuleObject } from "antd/lib/form";
import axios from "axios";


const GateEntryForm = ({ params }) => {
    const location = useLocation()
    const data = JSON.parse(localStorage.getItem("gate-form"))
    const [vehicleNumber, setvehicleNumber] = useState(localStorage.getItem("vehicleNumber"))
    const [vehicleStatus, setVehicleStatus] = useState(data ? data.vehicleStatus : '')
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [checkValues, setCheckValues] = useState([])
    const [invoices, setInvoices] = useState()
    const allData = data ? data : {
        "vehicleNumber": vehicleNumber,
        "driverName": '',
        "driverNumber": '',
        "gateEntryNumber": '',
        "gateEntryStatus": '',
        "inDate": '',
        "invoices": '',
        "licenseNumber": '',
        "lrDate": '',
        "lrNumber": '',
        "noOfPersons": '',
        "outDate": '',
        "pucStatus": '',
        "remarks": '',
        "transporterName": '',
        "vehicleStatus": '',
        "vehicleType": '',
    }
    console.log(vehicleNumber)
    const [finalData, setFinalData] = useState(allData)
    useEffect(() => {
        if (localStorage.getItem("gate-form")) {
            let data = JSON.parse(localStorage.getItem("gate-form"))
            setFinalData(data)
        }
    }, [])
    const Navigate = useNavigate()

    const showModal = () => {
        setIsModalOpen(true);
    };

    const handleOk = () => {
        setIsModalOpen(false);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };
    const validatePhoneNumber = async (_, value) => {
        if (!value || /^\d{10}$/.test(value)) {
            return Promise.resolve();
        }
        return Promise.reject(new Error("Phone number must be exactly 10 digits"));
    };
    const onFinish = async (values) => {
        console.log('Success:', values);
        let formattedData = {
            "vehicle_number": values.vehicleNumber,
            "vehicle_status": values.vehicleStatus,
            "gate_entry_number": values.gateEntryNumber,
            "gate_entry_status": values.gateEntryStatus,
            "in_date_time": values.inDate,  // Ensure this is the correct format
            "transporter_name": values.transporterName,
            "vehicle_type": values.vehicleType,
            "puc_status": values.pucStatus,
            "lr_number": values.lrNumber,
            "lr_date": values.lrDate,
            "driver_name": values.driverName,
            "driver_mobile_number": values.driverNumber,
            "license_number": values.licenseNumber,
            "number_of_persons": parseInt(values.noOfPersons) || 0,  // Ensure integer
            "number_of_invoices": parseInt(values.invoices) || 0,  // Ensure integer
            "remarks": values.remarks,
            "out_date": values.outDate
        };
    

        // let finalData = {
        //     "vehicleNumber": values.vehicleNumber,
        //     "driverName": values.driverName,
        //     "driverNumber": values.driverNumber,
        //     "gateEntryNumber": values.gateEntryNumber,
        //     "gateEntryStatus": values.gateEntryStatus,
        //     "inDate": values.inDate,
        //     "invoices": values.invoices,
        //     "licenseNumber": values.licenseNumber,
        //     "lrDate": values.lrDate,
        //     "lrNumber": values.lrNumber,
        //     "noOfPersons": values.noOfPersons,
        //     "outDate": values.outDate,
        //     "pucStatus": values.pucStatus,
        //     "remarks": values.remarks,
        //     "transporterName": values.transporterName,
        //     "vehicleStatus": values.vehicleStatus,
        //     "vehicleType": values.vehicleType,
        // }
        // setFinalData(finalData)
        // console.log('Final data:',finalData)
        setCheckValues(values)
        setInvoices(values.invoices)
        showModal()
        setFinalData(formattedData);
    console.log("Final Formatted Data:", formattedData);

        try {
            const response = await axios.post("http://127.0.0.1:5000/submit_gate_entry", formattedData, {
                headers: {
                    "Content-Type": "application/json",
                },
                withCredentials: true  // Ensures cookies are sent if needed
            });
    
            console.log("API Response:", response.data);
        } catch (error) {
            console.error("Error submitting form:", error.message);
        }

    };
    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };
    const handleUnloadingSubmit = () => {
        localStorage.setItem("gate-form", JSON.stringify(finalData))
        Navigate('/invoice', { state: { invoice: invoices, data: finalData } })
    }
    const handleLoadingSubmit = () => {
        Navigate('/preview', { replace: true, state: { data: finalData } })
    }
    const fieldTitles = {
        "driverName": "Driver Name",
        "driverNumber": "Driver Number",
        "gateEntryNumber": "Gate Entry Number",
        "gateEntryStatus": "Gate Entry Status",
        "inDate": "In Date",
        "invoices": "Invoices",
        "licenseNumber": "License Number",
        "lrDate": "LR Date",
        "lrNumber": "LR Number",
        "noOfPersons": "Number of Persons",
        "outDate": "Out Date",
        "pucStatus": "PUC Status",
        "remarks": "Remarks",
        "transporterName": "Transporter Name",
        "vehicleStatus": "Vehicle Status",
        "vehicleType": "Vehicle Type",
    };
    return (
        <>
            <Navbar />
            <div className='min-h-[80vh] w-[85%] bg-gray-100 mx-auto rounded-xl mt-10 px-10 pt-10 pb-2 mb-10'>
                <Form
                    name="basic"
                    initialValues={finalData}
                    onFinish={onFinish}
                    onFinishFailed={onFinishFailed}
                    autoComplete="off"
                    labelCol={{
                        span: 24,
                    }}
                    wrapperCol={{
                        span: 44,
                    }}
                >
                    <div className='w-full flex gap-10'>
                        <Form.Item label="Vehicle Number" name="vehicleNumber" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
                            {/* <Input disabled className='h-10' /> */}
                            <Input className='h-10' />
                        </Form.Item>
                        <Form.Item label="Vechile Status" labelCol={{ span: 24 }} name="vehicleStatus" rules={[{ required: true, message: 'Please select a value!' }]}>
                            <Select
                                className='h-10 !w-[255px] !border-none'
                                onChange={(value) => setVehicleStatus(value)}
                                placeholder="Choose"
                                options={[
                                    {
                                        value: 'loadingofmaterials',
                                        label: 'Loading of materials',
                                    },
                                    {
                                        value: 'unloadingofmaterials',
                                        label: 'Unloading of materials',
                                    },
                                ]}
                            />
                        </Form.Item>
                    </div>
                    <div className='w-full flex gap-10'>
                        <Form.Item className='w-[30%]' label="Gate Entry Number" name="gateEntryNumber" labelCol={{ span: 24 }} rules={[{ required: vehicleStatus === "unloadingofmaterials" ? false : true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="Gate Entry Status" name="gateEntryStatus" labelCol={{ span: 24 }} rules={[{ required: vehicleStatus === "unloadingofmaterials" ? false : true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="In Date & Time" name="inDate" labelCol={{ span: 24 }} rules={[{ required: vehicleStatus === "unloadingofmaterials" ? false : true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                    </div>
                    <div className='w-full flex gap-10'>
                        <Form.Item className='w-[30%]' label="Transporter Name" name="transporterName" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="Vehicle Type" name="vehicleType" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="PUC Status" name="pucStatus" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                    </div>
                    <div className='w-full flex gap-10'>
                        <Form.Item className='w-[30%]' label="LR Number" name="lrNumber" labelCol={{ span: 24 }} rules={[{ required: false, message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="LR Date" name="lrDate" labelCol={{ span: 24 }} rules={[{ required: false, message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="Driver Name" name="driverName" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                    </div>
                    <div className='w-full flex gap-10'>
                        <Form.Item className='w-[30%]' label="Driver Mobile Number" name="driverNumber" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Phone number needs to be 10 digits!' }, { validator: validatePhoneNumber }]}>
                            <Input className='!h-10' maxLength={10} />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="License Number" name="licenseNumber" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="No of Persons" name="noOfPersons" labelCol={{ span: 24 }} rules={[{ required: false, message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                    </div>
                    <div className='w-full flex gap-10'>
                        <Form.Item className='w-[30%]' label="Number of Invoices" name="invoices" labelCol={{ span: 24 }} rules={[{ required: vehicleStatus === "unloadingofmaterials" ? true : false, message: 'Please enter a value!' }]}>
                            <InputNumber className='h-10 w-[100%]' min={0} />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="Remarks" name="remarks" labelCol={{ span: 24 }} rules={[{ required: false, message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="Out Date" name="outDate" labelCol={{ span: 24 }} rules={[{ required: false, message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                    </div>
                    <Divider />
                    <Form.Item >
                        <Space>
                            {vehicleStatus === "loadingofmaterials" || vehicleStatus == '' ?
                                <>
                                    <Button htmlType="button" className='h-10 !bg-[#c47c5c] text-white hover:!text-white hover:!border-[#c47c5c]' icon={<RobotOutlined />} iconPosition='end' >
                                        Start Bot
                                    </Button>
                                    <Button type="primary" htmlType="submit" className='h-10 !bg-[#1d998b] font-semibold' icon={<CheckOutlined />} iconPosition='end'>
                                        Submit
                                    </Button>
                                </>
                                : null

                            }
                            {vehicleStatus === "unloadingofmaterials" &&
                                <Button type="primary" htmlType="submit" className='h-10 !bg-[#1d998b] font-semibold' icon={<ArrowRightOutlined />} iconPosition='end'>
                                    Next
                                </Button>
                            }
                        </Space>
                    </Form.Item>
                </Form>
            </div>
            <ConfigProvider
                theme={{
                    token: {
                        Modal: {
                            /* here is your component tokens */
                            titleColor: "#1d998b",
                            titleFontSize: 22
                        },
                    },
                }}
            >
                <Modal title="Preview" open={isModalOpen} onOk={handleOk} onCancel={handleCancel} maskClosable={false}
                    footer={null}
                >
                    <Divider />
                    <ul className=''>
                        {Object.entries(checkValues).map(([key, value]) => (
                            <li key={key} className='mb-4'>
                                {value !== '' &&
                                    <>
                                        <strong>{fieldTitles[key] || key}: </strong>
                                        {value === "loadingofmaterials" ? "Loading Of Materials" :
                                            value === "unloadingofmaterials" ? "Unloading Of Materials" : value}
                                    </>

                                }
                            </li>
                        ))}
                    </ul>
                    <Divider />
                    <div className='w-full flex justify-end gap-6'>
                        <Button key="back" onClick={handleCancel} className='h-10' icon={<CloseOutlined />} iconPosition='end'>
                            Cancel
                        </Button>
                        {vehicleStatus === "loadingofmaterials" ?

                            <Button key="submit" type="primary" className='h-10 !bg-[#1d998b] font-semibold' icon={<CheckOutlined />} iconPosition='end' onClick={handleLoadingSubmit}>
                                Submit
                            </Button>
                            :

                            <Button type="primary" onClick={handleUnloadingSubmit} className='h-10 !bg-[#1d998b] font-semibold' icon={<ArrowRightOutlined />} iconPosition='end'>
                                Next
                            </Button>}
                    </div>


                </Modal>
            </ConfigProvider >

        </>
    )
}

export default GateEntryForm