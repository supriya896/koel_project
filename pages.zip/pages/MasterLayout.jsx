// // components/layout/MasterLayout.jsx
// import React from 'react';
// import { Layout, Menu } from 'antd';
// import { FileTextOutlined, ContainerOutlined } from '@ant-design/icons';

// const { Header, Content, Footer, Sider } = Layout;

// const MasterLayout = ({ children }) => {
//   return (
//     <Layout style={{ minHeight: '100vh' }}>
//       <Sider theme="light">
//         <div className="logo" style={{ padding: '16px', fontWeight: 'bold' }}>
//           MyApp
//         </div>
//         <Menu mode="inline" defaultSelectedKeys={['mdr']}>
//           <Menu.Item key="mdr" icon={<FileTextOutlined />}>
//             <a href="/mdr">MDR</a>
//           </Menu.Item>
//           <Menu.Item key="dock" icon={<ContainerOutlined />}>
//             <a href="/dock">Dock In/Out</a>
//           </Menu.Item>
//         </Menu>
//       </Sider>
//       <Layout>
//         <Header style={{ background: '#fff', padding: 0, fontSize: '18px', paddingLeft: 24 }}>
//           Material & Dock Management
//         </Header>
//         <Content style={{ margin: '16px' }}>
//           <div style={{ padding: 24, background: '#fff', minHeight: 360 }}>
//             {children}
//           </div>
//         </Content>
//         <Footer style={{ textAlign: 'center' }}>© {new Date().getFullYear()} MyApp</Footer>
//       </Layout>
//     </Layout>
//   );
// };

// export default MasterLayout;

import { FileTextOutlined, ContainerOutlined, PlusCircleOutlined } from '@ant-design/icons';
import { Layout, Menu } from 'antd';
import React from 'react';
const { Header, Content, Footer, Sider } = Layout;
const { SubMenu } = Menu; // add this

const MasterLayout = ({ children }) => {
  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider theme="light">
        <div className="logo" style={{ padding: '16px', fontWeight: 'bold' }}>
          MyApp
        </div>
        <Menu mode="inline" defaultSelectedKeys={['mdr']}>
          <SubMenu key="mdr" icon={<FileTextOutlined />} title="MDR">
            <Menu.Item key="mdr-main">
              <a href="/mdr">View MDR</a>
            </Menu.Item>
            <Menu.Item key="add-unloading-location" icon={<PlusCircleOutlined />}>
              <a href="/add-unloading-location">Add Unloading Location</a>
            </Menu.Item>
          </SubMenu>
          <Menu.Item key="dock" icon={<ContainerOutlined />}>
            <a href="/dock">Dock In/Out</a>
          </Menu.Item>
        </Menu>
      </Sider>
      <Layout>
        <Header style={{ background: '#fff', padding: 0, fontSize: '18px', paddingLeft: 24 }}>
          Material & Dock Management
        </Header>
        <Content style={{ margin: '16px' }}>
          <div style={{ padding: 24, background: '#fff', minHeight: 360 }}>
            {children}
          </div>
        </Content>
        <Footer style={{ textAlign: 'center' }}>© {new Date().getFullYear()} MyApp</Footer>
      </Layout>
    </Layout>
  );
};

export default MasterLayout;
