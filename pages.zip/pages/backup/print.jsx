import React, { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router";
import {
  Button,
  DatePicker,
  Divider,
  Form,
  Input,
  Select,
  Space,
  Table,
} from "antd";
import { ArrowRightOutlined, PrinterOutlined } from "@ant-design/icons";
import MDRNavbar from "../components/MDRNavbar";
import TextArea from "antd/es/input/TextArea";
import MDRTable from "../components/MDRTable";
import { useReactToPrint } from "react-to-print";
import ColumnGroup from "antd/es/table/ColumnGroup";
import Column from "antd/es/table/Column";
import dayjs from "dayjs";
import { ConfigProvider } from "antd";
import QRCode from "qrcode";
import { useParams } from "react-router-dom";
import axios from 'axios'; 


// import "./preview.module.css";

const Print = ({ params }) => {
  const [form] = Form.useForm();
  const navigate = useNavigate();
  const location = useLocation();
  const { data, tableData, invoice_date, mdr_date } =location.state || {};
  const { email_id_to_logistics, email_id_cc } = location.state || {};
  const contentRef = useRef(null);
  const reactToPrintFn = useReactToPrint({ contentRef });
  const dateFormat = "YYYY/MM/DD";
  const { received_images } = location.state || { received_images: [] };
  const [qrDataUrl, setQrDataUrl] = useState("");
  const { mdr_number } = useParams(); // get from URL
  const mdrNumber = parseInt(mdr_number); // optional:
  const [fetchedTableData, setFetchedTableData] = useState([]);


  console.log(data);
  // const imagesToDisplay = Array.isArray(received_images) ? received_images.map(img => img.url) : [];
  const receivedImages = location.state?.received_images ?? [];

  console.log("Full State Received in Print Page:", location.state);
  console.log("Received Images in Print Page:", receivedImages);
  console.log("Type of receivedImages:", typeof receivedImages);
  console.log("Array Check:", Array.isArray(receivedImages));
  console.log("Length:", receivedImages.length);


  //Handleing On Enter Submit
  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === "Enter") {
        form.submit();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [form]);


  useEffect(() => {
    if (!data?.mdr_number) return;
  
    const generateQrCode = async () => {
      try {
        const qrText = `http://192.168.176.242:5173/mdr/print/${data.mdr_number}`;
        const url = await QRCode.toDataURL(qrText, {
          errorCorrectionLevel: "H", // Higher quality
          width: 200,
        });
        setQrDataUrl(url);
      } catch (err) {
        console.error("QR Code Generation Error: ", err);
      }
    };
    generateQrCode();
  }, [data]);

  
  useEffect(() => {
    const fetchMdrData = async () => {
      try {
        const dataArr = (await axios.get(`http://127.0.0.1:5100/mdr/print/${mdr_number}`)).data;
        console.log("Fetched Data:",dataArr) ;
        if (!Array.isArray(dataArr) || dataArr.length === 0) {
          console.error("❌ No MDR data found in response:", dataArr);
          return;
        }
  
        const data = dataArr[0];
  
        console.log("✅ Fetched MDR Data:", data);
        console.log("🔍 unloading_location value:", data.unloading_location);
  
        form.setFieldsValue({
          ...data,
          unloading_location: data.unloading_location,
          invDate: data.invoice_date || "",
          mdrDate: data.mdr_date || "",
          emailLogistics: data.email_id_to_logistics || "",
          emailCc: data.email_id_cc || "",
        });
        setFetchedTableData([data]); // ✅ convert object to array of 1 row            
      } catch (error) {
        console.error("❌ Failed to fetch MDR data", error);
      }
    };
  
    if (mdr_number) fetchMdrData();
  }, [mdr_number]);
  
  
  
  //Submitting Form
  const onFinish = (values) => {
    console.log("Table Data ", tableData);
    console.log("Success:", values);
    //Send the values and Table Data to the backend by converting into JSON
  };

  //Form validation Error
  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };

  console.log(data);

  return (
    <>
      <MDRNavbar />
      <div
        className="min-h-[80vh] w-[95%] bg-gray-30 mx-auto rounded-xl mt-10 px-10 pt-10 pb-2 mb-10"
        ref={contentRef}
      >
        <Form
          name="basic"
          form={form}
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
          initialValues={{ ...data, invDate: invoice_date, mdrDate: mdr_date,emailLogistics:email_id_to_logistics,emailCc:email_id_cc }}
          disabled={true}
          autoComplete="off"
          labelCol={{
            span: 24,
          }}
          wrapperCol={{
            span: 44,
          }}
        >
           {/* <div className="flex justify-start">
  <p className="text-sm font-semibold">KGL-F-STR-G-10-02</p>
</div> */}
         <div className="flex flex-col items-center text-center mb-8">
  {/* Logo */}
  <img src="/logo.jpg" className="h-12 mb-2 absolute top-0 right-0 m-4" />
  <p className="text-sm font-semibold h-12 mb-2 absolute top-9 right-0 m-4">KGL-F-STR-G-10-02</p>


  {/* Title */}
  <h3 className="text-[#1d998b] text-2xl font-semibold mb-2">
    Material Discrepancy Report
  </h3>

  {/* Address */}
  <p className="text-xl">Kagal Plant 1: D1, 5 Star MIDC, Kagal, Dist. Kolhapur - 416 202</p>
  <p className="text-xl">CIN No.: L29120PN2009PLC13351</p>
</div>

    <div>
      <h2>QR Code</h2>
      {qrDataUrl ? (
    <>
      <img
        src={qrDataUrl}
        alt="QR Code"
        style={{ width: "150px", height: "150px" }}
      />
      <div style={{ marginTop: "8px" }}>
        <a
          href={`http://192.168.176.242:5173/mdr/print/${data?.mdr_number}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          {`http://192.168.176.242:5173/mdr/print/${data?.mdr_number}`}
        </a>
      </div>
    </>
  ) : (
    <p>Generating QR Code...</p>
  )}
    </div>


<div className="w-full flex flex-wrap gap-5">
            <Form.Item
              className="w-[18%]"
              label="GRR/Sticker/MTN No."
              name="grr_mtn_sticker_number"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }]}
            >
              <Input.TextArea autoSize={{ minRows: 1, maxRows: 3 }} className="h-auto  text-black" style={{ borderColor: "black" , color:"black",fontWeight: "bold"}}/>
            </Form.Item>
            <Form.Item
              className="w-[18%] "
              label="Invoice Number"
              name="invoice_number"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }]}
            >
              <Input.TextArea autoSize={{ minRows: 1, maxRows: 5 }} className="h-auto  text-black" style={{ borderColor: "black" , color:"black",fontWeight: "bold"}} />
            </Form.Item>
            <Form.Item
              className="w-[18%]"
              label="Invoice Date"
              name="invDate"
              labelCol={{ span: 24 }}
            >
              <Input className="h-10 w-[100%] text-black" style={{ borderColor: "black", color:"black" ,fontWeight: "bold"}} />
            </Form.Item>
            <Form.Item
              className="w-[18%]"
              label="MDR Number"
              name="mdr_number"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }]}
            >
              <Input className="h-10  text-black" style={{ borderColor: "black" , color:"black",fontWeight: "bold"}} />
            </Form.Item>
            <Form.Item
              className="w-[18%]"
              label="MDR Date"
              name="mdrDate"
              labelCol={{ span: 24 }}
            >
              <Input className="h-10 w-[100%]  text-black" style={{ borderColor: "black", color:"black",fontWeight: "bold" }} />
            </Form.Item>
            {/* <Form.Item className='w-[25%]' label="GRR Number" name="grr_number" labelCol={{ span: 24 }} rules={[{ message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item> */}
           
          </div>
          <div className="w-full flex gap-10">
          <Form.Item
              label="Unloading Location"
              className="w-[30%] !bg-white"
              labelCol={{ span: 24 }}
              name="unloading_location"
              rules={[{ message: "Please select a value!" }]}
            >
              <ConfigProvider
    theme={{
      token: {
        colorBgContainerDisabled: "white",
      },
      components: {
        Select: {
          colorBgContainer: "white",
          colorText: "black",
          colorBorder: "black",
          optionSelectedBg: "#f0f0f0",
        },
      },
    }}
  >
              <Select
                className="h-10 w-[100%] !border-none !bg-white text-black"
                style={{ backgroundColor: "white !important", color:"black" ,fontWeight: "bold" }}
                dropdownStyle={{ backgroundColor: "#ffffff", color: "#000000" }}
                placeholder="Choose"
                // defaultValue={data.unloading_location}
                defaultValue={data?.unloading_location}
                options={[
                  {
                    value: "LMHP",
                    label: <span style={{ color: 'black' }}>LMHP</span>,
                  },
                  {
                    value: "HHP",
                    label:  <span style={{ color: 'black' }}>HHP</span>,
                  },
                  {
                    value: "Genset",
                    label:  <span style={{ color: 'black' }}>Genset</span>,
                  },
                  {
                    value: "RWH",
                    label:  <span style={{ color: 'black' }}>RWH</span>,
                  },
                  {
                    value: "Extended Store",
                    label:  <span style={{ color: 'black' }}>Extended Store</span>,
                  },
                  {
                    value: "RM Store",
                    label:  <span style={{ color: 'black' }}>RM Store</span>,
                  },
                ]}
              />
              </ConfigProvider>
            </Form.Item>
           

            <Form.Item
              label="MDR Raised At"
              labelCol={{ span: 24 }}
              className="w-[30%] !bg-white"
              name="mdr_raised_as"
              rules={[{ message: "Please select a value!" }]}
            >
              <ConfigProvider
    theme={{
      token: {
        colorBgContainerDisabled: "white",
        colorText:"black",
      },
      components: {
        Select: {
          colorBgContainer: "white",
          colorText: "black",
          colorBorder: "black",
          optionSelectedBg: "#f0f0f0",
        },
      },
    }}
  >
                <Select
                  className="h-10 w-[100%] !border-none !bg-white text-black font-bold"
                  style={{ backgroundColor: "white", color:"black",fontWeight: "bold"  }}
                  dropdownStyle={{ backgroundColor: 'white !important',color:"black" ,fontWeight: "bold", }}
                  placeholder="Choose"
                  // defaultValue={data.mdr_raised_as}
                  defaultValue={data?.mdr_raised_as}
                  options={[
                    {
                      value: "Storage",
                      label:  <span style={{ color: 'black' }}>Storage</span>,
                    },
                    {
                      value: "Unloading",
                      label: <span style={{ color: 'black' }}>Unloading</span>,
                    },
                  ]}
                />
              </ConfigProvider>
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="Vehicle Number"
              name="vehicle_number"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }]}
            >
              <Input className="h-10  text-black" style={{ borderColor: "black", color:"black",fontWeight: "bold" }} />
            </Form.Item>
          
          </div>
          <div className="w-full flex gap-10">
            <Form.Item
              className="w-[30%]"
              label="Transporter Name"
              name="transporter_name"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }]}
            >
              <Input className="h-10  text-black" style={{ borderColor: "black", color:"black" ,fontWeight: "bold"}} />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="Supplier Name"
              name="vendor_name"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }]}
            >
              <Input className="h-10  text-black" style={{ borderColor: "black", color:"black" ,fontWeight: "bold"}} />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="LR/Docket No"
              name="lr_field"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }]}
            >
              <Input className="h-10  text-black" style={{ borderColor: "black", color:"black",fontWeight: "bold"}} />
            </Form.Item>
            {/* <Form.Item className='w-[30%]' label="Vendor Namer" name="vendor_name" labelCol={{ span: 24 }} rules={[{ message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item> */}
            <Form.Item
              className="w-[30%]"
              label="Vendor Code"
              name="vendor_code"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }]}
            >
              <Input className="h-10  text-black" style={{ borderColor: "black", color:"black",fontWeight: "bold" }} />
            </Form.Item>
          </div>
          <div>
                        <p>The following discrepancies have been observed in the supply received from you:</p>
         </div>
          {/* <Table dataSource={tableData} pagination={false} className="mb-8 mx-4 text-black" style={{ borderColor: "black", color:"black" }}> */}
          <Table dataSource={fetchedTableData.length > 0 ? fetchedTableData : tableData} pagination={false} className="mb-8 mx-4 text-black" style={{ borderColor: "black", color:"black" }}>

            <Column title="Sr No." dataIndex="srno" key="srno" />
            <Column title="Part No." dataIndex="item_code" key="item_code" />
            <Column
              title="Material Description"
              dataIndex="item_description"
              key="item_description"
            />
            {/* <Column title="Unloading Location" dataIndex="unloading_location" key="unloading_location" /> */}
            <ColumnGroup title="Quantity">
              <Column
                title="As per Challan/Invoices"
                dataIndex="quantity_as_per_challan"
                key="quantity_as_per_challan"
              />
              <Column
                title="Actually Received"
                dataIndex="item_quantity_actual"
                key="item_quantity_actual"
              />
              <Column
                title="Storage/Excess/Qualitative"
                dataIndex="excess_shortfall_quantity"
                key="excess_shortfall_quantity"
              />
              <Column
                title="UOM"
                dataIndex="qualitative"
                key="qualitative"
              />
             
            </ColumnGroup>
            <Column
                title="No of Boxes"
                dataIndex="number_of_boxes_lr"
                key="No_of_boxes"
              />
              <Column title="Received" dataIndex="number_of_boxes_lr_recieved" key="received" />
          </Table>
          <div className="mt-6">
  <table className="w-full border border-black text-sm text-black table-fixed">
    <thead className="bg-gray-100">
      <tr>
        <th className="w-[10%] border  px-2 py-1">Sr No.</th>
        <th className="w-[90%] border  px-2 py-1">Remark</th>
      </tr>
    </thead>
    <tbody>
      {/* {tableData.map((item, index) => ( */}
      {tableData?.map((item, index)=>(
        <tr key={index}>
          <td className="border px-2 py-1 text-center">{item.srno}</td>
          <td className="border px-2 py-1">{item.mdr_remarks_1}</td>
        </tr>
      ))}
    </tbody>
  </table>
</div>  
          {/* <div className='w-full flex gap-10'>
                        <Form.Item className='w-[30%]' label="No.of Boxes/Carton's on LR" name="number_of_boxes" labelCol={{ span: 24 }} rules={[{ message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="Received" name="number_of_boxes_lr_recieved" labelCol={{ span: 24 }} rules={[{ message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>


                    </div> */}
          <div className="w-full flex gap-10">
            <ConfigProvider
              theme={{
                token: {
                  colorBgContainerDisabled: "white",
                },
              }}
            >
              {/* <Form.Item
                className="w-[30%] !bg-white"
                label="MDR remarks"
                name="mdr_remarks_1"
                labelCol={{ span: 24 }}
                rules={[{ message: "Please enter a value!" }]}
              >
                <TextArea className="h-10 text-black" style={{ borderColor: "black",color:"black" }}/>
              </Form.Item> */}
              <Form.Item
                className="w-1/2"
                label="Email TO Buyer"
                name="email_id_to"
                labelCol={{ span: 24 }}
                rules={[{ message: "Please enter a value!" }]}
              >
                <TextArea autoSize={{ minRows: 1, maxRows: 5 }} className="h-10  text-black" style={{ borderColor: "black", color:"black"}} />
              </Form.Item>
              <Form.Item
                className="w-1/2"
                label="Email TO Logistics"
                name="emailLogistics"
                labelCol={{ span: 24 }}
                rules={[{ message: "Please enter a value!" }]}
              >
                <TextArea autoSize={{ minRows: 1, maxRows: 5 }} className="h-10  text-black" style={{ borderColor: "black", color:"black"}} />
              </Form.Item>
              <Form.Item
                className="w-1/2"
                label="Email CC"
                name="emailCc"
                labelCol={{ span: 24 }}
                rules={[{ message: "Please enter a value!" }]}
              >
                <TextArea autoSize={{ minRows: 1, maxRows: 5 }} className="h-10  text-black" style={{ borderColor: "black", color:"black"}} />
              </Form.Item>
            </ConfigProvider>
          </div>



          <Divider />
          <Form.Item>
            <div className="w-full flex flex-row justify-between">
              <div className="flex flex-col gap-8">
                <p className="text-center">Prepared By</p>
                <p className="border-t-2 border-gray-700 w-[100px] text-center">
                  TA/Store
                </p>
              </div>
              <div>
                <p className="text-center flex flex-col mb-8">
                  Verified By Kirloskar
                </p>
                <div className="flex gap-8">
                  <p className="border-t-2 border-gray-700 w-[100px] text-center">
                    Buyer
                  </p>
                  <p className="border-t-2 border-gray-700 w-[100px] text-center">
                    Security
                  </p>
                </div>
              </div>
              <div>
                <p className="text-center flex flex-col mb-8">Verified By</p>
                <div className="flex gap-8">
                  <p className="border-t-2 border-gray-700 w-[100px] text-center">
                    Driver
                  </p>
                  <p className="border-t-2 border-gray-700 w-[100px] text-center">
                    Transporter/ Logistic
                  </p>
                </div>
              </div>
              <div>
                <p className="text-center flex flex-col mb-8">Approved By</p>
                <div className="flex gap-8">
                  <p className="border-t-2 border-gray-700 w-[160px] text-center">
                    TL/GL Store
                  </p>
                 
                </div>
              </div>
            </div>
          </Form.Item>
          {/* <div className="uploaded-images">
    {received_images && received_images.length > 0 ? (
        received_images.map((image, index) => (
            <img 
                key={index} 
                src={URL.createObjectURL(image)} 
                alt={`Uploaded ${index + 1}`} 
                style={{ width: '200px', margin: '10px' }}
            />
        ))
    ) : (
        <p>No images uploaded</p>
    )}
</div> */}

          
{/* {/* {imagesToDisplay.length > 0 ? (
  <div className="mt-6">
    {/* <h3 className="text-lg font-semibold mb-2">Uploaded Images</h3> */}
    {/* <div className="flex flex-wrap gap-4">
      {imagesToDisplay.map((imgSrc, index) => (
        imgSrc ? (
          <img
            key={index}
            src={imgSrc}
            alt={`Uploaded ${index}`}
            className="w-40 h-40 object-cover border rounded-lg"
          />
        ) : null
      ))}
    </div>
  </div>
) : (
  <p className="text-center text-gray-500">No uploaded images.</p>
)} */} 
 
        </Form>
      </div>
      <Divider />
      {typeof window !== "undefined" && (
  <div className=" page-footer">
    <span className="print-page-number" data-mdr-number={data?.mdr_number || "1"}></span>
  </div>
)}
      
      <Space className="w-[95%] flex justify-end mb-10">
      <button onClick={() => navigate("/mdr")}>Back</button>
        <Button
          type="primary"
          onClick={reactToPrintFn}
          className="h-10 !bg-[#1d998b] font-semibold"
          icon={<PrinterOutlined />}
          iconPosition="end"
        >
          Print
        </Button>
      </Space>
    </>
  );
};
export default Print;
