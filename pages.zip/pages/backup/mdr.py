from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_mail import Mail, Message
from fpdf import FPDF
from config import Config
from models import MdrDetails, MdrMaster, db
from datetime import datetime
# from pdf_generator import generate_mdr_pdf
import json
import os
import re
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.application import MIMEApplication
from email import encoders
from config import MAIL_DEFAULT_SENDER, SMTP_SERVER, SMTP_PORT, USERNAME, PASSWORD
 
# import smtplib
 
# SMTP_SERVER = "smtp.gmail.com"
# SMTP_PORT = 587
# USERNAME = "samu275001@gmail.com"
# PASSWORD = "gncn ubpu ghon pgiq"
# MAIL_DEFAULT_SENDER = "samrud.ravan@catnipit.com"
 
# try:
#     server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
#     server.starttls()
#     server.login(USERNAME, PASSWORD)
#     print("✅ SMTP connection successful!")
#     server.quit()
# except Exception as e:
#     print("❌ SMTP connection error:", str(e))
 
 
app = Flask(__name__)
app.config.from_object(Config)
CORS(app)
db.init_app(app)
mail = Mail(app)
 
 
UPLOAD_FOLDER = "mdr/"  # Directory to store images
os.makedirs(UPLOAD_FOLDER, exist_ok=True)  # Ensure folder exists
 
def parse_date(date_str):
    if date_str:
        try:
            return datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError as e:
            print("Date Parsing Error:", e)
            return None
    return None
 
 
@app.route("/submit_mdr", methods=["POST"])
def submit_mdr():
    try:
       
        # Get form fields
        invoice_number = request.form.get("invoice_number")
        mdr_number = request.form.get("mdr_number")
        email_id_to = request.form.get("email_id_to")  # Required
        email_id_to_logistics = request.form.get("email_id_to_logistics")  # Required
        email_id_cc = request.form.get("email_id_cc", "")  # Optional
        print("mdr_number:", mdr_number)
        invoice_date = parse_date(request.form.get("invoice_date", ""))
        mdr_date = parse_date(request.form.get("mdr_date", ""))
        count = 1

         # ✅ Check if the same mdr_number exists for another record
        duplicate_mdr = MdrMaster.query.filter(
            MdrMaster.mdr_number == mdr_number,
            # MdrMaster.invoice_number != invoice_number  # not the same record
        ).first()

        if duplicate_mdr:
            return jsonify({"error": f"MDR number '{mdr_number}' already exists."}), 409

       
        # Process uploaded images
        received_images = []
        if "received_images" in request.files:
            files = request.files.getlist("received_images")  # Get multiple files
            count = 1
            for file in files:
                filename = f"{mdr_number}_{count}_{file.filename}"
                file_path = os.path.join(UPLOAD_FOLDER, filename)
                file.save(file_path)  # Save image to server
                received_images.append(file_path)
                count += 1
 
        print("Received images:", received_images)  # Debugging
 
        if not mdr_number or not invoice_number:
            return jsonify({"error": "mdr number and invoice number required"}), 404
       
        existing_mdr = MdrMaster.query.filter_by(invoice_number=invoice_number).first()
 
        if existing_mdr:
            existing_mdr.mdr_number = mdr_number
            existing_mdr.invoice_date = invoice_date
            existing_mdr.mdr_date = mdr_date
            existing_mdr.vendor_code = request.form.get("vendor_code")
            existing_mdr.vendor_name = request.form.get("vendor_name")
            existing_mdr.transporter_name = request.form.get("transporter_name")
            existing_mdr.vehicle_number = request.form.get("vehicle_number")
            existing_mdr.mdr_raised_as = request.form.get("mdr_raised_as")
            existing_mdr.grr_mtn_sticker_number = request.form.get("grr_mtn_sticker_number")
            existing_mdr.lr_field = request.form.get("lr_field")
            existing_mdr.grr_number = request.form.get("grr_number")
            existing_mdr.prepared_by = request.form.get("prepared_by")
            existing_mdr.mdr_remarks_1 = request.form.get("mdr_remarks_1")
            existing_mdr.mdr_remarks_2 = request.form.get("mdr_remarks_2")
            existing_mdr.unloading_location = request.form.get("unloading_location")
            existing_mdr.email_id_cc =email_id_cc
            existing_mdr.email_id_to = email_id_to
            existing_mdr.email_id_to_logistics = email_id_to_logistics

 
        else:
            new_mdr = MdrMaster(
                invoice_number=invoice_number,
                invoice_date=invoice_date,
                mdr_number=mdr_number,
                mdr_date=mdr_date,
                vendor_code=request.form.get("vendor_code"),
                vendor_name=request.form.get("vendor_name"),
                transporter_name=request.form.get("transporter_name"),
                vehicle_number=request.form.get("vehicle_number"),
                mdr_raised_as=request.form.get("mdr_raised_as"),
                grr_mtn_sticker_number=request.form.get("grr_mtn_sticker_number"),
                lr_field=request.form.get("lr_field"),
                grr_number=request.form.get("grr_number"),
                prepared_by=request.form.get("prepared_by"),
                mdr_remarks_1=request.form.get("mdr_remarks_1"),
                mdr_remarks_2=request.form.get("mdr_remarks_2"),
                unloading_location=request.form.get("unloading_location"),
                email_id_cc=email_id_cc,
                email_id_to=email_id_to,
                email_id_to_logistics=email_id_to_logistics,

            )
            db.session.add(new_mdr)
 
        db.session.commit()
 
        mdr_details_list = request.form.get("tableData", "[]")
        try:
            mdr_details_list = json.loads(mdr_details_list)
        except json.JSONDecodeError:
            return jsonify({"error": "Invalid tableData format"}), 400
       
       
        MdrDetails.query.filter_by(mdr_number=mdr_number).delete()
        for detail in mdr_details_list:
                new_detail = MdrDetails(
                    mdr_number=mdr_number,
                    invoice_number=invoice_number,
                    invoice_date=invoice_date,
                    item_code=detail.get("item_code"),
                    item_description=detail.get("item_description"),
                    item_quantity_actual=detail.get("item_quantity_actual"),
                    quantity_as_per_challan=detail.get("quantity_as_per_challan"),
                    excess_shortfall_quantity=detail.get("excess_shortfall_quantity"),
                    number_of_boxes_lr=detail.get("number_of_boxes_lr"),
                    number_of_boxes_lr_recieved=detail.get("number_of_boxes_lr_recieved"),
                    remarks_1=detail.get("mdr_remarks_1"),
                )
                db.session.add(new_detail)
 
        db.session.commit()
 
        count = 1
 
        return jsonify({"message": "MDR record processed successfully", "mdr_number": mdr_number}), 201
 
    except Exception as e:
        db.session.rollback()
        print("Error:", str(e))
        return jsonify({"error": str(e)}), 500

 
# @app.route('/send_mdr_email', methods=['POST'])
# def send_email():
#     try:
#         # ✅ Get data from multipart/form-data
#         email_id_to = request.form.getlist("email_id_to")
#         email_id_to_logistics = request.form.getlist("email_id_to_logistics")
#         email_id_cc = request.form.getlist("email_id_cc")
#         subject = request.form.get("subject", "MDR Submission")
#         body_text = request.form.get("body", "")
#         screenshot_file = request.files.get("screenshot")

#         print("📩 Received email request:")
#         print("To:", email_id_to)
#         print("To Logistics:", email_id_to_logistics)
#         print("CC:", email_id_cc)
#         print("Subject:", subject)
#         print("Body:", body_text)

#         # ✅ Clean email lists
#         to_recipients = [email.strip() for email in email_id_to if email.strip()]
#         to_logistics_recipients = [email.strip() for email in email_id_to_logistics if email.strip()]
#         cc_recipients = [email.strip() for email in email_id_cc if email.strip()]

#         # ✅ Email validation
#         email_pattern = r"[^@]+@[^@]+\.[^@]+"
#         if not to_recipients or not all(re.match(email_pattern, email) for email in to_recipients):
#             return jsonify({"error": "Valid recipient email(s) required"}), 400

#         # ✅ Extract invoice and MDR number
#         invoice_match = re.search(r"Invoice Number:\s*(\d+)", body_text)
#         mdr_match = re.search(r"MDR Number:\s*(\d+)", body_text)
#         grr_match = re.search(r"GRR Number:\s*([\w-]+)", body_text)
#         invoice_date_match = re.search(r"Invoice Date:\s*(.+)", body_text)
#         mdr_date_match = re.search(r"MDR Date:\s*(.+)", body_text)
#         vehicle_number_match = re.search(r"Vehicle Number:\s*(.+)", body_text)
#         supplier_name_match = re.search(r"Supplier Name:\s*(.+)", body_text) 
#         table_data_match = re.search(r"Table Data:\s*(\[[\s\S]*?\]|\{[\s\S]*?\})", body_text)       
#         invoice_number = invoice_match.group(1) if invoice_match else "Unknown"
#         mdr_number = mdr_match.group(1) if mdr_match else "Unknown"
#         grr_number = grr_match.group(1) if grr_match else "Unknown"
#         invoice_date = invoice_date_match.group(1).strip() if invoice_date_match else "Unknown"
#         mdr_date = mdr_date_match.group(1).strip() if mdr_date_match else "Unknown"
#         vehicle_number = vehicle_number_match.group(1).strip() if vehicle_number_match else "Unknown"
#         supplier_name = supplier_name_match.group(1).strip() if supplier_name_match else "Unknown" 
#         if table_data_match:
#           try:
#              table_data_json = table_data_match.group(1)
#              table_data = json.loads(table_data_json)
#              print("✅ Extracted Table Data:", table_data)
#           except json.JSONDecodeError as e:
#              print("❌ JSON Decode Error:", e)
#              table_data = "Invalid JSON in table data"
#         else:
#               print("❌ No table data found")
#               table_data = "No table data"

#         subject = f"MDR Submission - {mdr_number}"
#         body = f"""
#     <html>
#       <body>
#         <p>Dear User,</p>

#         <p>Your MDR has been successfully submitted.</p>

#         <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse;">
#             <tr><th align="left">Invoice Number</th><td>{invoice_number}</td></tr>
#             <tr><th align="left">MDR Number</th><td>{mdr_number}</td></tr>
#             <tr><th align="left">GRR Number</th><td>{grr_number}</td></tr>
#             <tr><th align="left">Invoice Date</th><td>{invoice_date}</td></tr>
#             <tr><th align="left">MDR Date</th><td>{mdr_date}</td></tr>
#             <tr><th align="left">Vehicle Number</th><td>{vehicle_number}</td></tr>
#             <tr><th align="left">Supplier Name</th><td>{supplier_name}</td></tr>
#         </table>

#         <br/>

#         <p><strong>Table Data:</strong></p>
#         <p>{table_data}</p>

#         <p>Please find the attached MDR preview.</p>
#         </body>
#         </html>
#         """


#         # ✅ Create email
#         msg = MIMEMultipart()
#         msg["From"] = MAIL_DEFAULT_SENDER
#         msg["To"] = ", ".join(to_recipients)
#         msg["To Logistics"] = ", ".join(to_logistics_recipients)
#         msg["Cc"] = ", ".join(cc_recipients)
#         msg["Subject"] = subject
#         msg.attach(MIMEText(body, "plain"))
#         msg.attach(MIMEText(body, "html"))

#         # ✅ Attach screenshot
#         if screenshot_file:
#             screenshot_data = screenshot_file.read()
#             image_part = MIMEApplication(screenshot_data, _subtype="png")
#             image_part.add_header('Content-Disposition', 'attachment', filename="mdr_screenshot.png")
#             msg.attach(image_part)

#         all_recipients = to_recipients + cc_recipients + to_logistics_recipients
    

#         # ✅ Send the email
#         with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
#             server.starttls()
#             server.login(USERNAME, PASSWORD)
#             server.sendmail(MAIL_DEFAULT_SENDER, all_recipients, msg.as_string())

#         print("✅ Email sent successfully")
#         return jsonify({"message": "Email sent successfully"}), 200

#     except Exception as e:
#         print("❌ Email sending error:", str(e))
#         return jsonify({"error": str(e)}), 500

@app.route('/send_mdr_email', methods=['POST'])
def send_email():
    try:
        # ✅ Get data from multipart/form-data
        email_id_to = request.form.getlist("email_id_to")
        email_id_to_logistics = request.form.getlist("email_id_to_logistics")
        email_id_cc = request.form.getlist("email_id_cc")
        subject = request.form.get("subject", "MDR Submission")
        body_text = request.form.get("body", "")
        screenshot_file = request.files.get("screenshot")
        uploaded_images = request.files.getlist("images")

        print("📩 Received email request:")
        print("To:", email_id_to)
        print("To Logistics:", email_id_to_logistics)
        print("CC:", email_id_cc)
        print("Subject:", subject)
        for img in uploaded_images:
         print("Uploaded image:", img.filename)

        # ✅ Clean email lists
        to_recipients = [email.strip() for email in email_id_to if email.strip()]
        to_logistics_recipients = [email.strip() for email in email_id_to_logistics if email.strip()]
        cc_recipients = [email.strip() for email in email_id_cc if email.strip()]

        # ✅ Email validation
        email_pattern = r"[^@]+@[^@]+\.[^@]+"
        if not to_recipients or not all(re.match(email_pattern, email) for email in to_recipients):
            return jsonify({"error": "Valid recipient email(s) required"}), 400

        # ✅ Extract MDR details
        invoice_number = re.search(r"Invoice Number:\s*(\d+)", body_text)
        mdr_number = re.search(r"MDR Number:\s*(\d+)", body_text)
        grr_number = re.search(r"GRR Number:\s*([\w-]+)", body_text)
        invoice_date = re.search(r"Invoice Date:\s*(.+)", body_text)
        mdr_date = re.search(r"MDR Date:\s*(.+)", body_text)
        vehicle_number = re.search(r"Vehicle Number:\s*(.+)", body_text)
        supplier_name = re.search(r"Supplier Name:\s*(.+)", body_text)
        table_data_match = re.search(r"Table Data:\s*(\[[\s\S]*?\]|\{[\s\S]*?\})", body_text)

        # ✅ Fallbacks
        invoice_number = invoice_number.group(1) if invoice_number else "Unknown"
        mdr_number = mdr_number.group(1) if mdr_number else "Unknown"
        grr_number = grr_number.group(1) if grr_number else "Unknown"
        invoice_date = invoice_date.group(1).strip() if invoice_date else "Unknown"
        mdr_date = mdr_date.group(1).strip() if mdr_date else "Unknown"
        vehicle_number = vehicle_number.group(1).strip() if vehicle_number else "Unknown"
        supplier_name = supplier_name.group(1).strip() if supplier_name else "Unknown"

        # ✅ Merge fields into each row of table
        if table_data_match:
            try:
                table_data_json = table_data_match.group(1)
                table_data = json.loads(table_data_json)
                print("✅ Extracted Table Data:", table_data)

                mdr_fields = {
                    "invoice_number": invoice_number,
                    "mdr_number": mdr_number,
                    "grr_number": grr_number,
                    "invoice_date": invoice_date,
                    "mdr_date": mdr_date,
                    "vehicle_number": vehicle_number,
                    "supplier_name": supplier_name,
                }

                merged_columns = [
                    "invoice_number", "mdr_number", "grr_number", "invoice_date", "mdr_date",
                    "vehicle_number", "supplier_name",
                    "srno", "item_code", "item_description", "quantity_as_per_challan",
                    "item_quantity_actual", "excess_shortfall_quantity",
                    "number_of_boxes_lr", "number_of_boxes_lr_recieved", "mdr_remarks_1"
                ]

                column_headers = {
                    "invoice_number": "Invoice No.",
                    "mdr_number": "MDR No.",
                    "grr_number": "GRR No.",
                    "invoice_date": "Invoice Date",
                    "mdr_date": "MDR Date",
                    "vehicle_number": "Vehicle No.",
                    "supplier_name": "Supplier",
                    "srno": "Sr. No.",
                    "item_code": "Item Code",
                    "item_description": "Description",
                    "quantity_as_per_challan": "Challan Qty",
                    "item_quantity_actual": "Actual Qty",
                    "excess_shortfall_quantity": "Excess/Shortfall Qty",
                    "number_of_boxes_lr": "Boxes (LR)",
                    "number_of_boxes_lr_recieved": "Boxes Received",
                    "mdr_remarks_1": "MDR Remarks"
                }

                # ✅ Build single scrollable table with merged data
                if isinstance(table_data, list) and len(table_data) > 0:
                    headers = "".join(f"<th>{column_headers[col]}</th>" for col in merged_columns)
                    rows = ""
                    for row in table_data:
                        full_row = {**mdr_fields, **row}
                        rows += "<tr>" + "".join(f"<td>{full_row.get(col, '')}</td>" for col in merged_columns) + "</tr>"

                    table_data_html = f"""
                    <div style="max-height: 400px; overflow: auto; border: 1px solid #ccc;">
                      <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">
                        <thead>
                          <tr style="background-color: #f2f2f2;">{headers}</tr>
                        </thead>
                        <tbody>{rows}</tbody>
                      </table>
                    </div>
                    """
                else:
                    table_data_html = "<p>No table rows to display</p>"

            except json.JSONDecodeError as e:
                print("❌ JSON Decode Error:", e)
                table_data_html = "<p>Invalid JSON in table data</p>"
        else:
            print("❌ No table data found")
            table_data_html = "<p>No table data</p>"

        # ✅ Compose email body
        subject = f"MDR Submission - {mdr_number}"
        body = f"""
        <html>
          <body>
            <p>Dear User,</p>
            <p>Your MDR has been successfully submitted.</p>
            <p><strong>Discrepancy Table:</strong></p>
            {table_data_html}
            <p>Please find the attached MDR preview.</p>
          </body>
        </html>
        """

        # ✅ Email
        msg = MIMEMultipart()
        msg["From"] = MAIL_DEFAULT_SENDER
        msg["To"] = ", ".join(to_recipients)
        msg["Cc"] = ", ".join(cc_recipients)
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "html"))

        # ✅ Attach screenshot
        if screenshot_file:
            screenshot_data = screenshot_file.read()
            image_part = MIMEApplication(screenshot_data, _subtype="png")
            image_part.add_header('Content-Disposition', 'attachment', filename="mdr_screenshot.png")
            msg.attach(image_part)
        
        # ✅ Attach uploaded images
        for idx, image_file in enumerate(uploaded_images):
            image_data = image_file.read()
            image_part = MIMEApplication(image_data)
            image_part.add_header(
                'Content-Disposition',
                'attachment',
                filename=image_file.filename or f"image_{idx + 1}.png"
            )
            msg.attach(image_part)

        all_recipients = to_recipients + cc_recipients + to_logistics_recipients

        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(USERNAME, PASSWORD)
            server.sendmail(MAIL_DEFAULT_SENDER, all_recipients, msg.as_string())

        print("✅ Email sent successfully")
        return jsonify({"message": "Email sent successfully"}), 200

    except Exception as e:
        print("❌ Email sending error:", str(e))
        return jsonify({"error": str(e)}), 500


# Get mdr data
@app.route("/get_all_mdr_data", methods=["GET"])
def get_all_mdr_data():
    try:
        mdr_records = MdrMaster.query.all()

        result = []
        for mdr in mdr_records:
            # Fetch corresponding details
            details = MdrDetails.query.filter_by(mdr_number=mdr.mdr_number).all()
            for detail in details:
                row = {
                    "mdr_number": mdr.mdr_number,
                    "invoice_number": mdr.invoice_number,
                    "invoice_date": mdr.invoice_date.strftime("%Y-%m-%d") if mdr.invoice_date else None,
                    "mdr_date": mdr.mdr_date.strftime("%Y-%m-%d") if mdr.mdr_date else None,
                    "vendor_code": mdr.vendor_code,
                    "vendor_name": mdr.vendor_name,
                    "transporter_name": mdr.transporter_name,
                    "vehicle_number": mdr.vehicle_number,
                    "mdr_raised_as": mdr.mdr_raised_as,
                    "grr_mtn_sticker_number": mdr.grr_mtn_sticker_number,
                    "lr_field": mdr.lr_field,
                    "grr_number": mdr.grr_number,
                    "prepared_by": mdr.prepared_by,
                    "mdr_remarks_1": mdr.mdr_remarks_1,
                    "mdr_remarks_2": mdr.mdr_remarks_2,
                    "unloading_location": mdr.unloading_location,
                    "email_id_cc": mdr.email_id_cc,
                    "email_id_to": mdr.email_id_to,
                    "email_id_to_logistics": mdr.email_id_to_logistics,
                    # Detail fields:
                    "item_code": detail.item_code,
                    "item_description": detail.item_description,
                    "item_quantity_actual": detail.item_quantity_actual,
                    "quantity_as_per_challan": detail.quantity_as_per_challan,
                    "excess_shortfall_quantity": detail.excess_shortfall_quantity,
                    "number_of_boxes_lr": detail.number_of_boxes_lr,
                    "number_of_boxes_lr_recieved": detail.number_of_boxes_lr_recieved,
                    "remarks_1": detail.remarks_1,
                }
                result.append(row)

        return jsonify(result), 200

    except Exception as e:
        print("Error fetching flattened MDR data:", e)
        return jsonify({"error": "Failed to fetch MDR data"}), 500

# remainder_email
@app.route('/send_mdr_remainder_email', methods=['POST'])
def send_remainder_email():
    try:
        # ✅ Get data from multipart/form-data
        email_id_to = request.form.getlist("email_id_to")
        email_id_to_logistics = request.form.getlist("email_id_to_logistics")
        email_id_cc = request.form.getlist("email_id_cc")
        subject = request.form.get("subject", "MDR Reminder")
        body = request.form.get("body", "")

        print("📩 Received email request:")
        print("To:", email_id_to)
        print("To Logistics:", email_id_to_logistics)
        print("CC:", email_id_cc)
        print("Subject:", subject)
        print("Body:", body)

        # ✅ Clean email lists
        to_recipients = [email.strip() for email in email_id_to if email.strip()]
        to_logistics_recipients = [email.strip() for email in email_id_to_logistics if email.strip()]
        cc_recipients = [email.strip() for email in email_id_cc if email.strip()]

        # ✅ Validate at least one recipient
        email_pattern = r"[^@]+@[^@]+\.[^@]+"
        if not to_recipients or not all(re.match(email_pattern, email) for email in to_recipients):
            return jsonify({"error": "Valid recipient email(s) required"}), 400

        # ✅ Compose the email
        msg = MIMEMultipart()
        msg["From"] = MAIL_DEFAULT_SENDER
        msg["To"] = ", ".join(to_recipients)
        msg["Cc"] = ", ".join(cc_recipients)
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain"))

        all_recipients = to_recipients + cc_recipients + to_logistics_recipients

        # ✅ Send the email
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(USERNAME, PASSWORD)
            server.sendmail(MAIL_DEFAULT_SENDER, all_recipients, msg.as_string())

        print("✅ Reminder email sent successfully")
        return jsonify({"message": "Reminder email sent successfully"}), 200

    except Exception as e:
        print("❌ Email sending error:", str(e))
        return jsonify({"error": str(e)}), 500
 
# api for getting data of mdr_number for qr code
@app.route("/mdr/print/<int:mdr_number>", methods=["GET"])
def get_mdr_by_number(mdr_number):
    try:
        print(f"Trying to fetch MDR with number: {mdr_number}")

        # Convert mdr_number to string for the query
        mdr = MdrMaster.query.filter_by(mdr_number=str(mdr_number)).first()
        if not mdr:
            print("MDR not found")
            return jsonify({"error": "MDR not found"}), 404

        details = MdrDetails.query.filter_by(mdr_number=str(mdr_number)).all()

        result = []
        for detail in details:
            row = {
                "mdr_number": mdr.mdr_number,
                "invoice_number": mdr.invoice_number,
                "invoice_date": mdr.invoice_date.strftime("%Y-%m-%d") if mdr.invoice_date else None,
                "mdr_date": mdr.mdr_date.strftime("%Y-%m-%d") if mdr.mdr_date else None,
                "vendor_code": mdr.vendor_code,
                "vendor_name": mdr.vendor_name,
                "transporter_name": mdr.transporter_name,
                "vehicle_number": mdr.vehicle_number,
                "mdr_raised_as": mdr.mdr_raised_as,
                "grr_mtn_sticker_number": mdr.grr_mtn_sticker_number,
                "lr_field": mdr.lr_field,
                "grr_number": mdr.grr_number,
                "prepared_by": mdr.prepared_by,
                "mdr_remarks_1": mdr.mdr_remarks_1,
                "mdr_remarks_2": mdr.mdr_remarks_2,
                "unloading_location": mdr.unloading_location,
                "email_id_cc": mdr.email_id_cc,
                "email_id_to": mdr.email_id_to,
                "email_id_to_logistics": mdr.email_id_to_logistics,
                "item_code": detail.item_code,
                "item_description": detail.item_description,
                "item_quantity_actual": detail.item_quantity_actual,
                "quantity_as_per_challan": detail.quantity_as_per_challan,
                "excess_shortfall_quantity": detail.excess_shortfall_quantity,
                "number_of_boxes_lr": detail.number_of_boxes_lr,
                "number_of_boxes_lr_recieved": detail.number_of_boxes_lr_recieved,
                "remarks_1": detail.remarks_1,
            }
            result.append(row)

        return jsonify(result), 200

    except Exception as e:
        import traceback
        print("❌ Exception occurred:", e)
        traceback.print_exc()
        return jsonify({"error": "Failed to fetch MDR data"}), 500

   
@app.route("/", methods=["GET"])
def new():
    return jsonify({'data': "hello world"})
 
with app.app_context():
    db.create_all()
 
if __name__ == "__main__":
    with app.app_context():
        db.create_all()
app.run(debug=True, host="0.0.0.0", port=5100)  # Remove ssl_context
 
if __name__ == '__main__':
    app.run(debug=True)
 