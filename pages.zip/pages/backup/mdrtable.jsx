import React, { useState } from 'react';
import { Button, Table, Input, Form, Popconfirm } from 'antd';
import { DeleteOutlined, PlusCircleOutlined } from '@ant-design/icons';
import '../pages/invoice.css'

const EditableContext = React.createContext(null);

const EditableRow = ({ index, ...props }) => {
    const [form] = Form.useForm();
    return (
        <Form form={form} component={false}>
            <EditableContext.Provider value={form}>
                <tr {...props} />
            </EditableContext.Provider>
        </Form>
    );
};

const EditableCell = ({ title, editable, children, dataIndex, record, handleSave, ...restProps }) => {
    const [editing, setEditing] = useState(false);
    const inputRef = React.useRef(null);
    const form = React.useContext(EditableContext);

    React.useEffect(() => {
        if (editing) {
            inputRef.current?.focus();
        }
    }, [editing]);

    const toggleEdit = () => {
        setEditing(!editing);
        form.setFieldsValue({ [dataIndex]: record[dataIndex] });
    };

    const save = async () => {
        try {
            const values = await form.validateFields();
            toggleEdit();
            handleSave({ ...record, ...values });
        } catch (errInfo) {
            console.log('Save failed:', errInfo);
        }
    };

    let childNode = children;

    if (editable) {
        childNode = editing ? (
            <Form.Item style={{ margin: 0 }} name={dataIndex}>
                <Input ref={inputRef} onPressEnter={save} onBlur={save} />
            </Form.Item>
        ) : (
            <div className="editable-cell-value-wrap" style={{ paddingInlineEnd: 24 }} onClick={toggleEdit}>
                {children}
            </div>
        );
    }

    return <td {...restProps}>{childNode}</td>;
};

const MDRTable = ({ onDataSourceChange }) => {
    const [dataSource, setDataSource] = useState([]);
    const [count, setCount] = useState(1);

    const handleDelete = (key) => {
        const newData = dataSource.filter((item) => item.key !== key);
        setDataSource(newData);
        onDataSourceChange(newData); // Send updated data to parent
    };

    const handleAdd = () => {
        const newData = {
            key: count,
            srno: count.toString(),
            item_code: '',
            item_description: '',
            unloading_location:'',
            quantity_as_per_challan: '',
            item_quantity_actual: '',
        excess_shortfall_quantity: '',
        number_of_boxes_lr: '',
        number_of_boxes_lr_recieved: '',
        };
        const updatedData = [...dataSource, newData];
        setDataSource(updatedData);
        setCount(count + 1);
        onDataSourceChange(updatedData); // Send updated data to parent
    };

    const handleSave = (row) => {
        const newData = [...dataSource];
        const index = newData.findIndex((item) => row.key === item.key);
        const item = newData[index];
    
        // Auto-calculate excess/shortfall
        const challanQty = parseFloat(row.quantity_as_per_challan) || 0;
        const actualQty = parseFloat(row.item_quantity_actual) || 0;
        const difference = actualQty - challanQty;
    
        let result = '';
        if (difference > 0) {
            result = `Excess: ${difference}`;
        } else if (difference < 0) {
            result = `Shortage: ${Math.abs(difference)}`;
        } else {
            result = 'Qualitative';
        }
    
        const updatedRow = {
            ...item,
            ...row,
            excess_shortfall_quantity: result,
        };
    
        newData.splice(index, 1, updatedRow);
        setDataSource(newData);
        onDataSourceChange(newData);
    };
    


    const columns = [
        { title: 'Sr No', dataIndex: 'srno', width: '5%', editable: true },
        { title: 'Part No', dataIndex: 'item_code', editable: true },
        { title: 'Material Description', dataIndex: 'item_description', editable: true },
        // {title:"Unloading Location",dataIndex:'unloading_location',editable:true},
        {
            title: 'Quantity',
            children: [
                { title: 'As per Challan/Invoices', dataIndex: 'quantity_as_per_challan', editable: true, width: 100 },
                { title: 'Actually Received', dataIndex: 'item_quantity_actual', editable: true, width: 100 },
                { title: 'Shortage/Excess/Qualitative', dataIndex: 'excess_shortfall_quantity', editable: true, width: 100 },
                { title:'UOM', dataIndex: 'qualitative', editable: true, width: 100 },
               
            ],
        },
        { 
            title: 'No of Boxes As Per LR',
             dataIndex: 'number_of_boxes_lr',
              editable: true, 
            },
        {
             title: 'No of Boxes As Per Received',
              dataIndex: 'number_of_boxes_lr_recieved',
               editable: true,
             },
        {
            title: 'Action',
            dataIndex: 'action',
            width: '5%',
            render: (_, record) =>
                dataSource.length >= 1 ? (
                    <Popconfirm title="Sure to delete?" onConfirm={() => handleDelete(record.key)}>
                        <a className=''><DeleteOutlined className='text-red-400 text-xl' /></a>
                    </Popconfirm>
                ) : null,
        },
    ];

    const components = {
        body: {
            row: EditableRow,
            cell: EditableCell,
        },
    };

    const processedColumns = columns.map((col) => {
        if (col.children) {
            return {
                ...col,
                children: col.children.map((childCol) => ({
                    ...childCol,
                    onCell: (record) => ({
                        record,
                        editable: childCol.editable,
                        dataIndex: childCol.dataIndex,
                        title: childCol.title,
                        handleSave,
                    }),
                })),
            };
        }
        return col.editable
            ? {
                ...col,
                onCell: (record) => ({
                    record,
                    editable: col.editable,
                    dataIndex: col.dataIndex,
                    title: col.title,
                    handleSave,
                }),
            }
            : col;
    });

//     return (
//         <div>
//             <Table className='h-64 overflow-y-scroll' components={components} rowClassName={() => 'editable-row'} bordered dataSource={dataSource} columns={processedColumns} pagination={false} />
//             <Button
//                 onClick={handleAdd}
//                 type="primary"
//                 className='h-10 !bg-[#c47c5c] font-semibold my-8' icon={<PlusCircleOutlined />} iconPosition='end'
//             >
//                 Add a row
//             </Button>
//         </div>
//     );
// };

return (
    <div>
      {/* Scrollable container for the main editable table */}
      <div style={{ overflowX: "auto", width: "100%" }}>
        <Table
          className="h-64 overflow-y-scroll"
          components={components}
          rowClassName={() => "editable-row"}
          bordered
          dataSource={dataSource}
          columns={processedColumns}
          pagination={false}
          scroll={{ x: true }}
          tableLayout="fixed"
        />
      </div>
  
      {/* Scrollable container for the remarks table */}
      {dataSource.length > 0 && (
        <div
          className="mt-6"
          style={{ overflowX: "auto", width: "100%", boxSizing: "border-box" }}
        >
          <table
            className="w-full border border-gray text-sm text-black"
            style={{
              minWidth: "1000px",
              borderCollapse: "collapse",
              tableLayout: "auto",
            }}
          >
            <thead className="bg-gray-100">
              <tr>
                <th
                  className="border bg-gray-50 border-gray px-2 py-1"
                  style={{ width: "10%" }}
                >
                  Sr No.
                </th>
                <th
                  className="border bg-gray-50 border-gray px-2 py-1"
                  style={{ width: "90%" }}
                >
                  Remark
                </th>
              </tr>
            </thead>
            <tbody>
              {dataSource.map((item, index) => (
                <tr key={index}>
                  <td className="border border-gray px-2 py-1 text-center bg-white">
                    {item.srno}
                  </td>
                  <td className="border border-gray px-2 py-1">
                    <Input.TextArea
                      value={item.mdr_remarks_1}
                      onChange={(e) => {
                        const updatedData = [...dataSource];
                        updatedData[index].mdr_remarks_1 = e.target.value;
                        setDataSource(updatedData);
                        onDataSourceChange(updatedData);
                      }}
                      rows={2}
                      className="w-full"
                      placeholder="Enter remark here..."
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
  
      {/* Add Row Button */}
      <Button
        onClick={handleAdd}
        type="primary"
        className="h-10 !bg-[#c47c5c] font-semibold my-8"
        icon={<PlusCircleOutlined />}
        iconPosition="end"
      >
        Add a row
      </Button>
    </div>
  );
}      



export default MDRTable