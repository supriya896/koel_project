
// // MDR.JSX
// import React, { useEffect, useState } from "react";
// import { useLocation, useNavigate } from "react-router";
// import { Modal, Checkbox } from "antd";
// import {
//   Button,
//   DatePicker,
//   Divider,
//   Form,
//   Input,
//   Select,
//   Space,
//   Upload,
//   message,
// } from "antd";
// import {
//   ArrowRightOutlined,
//   UploadOutlined,
//   CheckCircleOutlined,
// } from "@ant-design/icons";
// import html2canvas from "html2canvas";
// import axios from "axios";
// import MDRNavbar from "../components/MDRNavbar";
// import TextArea from "antd/es/input/TextArea";
// import MDRTable from "../components/MDRTable";
// import QRDisplay from "./QRDisplay";
// import { Table, Spin } from "antd";
// import dayjs from "dayjs";

// // const QRPage = () => {
// //   return <QRDisplay url={window.location.href} />;
// // };

// const MDR = ({ params }) => {
//   const location = useLocation();
//   const [form] = Form.useForm();
//   const Navigate = useNavigate();
//   const [tableData, setTableData] = useState([]);
//   const [uploadedImages, setUploadedImages] = useState([]);
//   const [uploadedLRImages, setUploadedLRImages] = useState([]);
//   const [uploadedInvoiceImages, setUploadedInvoiceImages] = useState([]);
//   const [selectedImage, setSelectedImage] = useState(null);
//   const [isModalOpen, setIsModalOpen] = useState(false);
//   const [viewedImages, setViewedImages] = useState(new Set());
//   const [email_id_to, setEmailTo] = useState(""); // Ensure this is declared
//   const [email_id_to_logistics, setEmailToLogistics] = useState(" "); // Ensure this is declared
//   const [email_id_cc, setEmailCc] = useState("sup.khap@catnipit.com"); // Ensure this is declared

//   const [fromDate, setFromDate] = useState("");
//   const [toDate, setToDate] = useState("");
//   const [exportModalVisible, setExportModalVisible] = useState(false);

//   const handleExport = async () => {
//     if (!fromDate || !toDate) {
//       message.error("Please select both From and To dates.");
//       return;
//     }

//     try {
//       const response = await axios.get(
//         "http://localhost:5100/export_mdr_data",
//         {
//           params: {
//             from_date: dayjs(fromDate).format("YYYY-MM-DD"),
//             to_date: dayjs(toDate).format("YYYY-MM-DD"),
//           },
//           responseType: "blob", // Required for downloading files
//         }
//       );

//       const blob = new Blob([response.data], {
//         type: response.headers["content-type"],
//       });
//       const link = document.createElement("a");
//       link.href = URL.createObjectURL(blob);
//       link.download = "Completed_MDR_Export.xlsx";
//       link.click();

//       setExportModalVisible(false);
//       setFromDate(null);
//       setToDate(null);
//       message.success("✅ Exported Successfully!");
//     } catch (error) {
//       console.error("❌ Export failed:", error);
//       message.error("Failed to export data.");
//     }
//   };

//   //Handleing On Enter Submit
//   useEffect(() => {
//     const handleKeyDown = (event) => {
//       if (event.key === "Enter") {
//         form.submit();
//       }
//     };
//     window.addEventListener("keydown", handleKeyDown);
//     return () => {
//       window.removeEventListener("keydown", handleKeyDown);
//     };
//   }, [form]);

//   useEffect(() => {
//     console.log("Updated Uploaded Images:", uploadedImages);
//     console.log("Updated Uploaded LR Images:", uploadedLRImages);
//     console.log("Updated Uploaded Invoice Images:", uploadedInvoiceImages);
//   }, [uploadedImages, uploadedLRImages, uploadedInvoiceImages]);

//   useEffect(() => {
//     console.log("Viewed Images:", viewedImages);
//   }, [viewedImages]);

//   //Submitting Form
//   const onFinish = async (values) => {
//     const emailFields = [
//       values.email_id_to,

//       values.email_id_to_logistics,

//       values.email_id_cc,
//     ];

//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

//     for (const field of emailFields) {
//       const emails = field?.split(/[\s,]+/) || [];

//       for (const email of emails) {
//         if (email && !emailRegex.test(email)) {
//           alert(`Invalid email format: ${email}`);

//           return;
//         }
//       }
//     }
//     const allImagesVerified = uploadedImages.every((img) => img.verified);

//     if (!allImagesVerified) {
//       message.error("Please verify all uploaded images before submitting.");
//       return;
//     }
//     try {
//       let grr_date = values.grr_date
//         ? values.grr_date.format("YYYY-MM-DD")
//         : null;
//       let invoice_date = values.invoice_date
//         ? values.invoice_date.format("YYYY-MM-DD")
//         : null;
//       let mdr_date = values.mdr_date
//         ? values.mdr_date.format("YYYY-MM-DD")
//         : null;

//       const emailCcArray = email_id_cc
//         .split(/[\s,]+/)
//         .map((email) => email.trim())
//         .filter((email) => email.length > 0);

//       const emailToLogisticsArray = email_id_to_logistics
//         .split(/[\s,]+/)
//         .map((email) => email.trim())
//         .filter((email) => email.length > 0);

//       // Create FormData to send files
//       const formData = new FormData();
//       formData.append("invoice_number", values.invoice_number || "");
//       formData.append("invoice_date", invoice_date || "");
//       formData.append("grr_number", values.grr_number || "");
//       formData.append("grr_date", grr_date || "");
//       formData.append("mdr_number", values.mdr_number || "");
//       formData.append("mdr_date", mdr_date || "");
//       formData.append("mdr_raised_as", values.mdr_raised_as || "");
//       formData.append("vehicle_number", values.vehicle_number || "");
//       formData.append(
//         "grr_mtn_sticker_number",
//         values.grr_mtn_sticker_number || ""
//       );
//       formData.append("transporter_name", values.transporter_name || "");
//       formData.append("supplier_name", values.supplier_name || "");
//       formData.append("lr_field", values.lr_field || "");
//       formData.append("vendor_name", values.vendor_name || "");
//       formData.append("vendor_code", values.vendor_code || "");
//       formData.append("number_of_boxes", values.number_of_boxes || "");
//       formData.append("unloading_location", values.unloading_location || "");
//       formData.append(
//         "number_of_boxes_lr_recieved",
//         values.number_of_boxes_lr_recieved || ""
//       );
//       formData.append("mdr_remarks_1", values.mdr_remarks_1 || "");
//       formData.append("email_id_to", values.email_id_to || "");
//       // formData.append("email_id_to_logistics", values.email_id_to_logistics || "");
//       formData.append("email_id_to_logistics", emailToLogisticsArray.join(","));
//       // formData.append("email_id_cc", values.email_id_cc || "");
//       formData.append("email_id_cc", emailCcArray.join(","));

//       // Convert tableData to JSON and append it as text
//       formData.append("tableData", JSON.stringify(tableData));

//       uploadedImages.forEach((file, index) => {
//         formData.append(`received_images`, file); // Ensure each file is properly appended
//       });

//       // Append images to FormData
//       // if (values.uploadedImages) {
//       //     values.uploadedImages.forEach((file, index) => {
//       //         formData.append(`received_images`, file.originFileObj);
//       //     });
//       // }

//       console.log("Submitting MDR Data:", formData);

//       // Send data using axios with multipart/form-data
//       // const response = await axios.post("https://192.168.62.199:5200/submit_mdr", formData, {
//       const response = await axios.post(
//         "http://localhost:5100/submit_mdr",
//         formData,
//         {
//           headers: { "Content-Type": "multipart/form-data" },
//         }
//       );

//       if (response.status === 201) {
//         console.log("MDR submitted successfully!");

//         Navigate("/mdr/print", {
//           replace: true,
//           state: {
//             data: values,
//             tableData,
//             grr_date,
//             invoice_date,
//             mdr_date,
//             received_images: uploadedImages,
//             email_id_to_logistics,
//             email_id_cc,
//           },
//         });

//         const sendEmailWithScreenshot = async () => {
//           const formElement = document.querySelector("Form");
//           if (!formElement) {
//             console.error("Form element not found for screenshot.");
//             return;
//           }

//           const canvas = await html2canvas(formElement);
//           const imageBlob = await new Promise((resolve) =>
//             canvas.toBlob(resolve, "image/png")
//           );

//           const emailToArray = values.email_id_to
//             ? values.email_id_to
//                 .split(/[\s,]+/) // splits on comma, space, or newline
//                 .filter((email) => email.length > 0) // remove empty strings
//             : [];

//           // const emailCcArray = values.email_id_cc
//           //  ? values.email_id_cc
//           //  .split(/[\s,]+/)
//           //  .filter((email) => email.length > 0)
//           //  : [];

//           //  const emailToLogisticsArray = values.email_id_to_logistics
//           //  ? values.email_id_to_logistics
//           //      .split(/[\s,]+/)
//           //      .filter((email) => email.length > 0)
//           //  : [];

//           const formatDate = (dateStr) => {
//             const date = new Date(dateStr);
//             return `${date.getDate().toString().padStart(2, "0")}-${(
//               date.getMonth() + 1
//             )
//               .toString()
//               .padStart(2, "0")}-${date.getFullYear()}`;
//           };

//           const emailFormData = new FormData();
//           emailToArray.forEach((email) =>
//             emailFormData.append("email_id_to", email)
//           );
//           emailToLogisticsArray.forEach((email) =>
//             emailFormData.append("email_id_to_logistics", email)
//           );
//           emailCcArray.forEach((email) =>
//             emailFormData.append("email_id_cc", email)
//           );
//           emailFormData.append(
//             "subject",
//             `MDR Submission - ${values.mdr_number}`
//           );
//           emailFormData.append(
//             "body",
//             `Invoice Number: ${values.invoice_number}\nMDR Number: ${
//               values.mdr_number
//             }\n
//             GRR Number: ${
//               values.grr_mtn_sticker_number
//             }\nGRR Date: ${formatDate(values.grr_date)}
//             \nInvoice Date: ${formatDate(values.invoice_date)}\n
//             MDR Date: ${formatDate(values.mdr_date)}\nVehicle Number: ${
//               values.vehicle_number
//             }\n
//             Supplier Name: ${values.vendor_name}\n Table Data: ${JSON.stringify(
//               tableData
//             )}`
//           );
//           uploadedImages.forEach((image) => {
//             emailFormData.append("images", image.file);
//           });
//           console.log("Data", tableData);
//           emailFormData.append("screenshot", imageBlob, "mdr_screenshot.png");

//           try {
//             // await axios.post("https://192.168.62.199:5200/send_mdr_email", emailFormData, {
//             await axios.post(
//               "http://localhost:5100/send_mdr_email",
//               emailFormData,
//               {
//                 headers: {
//                   "Content-Type": "multipart/form-data",
//                 },
//               }
//             );
//             console.log("✅ Email with screenshot sent successfully!");
//           } catch (emailError) {
//             console.error("❌ Failed to send email:", emailError);
//             message.error("Failed to send email with screenshot.");
//           }
//         };

//         await sendEmailWithScreenshot();
//       } else {
//         throw new Error(response.data.message || "Failed to submit MDR");
//       }
//     } catch (error) {
//       console.error("Submission Error:", error);
//       if (error.response) {
//         alert(error.response.data.error || "Server error occurred.");
//       } else if (error.request) {
//         message.error("No response from the server. Check your network.");
//       } else {
//         message.error("An unexpected error occurred.");
//       }
//     }
//   };

//   const navigate = useNavigate();
//   const imageUrl = "/path-to-image.jpg"; // Replace with actual path

//   const handleNavigate = () => {
//     navigate("/print", { state: { image: imageUrl } });
//   };

//   //Form validation Erro_
//   const onFinishFailed = (errorInfo) => {
//     console.log("Failed:", errorInfo);
//   };
//   // const handleUpload = ({ fileList }) => {
//   //     // const images = fileList.map((file) => ({
//   //     //     name: file.name,
//   //     //     url: URL.createObjectURL(file.originFileObj),  // ✅ Temporary URL
//   //     //     file: file.originFileObj, // ✅ Store actual file
//   //     // }));
//   //     // setUploadedImages(images);
//   //     // console.log("Uploaded Images:", images, uploadedImages); // Debugging
//   //     setUploadedImages(fileList.map(file => file.originFileObj)); // Store actual file objects
//   //     console.log("Uploaded Images:", fileList);
//   //     console.log(uploadedImages)
//   // };

//   const handleUpload = ({ fileList }) => {
//     const images = fileList.map((file) => ({
//       uid: file.uid,
//       name: file.name,
//       url: URL.createObjectURL(file.originFileObj || file),
//       verified: false,
//       file: file.originFileObj || file,
//     }));
//     setUploadedImages(images);
//   };

//   // Open Image Modal
//   const handleImageClick = (img) => {
//     setSelectedImage(img);
//     setIsModalOpen(true);
//   };

//   // Toggle Verification
//   const handleVerificationChange = (checked) => {
//     setUploadedImages((prevImages) =>
//       prevImages.map((img) =>
//         img.uid === selectedImage.uid ? { ...img, verified: checked } : img
//       )
//     );
//     setSelectedImage((prev) => ({ ...prev, verified: checked }));
//   };

//   const handleUpload1 = ({ fileList }) => {
//     const images = fileList.map((file) => ({
//       uid: file.uid,
//       name: file.name,
//       url: URL.createObjectURL(file.originFileObj || file),
//       verified: false,
//       file: file.originFileObj || file,
//     }));
//     setUploadedLRImages(images);
//   };

//   const handleUpload2 = ({ fileList }) => {
//     const images = fileList.map((file) => ({
//       uid: file.uid,
//       name: file.name,
//       url: URL.createObjectURL(file.originFileObj || file),
//       verified: false,
//       file: file.originFileObj || file,
//     }));
//     setUploadedInvoiceImages(images);
//   };

//   const handleImageVerification = (uid) => {
//     setUploadedImages((prevImages) =>
//       prevImages.map((img) =>
//         img.uid === uid ? { ...img, verified: !img.verified } : img
//       )
//     );
//   };

//  const handleMdrSearch = async (mdrNumber) => {
//   if (!mdrNumber) {
//     message.warning("Please enter an MDR number.");
//     return;
//   }

//   try {
//     const response = await axios.get("http://localhost:5100/get_all_mdr_data");
//     const data = response.data;

//     // ✅ Filter only rows for this MDR
//     const filtered = data.filter(
//       (entry) => entry.mdr_number?.toLowerCase() === mdrNumber.toLowerCase()
//     );

//     if (filtered.length === 0) {
//       message.error("No MDR found with this number.");
//       return;
//     }

//     // ✅ Use first row for master form
//     const masterData = filtered[0];

//     // ✅ Use all rows for table data
//     const detailData = filtered.map((row) => ({
//       item_code: row.item_code || "",
//       item_description: row.item_description || "",
//       item_quantity_actual: row.item_quantity_actual || "",
//       quantity_as_per_challan: row.quantity_as_per_challan || "",
//       excess_shortfall_quantity: row.excess_shortfall_quantity || "",
//       number_of_boxes_lr: row.number_of_boxes_lr || "",
//       number_of_boxes_lr_recieved: row.number_of_boxes_lr_recieved || "",
//       mdr_remarks_1: row.remarks_1 || "",
//     }));

//     // Set form fields
//     form.setFieldsValue({
//       ...masterData,
//       invoice_date: masterData.invoice_date ? dayjs(masterData.invoice_date) : null,
//       mdr_date: masterData.mdr_date ? dayjs(masterData.mdr_date) : null,
//     });

//     setEmailTo(masterData.email_id_to || "");
//     setEmailCc(masterData.email_id_cc || "");
//     setEmailToLogistics(masterData.email_id_to_logistics || "");

//     // ✅ Set table data properly
//     setTableData(detailData);

//     message.success(`Loaded MDR ${mdrNumber} successfully.`);
//   } catch (error) {
//     console.error("❌ MDR Search Error:", error);
//     message.error("Failed to fetch MDR data.");
//   }
// };



//   return (
//     <>
//       <MDRNavbar />
//       <p className="text-center text-xl">
//         Kagal Plant 1:D1. 5 Star MIDC, Kagal Dist.Kolhapur - 416 202
//       </p>
//       <p className="text-center text-xl">CIN No. : L29120PN2009PLC13351</p>
//       <div className="min-h-[80vh] w-[85%] bg-gray-100 mx-auto rounded-xl mt-10 px-10 pt-10 pb-2 mb-10">

//         {/* Export button outside the form and right-aligned */}
//         <div
//           style={{
//             display: "flex",
//             justifyContent: "flex-end",
//             marginBottom: "10px",
//           }}
//         >
//            <Input.Search
//     placeholder="Enter MDR Number"
//     enterButton="Search"
//     onSearch={handleMdrSearch}
//     style={{ width: 300 }}
//   />
//           <Button
//             style={{
//               backgroundColor: "#d9d9d9",
//               border: "1px solid #ccc",
//               color: "#000",
//             }}
//             onClick={() => setExportModalVisible(true)}
//           >
//             Export to Excel
//           </Button>
//         </div>

//         {/* Modal for Export */}
//         <Modal
//           title="Export MDRs Data"
//           open={exportModalVisible}
//           onOk={handleExport}
//           onCancel={() => setExportModalVisible(false)}
//           okText="Export"
//         >
//           <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
//             <label>From Date:</label>
//             <DatePicker
//               value={fromDate}
//               onChange={(date) => setFromDate(date)}
//               format="YYYY-MM-DD"
//             />
//             <label>To Date:</label>
//             <DatePicker
//               value={toDate}
//               onChange={(date) => setToDate(date)}
//               format="YYYY-MM-DD"
//             />
//           </div>
//         </Modal>

//         <Form
//           name="basic"
//           form={form}
//           onFinish={onFinish}
//           onFinishFailed={onFinishFailed}
//           autoComplete="off"
//           labelCol={{
//             span: 24,
//           }}
//           wrapperCol={{
//             span: 44,
//           }}
//         >
//           {/* <div style={{ padding: 10 }}> */}
//           {/* <QRDisplay url={window.location.href} /> */}
//           {/* <QRDisplay url="http://192.168.176.242:5173/mdr" /> */}
//           {/* </div> */}

//           <div className="w-full flex flex-wrap gap-6">
//             <Form.Item
//               className="w-[18%]"
//               label="GRR/Sticker/MTN No."
//               name="grr_mtn_sticker_number"
//               labelCol={{ span: 24 }}
//               rules={[{ message: "Please enter a value!" }]}
//             >
//               {/* <Input className="h-10" /> */}
//               <Input.TextArea
//                 autoSize={{ minRows: 1, maxRows: 3 }}
//                 className="h-auto"
//               />
//             </Form.Item>
//             <Form.Item
//               className="w-[18%]"
//               label="GRR Date"
//               name="grr_date"
//               labelCol={{ span: 24 }}
//             >
//               <DatePicker className="h-10 w-[100%]" />
//             </Form.Item>
//             <Form.Item
//               className="w-[18%]"
//               label="Invoice Number"
//               name="invoice_number"
//               labelCol={{ span: 24 }}
//               rules={[{ required: true, message: "Please enter a value!" }]}
//             >
//               {/* <Input className="h-10" /> */}
//               <Input.TextArea
//                 autoSize={{ minRows: 1, maxRows: 3 }}
//                 className="h-auto"
//               />
//             </Form.Item>
//             <Form.Item
//               className="w-[18%]"
//               label="Invoice Date"
//               name="invoice_date"
//               labelCol={{ span: 24 }}
//             >
//               <DatePicker className="h-10 w-[100%]" />
//             </Form.Item>
//             <Form.Item
//               className="w-[18%]"
//               label="MDR Number"
//               name="mdr_number"
//               labelCol={{ span: 24 }}
//               rules={[{ required: true, message: "Please enter a value!" }]}
//             >
//               <Input className="h-10" />
//             </Form.Item>
//             <Form.Item
//               className="w-[18%]"
//               label="MDR Date"
//               name="mdr_date"
//               labelCol={{ span: 24 }}
//             >
//               <DatePicker className="h-10 w-[100%]" />
//             </Form.Item>
//           </div>
//           <div className="w-full flex gap-10">
//             <Form.Item
//               label="Unloading Location"
//               className="w-[30%]"
//               labelCol={{ span: 24 }}
//               name="unloading_location"
//               rules={[{ message: "Please select a value!" }]}
//             >
//               <Select
//                 className="h-10 w-[100%] !border-none"
//                 placeholder="Choose"
//                 options={[
//                   {
//                     value: "LMHP",
//                     label: "LMHP",
//                   },
//                   {
//                     value: "HHP",
//                     label: "HHP",
//                   },
//                   {
//                     value: "Genset",
//                     label: "Genset",
//                   },
//                   {
//                     value: "RWH",
//                     label: "RWH",
//                   },
//                   {
//                     value: "Extended Store",
//                     label: "Extended Store",
//                   },
//                   {
//                     value: "RM Store",
//                     label: "RM Store",
//                   },
//                 ]}
//               />
//             </Form.Item>

//             <Form.Item
//               label="MDR Raised At"
//               labelCol={{ span: 24 }}
//               className="w-[30%]"
//               name="mdr_raised_as"
//               rules={[{ message: "Please select a value!" }]}
//             >
//               <Select
//                 className="h-10 w-[100%] !border-none"
//                 placeholder="Choose"
//                 options={[
//                   {
//                     value: "Unloading",
//                     label: "Unloading",
//                   },
//                   {
//                     value: "Storage",
//                     label: "Storage",
//                   },
//                 ]}
//               />
//             </Form.Item>
//             <Form.Item
//               className="w-[30%]"
//               label="Vehicle Number"
//               name="vehicle_number"
//               labelCol={{ span: 24 }}
//               rules={[{ message: "Please enter a value!" }]}
//             >
//               <Input className="h-10" />
//             </Form.Item>
//           </div>
//           <div className="w-full flex gap-10">
//             <Form.Item
//               className="w-[30%]"
//               label="Transporter Name"
//               name="transporter_name"
//               labelCol={{ span: 24 }}
//               rules={[{ message: "Please enter a value!" }]}
//             >
//               <Input className="h-10" />
//             </Form.Item>
//             <Form.Item
//               className="w-[30%]"
//               label="Supplier Name"
//               name="vendor_name"
//               labelCol={{ span: 24 }}
//               rules={[{ message: "Please enter a value!" }]}
//             >
//               <Input className="h-10" />
//             </Form.Item>
//             <Form.Item
//               className="w-[30%]"
//               label="LR/Docket No."
//               name="lr_field"
//               labelCol={{ span: 24 }}
//               rules={[{ message: "Please enter a value!" }]}
//             >
//               <Input className="h-10" />
//             </Form.Item>

//             <Form.Item
//               className="w-[30%]"
//               label="Vendor Code"
//               name="vendor_code"
//               labelCol={{ span: 24 }}
//               rules={[{ message: "Please enter a value!" }]}
//             >
//               <Input className="h-10" />
//             </Form.Item>
//           </div>
//           <div>
//             <p>
//               The following discrepancies have been observed in the supply
//               received from you:
//             </p>
//           </div>
//           {/* <MDRTable onDataSourceChange={setTableData} /> */}
//           <MDRTable dataSource={tableData} onDataSourceChange={setTableData} />


//           <div className="w-full flex gap-10">
//             <Form.Item
//               className="w-1/2"
//               label="Email TO Buyer"
//               name="email_id_to"
//               labelCol={{ span: 24 }}
//               rules={[
//                 { required: false, message: "Please enter a valid email!" },
//               ]}
//             >
//               <TextArea
//                 // className="h-10"
//                 autoSize={{ minRows: 1, maxRows: 5 }} // Adjust min and max as needed
//                 value={email_id_to}
//                 onChange={(e) => setEmailTo(e.target.value)}
//               />
//             </Form.Item>
//             <Form.Item
//               className="w-1/2"
//               label="Email TO Logistics"
//               // name="email_id_to_logistics"
//               labelCol={{ span: 24 }}
//               rules={[
//                 { required: false, message: "Please enter a valid email!" },
//               ]}
//             >
//               <TextArea
//                 // className="h-10"
//                 autoSize={{ minRows: 1, maxRows: 5 }}
//                 value={email_id_to_logistics}
//                 onChange={(e) => setEmailToLogistics(e.target.value)}
//               />
//             </Form.Item>

//             <Form.Item
//               className="w-1/2"
//               label="Email CC"
//               // name="email_id_cc"
//               labelCol={{ span: 24 }}
//               rules={[{ required: false, message: "Please enter a value!" }]}
//             >
//               <TextArea
//                 // className="h-10"
//                 autoSize={{ minRows: 1, maxRows: 5 }}
//                 value={email_id_cc}
//                 onChange={(e) => setEmailCc(e.target.value)}
//               />
//             </Form.Item>
//           </div>
//           <div className="w-full flex gap-10">
//             <Form.Item
//               label="Upload Images"
//               name="received_images"
//               rules={[
//                 { required: false, message: "Upload at least one image!" },
//               ]}
//             >
//               <Upload
//                 beforeUpload={() => false}
//                 listType="picture"
//                 multiple
//                 onChange={handleUpload}
//               >
//                 <Button icon={<UploadOutlined />}>Click to Upload</Button>
//               </Upload>
//             </Form.Item>
//             <Form.Item
//               label="Upload LR Images"
//               name="received_lr_images"
//               rules={[
//                 { required: false, message: "Upload at least one image!" },
//               ]}
//             >
//               <Upload
//                 beforeUpload={() => false}
//                 listType="picture"
//                 multiple
//                 onChange={handleUpload1}
//               >
//                 <Button icon={<UploadOutlined />}>Click to Upload</Button>
//               </Upload>
//             </Form.Item>
//             <Form.Item
//               label="Upload Invoice Images"
//               name="received_invoice_images"
//               rules={[
//                 { required: false, message: "Upload at least one image!" },
//               ]}
//             >
//               <Upload
//                 beforeUpload={() => false}
//                 listType="picture"
//                 multiple
//                 onChange={handleUpload2}
//               >
//                 <Button icon={<UploadOutlined />}>Click to Upload</Button>
//               </Upload>
//             </Form.Item>
//           </div>

//           {/* Uploaded Images List */}
//           <div className="flex flex-wrap gap-3 mt-4">
//             {uploadedImages.map((img) => (
//               <img
//                 key={img.uid}
//                 src={img.url}
//                 alt={img.name}
//                 className="w-24 h-24 cursor-pointer border-2 rounded-md"
//                 style={{ borderColor: img.verified ? "green" : "red" }}
//                 onClick={() => handleImageClick(img)}
//               />
//             ))}
//           </div>

//           {/* Image Preview Modal */}
//           <Modal
//             open={isModalOpen}
//             onCancel={() => setIsModalOpen(false)}
//             footer={null}
//           >
//             {selectedImage && (
//               <div className="flex flex-col items-center">
//                 <img
//                   src={selectedImage.url}
//                   alt={selectedImage.name}
//                   className="w-full max-h-[400px] object-contain"
//                 />
//                 <Checkbox
//                   checked={selectedImage.verified}
//                   onChange={(e) => handleVerificationChange(e.target.checked)}
//                   className="mt-4"
//                 >
//                   Verified
//                 </Checkbox>
//               </div>
//             )}
//           </Modal>

//           <Divider />
//           <Form.Item>
//             <div className="w-full flex flex-row justify-between">
//               <div className="flex flex-col gap-8">
//                 <p className="text-center">Prepared By</p>
//                 <p className="border-t-2 border-gray-700 w-[160px] text-center">
//                   TA/Store
//                 </p>
//               </div>
//               <div>
//                 <p className="text-center flex flex-col mb-8">
//                   Verified By Kirloskar
//                 </p>
//                 <div className="flex gap-8">
//                   <p className="border-t-2 border-gray-700 w-[160px] text-center">
//                     Buyer
//                   </p>
//                   <p className="border-t-2 border-gray-700 w-[160px] text-center">
//                     Security
//                   </p>
//                 </div>
//               </div>
//               <div>
//                 <p className="text-center flex flex-col mb-8">Verified By</p>
//                 <div className="flex gap-8">
//                   <p className="border-t-2 border-gray-700 w-[160px] text-center">
//                     Driver
//                   </p>
//                   <p className="border-t-2 border-gray-700 w-[160px] text-center">
//                     Transporter/ Logistic
//                   </p>
//                 </div>
//               </div>
//               <div>
//                 <p className="text-center flex flex-col mb-8">Approved By</p>
//                 <div className="flex gap-8">
//                   <p className="border-t-2 border-gray-700 w-[160px] text-center">
//                     TL/GL Store
//                   </p>
//                 </div>
//               </div>
//             </div>
//             <Divider />
//             <Space className="w-full flex justify-end">
//               <Button
//                 type="primary"
//                 htmlType="submit"
//                 className="h-10 !bg-[#1d998b] font-semibold"
//                 icon={<ArrowRightOutlined />}
//                 iconPosition="end"
//               >
//                 Submit
//               </Button>
//             </Space>
//           </Form.Item>
//         </Form>
//       </div>
//     </>
//   );
// };

// export default MDR;

// MDR.JSX
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router";
import { Modal, Checkbox } from "antd";
import {
  Button,
  DatePicker,
  Divider,
  Form,
  Input,
  Select,
  Space,
  Upload,
  message,
} from "antd";
import { ArrowRightOutlined, UploadOutlined, CheckCircleOutlined,PrinterOutlined  } from "@ant-design/icons";
import html2canvas from "html2canvas";
import axios from "axios";
import MDRNavbar from "../components/MDRNavbar";
import TextArea from "antd/es/input/TextArea";
import MDRTable from "../components/MDRTable";
import dayjs from 'dayjs';

const MDR = ({ params }) => {

  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true)
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [exportModalVisible, setExportModalVisible] = useState(false);
  const [showDuplicateCopy, setShowDuplicateCopy] = useState(false);


  const handleExport = async () => {
    if (!fromDate || !toDate) {
      message.error("Please select both From and To dates.");
      return;
    }

    try {
      // const response = await axios.get("https://192.168.62.199:5200/export_mdr_data", {
      const response = await axios.get("http://localhost:5100/export_mdr_data", {
        params: {
          from_date: dayjs(fromDate).format("YYYY-MM-DD"),
          to_date: dayjs(toDate).format("YYYY-MM-DD"),
        },
        responseType: "blob", // Required for downloading files
      });

      const blob = new Blob([response.data], { type: response.headers["content-type"] });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "Completed_MDR_Export.xlsx";
      link.click();

      setExportModalVisible(false);
      setFromDate(null);
      setToDate(null);
      message.success("✅ Exported Successfully!");
    } catch (error) {
      console.error("❌ Export failed:", error);
      message.error("Failed to export data.");
    }
  };


  // useEffect(() => {
  //   const fetchProtectedData = async () => {
  //     try {
  //       const token = localStorage.getItem('token');

  //       const res = await axios.get('https://192.168.62.199:5100/auth/protected', {
  //         headers: {
  //           'Authorization': `Bearer ${token}`,
  //           'Content-Type': 'application/json'
  //         }

  //       });
  //       console.log("fff", res)
  //       setUserData(res.data);
  //       localStorage.setItem('userData', JSON.stringify(res.data))
  //       setLoading(false)
  //     } catch (error) {
  //       console.log(error)
  //       setLoading(false)
  //       alert('Unauthorized. Redirecting to login...');
  //       localStorage.removeItem('token');
  //       window.location.href = '/';
  //     }
  //   };

  //   fetchProtectedData();
  // }, []);


  const location = useLocation();
  const [form] = Form.useForm();
  const Navigate = useNavigate();
  const [tableData, setTableData] = useState([]);
  const [uploadedImages, setUploadedImages] = useState({
    invoice: [],
    lr: [],
    other: []
  }); const [selectedImage, setSelectedImage] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [viewedImages, setViewedImages] = useState(new Set());
  const [email_id_to, setEmailTo] = useState(""); // Ensure this is declared
  const [email_id_to_logistic, setEmailToLogistic] = useState(""); // Ensure this is declared
  const [email_id_cc, setEmailCc] = useState(""); // Ensure this is declared
  const [mdrData, setMdrData] = useState({ date: '', });
  const customFormat = (value) => value.format('DD-MMM-YY');

  const parsedUserData = JSON.parse(localStorage.getItem("userData"));
  // console.log("user:", parsedUserData?.username);

  //Handleing On Enter Submit
  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === "Enter") {
        form.submit();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [form]);

  useEffect(() => {
    console.log("Updated Uploaded Images:", uploadedImages);
  }, [uploadedImages]);

  useEffect(() => {
    console.log("Viewed Images:", viewedImages);
  }, [viewedImages]);

  //Submitting Form
  const onFinish = async (values) => {
    const allImages = [
      ...uploadedImages.invoice,
      ...uploadedImages.lr,
      ...uploadedImages.other
    ];
    const allImagesVerified = allImages.length === 0 || allImages.every(img => img.verified);
    if (!allImagesVerified) {
      message.error("Please verify all uploaded images before submitting.");
      return;
    }

    if (!allImagesVerified) {
      message.error("Please verify all uploaded images before submitting.");
      return;
    }
    try {
      let invoice_date = values.invoice_date
        ? values.invoice_date.format("YYYY-MM-DD")
        : null;
      let mdr_date = values.mdr_date
        ? values.mdr_date.format("YYYY-MM-DD")
        : null;

      // Create FormData to send files
      const formData = new FormData();
      formData.append("invoice_number", values.invoice_number || "");
      formData.append("invoice_date", invoice_date || "");
      formData.append("grr_number", values.grr_number || "");
      formData.append("mdr_number", values.mdr_number || "");
      formData.append("mdr_date", mdr_date || "");
      formData.append("mdr_raised_as", values.mdr_raised_as || "");
      formData.append("vehicle_number", values.vehicle_number || "");
      formData.append(
        "grr_mtn_sticker_number",
        values.grr_mtn_sticker_number || ""
      );
      formData.append("transporter_name", values.transporter_name || "");
      formData.append("supplier_name", values.supplier_name || "");
      formData.append("lr_field", values.lr_field || "");
      formData.append("vendor_name", values.vendor_name || "");
      formData.append("vendor_code", values.vendor_code || "");
      formData.append("number_of_boxes", values.number_of_boxes || "");
      formData.append("unloading_location", values.unloading_location || "");
      formData.append(
        "number_of_boxes_lr_recieved",
        values.number_of_boxes_lr_recieved || ""
      );
      formData.append("mdr_remarks_1", values.mdr_remarks_1 || "");
      formData.append("email_id_to", email_id_to || "");
      formData.append("email_id_to_logistic", email_id_to_logistic || "");
      formData.append("email_id_cc", email_id_cc || "");
      formData.append("sub_mdr_number", values.sub_mdr_number || "");
      formData.append("userMdr", parsedUserData?.username || "");

      // Convert tableData to JSON and append it as text
      formData.append("tableData", JSON.stringify(tableData));

      // uploadedImages.forEach((file, index) => {
      //   formData.append(`received_images`, file); // Ensure each file is properly appended
      // });
      Object.entries(uploadedImages).forEach(([category, images]) => {
        images.forEach((img, index) => {
          if (img.file instanceof File) {
            formData.append(`received_images_${category}`, img.file, img.name);
            console.log(`Appending file: category=${category}, index=${index}, filename=${img.name}`);
          } else {
            console.warn(`Item in uploadedImages.${category}[${index}] is not a File object:`, img);
          }
        });
      });






      // Append images to FormData
      // if (values.uploadedImages) {
      //     values.uploadedImages.forEach((file, index) => {
      //         formData.append(`received_images`, file.originFileObj);
      //     });
      // }

      console.log("Submitting MDR Data:", formData);

      // Send data using axios with multipart/form-data
      // const response = await axios.post("https://192.168.62.199:5200/submit_mdr", formData, {
        const response = await axios.post(
          "http://localhost:5100/submit_mdr",
          formData,
          {
        headers: { "Content-Type": "multipart/form-data" },
      }
      );

      if (response.status === 201) {
        console.log("MDR submitted successfully!");

        Navigate("/mdr/print", {
          replace: true,
          state: {
            data: values,
            tableData,
            invoice_date,
            mdr_date,
            received_images: uploadedImages,
          },
        });

        const sendEmailWithScreenshot = async () => {
          const formElement = document.querySelector("Form");
          if (!formElement) {
            console.error("Form element not found for screenshot.");
            return;
          }

          const canvas = await html2canvas(formElement);
          const imageBlob = await new Promise((resolve) =>
            canvas.toBlob(resolve, "image/png")
          );

          const emailToArray = values.email_id_to
            ? values.email_id_to
              .split(/[\s,]+/) // splits on comma, space, or newline
              .filter((email) => email.length > 0) // remove empty strings
            : [];

          const emailToLogisticArray = values.email_id_to_logistic
            ? values.email_id_to_logistic
              .split(/[\s,]+/) // splits on comma, space, or newline
              .filter((email) => email.length > 0) // remove empty strings
            : [];

          const emailCcArray = values.email_id_cc
            ? values.email_id_cc
              .split(/[\s,]+/)
              .filter((email) => email.length > 0)
            : [];

          const formatDate = (dateStr) => {
            const date = new Date(dateStr);
            return `${date.getDate().toString().padStart(2, "0")}-${(date.getMonth() + 1)
              .toString()
              .padStart(2, "0")}-${date.getFullYear()}`;
          };


          const emailFormData = new FormData();
          emailToArray.forEach((email) => emailFormData.append("email_id_to", email));
          emailToLogisticArray.forEach((email) => emailFormData.append("email_id_to_logistic", email));
          emailCcArray.forEach((email) => emailFormData.append("email_id_cc", email));
          emailFormData.append("subject", `MDR Intimation For Approval - ${values.mdr_number}`);
          // emailFormData.append(
          //   "body",
          //   `Invoice Number: ${values.invoice_number}\nMDR Number: ${values.mdr_number}`
          // );

          const invoiceNumberArray = values.invoice_number.split(",");
          const grrNumberArray = values.grr_mtn_sticker_number.split(",");

          // 🧠 Build enriched table data without affecting actual UI
          const enrichedTableData = tableData.map((row, index) => ({
            ...row,
            invoice_number: invoiceNumberArray[index]?.trim() || "-",
            grr_number: grrNumberArray[index]?.trim() || "-"
          }));

          // emailFormData.append(
          //   "body",
          //   `Invoice Number: ${values.invoice_number}\nMDR Number: ${values.mdr_number}\n
          //   GRR Number: ${values.grr_mtn_sticker_number}\nInvoice Date: ${formatDate(values.invoice_date)}\n
          //   MDR Date: ${formatDate(values.mdr_date)}\nVehicle Number: ${values.vehicle_number}\n
          //   Supplier Name: ${values.vendor_name}\n Table Data: ${JSON.stringify(enrichedTableData)}`

          // );
          emailFormData.append(
  "body",
  `Invoice Number: ${values.invoice_number}
   MDR Number: ${values.mdr_number}
   GRR Number: ${values.grr_mtn_sticker_number}
   GRR Date: ${formatDate(values.grr_date)}
   Invoice Date: ${formatDate(values.invoice_date)}
   MDR Date: ${formatDate(values.mdr_date)}
   Vehicle Number: ${values.vehicle_number}
   Supplier Name: ${values.vendor_name}
   Table Data: ${JSON.stringify(enrichedTableData)}`
);
          emailFormData.append("screenshot", imageBlob, "mdr_screenshot.png");

          Object.entries(uploadedImages).forEach(([category, images]) => {
            images.forEach((img, index) => {
              if (img.file instanceof File) {
                // You can use the same emailFormData object
                emailFormData.append(`received_images_${category}_${index}`, img.file, img.name);
                console.log(`Appending file to emailFormData: category=${category}, index=${index}, filename=${img.name}`);
              } else {
                console.warn(`Item in uploadedImages.${category}[${index}] is not a File object:`, img);
              }
            });
          });


          try {
            // await axios.post("https://192.168.62.199:5200/send_mdr_email", emailFormData, {
            await axios.post("http://localhost:5100/send_mdr_email", emailFormData, {
              headers: {
                "Content-Type": "multipart/form-data",
              },
            });
            console.log("✅ Email with screenshot sent successfully!");
          } catch (emailError) {
            console.error("❌ Failed to send email:", emailError);
            message.error("Failed to send email with screenshot.");
          }
        };

        await sendEmailWithScreenshot();
      } else {
        throw new Error(response.data.message || "Failed to submit MDR");
      }
    } catch (error) {
      console.error("Submission Error:", error);
      if (error.response) {
        message.error(error.response.data.error || "Server error occurred.");
      } else if (error.request) {
        message.error("No response from the server. Check your network.");
      } else {
        message.error("An unexpected error occurred.");
      }
    }
  };

  const navigate = useNavigate();
  const imageUrl = "/path-to-image.jpg"; // Replace with actual path

  const handleNavigate = () => {
    navigate("/print", { state: { image: imageUrl } });
  };

  //Form validation Erro_
  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };
  // const handleUpload = ({ fileList }) => {
  //     // const images = fileList.map((file) => ({
  //     //     name: file.name,
  //     //     url: URL.createObjectURL(file.originFileObj),  // ✅ Temporary URL
  //     //     file: file.originFileObj, // ✅ Store actual file
  //     // }));
  //     // setUploadedImages(images);
  //     // console.log("Uploaded Images:", images, uploadedImages); // Debugging
  //     setUploadedImages(fileList.map(file => file.originFileObj)); // Store actual file objects
  //     console.log("Uploaded Images:", fileList);
  //     console.log(uploadedImages)
  // };



  const handleUpload = ({ fileList }, category) => {
    const images = fileList.map((file) => ({
      uid: file.uid,
      name: file.name,
      url: URL.createObjectURL(file.originFileObj || file),
      verified: false,
      file: file.originFileObj || file,
    }));

    setUploadedImages((prev) => ({
      ...prev,
      [category]: images,
    }));
  };



  const handleImageClick = (img) => {
    setSelectedImage(img); // img now includes `category`
    setIsModalOpen(true);
  };

  const handleVerificationChange = (checked) => {
    const { uid, category } = selectedImage;

    setUploadedImages((prevImages) => ({
      ...prevImages,
      [category]: prevImages[category].map((img) =>
        img.uid === uid ? { ...img, verified: checked } : img
      ),
    }));

    setSelectedImage((prev) => ({ ...prev, verified: checked }));
  };

  const handleUnloadingLocationChange = async (location) => {
    try {
      // const response = await axios.get("https://192.168.62.199:5200/get_latest_submdr_number", {
      const response = await axios.get("http://localhost:5100/get_latest_submdr_number", {
        params: { unloading_location: location }
      });

      const latestSubMDR = response.data.latest_sub_mdr_number || 0;

      console.log("latest:", latestSubMDR)
      const newSubMDR = latestSubMDR + 1;

      console.log("New:", newSubMDR)

      form.setFieldsValue({
        unloading_location: location,
        sub_mdr_number: newSubMDR,
      });

      console.log("data:", form.getFieldsValue());

      message.success(`Sub-MDR No. ${newSubMDR} generated for ${location}`);
    } catch (error) {
      console.error("Failed to fetch Sub-MDR No:", error);
      message.error("Failed to fetch Sub-MDR No.");
    }
  };

  const handleSearchMDR = async (mdrNumber) => {
    if (!mdrNumber) return message.warning("Enter MDR number");

    try {
      const response = await axios.get(
        "http://localhost:5100/get_mdr_by_number",
      // const response = await axios.get(
      //   "https://192.168.62.199:5200/get_mdr_by_number",
        {
          params: { mdr_number: mdrNumber.trim() },
        }
      );

      const data = response.data;
      let loadedInvoiceDate = [];
      form.setFieldsValue({
        ...data,
        invoice_date: data.invoice_date ? dayjs(data.invoice_date) : null,
        mdr_date: data.mdr_date ? dayjs(data.mdr_date) : null,
      });

      setTableData(data.tableData || []);
      console.log("loaded data",data)
      setUploadedImages(
        data.received_images || { invoice: [], lr: [], other: [] }
      );
      setShowDuplicateCopy(true);
      message.success("MDR loaded successfully");
    } catch (err) {
      console.error(err);
      setShowDuplicateCopy(false);
      message.error("MDR not found or failed to load");
    }
  };


  return (
    <>
      <MDRNavbar />
      <p className="text-center text-xl">
        Kagal Plant 1:D1. 5 Star MIDC, Kagal Dist.Kolhapur - 416 202
      </p>
      <p className="text-center text-xl">CIN No. : L29120PN2009PLC13351</p>
      {showDuplicateCopy && (
      <div
        style={{
          fontWeight: "bold",
          color: "red",
          marginTop: "10px",
          marginBottom: "10px",
          textAlign: "center",
        }}
      >
        Duplicate Copy
      </div>
    )}

      <div className="min-h-[80vh] w-[85%] bg-gray-100 mx-auto rounded-xl mt-10 px-10 pt-10 pb-2 mb-10">
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: "10px",
          }}
        >
          {/* Left: Search Input */}
          <Form.Item label="Search MDR Number" style={{ marginBottom: 0 }}>
            <Input.Search
              placeholder="Enter MDR Number"
              enterButton="Search MDR"
              onSearch={handleSearchMDR}
              style={{ width: 300 }}
            />
          </Form.Item>

          {/* Right: Export Button */}
          <Button
            style={{
              backgroundColor: "#d9d9d9",
              border: "1px solid #ccc",
              color: "#000",
            }}
            onClick={() => setExportModalVisible(true)}
          >
            Export MDR
          </Button>
        </div>

        {/* Modal for Export */}
        <Modal
          title="Export MDRs Data"
          open={exportModalVisible}
          onOk={handleExport}
          onCancel={() => setExportModalVisible(false)}
          okText="Export"
        >
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <label>From Date:</label>
            <DatePicker
              value={fromDate}
              onChange={(date) => setFromDate(date)}
              format="YYYY-MM-DD"
            />
            <label>To Date:</label>
            <DatePicker
              value={toDate}
              onChange={(date) => setToDate(date)}
              format="YYYY-MM-DD"
            />
          </div>
        </Modal>

        <Form
          name="basic"
          form={form}
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
          autoComplete="off"
          labelCol={{
            span: 24,
          }}
          wrapperCol={{
            span: 44,
          }}
        >
          {/* <Form.Item label="Search MDR Number">
            <Input.Search
              placeholder="Enter MDR Number"
              enterButton="Search MDR"
              onSearch={handleSearchMDR}
              style={{ width: 300 }}
            />
          </Form.Item> */}
          <div className="w-full flex flex-wrap gap-6">
            <Form.Item
              className="w-[18%]"
              label="GRR/Sticker/MTN No."
              name="grr_mtn_sticker_number"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }]}
            >
              {/* <Input className="h-10" /> */}
              <Input.TextArea autoSize={{ minRows: 1.3, maxRows: 3 }} className="h-auto"
                style={{ wordBreak: "break-word", overflowWrap: "break-word" }}

              />

            </Form.Item>
            <Form.Item
              className="w-[18%]"
              label="Invoice Number"
              name="invoice_number"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              {/* <Input className="h-10" /> */}
              <Input.TextArea autoSize={{ minRows: 1.3, maxRows: 3 }} className="h-auto"
                style={{ wordBreak: "break-word", overflowWrap: "break-word" }}

              />

            </Form.Item>
            <Form.Item
              className="w-[18%]"
              label="Invoice Date"
              name="invoice_date"
              labelCol={{ span: 24 }}
            >
              <DatePicker
                format={customFormat}
                className="h-10 w-[100%]"
                value={mdrData.date ? dayjs(mdrData.date, 'DD-MMM-YY') : null}
                onChange={(date) => {
                  const formatted = date ? date.format('DD-MMM-YY') : '';
                  setMdrData({ ...mdrData, date: formatted });
                }}
              />

            </Form.Item>
            <Form.Item
              className="w-[18%]"
              label="MDR Number"
              name="mdr_number"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              <Input className="h-10" />
            </Form.Item>
            <Form.Item
              className="w-[18%]"
              label="MDR Date"
              name="mdr_date"
              labelCol={{ span: 24 }}
            >
              <DatePicker
                format={customFormat}
                className="h-10 w-[100%]"
                value={mdrData.date ? dayjs(mdrData.date, 'DD-MMM-YY') : null}
                onChange={(date) => {
                  const formatted = date ? date.format('DD-MMM-YY') : '';
                  setMdrData({ ...mdrData, date: formatted });
                }}
              />

            </Form.Item>

            {/* <Form.Item className='w-[25%]' label="GRR Number" name="grr_number" labelCol={{ span: 24 }} rules={[{ required: false, message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item> */}
          </div>
          <div className="w-full flex gap-10">
            <Form.Item
              label="Unloading Location"
              className="w-[30%]"
              labelCol={{ span: 24 }}
              name="unloading_location"
              rules={[{ message: "Please select a value!" }]}
            >
              <Select
                className="h-10 w-[100%] !border-none"
                onChange={handleUnloadingLocationChange}
                placeholder="Choose"
                options={[
                  {
                    value: "LMHP",
                    label: "LMHP",
                  },
                  {
                    value: "HHP",
                    label: "HHP",
                  },
                  {
                    value: "Genset",
                    label: "Genset",
                  },
                  {
                    value: "RWH",
                    label: "RWH",
                  },
                  {
                    value: "Extended Store",
                    label: "Extended Store",
                  },
                  {
                    value: "RM Store",
                    label: "RM Store",
                  },
                ]}
              />
            </Form.Item>
            <Form.Item
              label="Sub-MDR No."
              name="sub_mdr_number"
              labelCol={{ span: 24 }}
            >
              <Input value={form.getFieldValue("sub_mdr_number")} readOnly />
            </Form.Item>

            <Form.Item
              label="MDR Raised At"
              labelCol={{ span: 24 }}
              className="w-[30%]"
              name="mdr_raised_as"
              rules={[{ message: "Please select a value!" }]}
            >
              <Select
                className="h-10 w-[100%] !border-none"
                placeholder="Choose"
                options={[
                  {
                    value: "Unloading",
                    label: "Unloading",
                  },
                  {
                    value: "Storage",
                    label: "Storage",
                  },
                ]}
              />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="Vehicle Number"
              name="vehicle_number"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }
                // {
                //   pattern: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z0-9]{1,12}$/,
                //   message: 'Must be alphanumeric, include letters & numbers, max 10-12 chars',
                // }
              ]}
            >
              <Input className="h-10" />
            </Form.Item>
          </div>
          <div className="w-full flex gap-10">
            <Form.Item
              className="w-[30%]"
              label="Transporter Name"
              name="transporter_name"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }]}
            >
              <Input className="h-10" />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="Supplier Name"
              name="vendor_name"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }]}
            >
              {/* <Input className="h-10" /> */}
              <Input.TextArea autoSize={{ minRows: 1.3, maxRows: 3 }} className="h-auto"
                style={{ wordBreak: "break-word", overflowWrap: "break-word" }}

              />

            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="LR/Docket No."
              name="lr_field"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }]}
            >
              <Input className="h-10" />
            </Form.Item>
            {/* <Form.Item className='w-[30%]' label="Vendor Namer" name="vendor_name" labelCol={{ span: 24 }} rules={[{ message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item> */}
            <Form.Item
              className="w-[30%]"
              label="Vendor Code"
              name="vendor_code"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }]}
            >
              <Input className="h-10" />
            </Form.Item>
          </div>
          <div>
            <p>
              The following discrepancies have been observed in the supply
              received from you:
            </p>
          </div>
          <MDRTable dataSource={tableData} onDataSourceChange={setTableData} />
          {/* <div className='w-full flex gap-10'>
                        <Form.Item className='w-[30%]' label="No.of Boxes/Carton's on LR" name="number_of_boxes" labelCol={{ span: 24 }} rules={[{ message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="Received" name="number_of_boxes_lr_recieved" labelCol={{ span: 24 }} rules={[{ message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
 
 
                    </div> */}
          <div className="w-full flex gap-10">
            {/* <Form.Item
              className="w-[30%]"
              label="MDR remarks"
              name="mdr_remarks_1"
              labelCol={{ span: 24 }}
              rules={[{ message: "Please enter a value!" }]}
            >
              <TextArea className="h-10" />
            </Form.Item> */}
            <Form.Item
              className="w-1/2"
              label="Email TO Buyer"
              name="email_id_to"
              labelCol={{ span: 24 }}
              rules={[
                { required: true, message: "Please enter a valid email!" },
              ]}
            >
              <TextArea
                // className="h-10"
                autoSize={{ minRows: 2, maxRows: 5 }} // Adjust min and max as needed
                value={email_id_to}
                onChange={(e) => setEmailTo(e.target.value)}
              />
            </Form.Item>
            <Form.Item
              className="w-1/2"
              label="Email TO Logistic"
              name="email_id_to_logistic"
              labelCol={{ span: 24 }}
              rules={[
                { required: true, message: "Please enter a valid email!" },
              ]}
            >
              <TextArea
                // className="h-10"
                autoSize={{ minRows: 2, maxRows: 5 }} // Adjust min and max as needed
                value={email_id_to_logistic}
                onChange={(e) => setEmailToLogistic(e.target.value)}
              />
            </Form.Item>

            <Form.Item
              className="w-1/2"
              label="Email CC"
              name="email_id_cc"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              <TextArea
                // className="h-10"
                autoSize={{ minRows: 2, maxRows: 5 }} // Adjust min and max as needed
                value={email_id_cc}
                onChange={(e) => setEmailCc(e.target.value)}
              />
            </Form.Item>
          </div>
          <div className="w-full flex gap-10">
            <Form.Item
              label="Upload Invoice Image"
              name="received_images"
              rules={[
                { required: false, message: "Upload at least one image!" },
              ]}
            >
              <Upload
                beforeUpload={() => false}
                listType="picture"
                multiple
                onChange={(info) => handleUpload(info, 'invoice')}
              >
                <Button icon={<UploadOutlined />}>Click to Upload</Button>
              </Upload>
            </Form.Item>
            <Form.Item
              label="Upload LR Image"
              name="received_images"
              rules={[
                { required: false, message: "Upload at least one image!" },
              ]}
            >
              <Upload
                beforeUpload={() => false}
                listType="picture"
                multiple
                onChange={(info) => handleUpload(info, 'lr')}
              >
                <Button icon={<UploadOutlined />}>Click to Upload</Button>
              </Upload>
            </Form.Item>
            <Form.Item
              label="Upload Image"
              name="received_images"
              rules={[
                { required: false, message: "Upload at least one image!" },
              ]}
            >
              <Upload
                beforeUpload={() => false}
                listType="picture"
                multiple
                onChange={(info) => handleUpload(info, 'other')}
              >
                <Button icon={<UploadOutlined />}>Click to Upload</Button>
              </Upload>
            </Form.Item>
          </div>

          {/* Uploaded Images List */}
          <div>
            {Object.entries(uploadedImages).map(([category, images]) => (
              // Only render the category section if there are images in it
              images.length > 0 && (
                <div key={category} className="mt-4">
                  <h4 className="font-semibold capitalize mb-2">{category} Images</h4>
                  <div className="flex flex-wrap gap-3">
                    {/* Now map over the 'images' array for the current category */}
                    {images.map((img) => (
                      <div key={img.uid} className="relative">
                        <img
                          src={img.url}
                          alt={img.name}
                          className="w-24 h-24 cursor-pointer border-2 rounded-md object-cover" // Added object-cover
                          style={{ borderColor: img.verified ? 'green' : 'red' }}
                          // Ensure handleImageClick receives the category info too
                          onClick={() => handleImageClick({ ...img, category })}
                        />
                        {/* Optional: Display a checkmark for verified images */}
                        {img.verified && (
                          <CheckCircleOutlined
                            className="absolute top-1 right-1 text-green-500 bg-white rounded-full p-0.5"
                            style={{ fontSize: '16px' }}
                          />
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )
            ))}
          </div>

          {/* Image Preview Modal */}
          <Modal
            open={isModalOpen}
            onCancel={() => setIsModalOpen(false)}
            footer={null}
          >
            {selectedImage && (
              <div className="flex flex-col items-center">
                <img
                  src={selectedImage.url}
                  alt={selectedImage.name}
                  className="w-full max-h-[400px] object-contain"
                />
                <Checkbox
                  checked={selectedImage.verified}
                  onChange={(e) => handleVerificationChange(e.target.checked)}
                  className="mt-4"
                >
                  Verified
                </Checkbox>
              </div>
            )}
          </Modal>
          <Divider />
          <Form.Item>
            <div className="w-full flex flex-row justify-between">
              <div className="flex flex-col gap-8">
                <p className="text-center">Prepared By</p>
                <p className="border-t-2 border-gray-700 w-[160px] text-center">
                  TA/Store
                </p>
              </div>
              <div>
                <p className="text-center flex flex-col mb-8">
                  Verified By Kirloskar
                </p>
                <div className="flex gap-8">
                  <p className="border-t-2 border-gray-700 w-[160px] text-center">
                    Buyer
                  </p>
                  <p className="border-t-2 border-gray-700 w-[160px] text-center">
                    Security
                  </p>
                </div>
              </div>
              <div>
                <p className="text-center flex flex-col mb-8">Verified By</p>
                <div className="flex gap-8">
                  <p className="border-t-2 border-gray-700 w-[160px] text-center">
                    Driver
                  </p>
                  <p className="border-t-2 border-gray-700 w-[160px] text-center">
                    Transporter/ Logistic
                  </p>
                </div>
              </div>
              <div>
                <p className="text-center flex flex-col mb-8">Approved By</p>
                <div className="flex gap-8">
                  <p className="border-t-2 border-gray-700 w-[160px] text-center">
                    TL/GL Store
                  </p>

                </div>
              </div>
            </div>
            <Divider />
            <Space className="w-full flex justify-end">
              <Button
                type="primary"
                htmlType="submit"
                className="h-10 !bg-[#1d998b] font-semibold"
                icon={<ArrowRightOutlined />}
                iconPosition="end"
              >
                Submit
              </Button>

              <Button
                type="primary"
                className="h-10 !bg-[#1d998b] font-semibold"
                icon={<PrinterOutlined />}
                onClick={() => {
                  const formValues = form.getFieldsValue();
                  Navigate("/mdr/print", {
                    replace: true,
                    state: {
                      data: formValues,
                      tableData,
                      invoice_date:
                        formValues.invoice_date?.format("YYYY-MM-DD"),
                      mdr_date: formValues.mdr_date?.format("YYYY-MM-DD"),
                      received_images: uploadedImages,
                      showDuplicateCopy: true,
                    },
                  });
                }}
              >
                Print Only
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </div>
    </>
  );
};

export default MDR;
