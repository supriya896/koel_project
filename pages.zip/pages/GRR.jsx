
// // ManualGRRForm.jsx — Fully manual form for GRR with all fields and both tables

// import React, { useState, useContext, useRef } from "react";
// import {
//   Form,
//   Input,
//   DatePicker,
//   Button,
//   Table,
//   Popconfirm,
//   message,
// } from "antd";
// import { PlusOutlined, DeleteOutlined } from "@ant-design/icons";
// // import logo from "/Kirloskar-logo.png";

// const EditableContext = React.createContext(null);
// const EditableRow = ({ index, ...props }) => {
//   const [form] = Form.useForm();
//   return (
//     <Form form={form} component={false}>
//       <EditableContext.Provider value={form}>
//         <tr {...props} />
//       </EditableContext.Provider>
//     </Form>
//   );
// };

// const EditableCell = ({ editable, children, dataIndex, record, handleSave, ...restProps }) => {
//   const [editing, setEditing] = useState(false);
//   const inputRef = useRef(null);
//   const form = useContext(EditableContext);

//   const toggleEdit = () => {
//     setEditing(!editing);
//     form.setFieldsValue({ [dataIndex]: record[dataIndex] });
//   };

//   const save = async () => {
//     try {
//       const values = await form.validateFields();
//       toggleEdit();
//       handleSave({ ...record, ...values });
//     } catch (err) {
//       console.log("Save failed:", err);
//     }
//   };

//   let childNode = children;
//   if (editable) {
//     childNode = editing ? (
//       <Form.Item style={{ margin: 0 }} name={dataIndex}>
//         <Input ref={inputRef} onBlur={save} onPressEnter={save} />
//       </Form.Item>
//     ) : (
//       <div className="editable-cell-value-wrap" onClick={toggleEdit}>
//         {children}
//       </div>
//     );
//   }

//   return <td {...restProps}>{childNode}</td>;
// };

// const GRR = () => {
//   const [form] = Form.useForm();
//   const [itemRows, setItemRows] = useState([]);
//   const [taxRows, setTaxRows] = useState([]);
//   const [count, setCount] = useState(0);

//   const handleAddRow = (setRows) => {
//     const newRow = { key: count };
//     setRows(prev => [...prev, newRow]);
//     setCount(prev => prev + 1);
//   };

//   const handleDelete = (key, setRows) => {
//     setRows(prev => prev.filter(row => row.key !== key));
//   };

//   const handleSaveRow = (row, rows, setRows) => {
//     const newData = [...rows];
//     const index = newData.findIndex((item) => row.key === item.key);
//     newData.splice(index, 1, row);
//     setRows(newData);
//   };

//   const createEditableColumns = (columns, rows, setRows) =>
//     columns.map((col) =>
//       col.editable
//         ? {
//             ...col,
//             onCell: (record) => ({
//               record,
//               editable: true,
//               dataIndex: col.dataIndex,
//               title: col.title,
//               handleSave: (row) => handleSaveRow(row, rows, setRows),
//             }),
//           }
//         : col
//     );

//   const itemColumns = createEditableColumns(
//     [
//       { title: "Sr. No", render: (_, __, index) => index + 1 },
//       { title: "Part No", dataIndex: "partNo", editable: true },
//       { title: "Description", dataIndex: "description", editable: true },
//       { title: "Challan Qty", dataIndex: "challanQty", editable: true },
//       { title: "Received Qty", dataIndex: "receivedQty", editable: true },
//       { title: "Shortage/Excess", dataIndex: "shortageExcess", editable: true },
//       {
//         title: "Action",
//         render: (_, record) => (
//           <Popconfirm title="Delete?" onConfirm={() => handleDelete(record.key, setItemRows)}>
//             <DeleteOutlined className="text-red-500 cursor-pointer" />
//           </Popconfirm>
//         ),
//       },
//     ],
//     itemRows,
//     setItemRows
//   );

//   const taxColumns = createEditableColumns(
//     [
//       { title: "Sr. No", render: (_, __, index) => index + 1 },
//       { title: "Tax Rate Name", dataIndex: "taxRateName", editable: true },
//       { title: "Conversion Type", dataIndex: "conversionType", editable: true },
//       { title: "Currency", dataIndex: "currency", editable: true },
//       { title: "Tax %", dataIndex: "taxPercent", editable: true },
//       { title: "Recoverable Amt", dataIndex: "recoverableAmount", editable: true },
//       { title: "Recoverable", dataIndex: "recoverable", editable: true },
//       { title: "Party Name", dataIndex: "partyName", editable: true },
//       { title: "Party Site", dataIndex: "partySite", editable: true },
//       { title: "Functional Tax Amt", dataIndex: "functionalTaxAmount", editable: true },
//       {
//         title: "Action",
//         render: (_, record) => (
//           <Popconfirm title="Delete?" onConfirm={() => handleDelete(record.key, setTaxRows)}>
//             <DeleteOutlined className="text-red-500 cursor-pointer" />
//           </Popconfirm>
//         ),
//       },
//     ],
//     taxRows,
//     setTaxRows
//   );

//   const onSubmit = async () => {
//     try {
//       const values = await form.validateFields();
//       const payload = {
//         ...values,
//         itemDetails: itemRows,
//         taxRateDetails: taxRows,
//       };
//       console.log("GRR Submitted:", payload);
//       message.success("Form data logged to console.");
//     } catch (err) {
//       message.error("Please fill all required fields.");
//     }
//   };

//   return (
//     <div className="w-[85%] mx-auto mt-10 mb-20 bg-gray-100 p-10 rounded-xl">
//       {/* <img src={logo} alt="Kirloskar Logo" className="h-20 mb-6" /> */}
//       <Form form={form} layout="vertical">
//         <h2 className="text-xl font-semibold mb-4">GRR Entry</h2>
//         <div className="grid grid-cols-3 gap-6">
//           <Form.Item label="Receipt (GRR)" name="receiptGRR"><Input /></Form.Item>
//           <Form.Item label="Receipt Date" name="receiptDate"><DatePicker className="w-full" /></Form.Item>
//           <Form.Item label="Shipped Date" name="shippedDate"><DatePicker className="w-full" /></Form.Item>
//           <Form.Item label="Received By" name="receivedBy"><Input /></Form.Item>
//           <Form.Item label="Supplier" name="supplier"><Input /></Form.Item>
//           <Form.Item label="Packing Slips" name="packingSlips"><Input /></Form.Item>
//           <Form.Item label="Vendor Code" name="vendorcode"><Input /></Form.Item>
//           <Form.Item label="Invoice No" name="invoiceNo"><Input /></Form.Item>
//           <Form.Item label="Invoice Date" name="invoiceDate"><DatePicker className="w-full" /></Form.Item>
//           <Form.Item label="Shipment No" name="shipmentNo"><Input /></Form.Item>
//           <Form.Item label="Invoice Amount" name="invoiceAmount"><Input /></Form.Item>
//           <Form.Item label="Supplier Invoice Amount" name="supplierInvoiceAmount"><Input /></Form.Item>
//           <Form.Item label="Gate Entry Number" name="gateEntryNumber"><Input /></Form.Item>
//           <Form.Item label="Security Entry Date" name="securityEntryDate"><DatePicker className="w-full" /></Form.Item>
//           <Form.Item label="Comments" name="comments"><Input.TextArea rows={2} /></Form.Item>
//         </div>

//         <h3 className="text-lg font-semibold mt-10 mb-2">Item Details</h3>
//         <Button onClick={() => handleAddRow(setItemRows)} icon={<PlusOutlined />} className="mb-2">Add Row</Button>
//         <Table
//           components={{ body: { row: EditableRow, cell: EditableCell } }}
//           bordered
//           dataSource={itemRows}
//           columns={itemColumns}
//           rowClassName={() => "editable-row"}
//           pagination={false}
//         />

//         <h3 className="text-lg font-semibold mt-10 mb-2">Tax Rate Details</h3>
//         <Button onClick={() => handleAddRow(setTaxRows)} icon={<PlusOutlined />} className="mb-2">Add Row</Button>
//         <Table
//           components={{ body: { row: EditableRow, cell: EditableCell } }}
//           bordered
//           dataSource={taxRows}
//           columns={taxColumns}
//           rowClassName={() => "editable-row"}
//           pagination={false}
//         />

//         <div className="mt-10 text-center">
//           <Button type="primary" onClick={onSubmit} className="bg-[#1d998b]">Submit GRR</Button>
//         </div>
//       </Form>
//     </div>
//   );
// };

// export default GRR;

// import React, { useState, useRef, useContext } from "react";
// import {
//   Form, Input, DatePicker, Button, Table, Popconfirm, message
// } from "antd";
// import { PlusOutlined, DeleteOutlined } from "@ant-design/icons";

// // Editable context for tables
// const EditableContext = React.createContext(null);
// const EditableRow = ({ index, ...props }) => {
//   const [form] = Form.useForm();
//   return (
//     <Form form={form} component={false}>
//       <EditableContext.Provider value={form}>
//         <tr {...props} />
//       </EditableContext.Provider>
//     </Form>
//   );
// };

// const EditableCell = ({ editable, children, dataIndex, record, handleSave, ...restProps }) => {
//   const [editing, setEditing] = useState(false);
//   const inputRef = useRef(null);
//   const form = useContext(EditableContext);

//   const toggleEdit = () => {
//     setEditing(!editing);
//     form.setFieldsValue({ [dataIndex]: record[dataIndex] });
//   };

//   const save = async () => {
//     try {
//       const values = await form.validateFields();
//       toggleEdit();
//       handleSave({ ...record, ...values });
//     } catch (err) {
//       console.log("Save failed:", err);
//     }
//   };

//   let childNode = children;
//   if (editable) {
//     childNode = editing ? (
//       <Form.Item style={{ margin: 0 }} name={dataIndex}>
//         <Input ref={inputRef} onBlur={save} onPressEnter={save} />
//       </Form.Item>
//     ) : (
//       <div className="editable-cell-value-wrap" onClick={toggleEdit}>
//         {children}
//       </div>
//     );
//   }

//   return <td {...restProps}>{childNode}</td>;
// };

// const GRR = () => {
//   const [form] = Form.useForm();
//   const [showTables, setShowTables] = useState(false);
//   const [itemRows, setItemRows] = useState([]);
//   const [taxRows, setTaxRows] = useState([]);
//   const [count, setCount] = useState(0);

//   const handleAddRow = (setRows) => {
//     const newRow = { key: count };
//     setRows(prev => [...prev, newRow]);
//     setCount(prev => prev + 1);
//   };

//   const handleDelete = (key, setRows) => {
//     setRows(prev => prev.filter(row => row.key !== key));
//   };

//   const handleSaveRow = (row, rows, setRows) => {
//     const newData = [...rows];
//     const index = newData.findIndex((item) => row.key === item.key);
//     newData.splice(index, 1, row);
//     setRows(newData);
//   };

//   const createColumns = (columns, rows, setRows) =>
//     columns.map(col => col.editable ? {
//       ...col,
//       onCell: record => ({
//         record,
//         editable: true,
//         dataIndex: col.dataIndex,
//         title: col.title,
//         handleSave: row => handleSaveRow(row, rows, setRows),
//       }),
//     } : col);

//   const itemColumns = createColumns([
//     { title: "Sr No", render: (_, __, index) => index + 1 },
//     { title: "Part No", dataIndex: "partNo", editable: true },
//     { title: "Description", dataIndex: "description", editable: true },
//     { title: "Challan Qty", dataIndex: "challanQty", editable: true },
//     { title: "Received Qty", dataIndex: "receivedQty", editable: true },
//     { title: "Shortage/Excess", dataIndex: "shortageExcess", editable: true },
//     {
//       title: "Action",
//       render: (_, record) => (
//         <Popconfirm title="Delete?" onConfirm={() => handleDelete(record.key, setItemRows)}>
//           <DeleteOutlined className="text-red-500 cursor-pointer" />
//         </Popconfirm>
//       ),
//     },
//   ], itemRows, setItemRows);

//   const taxColumns = createColumns([
//     { title: "Sr No", render: (_, __, index) => index + 1 },
//     { title: "Tax Rate Name", dataIndex: "taxRateName", editable: true },
//     { title: "Conversion Type", dataIndex: "conversionType", editable: true },
//     { title: "Currency", dataIndex: "currency", editable: true },
//     { title: "Tax %", dataIndex: "taxPercent", editable: true },
//     { title: "Recoverable Amt", dataIndex: "recoverableAmount", editable: true },
//     { title: "Recoverable", dataIndex: "recoverable", editable: true },
//     { title: "Party Name", dataIndex: "partyName", editable: true },
//     { title: "Party Site", dataIndex: "partySite", editable: true },
//     { title: "Functional Tax Amt", dataIndex: "functionalTaxAmount", editable: true },
//     {
//       title: "Action",
//       render: (_, record) => (
//         <Popconfirm title="Delete?" onConfirm={() => handleDelete(record.key, setTaxRows)}>
//           <DeleteOutlined className="text-red-500 cursor-pointer" />
//         </Popconfirm>
//       ),
//     },
//   ], taxRows, setTaxRows);

//   const onSubmit = async () => {
//     try {
//       const values = await form.validateFields();
//       const payload = {
//         ...values,
//         itemDetails: itemRows,
//         taxRateDetails: taxRows,
//       };
//       console.log("GRR Submitted:", payload);
//       message.success("GRR Submitted. Check console for payload.");
//     } catch (err) {
//       message.error("Please complete required fields.");
//     }
//   };

//   return (
//     <div className="w-[85%] mx-auto mt-10 mb-20 bg-gray-100 p-10 rounded-xl">
//       <Form form={form} layout="vertical">
//         {!showTables ? (
//           <>
//             <h2 className="text-xl font-semibold mb-4">GRR Entry</h2>
//             <div className="grid grid-cols-3 gap-6">
//               <Form.Item label="Receipt (GRR)" name="receiptGRR"><Input /></Form.Item>
//               <Form.Item label="Receipt Date" name="receiptDate"><DatePicker className="w-full" /></Form.Item>
//               <Form.Item label="Shipped Date" name="shippedDate"><DatePicker className="w-full" /></Form.Item>
//               <Form.Item label="Received By" name="receivedBy"><Input /></Form.Item>
//               <Form.Item label="Supplier" name="supplier"><Input /></Form.Item>
//               <Form.Item label="Packing Slips" name="packingSlips"><Input /></Form.Item>
//               <Form.Item label="Vendor Code" name="vendorcode"><Input /></Form.Item>
//               <Form.Item label="Invoice No" name="invoiceNo"><Input /></Form.Item>
//               <Form.Item label="Invoice Date" name="invoiceDate"><DatePicker className="w-full" /></Form.Item>
//               <Form.Item label="Shipment No" name="shipmentNo"><Input /></Form.Item>
//               <Form.Item label="Invoice Amount" name="invoiceAmount"><Input /></Form.Item>
//               <Form.Item label="Supplier Invoice Amount" name="supplierInvoiceAmount"><Input /></Form.Item>
//               <Form.Item label="Gate Entry Number" name="gateEntryNumber"><Input /></Form.Item>
//               <Form.Item label="Security Entry Date" name="securityEntryDate"><DatePicker className="w-full" /></Form.Item>
//               <Form.Item label="Comments" name="comments"><Input.TextArea rows={2} /></Form.Item>
//             </div>

//             <div className="mt-10 text-center">
//               <Button type="primary" onClick={() => setShowTables(true)} className="bg-[#1677ff]">Next: Fill Tables</Button>
//             </div>
//           </>
//         ) : (
//           <>
//             <h3 className="text-lg font-semibold mt-10 mb-2">Item Details</h3>
//             <Button onClick={() => handleAddRow(setItemRows)} icon={<PlusOutlined />} className="mb-2">Add Row</Button>
//             <Table
//               components={{ body: { row: EditableRow, cell: EditableCell } }}
//               bordered
//               dataSource={itemRows}
//               columns={itemColumns}
//               rowClassName={() => "editable-row"}
//               pagination={false}
//               scroll={{ x: true }}
//             />

//             <h3 className="text-lg font-semibold mt-10 mb-2">Tax Rate Details</h3>
//             <Button onClick={() => handleAddRow(setTaxRows)} icon={<PlusOutlined />} className="mb-2">Add Row</Button>
//             <Table
//               components={{ body: { row: EditableRow, cell: EditableCell } }}
//               bordered
//               dataSource={taxRows}
//               columns={taxColumns}
//               rowClassName={() => "editable-row"}
//               pagination={false}
//               scroll={{ x: true }}
//             />

//             <div className="mt-10 text-center space-x-4">
//               <Button onClick={() => setShowTables(false)}>Back</Button>
//               <Button type="primary" onClick={onSubmit} className="bg-[#1d998b]">Submit GRR</Button>
//             </div>
//           </>
//         )}
//       </Form>
//     </div>
//   );
// };

// export default GRR;

// import React, { useState, useContext, useRef } from "react";
// import {
//   Form,
//   Input,
//   DatePicker,
//   Button,
//   Table,
//   Popconfirm,
//   message,
// } from "antd";
// import { PlusOutlined, DeleteOutlined } from "@ant-design/icons";
// import GRRTables from './GRRTables';

// const EditableContext = React.createContext(null);
// const EditableRow = ({ index, ...props }) => {
//   const [form] = Form.useForm();
//   return (
//     <Form form={form} component={false}>
//       <EditableContext.Provider value={form}>
//         <tr {...props} />
//       </EditableContext.Provider>
//     </Form>
//   );
// };

// const EditableCell = ({ editable, children, dataIndex, record, handleSave, ...restProps }) => {
//   const [editing, setEditing] = useState(false);
//   const inputRef = useRef(null);
//   const form = useContext(EditableContext);

//   const toggleEdit = () => {
//     setEditing(!editing);
//     form.setFieldsValue({ [dataIndex]: record[dataIndex] });
//   };

//   const save = async () => {
//     try {
//       const values = await form.validateFields();
//       toggleEdit();
//       handleSave({ ...record, ...values });
//     } catch (err) {
//       console.log("Save failed:", err);
//     }
//   };

//   let childNode = children;
//   if (editable) {
//     childNode = editing ? (
//       <Form.Item style={{ margin: 0 }} name={dataIndex}>
//         <Input ref={inputRef} onBlur={save} onPressEnter={save} />
//       </Form.Item>
//     ) : (
//       <div className="editable-cell-value-wrap" onClick={toggleEdit}>
//         {children}
//       </div>
//     );
//   }

//   return <td {...restProps}>{childNode}</td>;
// };

// const GRR = () => {
//   const [form] = Form.useForm();
//   const [showTables, setShowTables] = useState(false);
//   const [itemRows, setItemRows] = useState([]);
//   const [taxRows, setTaxRows] = useState([]);
//   const [count, setCount] = useState(0);

//   const handleAddRow = (setRows) => {
//     const newRow = { key: count };
//     setRows(prev => [...prev, newRow]);
//     setCount(prev => prev + 1);
//   };

//   const handleDelete = (key, setRows) => {
//     setRows(prev => prev.filter(row => row.key !== key));
//   };

//   const handleSaveRow = (row, rows, setRows) => {
//     const newData = [...rows];
//     const index = newData.findIndex((item) => row.key === item.key);
//     newData.splice(index, 1, row);
//     setRows(newData);
//   };

//   const createColumns = (columns, rows, setRows) =>
//     columns.map(col => col.editable ? {
//       ...col,
//       onCell: record => ({
//         record,
//         editable: true,
//         dataIndex: col.dataIndex,
//         title: col.title,
//         handleSave: row => handleSaveRow(row, rows, setRows),
//       }),
//     } : col);

//   const itemColumns = createColumns([
//     { title: "Sr. No", render: (_, __, index) => index + 1 },
//     { title: "Part No", dataIndex: "partNo", editable: true },
//     { title: "Description", dataIndex: "description", editable: true },
//     { title: "Challan Qty", dataIndex: "challanQty", editable: true },
//     { title: "Received Qty", dataIndex: "receivedQty", editable: true },
//     { title: "Shortage/Excess", dataIndex: "shortageExcess", editable: true },
//     {
//       title: "Action",
//       render: (_, record) => (
//         <Popconfirm title="Delete?" onConfirm={() => handleDelete(record.key, setItemRows)}>
//           <DeleteOutlined className="text-red-500 cursor-pointer" />
//         </Popconfirm>
//       ),
//     },
//   ], itemRows, setItemRows);

//   const taxColumns = createColumns([
//     { title: "Sr. No", render: (_, __, index) => index + 1 },
//     { title: "Tax Rate Name", dataIndex: "taxRateName", editable: true },
//     { title: "Conversion Type", dataIndex: "conversionType", editable: true },
//     { title: "Currency", dataIndex: "currency", editable: true },
//     { title: "Tax %", dataIndex: "taxPercent", editable: true },
//     { title: "Recoverable Amt", dataIndex: "recoverableAmount", editable: true },
//     { title: "Recoverable", dataIndex: "recoverable", editable: true },
//     { title: "Party Name", dataIndex: "partyName", editable: true },
//     { title: "Party Site", dataIndex: "partySite", editable: true },
//     { title: "Functional Tax Amt", dataIndex: "functionalTaxAmount", editable: true },
//     {
//       title: "Action",
//       render: (_, record) => (
//         <Popconfirm title="Delete?" onConfirm={() => handleDelete(record.key, setTaxRows)}>
//           <DeleteOutlined className="text-red-500 cursor-pointer" />
//         </Popconfirm>
//       ),
//     },
//   ], taxRows, setTaxRows);

//   const onSubmit = async () => {
//     try {
//       const values = await form.validateFields();
//       const payload = {
//         ...values,
//         itemDetails: itemRows,
//         taxRateDetails: taxRows,
//       };
//       console.log("GRR Submitted:", payload);
//       message.success("Form data logged to console.");
//     } catch (err) {
//       message.error("Please fill all required fields.");
//     }
//   };

//   return (
//     <div className="w-[85%] mx-auto mt-10 mb-20 bg-gray-100 p-10 rounded-xl">
//       <Form form={form} layout="vertical">
//         {!showTables ? (
//           <>
//             <h2 className="text-xl font-semibold mb-4">GRR Entry</h2>
//             <div className="grid grid-cols-3 gap-6">
//               <Form.Item label="Receipt (GRR)" name="receiptGRR"><Input /></Form.Item>
//               <Form.Item label="Receipt Date" name="receiptDate"><DatePicker className="w-full" /></Form.Item>
//               <Form.Item label="Shipped Date" name="shippedDate"><DatePicker className="w-full" /></Form.Item>
//               <Form.Item label="Received By" name="receivedBy"><Input /></Form.Item>
//               <Form.Item label="Supplier" name="supplier"><Input /></Form.Item>
//               <Form.Item label="Packing Slips" name="packingSlips"><Input /></Form.Item>
//               <Form.Item label="Vendor Code" name="vendorCode"><Input /></Form.Item>
//               <Form.Item label="Comments" name="comments"><Input.TextArea rows={1} /></Form.Item>
//               <Form.Item label="Invoice No" name="invoiceNo"><Input /></Form.Item>
//               <Form.Item label="Shipment No" name="shipmentNo"><Input /></Form.Item>
//               <Form.Item label="Invoice Amount" name="invoiceAmount"><Input /></Form.Item>
//               <Form.Item label="Supplier Invoice Amount" name="supplierInvoiceAmount"><Input /></Form.Item>
//               <Form.Item label="Gate Entry Number" name="gateEntryNumber"><Input /></Form.Item>
//               <Form.Item label="Security Entry Date" name="securityEntryDate"><DatePicker className="w-full" /></Form.Item>
//             </div>
//             <div className="mt-10 text-center">
//               <Button type="primary" onClick={() => setShowTables(true)} className="bg-[#1d998b]">Next</Button>
//             </div>
//           </>
//         ) : (
//           <>
//             <h3 className="text-lg font-semibold mt-10 mb-2">Item Details</h3>
//             <Button onClick={() => handleAddRow(setItemRows)} icon={<PlusOutlined />} className="mb-2">Add Row</Button>
//             <Table
//               components={{ body: { row: EditableRow, cell: EditableCell } }}
//               bordered
//               dataSource={itemRows}
//               columns={itemColumns}
//               rowClassName={() => "editable-row"}
//               pagination={false}
//               scroll={{ x: true }}
//             />

//             <h3 className="text-lg font-semibold mt-10 mb-2">Tax Rate Details</h3>
//             <Button onClick={() => handleAddRow(setTaxRows)} icon={<PlusOutlined />} className="mb-2">Add Row</Button>
//             <Table
//               components={{ body: { row: EditableRow, cell: EditableCell } }}
//               bordered
//               dataSource={taxRows}
//               columns={taxColumns}
//               rowClassName={() => "editable-row"}
//               pagination={false}
//               scroll={{ x: true }}
//             />

//             <div className="mt-10 text-center space-x-4">
//               <Button onClick={() => setShowTables(false)}>Back</Button>
//               <Button type="primary" onClick={onSubmit} className="bg-[#1d998b]">Submit GRR</Button>
//             </div>
//           </>
//         )}
//       </Form>
//     </div>
//   );
// };

import React, { useState, useContext, useRef } from "react";
import {
  Form,
  Input,
  DatePicker,
  Button,
  message,
} from "antd";
import GRRTables from "../components/GRRTables";

const EditableContext = React.createContext(null);
const EditableRow = ({ index, ...props }) => {
  const [form] = Form.useForm();
  return (
    <Form form={form} component={false}>
      <EditableContext.Provider value={form}>
        <tr {...props} />
      </EditableContext.Provider>
    </Form>
  );
};

const EditableCell = ({ editable, children, dataIndex, record, handleSave, ...restProps }) => {
  const [editing, setEditing] = useState(false);
  const inputRef = useRef(null);
  const form = useContext(EditableContext);

  const toggleEdit = () => {
    setEditing(!editing);
    form.setFieldsValue({ [dataIndex]: record[dataIndex] });
  };

  const save = async () => {
    try {
      const values = await form.validateFields();
      toggleEdit();
      handleSave({ ...record, ...values });
    } catch (err) {
      console.log("Save failed:", err);
    }
  };

  let childNode = children;
  if (editable) {
    childNode = editing ? (
      <Form.Item style={{ margin: 0 }} name={dataIndex}>
        <Input ref={inputRef} onBlur={save} onPressEnter={save} />
      </Form.Item>
    ) : (
      <div className="editable-cell-value-wrap" onClick={toggleEdit}>
        {children}
      </div>
    );
  }

  return <td {...restProps}>{childNode}</td>;
};

const GRR = () => {
  const [form] = Form.useForm();
  const [showTables, setShowTables] = useState(false);
  const [itemRows, setItemRows] = useState([]);
  const [taxRows, setTaxRows] = useState([]);
  const [taxRateRows, setTaxRateRows] = useState([]);
  const [count, setCount] = useState(0);

  const handleAddRow = (setRows) => {
    const newRow = { key: count };
    setRows(prev => [...prev, newRow]);
    setCount(prev => prev + 1);
  };

  const handleDelete = (key, setRows) => {
    setRows(prev => prev.filter(row => row.key !== key));
  };

  const handleSaveRow = (row, rows, setRows) => {
    const newData = [...rows];
    const index = newData.findIndex((item) => row.key === item.key);
    newData.splice(index, 1, row);
    setRows(newData);
  };

  const onSubmit = async () => {
    try {
      const values = await form.validateFields();
      const payload = {
        ...values,
        itemDetails: itemRows,
        taxDetails: taxRows,
        taxRateDetails: taxRateRows,
      };
      console.log("GRR Submitted:", payload);
      message.success("Form data logged to console.");
    } catch (err) {
      message.error("Please fill all required fields.");
    }
  };

  return (
    <div className="w-[85%] mx-auto mt-10 mb-20 bg-gray-100 p-10 rounded-xl">
      <Form form={form} layout="vertical">
        {!showTables ? (
          <>
            <h2 className="text-xl font-semibold mb-4">GRR Entry</h2>
            <div className="grid grid-cols-3 gap-6">
              <Form.Item label="Receipt (GRR)" name="receiptGRR"><Input /></Form.Item>
              <Form.Item label="Receipt Date" name="receiptDate"><DatePicker className="w-full" /></Form.Item>
              <Form.Item label="Shipped Date" name="shippedDate"><DatePicker className="w-full" /></Form.Item>
              <Form.Item label="Received By" name="receivedBy"><Input /></Form.Item>
              <Form.Item label="Supplier" name="supplier"><Input /></Form.Item>
              <Form.Item label="Packing Slips" name="packingSlips"><Input /></Form.Item>
              <Form.Item label="Vendor Code" name="vendorCode"><Input /></Form.Item>
              <Form.Item label="Comments" name="comments"><Input.TextArea rows={1} /></Form.Item>
              <Form.Item label="Invoice No" name="invoiceNo"><Input /></Form.Item>
              <Form.Item label="Shipment No" name="shipmentNo"><Input /></Form.Item>
              <Form.Item label="Invoice Amount" name="invoiceAmount"><Input /></Form.Item>
              <Form.Item label="Supplier Invoice Amount" name="supplierInvoiceAmount"><Input /></Form.Item>
              <Form.Item label="Gate Entry Number" name="gateEntryNumber"><Input /></Form.Item>
              <Form.Item label="Security Entry Date" name="securityEntryDate"><DatePicker className="w-full" /></Form.Item>
            </div>
            <div className="mt-10 text-center">
              <Button type="primary" onClick={() => setShowTables(true)} className="bg-[#1d998b]">Next</Button>
            </div>
          </>
        ) : (
          <GRRTables
            itemRows={itemRows} setItemRows={setItemRows}
            taxRows={taxRows} setTaxRows={setTaxRows}
            taxRateRows={taxRateRows} setTaxRateRows={setTaxRateRows}
            handleAddRow={handleAddRow}
            handleDelete={handleDelete}
            handleSaveRow={handleSaveRow}
            setShowTables={setShowTables}
            onSubmit={onSubmit}
            EditableRow={EditableRow}
            EditableCell={EditableCell}
          />
        )}
      </Form>
    </div>
  );
};

export default GRR;
