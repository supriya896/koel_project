import React from "react";
import { Table } from "antd";

const TripVehicleTable = () => {
  // Hardcoded sample data
  const data = [
    {
      key: 1,
      trip_id: "KOEL1761817631",
      pravesh_entry_date: "2025-10-30",
      vehicle_no: "KA22AA9792",
      total_invoices: 2,
      transporter: "ABC Logistics",
      vehicle_type: "PICK-UP",
      standard_weight: "3500",
      user_dock_in: "Supriya K",
    },
    {
      key: 2,
      trip_id: "KOEL1761895274",
      pravesh_entry_date: "2025-10-31",
      vehicle_no: "MH15GV5469",
      total_invoices: 3,
      transporter: "XYZ Transport",
      vehicle_type: "TRUCK",
      standard_weight: "18000",
      user_dock_in: "Ravi P",
    },
  ];

  // Table columns
  const columns = [
    {
      title: "Trip ID",
      dataIndex: "trip_id",
      key: "trip_id",
      align: "center",
    },
    {
      title: "Pravesh Entry Date",
      dataIndex: "pravesh_entry_date",
      key: "pravesh_entry_date",
      align: "center",
    },
    {
      title: "Vehicle No.",
      dataIndex: "vehicle_no",
      key: "vehicle_no",
      align: "center",
    },
    {
      title: "Total Invoices",
      dataIndex: "total_invoices",
      key: "total_invoices",
      align: "center",
    },
    {
      title: "Transporter",
      dataIndex: "transporter",
      key: "transporter",
      align: "center",
    },
    {
      title: "Vehicle Type",
      dataIndex: "vehicle_type",
      key: "vehicle_type",
      align: "center",
    },
    {
      title: "Standard Weight of the Vehicle",
      dataIndex: "standard_weight",
      key: "standard_weight",
      align: "center",
    },
    {
      title: "User Dock-In",
      dataIndex: "user_dock_in",
      key: "user_dock_in",
      align: "center",
    },
  ];

  return (
    <div className="p-6">
      <h2 style={{ textAlign: "center", marginBottom: 20 }}>
        Trip Vehicle Master
      </h2>
      <Table
        bordered
        dataSource={data}
        columns={columns}
        pagination={false}
      />
    </div>
  );
};

export default TripVehicleTable;
