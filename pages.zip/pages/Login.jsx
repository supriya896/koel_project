import React, { useState } from 'react'
import { Button, Form, Input } from 'antd';
import { Link, useNavigate } from 'react-router';

const Login = () => {
    const Navigate = useNavigate()
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('')

    const onFinish = (values) => {
        setLoading(true)
        console.log('Success:', values);
        if (values.username === "admin" && values.password === "admin") {
            Navigate('/search')
        } else {
            setError("Username or Password do not match.")
            setLoading(false)
        }
    };

    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };
    return (
        <div className='flex flex-col justify-center items-center min-h-screen gap-10'>
            <img src='/logo.jpg' className='h-20' />
            <div className='bg-[#FAFAFA] flex flex-col justify-center items-center py-20 px-5 md:px-10 lg:px-16 rounded-xl gap-4 w-[100%] md:w-[30%]'>

                <h3 className='font-bold text-3xl'>Welcome Back</h3>
                <p className='text-center text-gray-400'>Enter your username and password to <br /> access your account</p>
                <Form
                    name="basic"
                    initialValues={{
                        remember: true,
                    }}
                    onFinish={onFinish}
                    onFinishFailed={onFinishFailed}
                    autoComplete="on"
                    className='w-full'
                >
                    <Form.Item
                        name="username"
                        rules={[
                            {
                                required: true,
                                message: 'Please input your username!',
                            },
                        ]}
                    >
                        <Input placeholder='Username' className='h-16 w-[100%] border-none shadow' />
                    </Form.Item>

                    <Form.Item
                        name="password"
                        rules={[
                            {
                                required: true,
                                message: 'Please input your password!',
                            },
                        ]}
                    >
                        <Input.Password placeholder='Password' className='h-16 w-[100%] border-none shadow' />
                    </Form.Item>
                    {error ?
                        <p className='text-red-500 mb-2'>{error}</p>
                        : null}
                    <Link to='/password/reset' className='text-blue-500'>
                        Forgot Password ?
                    </Link>


                    <Form.Item label={null} className='mt-4'>
                        <Button type="default" htmlType="submit" variant="solid" className='h-16 w-[100%] flex items-center justify-center bg-[#1d998b] !text-white mt-4 hover:!bg-[#1d998b] hover:border-none' loading={loading} iconPosition="end">
                            Login
                        </Button>
                    </Form.Item>
                </Form>
            </div>
        </div>
    )
}

export default Login