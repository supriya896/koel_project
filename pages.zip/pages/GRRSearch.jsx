import React, { useState } from "react";
import { Button, Input, List } from "antd";
import { SearchOutlined, SyncOutlined } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";

const GRRSearch = () => {
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const navigate = useNavigate();

  // Example list of gate entry numbers — replace this with API call if needed
  const gateEntryNumbers = [
    "GE001", "GE002", "GE003", "GE004", "GE005", "GE006"
  ];

  const handleInputChange = (e) => {
    const input = e.target.value;
    setQuery(input);

    if (input) {
      const filtered = gateEntryNumbers.filter((num) => num.includes(input));
      setSuggestions(filtered);
    } else {
      setSuggestions([]);
    }
  };

  const handleSuggestionClick = (value) => {
    setQuery(value);
    setSuggestions([]);
  };

  const handleSearch = () => {
    setLoading(true);
    setTimeout(() => {
      localStorage.setItem("gateEntryNumber", query); // pass data
      navigate("/GRR"); // navigate to GRR form
    }, 1000);
  };

  return (
    <div className="flex flex-col justify-center items-center min-h-screen gap-10">
      <img src="/logo.jpg" className="h-24" alt="Logo" />
      <div className="bg-[#FAFAFA] flex flex-col lg:flex-row justify-center items-center py-20 px-10 rounded-xl gap-4 w-[80%]">
        <div className="relative w-full lg:w-[60%]">
          <Input
            size="large"
            placeholder="Enter Gate Entry Number"
            prefix={<SearchOutlined />}
            className="h-16 w-full shadow"
            value={query}
            onChange={handleInputChange}
          />
          {suggestions.length > 0 && (
            <div className="absolute top-20 bg-white rounded shadow-lg w-full max-h-48 overflow-y-auto z-10">
              <List
                dataSource={suggestions}
                renderItem={(item) => (
                  <List.Item
                    className="cursor-pointer hover:bg-gray-100 !px-4 py-2"
                    onClick={() => handleSuggestionClick(item)}
                  >
                    {item}
                  </List.Item>
                )}
              />
            </div>
          )}
        </div>
        <Button
          className="h-16 w-full lg:w-[20%] !bg-[#1d998b] font-semibold"
          type="primary"
          loading={loading}
          icon={<SyncOutlined spin={loading} />}
          onClick={handleSearch}
        >
          Search
        </Button>
      </div>
    </div>
  );
};

export default GRRSearch;
