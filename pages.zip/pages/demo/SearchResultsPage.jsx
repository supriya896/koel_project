import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import { backend_link } from "./backend_link";
import "./SearchPage.css";

const SearchResultsPage = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const gateEntryNumber = state?.gateEntryNumber || localStorage.getItem("lastGateEntry");
  const rejectedShipments = JSON.parse(localStorage.getItem("rejectedShipments") || "[]");

  const handleFieldChange = (index, field, value) => {
    setData((prevData) => {
      const newData = [...prevData];
      newData[index] = { ...newData[index], [field]: value };

      const grrStatus = JSON.parse(localStorage.getItem("grrProgress") || "[]");
      const shipmentKey = newData[index].shipment_number || newData[index].newAsn || `row-${index}`;

      const existingIndex = grrStatus.findIndex((g) => g.shipment_number === shipmentKey);

      if (existingIndex >= 0) {
        grrStatus[existingIndex] = {
          ...grrStatus[existingIndex],
          [field]: value,
          shipment_number: shipmentKey,
        };
      } else {
        grrStatus.push({
          shipment_number: shipmentKey,
          status: "Pending",
          grrNumber: "",
          reason: field === "reason" ? value : "",
          newAsn: field === "newAsn" ? value : "",
        });
      }

      localStorage.setItem("grrProgress", JSON.stringify(grrStatus));

      return newData;
    });
  };

  const handleEdit = (shipment_number) => {
    const updatedRejected = rejectedShipments.filter(
      (rej) => rej.shipment_number !== shipment_number
    );
    localStorage.setItem("rejectedShipments", JSON.stringify(updatedRejected));
    window.location.reload();
  };

  useEffect(() => {
    const fetchData = async () => {
      if (!gateEntryNumber) return;
      setLoading(true);
      setError(null);
      try {
        const response = await axios.get(`${backend_link}/search_gate_entry_invoices`, {
          params: { gate_entry_number: gateEntryNumber },
        });

        let backendData = response.data || [];

        rejectedShipments.forEach((rej) => {
          const alreadyExists = backendData.some(
            (record) => record.shipment_number === rej.shipment_number
          );
          if (!alreadyExists) {
            backendData.push({
              shipment_number: rej.shipment_number,
              invoice_number: "-",
              invoice_date: "-",
              other: "-",
              grrNumber: "-",
              status: "Rejected",
              rejected: true,
              reason: rej.reason,
            });
          }
        });

        const grrStatus = JSON.parse(localStorage.getItem("grrProgress") || "[]");

        backendData = backendData.map((record, index) => {
          const key = record.shipment_number || record.newAsn || `row-${index}`;
          const match = rejectedShipments.find(
            (rej) => rej.shipment_number === record.shipment_number
          );
          const grrMatch = grrStatus.find((g) => g.shipment_number === key);

          return {
            ...record,
            reason: grrMatch?.reason || match?.reason || record.reason || "",
            newAsn: grrMatch?.newAsn || record.newAsn || "",
            rejected: !!match,
            status: grrMatch?.status || record.status || "Pending",
            grrNumber: grrMatch?.grrNumber || record.grrNumber || "-",
          };
        });

        setData(backendData);
      } catch (err) {
        console.error(err);
        setError("Error fetching data");
      }
      setLoading(false);
    };

    fetchData();
  }, [gateEntryNumber]);

  const handleCreateGRR = (record, index) => {
    const progressList = JSON.parse(localStorage.getItem("grrProgress") || "[]");
    const shipmentKey = record.shipment_number || record.newAsn || `row-${index}`;
    const existing = progressList.filter((r) => r.shipment_number !== shipmentKey);

    existing.push({
      shipment_number: shipmentKey,
      status: "In-Progress",
      grrNumber: "",
      reason: record.reason,
      newAsn: record.newAsn,
    });

    localStorage.setItem("grrProgress", JSON.stringify(existing));

    navigate("/grr", {
      state: {
        shipmentNo: record.shipment_number || record.newAsn,
        invoiceNo: record.invoice_number,
        invoiceDate: record.invoice_date,
        shipmentType: record.shipment_type,
        rowIndex: index,
        gateEntryNumber: record.gate_entry_number,
        currentReason: record.reason,
        currentNewAsn: record.newAsn,
      },
    });
  };

  const handleViewGRR = (record, index) => {
    navigate("/grr", {
      state: {
        shipmentNo: record.shipment_number || record.newAsn,
        invoiceNo: record.invoice_number,
        invoiceDate: record.invoice_date,
        shipmentType: record.shipment_type,
        rowIndex: index,
        gateEntryNumber: record.gate_entry_number,
        currentReason: record.reason,
        currentNewAsn: record.newAsn,
      },
    });
  };
  

  return (
    
    <div className="search-container">
      <div style={{ display: "flex", justifyContent: "flex-end", padding: "10px" }}>
  <button
    className="search-home-btn"
    onClick={() => navigate("/")}
    style={{
      backgroundColor: "#888888",
      color: "white",
      border: "none",
      padding: "8px 16px",
      borderRadius: "4px",
      cursor: "pointer",
    }}
  >
    Gate Entry Number
  </button>
</div>

      <h2 className="search-title">Search Results</h2>
      {loading ? (
        <p className="search-loading">Loading...</p>
      ) : error ? (
        <p className="search-error">{error}</p>
      ) : data.length === 0 ? (
        <p className="search-error">No results found.</p>
      ) : (
        <table className="search-table">
          <thead>
            <tr>
              <th>Shipment No</th>
              <th>Invoice No</th>
              <th>Other</th>
              <th>Reason</th>
              <th>New ASN</th>
              <th>Status</th>
              <th>GRR Number</th>
              <th>Rejected</th>
              <th>Action</th>
              <th>Edit</th>
            </tr>
          </thead>
          <tbody>
            {data.map((entry, index) => (
              <tr key={index}>
                <td>{entry.shipment_number || "-"}</td>
                <td>{entry.invoice_number || "-"}</td>
                <td>{entry.other || "-"}</td>
                <td>
                  {entry.other ? (
                    <input
                      type="text"
                      value={entry.reason || ""}
                      onChange={(e) => handleFieldChange(index, "reason", e.target.value)}
                      placeholder="Enter reason"
                      style={{ width: "100%" }}
                    />
                  ) : (
                    entry.reason || "-"
                  )}
                </td>
                <td>
                  {entry.other && entry.reason?.trim() ? (
                    <input
                      type="text"
                      value={entry.newAsn || ""}
                      onChange={(e) => handleFieldChange(index, "newAsn", e.target.value)}
                      placeholder="Enter New ASN"
                      style={{ width: "100%" }}
                    />
                  ) : (
                    "-"
                  )}
                </td>
                <td>{entry.status || "Pending"}</td>
                <td>{entry.grrNumber || "-"}</td>
                <td>{entry.rejected ? "Yes" : "No"}</td>
                <td>
                    {entry.rejected ? (
                      <span style={{ color: "gray", fontSize: "12px" }}>Rejected</span>
                    ) : entry.status === "Completed" ? (
                      <span
                        style={{
                          color: "gray",
                          textDecoration: "underline",
                          cursor: "pointer",
                          fontSize: "14px",
                        }}
                        onClick={() => handleViewGRR(entry, index)}
                      >
                        Submitted
                      </span>                    
                    ) : entry.shipment_type === "Other" ? (
                      entry.other && entry.reason?.trim() && entry.newAsn?.trim() ? (
                        <button
                          className="search-create-grr"
                          onClick={() => handleCreateGRR(entry, index)}
                        >
                          Create GRR
                        </button>
                      ) : (
                        <span style={{ color: "gray", fontSize: "12px" }}>Enter reason & ASN</span>
                      )
                    ) : (
                      <button
                        className="search-create-grr"
                        onClick={() => handleCreateGRR(entry, index)}
                      >
                        Create GRR
                      </button>
                    )}
                  </td>

        <td>
                  {entry.rejected ? (
                    <button onClick={() => handleEdit(entry.shipment_number)}>Edit</button>
                  ) : (
                    "-"
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default SearchResultsPage;
