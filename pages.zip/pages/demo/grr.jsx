import { useState, useEffect } from "react";
import { useLocation, useNavigate } from 'react-router-dom'; // ✅ useNavigate added
import "./GRR.css";
// import { useLocation } from 'react-router-dom';
import axios from "axios";
import { backend_link } from './backend_link'
import logo from "/Kirloskar-logo.png"; // Importing the logo

// [
//   {
//       "asn_qty": 10,
//       "base_val": 221000.0,
//       "challan_date": "23-Oct-24",
//       "default_subinventory": null,
//       "hazard_class": "G/GN/FL0BL25",
//       "invoice_value": 260780.0,
//       "item": "02.409.03.0.00",
//       "item_desc": "TELESCOPIC SLIDER, ROLLON MAKE, ASN43-930-558 (WITH COUNTERSUNK HEAD BOLTS, M8X1.25, QTY.:12 NOS)",
//       "item_type": "Direct Material",
//       "location_code": "ENG-KAGAL",
//       "org_name": "KAGAL-ENGINES-71",
//       "pending_days": "103",
//       "po_buyer_email": "Shrikant.Jadhav@kirloskar.com",
//       "po_buyer_name": "Mr.Jadhav S.C.",
//       "po_dt": "15-Jul-24",
//       "shipment_num": "MS2310/02/830438/2024",
//       "tax_category_name": "Pur-Outside State-18%-Rec",
//       "tax_percent": 18.0,
//       "vendor_code": 830438,
//       "vendor_name": "ROLLON INDIA PRIVATE LIMITED",
//       "vsc": 7025013714  712520016138
//   }
// ]



const GRR = () => {
  const location = useLocation();
  const navigate = useNavigate(); // ✅ This is what was missing
  const [res_data, setres_data] = useState([]);
  const { shipmentNo, invoiceNo, invoiceDate, gateEntryNumber } = location.state || {};
  const [formData1, setFormData1] = useState([]);

  const [formData, setFormData] = useState({
    receiptGRR: "",
    receiptDate: "",
    shippedDate: "",
    receivedBy: "",
    supplier: "",
    packingSlips: "",
    comments: "",
    vendorcode: "",
    invoiceNo: invoiceNo || "",
    invoiceDate: invoiceDate || "",
    shipmentNo: shipmentNo || "",
    invoiceAmount: "",
    supplierInvoiceAmount: "",
    gateEntryNumber: gateEntryNumber,
    securityEntryDate: "",
  });

  useEffect(() => {
    function formatDateToInput(dateStr) {
      const date = new Date(dateStr);
      if (isNaN(date)) return ""; // fallback for invalid dates
      return date.toISOString().split("T")[0]; // returns yyyy-MM-dd
    }
    const fetchData = async () => {
      try {
        const response = await axios.get(`${backend_link}/search_shipment_no`, {
          params: { shipment_num: shipmentNo },
        });

        const mergedData = response.data;
        console.log("response", mergedData);

        if (mergedData && (Array.isArray(mergedData) || typeof mergedData === 'object')) {
          // Handle both array and single object responses
          const finalData = Array.isArray(mergedData) ? mergedData : [mergedData];
          const dataObject = Array.isArray(mergedData) ? mergedData[0] : mergedData;

          // Extract list data for res_data directly from the object
          // const listData = {
          //   asn_qty: Array.isArray(dataObject.asn_qty) ? dataObject.asn_qty : [],
          //   assessable_price_list: Array.isArray(dataObject.assessable_price_list) ? dataObject.assessable_price_list : [],
          //   functional_tax_amount: Array.isArray(dataObject.functional_tax_amount) ? dataObject.functional_tax_amount : [],
          //   hsn_code: Array.isArray(dataObject.hsn_code) ? dataObject.hsn_code : [],
          //   item: Array.isArray(dataObject.item) ? dataObject.item : [],
          //   item_desc: Array.isArray(dataObject.item_desc) ? dataObject.item_desc : [],
          //   line_amount: Array.isArray(dataObject.line_amount) ? dataObject.line_amount : [],
          //   line_tax_amt: Array.isArray(dataObject.line_tax_amt) ? dataObject.line_tax_amt : [],
          //   po_qty: Array.isArray(dataObject.po_qty) ? dataObject.po_qty : [],
          //   price: Array.isArray(dataObject.price) ? dataObject.price : [],
          //   recoverable_amount: Array.isArray(dataObject.recoverable_amount) ? dataObject.recoverable_amount : [],
          //   shipment_num: Array.isArray(dataObject.shipment_num) ? dataObject.shipment_num : [],
          //   tax_category_name: Array.isArray(dataObject.tax_category_name) ? dataObject.tax_category_name : [],
          //   tax_percent: Array.isArray(dataObject.tax_percent) ? dataObject.tax_percent : [],
          //   tax_rate: Array.isArray(dataObject.tax_rate) ? dataObject.tax_rate : [],
          //   tax_rate_name: Array.isArray(dataObject.tax_rate_name) ? dataObject.tax_rate_name : [],
          //   tax_type: Array.isArray(dataObject.tax_type) ? dataObject.tax_type : [],
          //   total_line_amount: Array.isArray(dataObject.total_line_amount) ? dataObject.total_line_amount : [],
          //   uom: Array.isArray(dataObject.uom) ? dataObject.uom : [],
          //   po_type :Array.isArray(dataObject.po_type)?dataObject.po_type:[],
          //   po_line :Array.isArray(dataObject.po_line)?dataObject.po_line:[],
          //   po_num : Array.isArray(dataObject.po_num)?dataObject.po_num:[],


          // };
          const listData = Object.fromEntries(
            Object.entries(mergedData).filter(([_, value]) => Array.isArray(value))
          );
          console.log(listData)

          // Set form data with the main object data
          setFormData((prevData) => ({
            ...prevData,
            ...mergedData,
            receiptGRR: dataObject.vsc || "",
            receiptDate: formatDateToInput(dataObject.po_date),      // formatted
            shippedDate: formatDateToInput(dataObject.challan_date), // formatted
            receivedBy: dataObject.po_buyer_name || "",
            supplier: dataObject.vendor_name || "",
            packingSlips: Array.isArray(dataObject.shipment_num)
              ? dataObject.shipment_num[0] || ""
              : dataObject.shipment_num || "",
            comments: "",
            vendorcode: dataObject.vendor_code || "",
            invoiceAmount: dataObject.invoice_value || "",
            supplierInvoiceAmount: dataObject.base_val || "",
            gateEntryNumber: gateEntryNumber || "",
            securityEntryDate: "",
          }));

          //           setFormData((prevData) => ({
          //   ...prevData,
          //   receiptGRR: dataObject.vsc || "",
          //   receiptDate: formatDateToInput(dataObject.po_date),
          //   shippedDate: formatDateToInput(dataObject.challan_date),
          //   receivedBy: Array.isArray(dataObject.po_buyer_name) ? dataObject.po_buyer_name[0] : dataObject.po_buyer_name || "",
          //   supplier: dataObject.vendor_name || "",
          //   packingSlips: Array.isArray(dataObject.shipment_num) ? dataObject.shipment_num[0] : dataObject.shipment_num || "",
          //   comments: "",
          //   vendorcode: dataObject.vendor_code || "",
          //   invoiceNo: dataObject.invoiceNo || "",
          //   invoiceDate: dataObject.invoiceDate || "",
          //   shipmentNo: dataObject.shipmentNo || "",
          //   invoiceAmount: dataObject.invoice_value || "",
          //   supplierInvoiceAmount: dataObject.base_val || "",
          //   gateEntryNumber: gateEntryNumber || "",
          //   securityEntryDate: "",
          //   currency: Array.isArray(dataObject.currency) ? dataObject.currency[0] : dataObject.currency || "",
          //   party_site: Array.isArray(dataObject.party_site) ? dataObject.party_site[0] : dataObject.party_site || "",
          //   po_buyer_name: Array.isArray(dataObject.po_buyer_name) ? dataObject.po_buyer_name[0] : dataObject.po_buyer_name || "",
          // }));


          // Set res_data with the list data
          setres_data(listData);

          console.log("Using merged data:", dataObject);
          console.log("List data set in res_data:", listData);


        } else {
          console.warn("No data found for the given shipment number.");
          setres_data({});
        }

      } catch (error) {
        console.error("Error fetching shipment details:", error);
        setres_data({});
      }
    };

    if (shipmentNo) {
      fetchData();
    }
  }, [shipmentNo]);



  const [showTaxDetails, setShowTaxDetails] = useState(false);
  const [itemDetails, setItemDetails] = useState([]);
  const [taxDetails, setTaxDetails] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      setItemDetails([]);
      setTaxDetails([]);
    };

    fetchData();
  }, []);

  const handleNextClick = () => {
    setShowTaxDetails(true);
    collectData();
  };

  const handleBackClick = () => {
    setShowTaxDetails(false);
    setFormData1([])
  };


  useEffect(() => {
    const grrProgress = JSON.parse(localStorage.getItem("grrProgress") || "[]");
    const existingEntry = grrProgress.find(
      (r) => r.shipment_number === shipmentNo
    );
  
    if (existingEntry) {
      if (existingEntry.grrNumber) {
        setFormData((prev) => ({
          ...prev,
          receiptGRR: existingEntry.grrNumber,
        }));
      }
      if (existingEntry.status === "Completed") {
        setDisableSubmit(true);
      }
    }
  }, [shipmentNo]);
  


  // const handleSubmit = async () => {
  //   if (!confirmTaxes) {
  //     alert("Please confirm taxes before submitting.");
  //     return;
  //   }

  //   console.log("Form submitted successfully!");

  //   try {
  //     const response = await axios.post("https://192.168.62.197:5200/trigger-bot-grr", null, {
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //     });

  //     console.log("GRR Bot Response:", response.data);

  //     if (response.data?.parsed_text) {
  //       alert("✅ GRR Bot Triggered Successfully!\n\n" + response.data.parsed_text.join("\n"));
  //       setFormData({ ...formData, receiptGRR: response.data.parsed_text.join("\n") })
  //     } else {
  //       alert("⚠️ GRR Bot triggered, but no output received.");
  //     }
  //   } catch (error) {
  //     console.error("Error triggering GRR Bot:", error);
  //     alert("❌ Failed to trigger GRR Bot");
  //   }
  // };

  const handleSubmit = async () => {
    if (!confirmTaxes) {
      alert("Please confirm taxes before submitting.");
      return;
    }
  
    const previous = JSON.parse(localStorage.getItem("grrProgress") || "[]");
    const existingEntry = previous.find((r) => r.shipment_number === shipmentNo);
    
    // const grrInfo = {
    //   shipment_number: shipmentNo,
    //   status: "In-Progress",
    //   grrNumber: "",
    //   reason: existingEntry?.reason || "",
    //   newAsn: existingEntry?.newAsn || "",
    // };
    const actualShipmentNo = existingEntry?.newAsn || shipmentNo;

const grrInfo = {
  shipment_number: actualShipmentNo,
  status: "In-Progress",
  grrNumber: "",
  reason: existingEntry?.reason || "",
  newAsn: existingEntry?.newAsn || "",
};
console.log("grrinfo:",grrInfo);

    
  
    // Save 'In-Progress' status in localStorage
    const progressList = JSON.parse(localStorage.getItem("grrProgress") || "[]");
    const updatedProgress = [
      ...progressList.filter(item => item.shipment_number !== shipmentNo),
      grrInfo,
    ];
    localStorage.setItem("grrProgress", JSON.stringify(updatedProgress));
  
    // Redirect to show "In-Progress"
    navigate("/search-results", {
      state: { gateEntryNumber },
    });
  
    try {
      const response = await axios.post("https://192.168.62.197:5200/trigger-bot-grr", null, {
        headers: { "Content-Type": "application/json" },
      });
    
      if (response.data?.parsed_text) {
        const generatedGRR = response.data.parsed_text[0];
    
        // const finalUpdate = [
        //   {
        //     shipment_number: shipmentNo,
        //     status: "Completed",
        //     grrNumber: generatedGRR,
        //     reason: existingEntry?.reason || "",
        //     newAsn: existingEntry?.newAsn || "",
        //   },
        // ];
        const finalUpdate = [
          {
            shipment_number: actualShipmentNo,
            status: "Completed",
            grrNumber: generatedGRR,
            reason: existingEntry?.reason || "",
            newAsn: existingEntry?.newAsn || "",
          },
        ];
        
        
    
        localStorage.setItem("grrProgress", JSON.stringify(finalUpdate));
    
        alert("✅ GRR Bot Triggered Successfully!\n\n" + response.data.parsed_text.join("\n"));
        navigate("/search-results", { state: { gateEntryNumber } });
      } else {
        alert("⚠️ GRR Bot triggered, but no GRR number returned.");
        // No update to localStorage here — stays as 'Pending'
      }
    } catch (error) {
      console.error("Bot failed:", error);
      alert("❌ GRR Bot failed to trigger. Status remains Pending.");
      // No update to localStorage — again, stays 'Pending'
    }    
  };
  


  const [confirmTaxes, setConfirmTaxes] = useState(false);
  const [loading, setLoading] = useState(false);
  const [disableSubmit, setDisableSubmit] = useState(false);



  // Function to process tax categories
  const processTaxCategory = (taxCategory) => {
    if (taxCategory && taxCategory.toLowerCase().includes("outside state")) {
      return "PUR-IGST-REC";
    } else if (taxCategory && taxCategory.toLowerCase().includes("within state")) {
      return "PUR-CGST-REC";
    }
    return taxCategory; // Return original if no match
  };

  // Function to get tax percentage from category name
  const getTaxPercentFromCategory = (taxCategory) => {
    if (!taxCategory) return 0;

    const percentMatch = taxCategory.match(/(\d+)%/);
    if (percentMatch && percentMatch[1]) {
      return parseFloat(percentMatch[1]);
    }
    return 0;
  };
  const collectData = () => {
    const container = document.getElementById('dataSection');

    // Get only inputs outside the table
    const allInputs = container.querySelectorAll('input');
    const tableInputs = container.querySelectorAll('table input');
    const inputValues = {};

    allInputs.forEach(input => {
      if (![...tableInputs].includes(input)) {
        inputValues[input.name] = input.value;
      }
    });

    // Get table headers
    const headers = Array.from(container.querySelectorAll('table thead th')).map(th =>
      th.textContent.trim().toLowerCase().replace(/\s+/g, '_')
    );

    // Get table rows
    const tableRows = container.querySelectorAll('table tbody tr');
    const tableData = [];

    tableRows.forEach(row => {
      const rowData = {};
      const cells = row.querySelectorAll('td');

      cells.forEach((cell, index) => {
        const key = headers[index] || `col_${index}`;
        const input = cell.querySelector('input');
        rowData[key] = input ? input.value : cell.textContent.trim();
      });

      tableData.push(rowData);
    });
    const d = [...formData1, {
      inputs: inputValues,
      table: tableData
    }];

    console.log("data:", d);
    console.log("formdata:", formData)

    // Update the state
    setFormData1((prev) => [...prev, {
      inputs: inputValues,
      table: tableData
    }]);
    //    // Add tables into formData object before logging
    // formData.item_details = (res_data?.item || []).map((_, index) => ({
    //   sr_no: index + 1,
    //   part_number: res_data.item?.[index] || "",
    //   description: res_data.item_desc?.[index] || "",
    //   quantity: res_data.asn_qty?.[index] || res_data.po_qty?.[index] || "",
    //   uom: res_data.uom?.[index] || "",
    //   destination_type: res_data.destinationType?.[index] || "",
    //   item: res_data.item?.[index] || "",
    //   rev: res_data.rev?.[index] || ""
    // }));

    // formData.tax_details = (res_data?.item || []).map((_, index) => ({
    //   line_number: res_data.po_line?.[index] || "",
    //   document_type: res_data.po_type?.[index] || "",
    //   po_number: res_data.po_num?.[index] || "",
    //   shipment: res_data.shipment_num?.[index] || "",
    //   tax_category: res_data.tax_category_name?.[index] || "",
    //   line_amount: res_data.line_amount?.[index] || "",
    //   tax_amount: res_data.line_tax_amt?.[index] || "",
    //   line_total: res_data.total_line_amount?.[index] || "",
    //   hsn_code: res_data.hsn_code?.[index] || "",
    //   item: res_data.item?.[index] || "",
    //   item_description: res_data.item_desc?.[index] || "",
    //   quantity: res_data.asn_qty?.[index] || res_data.po_qty?.[index] || "",
    //   price: res_data.price?.[index] || "",
    //   assessable_price_list: res_data.assessable_price_list?.[index] || ""
    // }));

    // formData.tax_rate_details = (res_data?.tax_category_name || []).flatMap((taxCategory, index) => {
    //   const category = (taxCategory || "").toLowerCase();
    //   const isOutsideState = category.includes("outside state");
    //   const isWithinState = category.includes("within state");

    //   const fullTaxPercent = Number(res_data.tax_percent?.[index] || getTaxPercentFromCategory(taxCategory) || 0);
    //   const fullTaxAmount = Number(res_data.functional_tax_amount?.[index]) || 0;
    //   const halfTaxPercent = (fullTaxPercent / 2).toFixed(2);
    //   const halfTaxAmount = (fullTaxAmount / 2).toFixed(2);

    //   const vendorName = formData?.po_buyer_name?.[index] || formData?.po_buyer_name || "";
    //   const partySite = res_data?.party_site?.[index] || res_data?.party_site || "";
    //   const currency = res_data?.currency?.[index] || res_data?.currency || "INR";

    //   if (isOutsideState) {
    //     return [{
    //       sr_no: index + 1,
    //       tax_rate_name: "PUR-IGST-REC",
    //       tax_conversion_type: "IGST-Recoverable",
    //       currency,
    //       tax_rate_percent: fullTaxPercent,
    //       recoverable_amount: fullTaxAmount.toFixed(2),
    //       recoverable: true,
    //       party_name: vendorName,
    //       party_site: partySite,
    //       functional_tax_amount: fullTaxAmount.toFixed(2)
    //     }];
    //   } else if (isWithinState) {
    //     return [
    //       {
    //         sr_no: index * 2 + 1,
    //         tax_rate_name: "PUR-CGST-REC",
    //         tax_conversion_type: "CGST-Recoverable",
    //         currency,
    //         tax_rate_percent: halfTaxPercent,
    //         recoverable_amount: halfTaxAmount,
    //         recoverable: true,
    //         party_name: vendorName,
    //         party_site: partySite,
    //         functional_tax_amount: halfTaxAmount
    //       },
    //       {
    //         sr_no: index * 2 + 2,
    //         tax_rate_name: "PUR-SGST-REC",
    //         tax_conversion_type: "SGST-Recoverable",
    //         currency,
    //         tax_rate_percent: halfTaxPercent,
    //         recoverable_amount: halfTaxAmount,
    //         recoverable: true,
    //         party_name: vendorName,
    //         party_site: partySite,
    //         functional_tax_amount: halfTaxAmount
    //       }
    //     ];
    //   } else {
    //     return [{
    //       sr_no: index + 1,
    //       tax_rate_name: processTaxCategory(taxCategory),
    //       tax_conversion_type: "-",
    //       currency,
    //       tax_rate_percent: fullTaxPercent,
    //       recoverable_amount: fullTaxAmount.toFixed(2),
    //       recoverable: true,
    //       party_name: vendorName,
    //       party_site: partySite,
    //       functional_tax_amount: fullTaxAmount.toFixed(2)
    //     }];
    //   }
    // });

    // ✅ Single unified console log
    // console.log("formdata:", formData);

  };




  return (
    <div className="grr-container" id="dataSection">
      {/* Logo at the top */}
      <div className="logo-container">
        <img src={logo} alt="Kirloskar Logo" className="logo-container" />
      </div>

      {!showTaxDetails ? (
        <div>
          <h2 className="grr-section-title">General Information</h2>
          <form className="grr-form-container">
            {/* General Information Section */}
            <div className="grr-form-row">

              <div className="grr-form-group">
                <label>Receipt Date</label>
                <input type="date" value={formData.receiptDate} name="Receipt Date" />
              </div>
              <div className="grr-form-group">
                <label>Shipped Date</label>
                <input type="date" value={formData.shippedDate} readOnly name="Shipped Date" />
              </div>
            </div>

            <div className="grr-form-row">
              <div className="grr-form-group">
                <label>Received By</label>
                <input type="text" value={formData.receivedBy} />
              </div>
              <div className="grr-form-group">
                <label>Supplier</label>
                <input type="text" value={formData.supplier} readOnly />
              </div>
              <div className="grr-form-group">
                <label>Packing Slips</label>
                <input type="text" value={formData.packingSlips} readOnly />
              </div>
            </div>

            <div className="grr-form-row">
              <div className="grr-form-group">
                <label>Vendor Code</label>
                <input type="text" value={formData.vendorcode} readOnly />
              </div>
              <div className="grr-form-row">
                <div className="grr-form-group">
                  <label>Comments</label>
                  <textarea
                    value={formData.comments}
                    onChange={(e) => setFormData({ ...formData, comments: e.target.value })}
                    style={{ width: "500%", height: "38px", padding: "10px" }}
                  />
                </div>
              </div>
            </div>

            {/* Shipment Information Section */}
            <h2 className="grr-section-title">Shipment Information</h2>

            <div className="grr-form-row">
              <div className="grr-form-group">
                <label>Invoice No</label>
                <input type="text" value={formData.invoiceNo} readOnly />
              </div>
              <div className="grr-form-group">
                <label>Shipment No</label>
                <input type="text" value={formData.shipmentNo} readOnly />
              </div>
              <div className="grr-form-group">
                <label>Invoice Amount</label>
                <input type="text" value={formData.invoiceAmount} readOnly />
              </div>
            </div>

            <div className="grr-form-row">
              <div className="grr-form-group">
                <label>Supplier Invoice Amount</label>
                <input type="text" value={formData.supplierInvoiceAmount} readOnly />
              </div>
              <div className="grr-form-group">
                <label>Gate Entry Number</label>
                <input type="text" value={formData.gateEntryNumber} readOnly />
              </div>
              <div className="grr-form-group">
                <label>Security Entry Date</label>
                <input type="date" value={formData.securityEntryDate} readOnly />
              </div>
            </div>

            {/* Item Details Section */}
            <h2 className="grr-section-title">Item Details</h2>
            <div className="table-container">
              <table className="grr-item-table">
                <thead>
                  <tr>
                    <th>Sr. No</th>
                    <th>Part Number</th>
                    <th>Description</th>
                    <th>Quantity</th>
                    <th>UOM</th>
                    {/* <th>Secondary Quantity</th>
      <th>Secondary UOM</th> */}
                    <th>Destination Type</th>
                    <th>Item</th>
                    <th>Rev</th>
                  </tr>
                </thead>
                <tbody>
                  {!res_data || !res_data.item || res_data.item.length === 0 ? (
                    <tr>
                      <td colSpan="10" className="no-data">No items available</td>
                    </tr>
                  ) : (
                    res_data.item.map((partNumber, index) => (
                      <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{partNumber || "-"}</td>                                    {/* Part Number */}
                        <td>{res_data.item_desc?.[index] || "-"}</td>                   {/* Description */}
                        <td>{res_data.asn_qty?.[index] || res_data.po_qty?.[index] || "-"}</td>  {/* Quantity */}
                        <td>{res_data.uom?.[index] || "-"}</td>                         {/* UOM */}
                        {/* <td>{res_data.secQuantity?.[index] || "-"}</td>                 {/* Secondary Quantity */}
                        {/* <td>{res_data.secUOM?.[index] || "-"}</td>                      Secondary UOM */}
                        <td>{res_data.destinationType?.[index] || "-"}</td>             {/* Destination Type */}
                        <td>{partNumber || "-"}</td>                                    {/* Item (same as Part Number) */}
                        <td>{res_data.rev?.[index] || "-"}</td>                         {/* Rev */}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>

            </div>

            {/* Button Section */}
            <div className="grr-button-container">
              <button type="button" className="grr-next-btn" onClick={handleNextClick}>
                Next
              </button>
            </div>
          </form>
        </div>
      ) : (
        <div>
          <button className="grr-back-btn" onClick={handleBackClick}></button>

          <h2 className="grr-section-title">Tax Details</h2>
          <div className="table-container">
            <table className="grr-tax-details-table">
              <thead>
                <tr>
                  <th style={{ width: '50px' }}>Line Number</th>
                  <th>Document Type</th>
                  <th>PO NUMBER</th>
                  {/* <th>Document Line</th> */}
                  <th>Shipment</th>
                  <th>Tax Category</th>
                  <th>Line Amount</th>
                  <th>Tax Amount</th>
                  <th>Line Total</th>
                  <th>HSN Code</th>
                  <th>Item</th>
                  <th>Item Description</th>
                  <th>Quantity</th>
                  <th>Price</th>
                  <th>Assessable Price List</th>
                </tr>
              </thead>
              <tbody>
                {!res_data || !res_data.item || res_data.item.length === 0 ? (
                  <tr>
                    <td colSpan="15" className="no-data">No tax details available</td>
                  </tr>
                ) : (
                  res_data.item.map((item, index) => (
                    <tr key={index}>
                      <td>{res_data.po_line[index] || "-"}</td>
                      <td>{res_data.po_type[index]}</td>
                      <td>{res_data.po_num[index] || "-"}</td>
                      {/* <td>{res_data.po_line ||"-"}</td> */}
                      <td>{res_data.shipment_num?.[index] || "-"}</td>
                      <td>{res_data.tax_category_name?.[index] || "-"}</td>
                      <td>{res_data.line_amount?.[index] || "-"}</td>
                      <td>{res_data.line_tax_amt?.[index] || "-"}</td>
                      <td>{res_data.total_line_amount?.[index] || "-"}</td>
                      <td>{res_data.hsn_code?.[index] || "-"}</td>
                      <td>{item || "-"}</td>
                      <td>{res_data.item_desc?.[index] || "-"}</td>
                      <td>{res_data.asn_qty?.[index] || res_data.po_qty?.[index] || "-"}</td>
                      <td>{res_data.price?.[index] || "-"}</td>
                      <td>{res_data.assessable_price_list?.[index] || "-"}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Additional Tax Rate Details Table */}
          <h2 className="grr-section-title">Tax Rate Details</h2>
          <div className="table-container">
            <table className="tax-rate-details-table">
              <thead>
                <tr>
                  <th>Sr. No</th>
                  <th>Tax Rate Name</th>
                  <th>Tax Conversion Type</th>
                  <th>Currency</th>
                  <th>Tax Rate %</th>
                  <th>Recoverable Amount</th>
                  <th>Recoverable</th>
                  <th>Party Name</th>
                  <th>Party Site</th>
                  <th>Functional Tax Amount</th>
                </tr>
              </thead>
              <tbody>
                {!res_data || !res_data.tax_category_name || res_data.tax_category_name.length === 0 ? (
                  <tr>
                    <td colSpan="10" className="no-data">No tax rate details available</td>
                  </tr>
                ) : (
                  res_data.tax_category_name.flatMap((taxCategory, index) => {
                    const category = taxCategory?.toLowerCase() || "";
                    const isOutsideState = category.includes("outside state");
                    const isWithinState = category.includes("within state");
                    const vendorName = formData.po_buyer_name || "";
                    const partySite = formData.party_site || "";
                    const fullTaxPercent = res_data.tax_percent?.[index] || getTaxPercentFromCategory(taxCategory) || 0;
                    const fullTaxAmount = Number(res_data.functional_tax_amount?.[index]) || 0;
                    const halfTaxPercent = (fullTaxPercent / 2).toFixed(2);
                    const halfTaxAmount = (fullTaxAmount / 2).toFixed(2);

                    if (isOutsideState) {
                      return [
                        <tr key={`${index}-igst`}>
                          <td>{index + 1}</td>
                          <td>PUR-IGST-REC</td>
                          <td>IGST-Recoverable</td>
                          <td>{formData.currency[index]}</td>
                          <td>{fullTaxPercent}</td>
                          <td>{fullTaxAmount.toFixed(2)}</td>
                          <td><input type="checkbox" checked readOnly /></td>
                          <td>{vendorName}</td>
                          <td>{partySite}</td>
                          <td>{fullTaxAmount.toFixed(2)}</td>
                        </tr>
                      ];
                    } else if (isWithinState) {
                      return [
                        <tr key={`${index}-cgst`}>
                          <td>{index * 2 + 1}</td>
                          <td>PUR-CGST-REC</td>
                          <td>CGST-Recoverable</td>
                          <td>{formData.currency[index]}</td>
                          <td>{halfTaxPercent}</td>
                          <td>{halfTaxAmount}</td>
                          <td><input type="checkbox" checked readOnly /></td>
                          <td>{vendorName}</td>
                          <td>{partySite}</td>
                          <td>{halfTaxAmount}</td>
                        </tr>,
                        <tr key={`${index}-sgst`}>
                          <td>{index * 2 + 2}</td>
                          <td>PUR-SGST-REC</td>
                          <td>SGST-Recoverable</td>
                          <td>{formData.currency[index]}</td>
                          <td>{halfTaxPercent}</td>
                          <td>{halfTaxAmount}</td>
                          <td><input type="checkbox" checked readOnly /></td>
                          <td>{vendorName}</td>
                          <td>{partySite}</td>
                          <td>{halfTaxAmount}</td>
                        </tr>
                      ];
                    } else {
                      return [
                        <tr key={`${index}-other`}>
                          <td>{index + 1}</td>
                          <td>{processTaxCategory(taxCategory)}</td>
                          <td>-</td>
                          <td>-</td>
                          <td>{fullTaxPercent}</td>
                          <td>{fullTaxAmount.toFixed(2)}</td>
                          <td><input type="checkbox" checked readOnly /></td>
                          <td>{vendorName}</td>
                          <td>{partySite}</td>
                          <td>{fullTaxAmount.toFixed(2)}</td>
                        </tr>
                      ];
                    }
                  })
                )}
              </tbody>
            </table>

          </div>

          {/* Amount Summary Section */}
          <h2 className="grr-section-title">Amount Summary</h2>
          <div className="grr-form-container">
            <div className="grr-form-row">
              <div className="grr-form-group">
                {/* line_amount */}
                <label>Amount</label>
                <input type="text" value={formData.line_amount?.join(' + ')} readOnly />
              </div>
              <div className="grr-form-group">
                <label>Tax Amount</label>
                <input type="text" value={formData.total_line_tax_amount} readOnly />
              </div>
              <div className="grr-form-group">
                <label>Total Amount</label>
                <input type="text" value={formData.total_line_amount?.reduce((a, b) => Number(a) + Number(b), 0)} readOnly />
              </div>
            </div>

            <div className="grr-form-row">
              <div className="grr-form-group">
                <label>Supplier Invoice Number</label>
                <input type="text" value={formData.supplierInvoiceNumber} />
              </div>
              <div className="grr-form-group">
                <label>Supplier Invoice Date</label>
                <input type="date" value={formData.supplierInvoiceDate} />
              </div>
              <div className="grr-form-group">
                <label>Receipt (GRR)</label>
                <input
                    type="text"
                    value={formData.receiptGRR}
                    readOnly
                    placeholder="Will populate after submit"
                  />


              </div>
              <div className="grr-form-group confirm-taxes-group">
                <label>Confirm Taxes*</label>
                <input
                  type="checkbox"
                  checked={confirmTaxes}
                  onChange={(e) => setConfirmTaxes(e.target.checked)}
                />
              </div>
            </div>


            <button
  type="button"
  className="grr-reject-btn"
  onClick={() => {
    const reason = prompt("Enter reason for rejection:");
    if (!reason) return;

    const shipmentNo = location.state?.shipmentNo;
    if (!shipmentNo) {
      alert("❌ Shipment number missing.");
      return;
    }

    // Step 1: Fetch existing rejections
    let rejected = JSON.parse(localStorage.getItem("rejectedShipments") || "[]");

    // Step 2: Remove any old entry for same shipment
    rejected = rejected.filter(r => r.shipment_number !== shipmentNo);

    // Step 3: Add the new rejection
    rejected.push({
      shipment_number: shipmentNo,
      reason: reason
    });

    // Step 4: Save back to localStorage
    localStorage.setItem("rejectedShipments", JSON.stringify(rejected));
    localStorage.setItem("lastGateEntry", location.state?.gateEntryNumber || "");

    alert("🚫 Rejected and saved.");
    navigate("/search-results", {
      state: {
        gateEntryNumber: formData.gateEntryNumber,
        fromReject: true, // optional flag to distinguish reject flow
      }
    });
    console.log("gate no",gateEntryNumber)
    console.log("shipment:",shipmentNo)
    
  }}
>
  Reject
</button>


            {/* Submit Button */}
            <div className="grr-button-container">
            <button
                type="submit"
                className="grr-submit-btn"
                onClick={(e) => {
                  e.preventDefault();
                  handleSubmit();
                }}
                disabled={loading || disableSubmit}
              >
                {disableSubmit ? "Already Completed" : loading ? "Submitting..." : "Submit"}
              </button>

            </div>

          </div>
        </div>
      )}
    </div>
  );
};



export default GRR;
