import React, { useEffect, useState } from "react";
import { Button, Form, Input, Table, Tag, Modal, message, Select } from "antd";
import moment from "moment";
import TextArea from "antd/es/input/TextArea";
import Navbar from "../components/Navbar";
import { EditOutlined } from "@ant-design/icons";
const { Option } = Select;
 
const DocIn = () => {
  const [form] = Form.useForm();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedKeys, setSelectedKeys] = useState(new Set());
  const [showDockIn, settShowDockIn] = useState(true);
  const [role, setRole] = useState("admin");
  const [LMHPIsTrue, setLMHPIsTrue] = useState(false);
  const [HHPIsTrue, setHHPIsTrue] = useState(false);
  const [gensetIsTrue, setGensetIsTrue] = useState(false);
  const [RWHIsTrue, setRWHIsTrue] = useState(false);
  const [EStoreIsTrue, setEStoreIsTrue] = useState(false);
  const [otherIsTrue, setOtherIsTrue] = useState(false);
  const [adminIsTrue, setAdminIsTrue] = useState(false);
 
  const handleAddRow = () => {
    const newRow = {
      key: data.length + 1,
      srNo: data.length + 1,
      vehicleNo: "",
      gateEntryNo: "",
      transporterName: "",
      grnStatus: "",
      totalInvoice: "",
      loadingUnloading: "",
      materialCategory: "",
      location: "",
      duration: "",
      action: "",
      remarks: "",
    };
    setData([...data, newRow]); // Append new row
  };
  const [data, setData] = useState([
    {
      key: 1,
      srNo: 1,
      vehicleNo: "MH12AB1234",
      gateEntryNo: "123",
      transporterName: "XYZ Logistics",
      grrStatus: "Pending",
      totalInvoices: 4,
      loadingUnloading: "Loading",
      startTime: "-",
      endTime: "-",
      duration: "-",
      LMHP: 0,
      HHP: 0,
      Genset: 0,
      RWH: 0,
      EStore: 0,
      Other: 0,
    },
    {
      key: 2,
      srNo: 2,
      vehicleNo: "MH09AB4567",
      gateEntryNo: "543",
      transporterName: "XYZ Logistics",
      grrStatus: "Completed",
      totalInvoices: 5,
      loadingUnloading: "Unloading",
      startTime: "-",
      endTime: "-",
      duration: "-",
      LMHP: 0,
      HHP: 0,
      Genset: 0,
      RWH: 0,
      EStore: 0,
      Other: 0,
    },
    {
      key: 3,
      srNo: 3,
      vehicleNo: "MH10AB5664",
      gateEntryNo: "987",
      transporterName: "ABC Logistics",
      grrStatus: "Pending",
      totalInvoices: 5,
      loadingUnloading: "Loading",
      startTime: "-",
      endTime: "-",
      duration: "-",
      LMHP: 0,
      HHP: 0,
      Genset: 0,
      RWH: 0,
      EStore: 0,
      Other: 0,
    },
    {
      key: 4,
      srNo: 4,
      vehicleNo: "MH12AB1234",
      gateEntryNo: "123",
      transporterName: "HHH Logistics",
      grrStatus: "Completed",
      totalInvoices: 4,
      loadingUnloading: "Loading",
      startTime: "-",
      endTime: "-",
      duration: "-",
      LMHP: 0,
      HHP: 0,
      Genset: 0,
      RWH: 0,
      EStore: 0,
      Other: 0,
    },
  ]);
 
  useEffect(() => {
    data.forEach((record) => {
      console.log(`Gate Entry No: ${record.gateEntryNo}, Total Invoices: ${record.totalInvoices}`);
    });
  }, [data]);
  useEffect(() => {
    // Reset all states before updating the current role state
    setLMHPIsTrue(false);
    setHHPIsTrue(false);
    setGensetIsTrue(false);
    setRWHIsTrue(false);
    setEStoreIsTrue(false);
    setOtherIsTrue(false);
    setAdminIsTrue(false);
 
    // Set the correct state based on the role
    switch (role) {
      case "LMHP":
        setLMHPIsTrue(true);
        break;
      case "HHP":
        setHHPIsTrue(true);
        break;
      case "genset":
        setGensetIsTrue(true);
        break;
      case "RWH":
        setRWHIsTrue(true);
        break;
      case "EStore":
        setEStoreIsTrue(true);
        break;
      case "other":
        setOtherIsTrue(true);
        break;
      default:
        setAdminIsTrue(true);
    }
  }, [role]); // Runs when 'role' changes
 
  // Separate useEffect to log updated states correctly
  useEffect(() => {
    console.log(
      "LMHP:",
      LMHPIsTrue,
      "HHP:",
      HHPIsTrue,
      "Genset:",
      gensetIsTrue,
      "RWH:",
      RWHIsTrue,
      "EStore:",
      EStoreIsTrue,
      "Other:",
      otherIsTrue,
      "Admin:",
      adminIsTrue
    );
  }, [
    LMHPIsTrue,
    HHPIsTrue,
    gensetIsTrue,
    RWHIsTrue,
    EStoreIsTrue,
    otherIsTrue,
    adminIsTrue,
  ]);
 
  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };
 
  const [vehicleNoSearch, setVehicleNoSearch] = useState("");
  const [gateEntryNoSearch, setGateEntryNoSearch] = useState("");
  const [transporterNameSearch, setTransporterNameSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("All");
 
  const handleFilterChange = (status) => {
    setFilterStatus(status);
    
    setData(
      originalData.filter((record) => {
        const locations = ["LMHP", "HHP", "Genset", "RWH", "EStore", "Other"];
  
        // Check if any location has a startTime but no endTime (DockIn)
        // const isDockInCompleted = locations.some(
        //   (loc) => record[`${loc}_startTime`] && !record[`${loc}_endTime`]
        // );
  
        // // Check if any location has both startTime and endTime (DockOut)
        // const isDockOutCompleted = locations.some(
        //   (loc) => record[`${loc}_startTime`] && record[`${loc}_endTime`]
        // );
  
        // if (status === "DockIn") return isDockInCompleted;
        // if (status === "DockOut") return isDockOutCompleted;
        // return true; // "All" should return all records
      })
    );
  };
  
  const filteredData = data.filter((item) => {
    const matchesVehicleNo = item.vehicleNo
      .toLowerCase()
      .includes(vehicleNoSearch.toLowerCase());
    const matchesGateEntryNo = item.gateEntryNo
      .toLowerCase()
      .includes(gateEntryNoSearch.toLowerCase());
    const matchesTransporterName = item.transporterName
      .toLowerCase()
      .includes(transporterNameSearch.toLowerCase());
  
    const matchesSearch =
      matchesVehicleNo && matchesGateEntryNo && matchesTransporterName;
  
    // Check if ANY location has a DockIn or DockOut status
    const isDockIn = ["LMHP", "HHP", "Genset","RMStore", "RWH", "EStore", "Other"].some(
      (loc) => item[`${loc}_textbox`] && !item[`${loc}_startTime`] // Added textbox check
    );
  
    const isDockOut = ["LMHP", "HHP", "Genset","RMStore","RWH", "EStore", "Other"].some(
      (loc) => item[`${loc}_startTime`] && !item[`${loc}_endTime`]
    );
  
    if (filterStatus === "DockIn") return matchesSearch && isDockIn;
    if (filterStatus === "DockOut") return matchesSearch && isDockOut;
  
    return matchesSearch; // Show all when "All" is selected
  });
  
  const [history, setHistory] = useState({}); // Stores history per row
 
  const handleUndo = (key) => {
    if (!history[key] || history[key].length === 0) {
      console.log(`No actions to undo for row: ${key}`);
      return;
    }
 
    // Get the last saved state and remove it from history
    const previousState = history[key].pop();
 
    setHistory((prevHistory) => ({
      ...prevHistory,
      [key]: [...prevHistory[key]], // Update without modifying state directly
    }));
 
    // Restore the row's previous state
    setData((prevData) =>
      prevData.map((row) => (row.key === key ? previousState : row))
    );
  };
  const saveHistory = (key, row) => {
    setHistory((prevHistory) => ({
      ...prevHistory,
      [key]: [...(prevHistory[key] || []), { ...row }], // Deep copy
    }));
  };
 
  const handleDockIn = (key, invoice) => {
    setData((prevData) =>
      prevData.map((row) => {
        if (row.key === key) {
          saveHistory(key, row); // Save previous state before changing
          return {
            ...row,
            dockedInvoice: invoice, // Store selected invoice
            // [`${invoice}_startTime`]: moment().format("HH:mm:ss"), // Start time
            [`${invoice}_startTime`]: moment().format("YYYY-MM-DD HH:mm:ss"),
            [`${invoice}_isDockedIn`]: true,
            isAnyDockedIn: true, // Prevent selecting other locations until dock-out
          };
        }
        return row;
      })
    );
  };
 
  
  // Ensure valid time format
  // const handleDockOut = (key) => {
  //   setData((prevData) =>
  //     prevData.map((row) => {
  //       if (row.key === key && row.dockedInvoice) {
  //         saveHistory(key, row); // Save previous state before changing
  
  //         const invoice = row.dockedInvoice;
  //         // const endTime = moment().format("HH:mm:ss");
  //         const endTime = moment().format("YYYY-MM-DD HH:mm:ss");
  //         const startTimeMoment = moment(row[`${invoice}_startTime`], "HH:mm:ss");
  //         const endTimeMoment = moment(endTime, "HH:mm:ss");
  
  //         if (!startTimeMoment.isValid() || !endTimeMoment.isValid()) {
  //           console.error(`Invalid time format for invoice: ${invoice}`);
  //           return row;
  //         }
  
  //         // Calculate duration
  //         const durationMinutes = endTimeMoment.diff(startTimeMoment, "minutes");
  //         const hours = Math.floor(durationMinutes / 60);
  //         const minutes = durationMinutes % 60;
  //         const formattedDuration = `${hours}h ${minutes}m`;
  
  //         return {
  //           ...row,
  //           [`${invoice}_endTime`]: endTime,
  //           [`${invoice}_duration`]: formattedDuration,
  //           [`${invoice}_isCompleted`]: true, // Mark as completed
  //           isAnyDockedIn: false, // Allow choosing another location after completion
  //           dockedInvoice: null, // Reset docked invoice
  //         };
  //       }
  //       return row;
  //     })
  //   );
  // };
  const handleDockOut = (key) => {
    setData((prevData) =>
      prevData.map((row) => {
        if (row.key === key && row.dockedInvoice) {
          saveHistory(key, row); // Save previous state before changing
  
          const invoice = row.dockedInvoice;
          const endTime = moment().format("YYYY-MM-DD HH:mm:ss"); // Date + Time
          const startTime = row[`${invoice}_startTime`];
  
          const startTimeMoment = moment(startTime, "YYYY-MM-DD HH:mm:ss");
          const endTimeMoment = moment(endTime, "YYYY-MM-DD HH:mm:ss");
  
          if (!startTimeMoment.isValid() || !endTimeMoment.isValid()) {
            console.error(`Invalid datetime format for invoice: ${invoice}`);
            return row;
          }
  
          // Calculate duration
          const duration = moment.duration(endTimeMoment.diff(startTimeMoment));
          const hours = Math.floor(duration.asHours());
          const minutes = duration.minutes();
          const formattedDuration = `${hours}h ${minutes}m`;
  
          return {
            ...row,
            [`${invoice}_endTime`]: endTime,
            [`${invoice}_duration`]: formattedDuration,
            [`${invoice}_isCompleted`]: true,
            isAnyDockedIn: false,
            dockedInvoice: null,
          };
        }
        return row;
      })
    );
  };
  
  
 
  // const isDockInDisabled = (record) => {
  //   const locationSum =
  //     (Number(record.LMHP_textbox) || 0) +
  //     (Number(record.HHP_textbox) || 0) +
  //     (Number(record.Genset_textbox) || 0) +
  //     (Number(record.RWH_textbox) || 0) +
  //     (Number(record.EStore_textbox) || 0) +
  //     (Number(record.Other_textbox) || 0);
 
  //   if (locationSum > Number(record.totalInvoices)) {
  //     // Show warning only once per row
  //     if (!record.warningShown) {
  //       message.warning(
  //         `Row ${record.key}: Total Invoices have been reached or exceeded. Dock-In is stopped!`
  //       );
  //       record.warningShown = true; // Set flag to prevent duplicate messages
  //     }
  //     return true; // Disable Dock-In button
  //   } else {
  //     record.warningShown = false; // Reset flag when condition is not met
  //   }
 
  //   return false; // Keep Dock-In enabled
  // };
 
  const handleInputChange = (key, field, value) => {
    setData((prevData) =>
      prevData.map((row) => {
        if (row.key === key) {
          if (field === "vehicleNo" && value.length > 10) {
            message.error("Vehicle No must be exactly 10 characters");
            return row;
          }
          if (field === "gateEntryNo" && value.length > 12) {
            message.error("Gate Entry No must be exactly 12 digits");
            return row;
          }
          if (field === "transporterName" && value.length > 15) {
            message.error("Transporter Name must be at most 15 characters");
            return row;
          }
          return { ...row, [field]: value };
        }
        return row;
      })
    );
  };
 
  // const handleEdit = (key) => {
  //   setData((prevData) =>
  //     prevData.map((item) =>
  //       item.key === key ? { ...item, isDisabled: !item.isDisabled } : item
  //     )
  //   );
  // };
  const columns = [
    // {
    //   title: <strong>Edit</strong>,
    //   dataIndex: "edit",
    //   width: 20,
    //   key: "edit",
    //   render: (_, record) => (
    //     <EditOutlined
    //       className="text-gray-500 text-2xl cursor-pointer"
    //       onClick={() => handleEdit(record.key)}
    //     />
    //   ),
    //  },
    {
      title: <strong>Sr No</strong>,
      dataIndex: "srNo",
      align: "center",
      width: 10,
      key: "srNo",
    },
    {
      title: <strong>Vehicle No</strong>,
      dataIndex: "vehicleNo",
      align: "center",
      width: 150,
      key: "vehicleNo",
      render: (_, record) => (
        <Input
          value={record.vehicleNo}
          onChange={(e) =>
            handleInputChange(record.key, "vehicleNo", e.target.value)
          }
          maxLength={10}
          disabled={record.isDisabled}
        />
      ),
    },
    {
      title: <strong>Gate Entry No</strong>,
      dataIndex: "gateEntryNo",
      align: "center",
      width: 150,
      key: "gateEntryNo",
      render: (_, record) => (
        <Input
          type="number"
          value={record.gateEntryNo}
          onChange={(e) =>
            handleInputChange(record.key, "gateEntryNo", e.target.value)
          }
          maxLength={4}
          disabled={record.isDisabled}
        />
      ),
    },
    {
      title: <strong>Transporter Name</strong>,
      dataIndex: "transporterName",
      align: "center",
      width: 150,
      key: "transporterName",
      render: (_, record) => (
        <Input
          value={record.transporterName}
          onChange={(e) =>
            handleInputChange(record.key, "transporterName", e.target.value)
          }
          maxLength={15}
          disabled={record.isDisabled}
        />
      ),
    },
    {
      title: <strong>GRR Status</strong>,
      dataIndex: "grrStatus",
      align: "center",
      width: 100,
      key: "grrStatus",
      render: (status) => (
        <Tag color={status === "Completed" ? "green" : "red"}>{status}</Tag>
      ),
    },
    {
  title: <strong>Total Invoices</strong>,
  dataIndex: "totalInvoices",
  align: "center",
  width: 100,
  key: "totalInvoices",
  render: (_, record) => {
    const locations = ["LMHP", "HHP", "Genset","RMStore", "RWH", "EStore", "Other"];

    // Calculate total sum of location textboxes
    const totalInputSum = locations.reduce(
      (sum, loc) => sum + (Number(record[`${loc}_textbox`]) || 0),
      0
    );

    return (
      <div style={{ position: "relative" }}>
        <Input type="number" value={record.totalInvoices} disabled={record.isDisabled} />
        {totalInputSum >= record.totalInvoices && (
          <span style={{ color: "black", fontWeight: "bold", marginLeft: "10px" }}>
            {totalInputSum === record.totalInvoices
              ? "✅ Equal to Total Invoices"
              : "⚠️ Exceeds Total Invoices"}
          </span>
        )}
      </div>
    );
  },
},
    {
      title: <strong>Loading/Unloading</strong>,
      dataIndex: "loadingUnloading",
      align: "center",
      width: 150,
      key: "loadingUnloading",
      render: (_, record) => (
        <Input value={record.loadingUnloading} disabled={record.isDisabled} />
      ),
    },
    {
      title: <strong>Material Category</strong>,
      dataIndex: "materialCategory",
      align: "center",
      width: 150,
      key: "materialCategory",
      render: (_, record) => {
        return (
          <Select
          defaultValue={record.materialCategory || "select"}
            disabled={record.isDisabled}
            style={{ width: "100%" }}
          >
            <Option value="Raw Material">
              Raw Material & Indirect Material
            </Option>
            <Option value="Oil Petrol Diesel Chemicals">
              Oil, Petrol, Diesel, Chemicals
            </Option>
            <Option value="Finished Goods">Finished Goods</Option>
            <Option value="Gas All-LPG,Co2,O2">Gas All-LPG, Co2, O2</Option>
            <Option value="Hazardous Waste">Hazardous Waste</Option>
 
            <Option value="Scrap Material">Scrap Material</Option>
            <Option value="Spare Parts">Spare Parts</Option>
          </Select>
        );
      },
    },
    //   {
    //    title: "Invoice Type",
    //    dataIndex: "invoiceType",
    //    align: "center",
    //    width: 150,
    //    key: "invoiceType",
    //    render: (_, record) => {
    //      // Function to check if an invoice is completed
    //      const isInvoiceCompleted = (field) =>
    //        record[`${field}_startTime`] && record[`${field}_endTime`];
 
    //      // Check if all four invoices are completed
    //      const allInvoicesCompleted =
    //      isInvoiceCompleted("LMHP") &&
    //        isInvoiceCompleted("HHP") &&
    //        isInvoiceCompleted("Genset") &&
    //        isInvoiceCompleted("RWH") &&
    //        isInvoiceCompleted("EStore") &&
    //        isInvoiceCompleted("Other");
 
    //      return (
    //        <Select
    //          style={{ width: "100%" }}
    //          placeholder="Select Invoice"
    //          value={record.dockedInvoice || undefined}
    //          onChange={(value) => {
    //            setData((prevData) =>
    //              prevData.map((row) =>
    //                row.key === record.key
    //                  ? { ...row, dockedInvoice: value }
    //                  : row
    //              )
    //            );
    //    }}
    //         disabled={allInvoicesCompleted} // Disable only when all invoices are completed
    //        >
    //          <Select.Option value="LMHP">LMHP</Select.Option>
    //          <Select.Option value="HHP">HHP</Select.Option>
    //          <Select.Option value="Genset">Genset</Select.Option>
    //          <Select.Option value="RWH">RWH</Select.Option>
    //          <Select.Option value="EStore">EStore</Select.Option>
    //          <Select.Option value="Other">Other</Select.Option>
    //        </Select>
    //      );
    //    },
    //  },
    {
      title: <strong>Location</strong>,
      dataIndex: "location",
      align: "center",
      key: "location",
      width: 400,
      render: (_, record) => {
        // Function to calculate duration
        const calculateDuration = (startTime, endTime) => {
          if (!startTime || !endTime) return "0h 0m";
          // const start = moment(startTime, "HH:mm:ss", true);
          // const end = moment(endTime, "HH:mm:ss", true);
          const start = moment(startTime, "YYYY-MM-DD HH:mm:ss", true);
          const end = moment(endTime, "YYYY-MM-DD HH:mm:ss", true);
          if (!start.isValid() || !end.isValid()) return "Invalid Time";
          const duration = moment.duration(end.diff(start));
          return `${Math.floor(duration.asHours())}h ${duration.minutes()}m`;
        };
    
        // Filtering logic for DockIn and DockOut at location level
        const shouldShowLocation = (field) => {
          const hasTextboxValue = record[`${field}_textbox`]; // Check if a value is entered in the textbox
          const hasStartTime = record[`${field}_startTime`]; // Check if DockIn has been done
          const hasEndTime = record[`${field}_endTime`]; // Check if DockOut has been completed
        
          if (filterStatus === "DockIn") return hasTextboxValue && !hasStartTime; // Only show locations where DockIn is pending
          if (filterStatus === "DockOut") return hasStartTime && !hasEndTime; // Only show locations where DockOut is pending
          return true; // Show all when "All" is selected
        };
        
        
    
        const renderLocationField = (field) => {
          if (!shouldShowLocation(field)) return null; // Hide non-matching locations
    
          const isCompleted = record[`${field}_isCompleted`] ?? false;
          const isCurrentSelected = record.dockedInvoice === field;
          const hasActiveInvoice = record.isAnyDockedIn && !isCompleted;
          const showDuration = isCompleted; // Show duration only when DockOut is clicked
          return (
            <div
              key={field}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "5px",
              }}
            >
              {/* Textbox - Initially enabled, disabled when completed */}
              <Input
  style={{ width: "80px", textAlign: "center" }}
  value={record[`${field}_textbox`] || ""}
  placeholder="Enter No Of Invoices"
  title="Enter No Of Invoices" // Shows full text on hover
  disabled={!!record[`${field}_endTime`]} 
  // 🔹 Keep editable before DockOut, disable after DockOut
  onChange={(e) => {
    const newValue = e.target.value;
    handleInputChange(record.key, `${field}_textbox`, newValue);
    setData((prevData) =>
      prevData.map((row) =>
        row.key === record.key
          ? { ...row, [`${field}_textbox`]: newValue, dockedInvoice: field }
          : row
      )
    );
  }}
/>
    
              {/* Invoice Label with Color Change */}
              <span
                style={{
                  color: isCompleted ? "green" : isCurrentSelected ? "green" : "red",
                  fontWeight: "bold",
                }}
              >
                {field}
              </span>
    
              {/* Start Time */}
              <Input
                style={{ width: "120px" }}
                value={record[`${field}_startTime`] || ""}
                placeholder="Start Time"
                disabled={!isCurrentSelected}
              />
    
              {/* End Time */}
              <Input
                style={{ width: "120px" }}
                value={record[`${field}_endTime`] || ""}
                placeholder="End Time"
                disabled={!isCurrentSelected}
              />
    
              {/* Duration Calculation - Initially Hidden, Visible on DockOut */}
      {showDuration && (
        <span style={{ color: "blue" }}>
          {calculateDuration(record[`${field}_startTime`], record[`${field}_endTime`])}
        </span>
      )}
            </div>
          );
        };
    
        return (
          <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
            {["LMHP", "HHP", "Genset","RMStore", "RWH", "EStore", "Other"].map(renderLocationField)}
          </div>
        );
      },
    },    
    {
      title: <strong>Duration</strong>,
      dataIndex: "duration",
      align: "center",
      width: 150,
      key: "duration",
      render: (_, record) => {
        const calculateDuration = (startTime, endTime) => {
          if (!startTime || !endTime) return 0; // Return 0 minutes if no valid time
 
          const start = moment(startTime, "HH:mm:ss", true);
          const end = moment(endTime, "HH:mm:ss", true);
 
          if (!start.isValid() || !end.isValid()) return 0;
 
          const durationMs = end.diff(start); // Difference in milliseconds
          const duration = moment.duration(durationMs); // Convert to duration
 
          return duration.asMinutes(); // Return duration in minutes
        };
 
        // Calculate total duration (sum of LMHP, HHP, Genset, Other)
        const totalMinutes =
          calculateDuration(record["LMHP_startTime"], record["LMHP_endTime"]) +
          calculateDuration(record["HHP_startTime"], record["HHP_endTime"]) +
          calculateDuration(
            record["Genset_startTime"],
            record["Genset_endTime"]
          ) +
          calculateDuration(record["RWH_startTime"], record["RWH_endTime"]) +
          calculateDuration(
            record["EStore_startTime"],
            record["EStore_endTime"]
          ) +
          calculateDuration(record["Other_startTime"], record["Other_endTime"])+
          calculateDuration(record["RMStore_startTime"], record["RMStore_endTime"]);
 
        const hours = Math.floor(totalMinutes / 60);
        const minutes = Math.round(totalMinutes % 60); // Ensure whole number
 
        return (
          <span style={{ color: "blue" }}>
            {hours}h {minutes > 0 ? `${minutes}m` : "0m"}
          </span>
        );
      },
    },
    {
      title: <strong>Actions</strong>,
      dataIndex: "actions",
      align: "center",
      width: 200,
      key: "actions",
      render: (_, record) => (
        <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
          {/* Dock In Button */}
          <Button
            type="primary"
            onClick={() => handleDockIn(record.key, record.dockedInvoice)}
            disabled={
              !record.dockedInvoice || record.isAnyDockedIn
              // || isDockInDisabled(record)
            }
            //disabled={isDockInDisabled(record)}
          >
            Dock In
          </Button>
 
          {/* Dock Out Button */}
          <Button
            type="primary"
            onClick={
              () => handleDockOut(record.key) /*|| isDockInDisabled(record)*/
            }
            disabled={!record.isAnyDockedIn}
          >
            Dock Out
          </Button>
          <Button
          onClick={() => handleUndo(record.key)}
          disabled={!history[record.key] || history[record.key].length === 0}
        >
          Undo
        </Button>
        </div>
      ),
    },
    // {
    //   title: <strong>Undo</strong>,
    //   dataIndex: "undo",
    //   align: "center",
    //   width: 150,
    //   key: "undo",
    //   render: (_, record) => (
    //     <Button
    //       onClick={() => handleUndo(record.key)}
    //       disabled={!history[record.key] || history[record.key].length === 0}
    //     >
    //       Undo
    //     </Button>
    //   ),
    // },
    // {
    //   title: <strong>Remark</strong>,
    //   dataIndex: "Remark",
    //   align: "center",
    //   width: 150,
    //   key: "Remark",
    //   render: (_, record) => (
    //     <TextArea
    //       rows={3}
    //       value={record.Remark}
    //       onChange={(e) =>
    //         handleInputChange(record.key, "Remark", e.target.value)
    //       }
    //       disabled={record.isDisabled}
    //     />
    //   ),
    // },
    {
      title: <strong>Remark</strong>,
      dataIndex: "Remark",
      align: "center",
      width: 150,
      key: "Remark",
      render: (_, record) => (
        <Select
          value={record.Remark || undefined}
          onChange={(value) => handleInputChange(record.key, "Remark", value)}
          disabled={record.isDisabled}
          style={{ width: "100%" }}
          placeholder="Select Remark"
        >
          <Option value="Delayed Entry">Delayed Entry</Option>
          <Option value="Invoice Mismatch">Invoice Mismatch</Option>
          <Option value="Damaged Goods">Damaged Goods</Option>
          <Option value="Other">Other</Option>
        </Select>
      ),
    }
    
  ];
  console.log("Filtered Data:", filteredData);
  console.log({
    gateEntryNo: filteredData.gateEntryNo,
    totalInvoices: filteredData.totalInvoices
  });
  
  return (
    <>
      <Navbar />
      <div>
        <Form form={form} className="px-20 ">
          <h3 className="text-center text-4xl font-semibold mb-4">
            Dock In / Dock Out
          </h3>
 
          <div className="container flex items-center gap-2 mt-4 p-5">
          <div style={{ border: "2px solid black", padding: 10, display: "flex", borderRadius: 8, width: "100%", maxWidth: "1000px", gap: 8 }}>
  <Input
    placeholder="Search Vehicle No"
    style={{flex: 1 }}
    value={vehicleNoSearch}
    onChange={(e) => setVehicleNoSearch(e.target.value)}
  />
  <Input
    placeholder="Search Gate Entry No"
    style={{flex: 1 }}
    value={gateEntryNoSearch}
    onChange={(e) => setGateEntryNoSearch(e.target.value)}
  />
  <Input
    placeholder="Search Transporter Name"
    style={{flex: 1 }}
    value={transporterNameSearch}
    onChange={(e) => setTransporterNameSearch(e.target.value)}
  />
</div>


<div style={{ border: "2px solid black", padding: 10, display: "flex", borderRadius: 8,width: "100%", maxWidth: "600px", gap: 8 }}>
  
  <Button
    style={{ marginLeft: 8,flex: 1 }}
    onClick={() => setFilterStatus("DockIn")}
    type={filterStatus === "DockIn" ? "primary" : "default"}
  >
   Pending For DockIn
  </Button>
  <Button
    style={{ marginLeft: 8 ,flex: 1}}
    onClick={() => setFilterStatus("DockOut")}
    type={filterStatus === "DockOut" ? "primary" : "default"}
  >
    Pending For DockOut
  </Button>
  <Button
    style={{ marginLeft: 8,flex: 1 }}
    onClick={() => setFilterStatus("All")}
    type={filterStatus === "All" ? "primary" : "default"}
  >
    All
  </Button>
</div>

  {/* <Select style={{ width: "100%" }} placeholder="Select Invoice">
  {["LMHP", "HHP", "Genset", "RWH", "EStore", "Other"].map((type) => (
    <Select.Option key={type} value={type}>
      {type}
    </Select.Option>
  ))}
</Select> */}

          </div>
          {showDockIn && (
            <Table
              className="border p-4 "
              columns={columns}
              size="small"
              pagination={{ pageSize: 10 }}
              dataSource={filteredData}
              rowClassName={(record) =>
                selectedKeys.has(record.key) ? "selected-row" : ""
              }
              scroll={{ x: "max-content" }}
              bordered
              footer={() => (
                <div style={{ textAlign: "left", padding: "10px" }}>
                <Button 
                 type="default" 
                 style={{ backgroundColor: "#f0f0f0", borderColor: "#d9d9d9", color: "#000" }} 
                 onClick={handleAddRow}
                >
              Add Row
              </Button>

                </div>
              )}
              
              
            />
          )}
          {/* <Button type="primary" onClick={handleAddRow} style={{ marginTop: "10px" }}>
        Add Row
      </Button> */}
        </Form>
        
      </div>
    </>
  );
};
 
export default DocIn;