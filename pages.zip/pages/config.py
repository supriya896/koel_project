from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
db = SQLAlchemy()  # ✅ Define db before using it

class Config:
    """Configuration for the PostgreSQL database."""
    SQLALCHEMY_DATABASE_URI = 'postgresql://postgres:123456@localhost:5432/test'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

# Apply configuration
app.config.from_object(Config)

# Initialize SQLAlchemy with the app
db.init_app(app)

# Create database tables within the app context
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
