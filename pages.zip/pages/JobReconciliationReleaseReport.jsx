defVar --name jnlp_paths --type List --innertype String
defVar --name jnlp_files --type List --innertype String
defVar --name jnlp_file --type String
defVar --name succes --type Boolean
defVar --name security_window_first --type Window
defVar --name security_window --type Window
defVar --name security_window_success --type Boolean
defVar --name erp_window --type Window
defVar --name erp_window_success --type Boolean
defVar --name time --type DateTime
webStart --name demoInstance --type "Chrome" --userprofilepreferences "AutomationOptimized" --downloadpath "C:\\Users\\v-cipl064\\AppData\\Local\\IBM Robotic Process Automation\\downloads"
webNavigate --url "https://knode1.koel.co.in:8443/OA_HTML/AppsLocalLogin.jsp?langCode=US&username=6-8ewdZ7FkqqAYcbvfGPM8SgmSaRpqF1tPP3JX8z3z8"
webSet --value REBOMQ --selector "XPath" --xpath "/html/body/div[2]/div/form/div[1]/input" --simulatehuman  --timeout "00:00:10"
webSet --value "India$2024" --selector "XPath" --xpath "/html/body/div[2]/div/form/div[3]/input" --simulatehuman  --timeout "00:00:10"
webClick --selector "XPath" --xpath "/html/body/div[2]/div/div[1]/button[1]" --simulatehuman  --timeout "00:00:05"
logMessage --message "Login Successfully" --type "Info"
delay --timeout "00:00:10"
webClick --selector "XPath" --xpath "/html/body/div[3]/form/span[2]/div[3]/div/div[1]/div/div[3]/div[1]/div[2]/table[2]/tbody/tr/td/div/table/tbody/tr/td[1]/table/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr/td/ul/li[12]/a/div[1]/img[1]" --simulatehuman
logMessage --message "SSOB REBOMQ done\r\n" --type "Info"
delay --timeout "00:00:05"
webClick --selector "XPath" --xpath "/html/body/div[3]/form/span[2]/div[3]/div/div[1]/div/div[3]/div[1]/div[2]/table[2]/tbody/tr/td/div/table/tbody/tr/td[1]/table/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr/td/ul/li[12]/ul/li[14]/a/div[2]" --simulatehuman  --timeout "00:00:10"
logMessage --message "WIP enquiry done\r\n" --type "Info"
delay --timeout "00:00:05"
webClick --selector "XPath" --xpath "/html/body/div[3]/form/span[2]/div[3]/div/div[1]/div/div[3]/div[1]/div[2]/table[2]/tbody/tr/td/div/table/tbody/tr/td[1]/table/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr/td/ul/li[12]/ul/li[14]/ul/li[2]/a/div[2]" --simulatehuman  --timeout "00:00:10"
logMessage --message "view discrete jobs done" --type "Info"
delay --timeout "00:00:10"
getFiles --path "C:\\Users\\v-cipl064\\AppData\\Local\\IBM Robotic Process Automation\\downloads" --ignorecase  --orderbylastmodification  jnlp_files=value
get --collection "${jnlp_files}" --index 1 jnlp_file=value
logMessage --message "Path - ${jnlp_file}" --type "Info"
powerShell --apartmentState "MTA" --script "javaws \"${jnlp_file}\"\r\n" succes=success
waitProcess --mode "Start" --by "Name" --name "Oracle Applications - KIRAN" --sessionsearch "AllSessions"
waitWindow --title "Security Warning" --recursive  --safesearch  --timeout "00:05:00" security_window_first=value
findWindow --title "Security Warning" --safesearch  security_window_first=value
attachWindow --window ${security_window_first}
delay --timeout "00:00:00.5000000"
logMessage --message "security window opened" --type "Info"

click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/panel[2]/panel[2]/push_button[1]"
waitWindow --title "Security Warning" --safesearch  --timeout "00:05:00" security_window=value
findWindow --title "Security Warning" --safesearch  security_window=value security_window_success=success
attachWindow --window ${security_window}
delay --timeout "00:00:00.5000000"
logMessage --message Success --type "Info"

click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/panel[2]/panel[2]/panel[2]/check_box[1]"
delay --timeout "00:00:01"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/panel[2]/panel[2]/panel[2]/panel[1]/push_button[1]"
waitWindow --title "Oracle Applications - KIRAN" --safesearch  --timeout "00:05:00" erp_window=value
findWindow --title "Oracle Applications - KIRAN" --safesearch  erp_window=value erp_window_success=success
attachWindow --window ${erp_window}
delay --timeout "00:00:05"
logMessage --message "Oracle application opened" --type "Info"

keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Return"
delay --timeout "00:00:05"
logMessage --message "M71 done\r\n" --type "Info"


webClose --name demoInstance --leavebrowseropen