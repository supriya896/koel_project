// import React, { useState } from "react";
// import { Form, Input, Select, Button, Table, Card } from "antd";

// const { Option } = Select;

// // All vehicle types
// const allVehicleTypes = [
//   { label: "APPE", value: "APPE" },
//   { label: "Couriers", value: "Couriers" },
//   { label: "AUTO", value: "AUTO" },
//   { label: "BYHAND", value: "BYHAND" },
//   { label: "L-1109", value: "L-1109" },
//   { label: "L-1110", value: "L-1110" },
//   { label: "L-909", value: "L-909" },
//   { label: "OTHER", value: "OTHER" },
//   { label: "PICK-UP", value: "PICK-UP" },
//   { label: "PRIVATE VEHICLE", value: "PRIVATE VEHICLE" },
//   { label: "T-407", value: "T-407" },
//   { label: "T-709", value: "T-709" },
//   { label: "TEMPO", value: "TEMPO" },
//   { label: "TORUS", value: "TORUS" },
//   { label: "TRAILER / CONTAINER", value: "TRAILER / CONTAINER" },
//   { label: "TRUCK", value: "TRUCK" },
//   { label: "VAN", value: "VAN" },
// ];

// // Vehicle constants — add only for types that have defined time/weight
// const vehicleData = {
//     "APPE":{time: 120 , weight:10000},
//   "Couriers": { time: 150, weight: 12000 },
//     "AUTO": { time: 100, weight: 2000 },
//     "BYHAND": { time: 100, weight: 2000 },
//     "L-1109": { time: 180, weight: 2000 },
//     "L-1110": { time: 180, weight: 2000 },
//   "L-909": { time: 180, weight: 16000 },
//   "OTHER": { time: 150, weight: 16000 },
//     "PICK-UP": { time: 120, weight: 16000 },
//     "PRIVATE VEHICLE": { time: 180, weight: 16000 },
//   "T-407": { time: 150, weight: 12000 },
//     "T-709": { time: 180, weight: 14000 },
//     "TEMPO": { time: 90, weight: 3000 },
//   "TORUS": { time: 240, weight: 3000 },
//   "TRAILER / CONTAINER": { time: 240, weight: 25000 },
//     "TRUCK": { time: 210, weight: 18000 },
//       "VAN": { time: 120, weight: 4000 },
// };

// const categories = ["Raw Material","RM-clubbing", "RM-5C", "RM-wooden","Oil,Petrol,Diesel Chemicals","Finished Goods","Gas All-LPG","Hazardous Waste","Scrap Material","Spare Parts","Skid/Bin/Pallet"];

// const VehicleStandardReport = () => {
//   const [form] = Form.useForm();
//   const [tableData, setTableData] = useState([]);
//   const [editingIndex, setEditingIndex] = useState(null);
//   const [baseTime, setBaseTime] = useState(0);

//   const handleVehicleChange = (value) => {
//     const vehicleInfo = vehicleData[value];
//     if (vehicleInfo) {
//       setBaseTime(vehicleInfo.time);
//       form.setFieldsValue({
//         standard_time: vehicleInfo.time,
//         standard_weight: vehicleInfo.weight,
//       });
//     } else {
//       // If vehicle not in list, clear fields
//       setBaseTime(0);
//       form.setFieldsValue({
//         standard_time: "",
//         standard_weight: "",
//       });
//     }
//   };

//   const handleCategoryChange = (value) => {
//     const doubledCategories = ["RM-clubbing", "RM-5C", "RM-wooden"];
//     const currentBaseTime = baseTime || form.getFieldValue("standard_time");
//     if (doubledCategories.includes(value)) {
//       form.setFieldsValue({
//         standard_time: currentBaseTime * 2,
//       });
//     } else {
//       form.setFieldsValue({
//         standard_time: currentBaseTime,
//       });
//     }
//   };

//   const onFinish = (values) => {
//     if (editingIndex !== null) {
//       const updatedData = [...tableData];
//       updatedData[editingIndex] = values;
//       setTableData(updatedData);
//       setEditingIndex(null);
//     } else {
//       setTableData((prev) => [...prev, values]);
//     }

//     form.resetFields(["vehicle_type", "category", "standard_time", "standard_weight"]);
//     setBaseTime(0);
//   };

//   const handleEdit = (record, index) => {
//     form.setFieldsValue(record);
//     setEditingIndex(index);
//     setBaseTime(record.standard_time / 2 || record.standard_time);
//   };

//   const columns = [
//     { title: "Plant Location", dataIndex: "plant_location" },
//     { title: "Status", dataIndex: "status" },
//     { title: "Vehicle Type", dataIndex: "vehicle_type" },
//     { title: "Unload", dataIndex: "unload" },
//     { title: "Category", dataIndex: "category" },
//     { title: "Standard Time (min)", dataIndex: "standard_time" },
//     { title: "Standard Weight (kg)", dataIndex: "standard_weight" },
//     {
//       title: "Action",
//       render: (_, record, index) => (
//         <Button type="link" onClick={() => handleEdit(record, index)}>
//           Edit
//         </Button>
//       ),
//     },
//   ];

//   return (
//     <div className="p-6">
//       <Card title="Vehicle Standard Report" className="rounded-2xl shadow-md">
//         <Form
//           layout="vertical"
//           form={form}
//           onFinish={onFinish}
//           initialValues={{
//             plant_location: "KAGALPLANT",
//             status: "Normal",
//             unload: "RMUNLOAD",
//           }}
//         >
//           <div className="grid grid-cols-3 gap-4">
//             {/* Plant Location */}
//             <Form.Item name="plant_location" label="Plant Location">
//               <Input />
//             </Form.Item>

//             {/* Status (Fixed) */}
//             <Form.Item name="status" label="Status">
//               <Input readOnly />
//             </Form.Item>

//             {/* Vehicle Type */}
//             <Form.Item
//               name="vehicle_type"
//               label="Vehicle Type"
//               rules={[{ required: true, message: "Please select vehicle type" }]}
//             >
//               <Select placeholder="Select Vehicle Type" onChange={handleVehicleChange} showSearch>
//                 {allVehicleTypes.map((v) => (
//                   <Option key={v.value} value={v.value}>
//                     {v.label}
//                   </Option>
//                 ))}
//               </Select>
//             </Form.Item>

//             {/* Unload */}
//             <Form.Item name="unload" label="Unload">
//               <Input readOnly />
//             </Form.Item>

//             {/* Category */}
//             <Form.Item
//               name="category"
//               label="Category"
//               rules={[{ required: true, message: "Please select category" }]}
//             >
//               <Select placeholder="Select Category" onChange={handleCategoryChange}>
//                 {categories.map((cat) => (
//                   <Option key={cat} value={cat}>
//                     {cat}
//                   </Option>
//                 ))}
//               </Select>
//             </Form.Item>

//             {/* Standard Time */}
//             <Form.Item name="standard_time" label="Standard Time (minutes)">
//               <Input readOnly />
//             </Form.Item>

//             {/* Standard Weight */}
//             <Form.Item name="standard_weight" label="Standard Weight (kg)">
//               <Input readOnly />
//             </Form.Item>
//           </div>

//           <Form.Item>
//             <Button type="primary" htmlType="submit">
//               {editingIndex !== null ? "Update Record" : "Add Record"}
//             </Button>
//           </Form.Item>
//         </Form>
//       </Card>

//       <Card title="Report Table" className="mt-6 rounded-2xl shadow-md">
//         <Table columns={columns} dataSource={tableData} rowKey={(r, i) => i} pagination={false} />
//       </Card>
//     </div>
//   );
// };

// export default VehicleStandardReport;





// import React, { useState } from "react";
// import { Table, Select, Input, Button } from "antd";

// const { Option } = Select;

// const vehicleData = {
//   "T-407": { time: 150, weight: 12000 },
//   "T-607": { time: 150, weight: 13000 },
//   "T-709": { time: 180, weight: 14000 },
//   "L-909": { time: 180, weight: 16000 },
//   "L-1109": { time: 180, weight: 16000 },
//   "L-1110": { time: 180, weight: 16000 },
//   VAN: { time: 120, weight: 4000 },
//   ACE: { time: 120, weight: 2000 },
//   APPE: { time: 120, weight: 2000 },
//   "PICK-UP": { time: 120, weight: 3500 },
//   TRUCK: { time: 210, weight: 18000 },
//   "10 TON": { time: 210, weight: 18000 },
//   TAURUS: { time: 240, weight: 25000 },
//   Couriers: { time: 120, weight: 1000 },
//   AUTO: { time: 120, weight: 2000 },
//   BYHAND: { time: 120, weight: 100 },
//   "PRIVATE VEHICLE": { time: 120, weight: 1000 },
// };

// const categories = ["RM", "RM-clubbing", "RM-5C", "RM-wooden"];

// const VehicleStandardTable = () => {
//   const [data, setData] = useState(
//     Object.keys(vehicleData).map((vehicle, index) => ({
//       key: index,
//       plant_location: "KAGALPLANT",
//       status: "Normal",
//       vehicle_type: vehicle,
//       unload: "RMUNLOAD",
//       category: "RM",
//       standard_time: vehicleData[vehicle].time,
//       standard_weight: vehicleData[vehicle].weight,
//     }))
//   );

//   const handleCategoryChange = (value, record) => {
//     const doubleCats = ["RM-clubbing", "RM-5C", "RM-wooden"];
//     const newData = data.map((item) => {
//       if (item.key === record.key) {
//         const baseTime =
//           vehicleData[item.vehicle_type]?.time || item.standard_time;
//         return {
//           ...item,
//           category: value,
//           standard_time: doubleCats.includes(value) ? baseTime * 2 : baseTime,
//         };
//       }
//       return item;
//     });
//     setData(newData);
//   };

//   const handleAddRecord = () => {
//     const newKey = data.length;
//     const newRecord = {
//       key: newKey,
//       plant_location: "KAGALPLANT",
//       status: "Normal",
//       vehicle_type: "",
//       unload: "RMUNLOAD",
//       category: "RM",
//       standard_time: "",
//       standard_weight: "",
//     };
//     setData([...data, newRecord]);
//   };

//   const columns = [
//     {
//       title: "PLANT LOCATION",
//       dataIndex: "plant_location",
//       align: "center",
//       render: (text, record) => (
//         <Input
//           value={text}
//           onChange={(e) => {
//             const newData = [...data];
//             newData[record.key].plant_location = e.target.value;
//             setData(newData);
//           }}
//         />
//       ),
//     },
//     {
//       title: "STATUS",
//       dataIndex: "status",
//       align: "center",
//       render: () => <Input value="Normal" readOnly />,
//     },
//     {
//       title: "VEHICLE TYPE",
//       dataIndex: "vehicle_type",
//       align: "center",
//       render: (text) => <Input value={text} readOnly />,
//     },
//     {
//       title: "UNLOAD",
//       dataIndex: "unload",
//       align: "center",
//       render: (text, record) => (
//         <Input
//           value={text}
//           onChange={(e) => {
//             const newData = [...data];
//             newData[record.key].unload = e.target.value;
//             setData(newData);
//           }}
//         />
//       ),
//     },
//     {
//       title: "CATEGORY",
//       dataIndex: "category",
//       align: "center",
//       render: (text, record) => (
//         <Select
//           value={text}
//           style={{ width: 150 }}
//           onChange={(value) => handleCategoryChange(value, record)}
//         >
//           {categories.map((cat) => (
//             <Option key={cat} value={cat}>
//               {cat}
//             </Option>
//           ))}
//         </Select>
//       ),
//     },
//     // {
//     //   title: "Standard TIME minutes",
//     //   dataIndex: "standard_time",
//     //   align: "center",
//     //   render: (text) => <Input value={text} readOnly />,
//     // },
//     // {
//     //   title: "Standard Weight of the Vehicle",
//     //   dataIndex: "standard_weight",
//     //   align: "center",
//     //   render: (text) => <Input value={text} readOnly />,
//     // },
//     {
//   title: "Standard TIME minutes",
//   dataIndex: "standard_time",
//   align: "center",
//   render: (text, record) => (
//     <Input
//       value={text}
//       onChange={(e) => {
//         const newData = [...data];
//         newData[record.key].standard_time = e.target.value;
//         setData(newData);
//       }}
//     />
//   ),
// },
// {
//   title: "Standard Weight of the Vehicle",
//   dataIndex: "standard_weight",
//   align: "center",
//   render: (text, record) => (
//     <Input
//       value={text}
//       onChange={(e) => {
//         const newData = [...data];
//         newData[record.key].standard_weight = e.target.value;
//         setData(newData);
//       }}
//     />
//   ),
// },

//   ];
// return (
//   <div className="bg-gray-50 min-h-screen flex items-start justify-center pt-10">
//     <div className="bg-white p-6 shadow-lg rounded-lg w-full max-w-7xl">
//       <h2 className="text-xl font-semibold mb-4 text-center">
//         Vehicle Standard Time & Weight Report
//       </h2>

//       <Table
//         bordered
//         pagination={false}
//         columns={columns}
//         dataSource={data}
//         className="shadow-lg rounded-lg"
//       />

//       <div className="flex justify-center mt-6 gap-4">
//         <Button type="primary" onClick={handleAddRecord}>
//           ➕ Add Record
//         </Button>
//         <Button type="default" onClick={() => console.log(data)}>
//           💾 Save
//         </Button>
//       </div>
//     </div>
//   </div>
// );

// };

// export default VehicleStandardTable;


import React, { useState, useEffect } from "react";
import { Table, Select, Input, Button, message } from "antd";
import axios from "axios";

const { Option } = Select;

const categories = ["RM", "RM-clubbing", "RM-5C", "RM-wooden"];

const VehicleStandardTable = () => {
  const [data, setData] = useState([]);

  // ✅ Fetch data from backend
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get("http://localhost:5100/api/vehicle_standard"); // adjust port if needed
        const formatted = res.data.map((item, index) => ({
          key: item.id || index,
          ...item,
        }));
        setData(formatted);
        console.log("Data:", formatted);
      } catch (error) {
        console.error("Error fetching vehicle standard data:", error);
        message.error("Failed to load data from backend");
      }
    };

    fetchData();
  }, []);

  // ✅ Handle category change
  const handleCategoryChange = (value, record) => {
    const doubleCats = ["RM-clubbing", "RM-5C", "RM-wooden"];
    const newData = data.map((item) => {
      if (item.key === record.key) {
        const baseTime = parseInt(item.standard_time_minutes);
        return {
          ...item,
          category: value,
          standard_time_minutes: doubleCats.includes(value)
            ? baseTime * 2
            : baseTime,
        };
      }
      return item;
    });
    setData(newData);
  };

  // ✅ Handle Add Record
  const handleAddRecord = () => {
    const newRecord = {
      key: Date.now(),
      plant_location: "KAGALPLANT",
      status: "Normal",
      vehicle_type: "",
      unload: "RMUNLOAD",
      category: "RM",
      standard_time_minutes: "",
      standard_weight: "",
    };
    setData([...data, newRecord]);
  };

  const handleSave = async () => {
    try {
      const res = await axios.post("http://localhost:5100/api/save_vehicle_standard", data);
      message.success("✅ Data saved successfully!");
      console.log(res.data);
    } catch (error) {
      console.error("Save error:", error);
      message.error("❌ Failed to save data!");
    }
  };

  // ✅ Columns Definition
  const columns = [
    {
      title: "PLANT LOCATION",
      dataIndex: "plant_location",
      align: "center",
      render: (text, record) => (
        <Input
          value={text}
          onChange={(e) => {
            const newData = [...data];
            const index = newData.findIndex((item) => item.key === record.key);
            newData[index] = { ...newData[index], plant_location: e.target.value };
            setData(newData);
          }}
        />
      ),
    },
    {
      title: "STATUS",
      dataIndex: "status",
      align: "center",
      render: (text, record) => (
        <Input
          value={text}
          onChange={(e) => {
            const newData = [...data];
            const index = newData.findIndex((item) => item.key === record.key);
            newData[index] = { ...newData[index], status: e.target.value };
            setData(newData);
          }}
        />
      ),
    },
    {
      title: "VEHICLE TYPE",
      dataIndex: "vehicle_type",
      align: "center",
      render: (text, record) => (
        <Input
          value={text}
          onChange={(e) => {
            const newData = [...data];
            const index = newData.findIndex((item) => item.key === record.key);
            newData[index] = { ...newData[index], vehicle_type: e.target.value };
            setData(newData);
          }}
        />
      ),
    },
    {
      title: "UNLOAD",
      dataIndex: "unload",
      align: "center",
      render: (text, record) => (
        <Input
          value={text}
          onChange={(e) => {
            const newData = [...data];
            const index = newData.findIndex((item) => item.key === record.key);
            newData[index] = { ...newData[index], unload: e.target.value };
            setData(newData);
          }}
        />
      ),
    },
    {
      title: "CATEGORY",
      dataIndex: "category",
      align: "center",
      render: (text, record) => (
        <Select
          value={text}
          style={{ width: 150 }}
          onChange={(value) => handleCategoryChange(value, record)}
        >
          {categories.map((cat) => (
            <Option key={cat} value={cat}>
              {cat}
            </Option>
          ))}
        </Select>
      ),
    },
    {
      title: "Standard TIME minutes",
      dataIndex: "standard_time_minutes",
      align: "center",
      render: (text, record) => (
        <Input
          value={text}
          onChange={(e) => {
            const newData = [...data];
            const index = newData.findIndex((item) => item.key === record.key);
            newData[index] = { ...newData[index], standard_time_minutes: e.target.value };
            setData(newData);
          }}
        />
      ),
    },
    {
      title: "Standard Weight of the Vehicle",
      dataIndex: "standard_weight",
      align: "center",
      render: (text, record) => (
        <Input
          value={text}
          onChange={(e) => {
            const newData = [...data];
            const index = newData.findIndex((item) => item.key === record.key);
            newData[index] = { ...newData[index], standard_weight: e.target.value };
            setData(newData);
          }}
        />
      ),
    },
  ];

  return (
    <div className="bg-gray-50 min-h-screen flex items-start justify-center pt-10">
      <div className="bg-white p-6 shadow-lg rounded-lg w-full max-w-7xl">
        <h2 className="text-xl font-semibold mb-4 text-center">
          Vehicle Standard Time & Weight Report
        </h2>

        <Table bordered pagination={false} columns={columns} dataSource={data} />

        <div className="flex justify-center mt-6 gap-4">
          <Button type="primary" onClick={handleAddRecord}>
            ➕ Add Record
          </Button>
          <Button type="default" onClick={handleSave}>
            💾 Save
          </Button>
        </div>
      </div>
    </div>
  );
};

export default VehicleStandardTable;
