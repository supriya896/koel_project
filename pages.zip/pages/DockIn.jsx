import React, { useEffect, useState } from "react";
import { Button, Form, Input, Table, Tag, Modal, message, Select } from "antd";
import moment from "moment";
import TextArea from "antd/es/input/TextArea";
import DockNavbar from "../components/DockNavbar";
import axios from "axios";
// import { EditOutlined } from "@ant-design/icons";
// import { CloudCog } from "lucide-react";
const { Option } = Select;
import { DatePicker } from "antd";
import dayjs from "dayjs";

const DocIn = () => {
  const [form] = Form.useForm();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedKeys, setSelectedKeys] = useState(new Set());
  const [showDockIn, settShowDockIn] = useState(true);
  const [role, setRole] = useState("admin");
  const [LMHPIsTrue, setLMHPIsTrue] = useState(false);
  const [HHPIsTrue, setHHPIsTrue] = useState(false);
  const [gensetIsTrue, setGensetIsTrue] = useState(false);
  const [RWHIsTrue, setRWHIsTrue] = useState(false);
  const [EStoreIsTrue, setEStoreIsTrue] = useState(false);
  const [otherIsTrue, setOtherIsTrue] = useState(false);
  const [adminIsTrue, setAdminIsTrue] = useState(false);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedDate, setSelectedDate] = useState(null);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [exportModalVisible, setExportModalVisible] = useState(false);


  const handleExport = async () => {
    if (!fromDate || !toDate) {
      message.error("Please select both From and To dates.");
      return;
    }

    try {
      const response = await axios.get("https://koelpravesh.kirloskar.com:5100/export_dock_data", {
        params: {
          from_date: dayjs(fromDate).format("YYYY-MM-DD"),
          to_date: dayjs(toDate).format("YYYY-MM-DD"),
        },
        responseType: "blob", // Required for downloading files
      });

      const blob = new Blob([response.data], { type: response.headers["content-type"] });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "Completed_DOCK_Export.xlsx";
      link.click();

      setExportModalVisible(false);
      setFromDate(null);
      setToDate(null);
      message.success("Exported Successfully!");
    } catch (error) {
      console.error("❌ Export failed:", error);
      message.error("Failed to export data.");
    }
  };


  const parsedUserData = JSON.parse(localStorage.getItem("userData"));
  console.log("user:", parsedUserData?.username);
  const [userData, setUserData] = useState(parsedUserData);
  useEffect(() => {
    const fetchProtectedData = async () => {
      try {
        const token = localStorage.getItem('token');

        const res = await axios.get('https://koelpravesh.kirloskar.com:5100/auth/protected', {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }

        });
        console.log("fff", res)
        setUserData(res.data);
        localStorage.setItem('userData', JSON.stringify(res.data))
        setLoading(false)
      } catch (error) {
        console.log(error)
        setLoading(false)
        alert('Unauthorized. Redirecting to login...');
        localStorage.removeItem('token');
        window.location.href = '/';
      }
    };

    fetchProtectedData();
  }, []);

  useEffect(() => {
    // Reset all states before updating the current role state
    setLMHPIsTrue(false);
    setHHPIsTrue(false);
    setGensetIsTrue(false);
    setRWHIsTrue(false);
    setEStoreIsTrue(false);
    setOtherIsTrue(false);
    setAdminIsTrue(false);

    // Set the correct state based on the role
    switch (role) {
      case "LMHP":
        setLMHPIsTrue(true);
        break;
      case "HHP":
        setHHPIsTrue(true);
        break;
      case "genset":
        setGensetIsTrue(true);
        break;
      case "RWH":
        setRWHIsTrue(true);
        break;
      case "EStore":
        setEStoreIsTrue(true);
        break;
      case "other":
        setOtherIsTrue(true);
        break;
      default:
        setAdminIsTrue(true);
    }
  }, [role]); // Runs when 'role' changes

  // Separate useEffect to log updated states correctly
  useEffect(() => {
    console.log(
      "LMHP:",
      LMHPIsTrue,
      "HHP:",
      HHPIsTrue,
      "Genset:",
      gensetIsTrue,
      "RWH:",
      RWHIsTrue,
      "EStore:",
      EStoreIsTrue,
      "Other:",
      otherIsTrue,
      "Admin:",
      adminIsTrue
    );
  }, [
    LMHPIsTrue,
    HHPIsTrue,
    gensetIsTrue,
    RWHIsTrue,
    EStoreIsTrue,
    otherIsTrue,
    adminIsTrue,
  ]);

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const [vehicleNoSearch, setVehicleNoSearch] = useState("");
  const [gateEntryNoSearch, setGateEntryNoSearch] = useState("");
  const [transporterNameSearch, setTransporterNameSearch] = useState("");

  const [filterStatus, setFilterStatus] = useState("All");
  // const [activeDockState, setActiveDockState] = useState({ key: null,
  //   location: null,
  //   dockInEnabled: false,
  //   dockOutEnabled: false,});

  // const handleInvoiceClick = (key, location) => {
  //     const selectedRow = data.find((row) => row.key === key);
  //     console.log("Clicked Invoice for:", key, location);
  //     if (!selectedRow) return;

  //     const start = selectedRow[`${location}Start`];
  //     const end = selectedRow[`${location}End`];

  //     let dockInEnabled = false;
  //     let dockOutEnabled = false;

  //     if (start && !end) {
  //       dockOutEnabled = true;
  //     } else if (start && end) {
  //       dockInEnabled = true;
  //     } else if (!start && !end) {
  //       dockInEnabled = true;
  //     }

  //     setActiveDockState({
  //       key,
  //       location,
  //       dockInEnabled,
  //       dockOutEnabled,
  //     });

  //     console.log("Updated Active Dock State:", {
  //       key,
  //       location,
  //       dockInEnabled,
  //       dockOutEnabled,
  //     });
  //   };


  const handleFilterChange = (status) => {
    setFilterStatus(status);

    setData(
      originalData.filter((record) => {
        const locations = ["LMHP", "HHP", "Genset", "RM Store", "RWH", "EStore", "Other"];

        // Check if any location has a startTime but no endTime (DockIn)
        // const isDockInCompleted = locations.some(
        //   (loc) => record[`${loc}_startTime`] && !record[`${loc}_endTime`]
        // );

        // // Check if any location has both startTime and endTime (DockOut)
        // const isDockOutCompleted = locations.some(
        //   (loc) => record[`${loc}_startTime`] && record[`${loc}_endTime`]
        // );

        // if (status === "DockIn") return isDockInCompleted;
        // if (status === "DockOut") return isDockOutCompleted;
        // return true; // "All" should return all records
      })
    );
  };

  const filteredData = data
    .filter((item) => {
      const matchesVehicleNo = (item.vehicleNo?.toLowerCase() || "")
        .includes(vehicleNoSearch?.toLowerCase() || "");
      const matchesGateEntryNo = (item.gateEntryNo?.toLowerCase() || "")
        .includes(gateEntryNoSearch?.toLowerCase() || "");
      const matchesTransporterName = (item.transporterName?.toLowerCase() || "")
        .includes(transporterNameSearch?.toLowerCase() || "");

      const matchesSearch =
        matchesVehicleNo && matchesGateEntryNo && matchesTransporterName;

      const isDockIn = ["LMHP", "HHP", "Genset", "RMStore", "RWH", "EStore", "Other"].some(
        (loc) =>
          (!item[`${loc}_textbox`] || item[`${loc}_textbox`] === "") &&
          (!item[`${loc}_startTime`] && !item[`${loc}Start`]) &&
          (!item[`${loc}_endTime`] && !item[`${loc}End`])
      );

      const isDockOut = ["LMHP", "HHP", "Genset", "RMStore", "RWH", "EStore", "Other"].some(
        (loc) =>
          (item[`${loc}_startTime`] || item[`${loc}Start`]) &&
          (!item[`${loc}_endTime`] && !item[`${loc}End`])
      );

      const matchesDate = selectedDate ? moment.utc(item.entryDate).format("DD-MM-YYYY") === selectedDate : true;

      if (filterStatus === "DockIn") return matchesSearch && isDockIn && matchesDate;
      if (filterStatus === "DockOut") return matchesSearch && isDockOut && matchesDate;

      return matchesSearch && matchesDate;
    })


    // 🔽 Sort by entryDate ascending if vehicle number is being searched
    .sort((a, b) => {
      if (vehicleNoSearch) {
        return new Date(b.entryDate) - new Date(a.entryDate);
      }
      return 0; // No sorting when vehicle number is not searched
    });

  const [invoiceMessages, setInvoiceMessages] = useState({});

  const handleInvoiceChange = (e, key) => {
    const value = e.target.value;
    setData(prev =>
      prev.map(row =>
        row.key === key ? { ...row, totalInvoices: value } : row
      )
    );
  };


  const [history, setHistory] = useState({}); // Stores history per row

 const fetchData = async () => {
      try {
        setLoading(true);

        // Fetch both APIs concurrently
        const [unloadingRes, dockRes] = await Promise.all([
          axios.get("https://koelpravesh.kirloskar.com:5100/get_unloading_documents"),
          axios.get("https://koelpravesh.kirloskar.com:5100/get_dock_in_out_details"),
        ]);

        // Extract data
        const unloadingDocs = unloadingRes.data.documents || [];
        const dockDetails = dockRes.data.dockInOutDetails || [];
        console.log("Unloading Docs:", unloadingDocs);
        console.log("Dock Details:", dockDetails);

        // Merge dock details into unloading documents based on vehicleNumber and tripId
        const mergedData = unloadingDocs.map((doc, index) => {
          const matchingDocks = dockDetails.filter(
            (dock) =>
              dock.vehicleNumber === doc.vehicleNumber &&
              dock.tripId === doc.tripId
          );
          const materialCategory =
            matchingDocks.length > 0 && matchingDocks[0].materialCategory
              ? matchingDocks[0].materialCategory
              : null;
            const remarkDock = matchingDocks.find(dock => dock.remarks && dock.remarks.trim() !== "");
            const remarks = remarkDock ? remarkDock.remarks : "";
          const getDockDataForLocation = (location) => {
            const dockEntry = matchingDocks.find(
              (dock) => dock.dockedLocation === location
            );
            return dockEntry
              ? {
                start: dockEntry.startTime,
                end: dockEntry.endTime,
                duration: dockEntry.duration || "-",
                invoices: dockEntry.docked_invoices || "0",
              }
              : { start: "", end: "", duration: "-", invoices: "0" };
          };

          // Get data for each location
          const eStoreData = getDockDataForLocation("EStore");
          const otherData = getDockDataForLocation("Other");
          const lmhpData = getDockDataForLocation("LMHP");
          const hhpData = getDockDataForLocation("HHP");
          const gensetData = getDockDataForLocation("Genset");
          const rwhData = getDockDataForLocation("RWH");
          const rmstoreData = getDockDataForLocation("RM Store");

          return {
            key: doc.tripId,
            srNo: index + 1,
            tripId: doc.tripId,
            vehicleNo: doc.vehicleNumber,
            gateEntryNo: doc.gateEntryNumber,
            transporterName: doc.transporterName,
            grrStatus: doc.gateExitStatus ? "Completed" : "Pending",
            totalInvoices: doc.total_invoices, // Update this if needed
            loadingUnloading: doc.loadingUnloading,
            entryDate: doc.timeStamp,
            materialCategory,
            vehicleType: doc.vehicleType,
            driverMobileNumber: doc.driverMobileNumber,
            Remark: remarks,

            // Location-wise Start, End, Duration, Invoices
            EStoreStart: eStoreData.start,
            EStoreEnd: eStoreData.end,
            EStoreDuration: eStoreData.duration,
            EStoreInvoices: eStoreData.invoices,

            OtherStart: otherData.start,
            OtherEnd: otherData.end,
            OtherDuration: otherData.duration,
            OtherInvoices: otherData.invoices,

            LMHPStart: lmhpData.start,
            LMHPEnd: lmhpData.end,
            LMHPDuration: lmhpData.duration,
            LMHPInvoices: lmhpData.invoices,

            HHPStart: hhpData.start,
            HHPEnd: hhpData.end,
            HHPDuration: hhpData.duration,
            HHPInvoices: hhpData.invoices,

            GensetStart: gensetData.start,
            GensetEnd: gensetData.end,
            GensetDuration: gensetData.duration,
            GensetInvoices: gensetData.invoices,

            RWHStart: rwhData.start,
            RWHEnd: rwhData.end,
            RWHDuration: rwhData.duration,
            RWHInvoices: rwhData.invoices,

            RMStoreStart: rmstoreData.start,
            RMStoreEnd: rmstoreData.end,
            RMStoreDuration: rmstoreData.duration,
            RMStoreInvoices: rmstoreData.invoices,

            // Flags for locations
            LMHP: lmhpData.start !== "" ? 1 : 0,
            HHP: hhpData.start !== "" ? 1 : 0,
            Genset: gensetData.start !== "" ? 1 : 0,
            RWH: rwhData.start !== "" ? 1 : 0,
            EStore: eStoreData.start !== "" ? 1 : 0,
            RMStore: rmstoreData.start !== "" ? 1 : 0,
            Other: otherData.start !== "" ? 1 : 0,

          };
        });

        setData(mergedData);
        console.log("Merged Data:", mergedData);
        console.log("d:", data)
      } catch (err) {
        console.error("Error fetching data:", err);
        setError("Failed to fetch data");
      } finally {
        setLoading(false);
      }
    };

  useEffect(() => {
    fetchData();
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;




  const handleUndo = (key) => {
    if (!history[key] || history[key].length === 0) {
      console.log(`No actions to undo for row: ${key}`);
      return;
    }

    // Get the last saved state and remove it from history
    const previousState = history[key].pop();

    setHistory((prevHistory) => ({
      ...prevHistory,
      [key]: [...prevHistory[key]], // Update without modifying state directly
    }));

    // Restore the row's previous state in the UI
    setData((prevData) =>
      prevData.map((row) => (row.key === key ? previousState : row))
    );

    // Call the async function separately
    undoLastTransaction(previousState, key, history[key].length);
  };

  // Async function for backend call
  const undoLastTransaction = async (previousState, key, undoCount) => {
    try {
      console.log("Undo Request Payload:", {
        gateEntryNo: previousState.gateEntryNo,
        tripId: previousState.tripId,
        dockedInvoice: previousState.dockedInvoice,
        undoCount: undoCount || 1,

      }); // Log the payload before

      const response = await axios.post(
        "https://koelpravesh.kirloskar.com:5100/undo",
        JSON.stringify({
          gateEntryNo: previousState.gateEntryNo,
          dockedInvoice: previousState.dockedInvoice,
          tripId: previousState.tripId,
          undoCount: undoCount || 1,
        }),
        {
          headers: {
            "Content-Type": "application/json", // Ensure JSON format
          },
        }
      );

      if (response.status === 200) {
        console.log("Undo successful:", response.data);

        // Restore the row's previous state in the UI
        // setData((prevData) =>
        //   prevData.map((row) => (row.key === key ? previousState : row))
        // );
      } else {
        console.error("Undo failed:", response.data);
      }
    } catch (error) {
      console.error("Error undoing transaction:", error.response?.data || error.message);
      if (error.response) {
        console.error("Response Data:", error.response.data);
        console.error("Status Code:", error.response.status);
      }

    }

  };


  // const handleUndo = (key) => {
  //   if (!history[key] || history[key].length === 0) {
  //     console.log(`No actions to undo for row: ${key}`);
  //     return;
  //   }

  //   // Get the last saved state and remove it from history
  //   const previousState = history[key].pop();

  //   setHistory((prevHistory) => ({
  //     ...prevHistory,
  //     [key]: [...prevHistory[key]], // Update without modifying state directly
  //   }));

  // Restore the row's previous state
  //   setData((prevData) =>
  //     prevData.map((row) => (row.key === key ? previousState : row))
  //   );
  // };

  const saveHistory = (key, row) => {
    setHistory((prevHistory) => ({
      ...prevHistory,
      [key]: [...(prevHistory[key] || []), { ...row }], // Deep copy
    }));
  };

  const handleDockIn = (key, invoice) => {

    setData((prevData) =>
      prevData.map((row) => {

        // Ensure update only for matching tripId and vehicleNo
        if (row.key === key && row.tripId != "" && row.vehicleNo != "") {
          saveHistory(key, row); // Save previous state before changing
          const textboxValue = row.loadingUnloading === "Loading" ? "" : row[`${invoice}_textbox`] || "";
          const updatedRow = {
            gateEntryNo: row.gateEntryNo,
            vehicleNo: row.vehicleNo,
            totalInvoices: row.totalInvoices,
            duration: row.duration,
            // startTime: moment().format("HH:mm:ss"), // Set the start time
            startTime: moment().format(" HH:mm:ss DD-MM-YYYY"),
            textbox: textboxValue, // Get the textbox value for the invoice
            dockedInvoice: invoice, // Store selected invoice
            isDockedIn: true, // Mark as docked in
            transporterName: row.transporterName,
            grrStatus: row.grrStatus,
            materialCategory: row.materialCategory,
            remarks: row.Remark,
            loadingUnloading: row.loadingUnloading,
            tripId: row.tripId,
            userDockIn: parsedUserData?.username,
            vehicleType: row.vehicleType,
          };
          console.log("fff", updatedRow.gateEntryNo)

          const locations = ["LMHP", "HHP", "Genset", "RM Store", "RWH", "EStore", "Other"];
          const totalInputSum = locations.reduce((sum, loc) => {
            const value = row[`${loc}_textbox`] !== undefined
              ? Number(row[`${loc}_textbox`])
              : Number(row[`${loc.replaceAll(' ', '')}Invoices`] || 0);
            return sum + value;
          }, 0);
          const totalInvoices = Number(row.totalInvoices);
          if (totalInputSum > totalInvoices && row.loadingUnloading === "Unloading") {
            alert("Looks like you've added more invoice than total invoices.");
            return row;
          }

          if (updatedRow.gateEntryNo == null) {
            alert("Fill Gate Entry Number")
            return row;
          }
          if (String(updatedRow.gateEntryNo).length < 12) {
            alert("Gate Entry Number must be 12 digits");
            return row;
          }
          if (!row.materialCategory || row.materialCategory === "select") {
            alert("Material Category is required");
            return row;
          }
           if (
            row.loadingUnloading === "Unloading" &&
            (invoice === "0" || Number(textboxValue) === 0) &&
            (!row.Remark || row.Remark.trim() === "")
          ) {
            alert("Remarks are required when docking in with zero invoices.");
            return row;
          }

          sendDockInRequest(updatedRow);
          console.log("Updated Row:", updatedRow);


          return {
            ...row,
            dockedInvoice: invoice, // Store selected invoice
            // [`${invoice}_startTime`]: moment().format("HH:mm:ss"), // Start time
            [`${invoice}_startTime`]: moment().format("HH:mm:ss DD-MM-YYYY"),
            [`${invoice}_isDockedIn`]: true,
            totalInvoices: row.totalInvoices,
            isAnyDockedIn: true, // Prevent selecting other locations until dock-out
            isDockInEnabled: false,
            isDockOutEnabled: true
          };
        }

        return row;


        // Keep other rows unchanged
      })
    );
  };

  const sendDockInRequest = async (data) => {
    try {
      console.log(data.startTime)
      const response = await axios.post("https://koelpravesh.kirloskar.com:5100/submit_dock_in", data, {
        headers: {
          "Content-Type": "application/json",

        },
      });
      console.log("Dock-in successful:", response.data);
      alert("Dock-in recorded successfully!");

    } catch (error) {
      if (error.response) {
        console.error("Error during dock-in:", error.response.data);
        alert(error.response.data.error || "Failed to record dock-in. Please try again.");
      } else {
        console.error("Error during dock-in:", error.message);
        alert("Network error. Please try again.");
      }
    }
  };

  // Ensure valid time format
  const handleDockOut = (key) => {
    setData((prevData) => prevData.map((row) => {
      if (row.key === key && row.dockedInvoice) {
        const invoice = row.dockedInvoice;
        const invoiceCount = row[`${invoice}_textbox`];

         if (
          row.loadingUnloading === "Loading" &&
          (invoiceCount === "0" || Number(invoiceCount) === 0) &&
          (!row.Remark || row.Remark.trim() === "")
        ) {
          alert("Remarks are required when docking out with zero invoices.");
          return row;
        }
        
        if (row.loadingUnloading === "Loading" && (!invoiceCount || Number(invoiceCount) < 0)) {
          alert("Please enter the number of invoices greater than zero before dock out.");
          return row; // Stop the function and prevent dock-out
        }
  
        saveHistory(key, row); // Save previous state before changing

        // const invoice = row.dockedInvoice;
        // const endTime = moment().format("HH:mm:ss");
        // // const startTimeMoment = moment(row[`${invoice}Start`] || [`${invoice}_startTime`], "HH:mm:ss");
        // const startTimeValue = row[`${invoice}Start`] || row[`${invoice}_startTime`];
        // const startTimeMoment = moment(startTimeValue, "HH:mm:ss");
        // const endTimeMoment = moment(endTime, "HH:mm:ss");

        // // if (!startTimeMoment.isValid() || !endTimeMoment.isValid()) {
        // //   console.error(`Invalid time format for invoice: ${invoice}`);
        // //   return row;
        // // }

        // // Calculate duration
        // const durationMinutes = endTimeMoment.diff(startTimeMoment, "minutes");
        // const hours = Math.floor(durationMinutes / 60);
        // const minutes = durationMinutes % 60;
        // const formattedDuration = `${hours}h ${minutes}m`;
        // const startTimeValue = row[`${invoice}Start`] || row[`${invoice}_startTime`];

        const sanitizeKey = (invoice) => invoice.replace(/\s+/g, '');  // Remove spaces

        const sanitizedInvoice = sanitizeKey(invoice);
        const startTimeValue = row[`${sanitizedInvoice}Start`] || row[`${sanitizedInvoice}_startTime`];


        if (!startTimeValue) {
          console.warn("Missing start time value for invoice:", invoice, row);
          return row; // Prevent further execution if start time is missing
        }

        const endTime = moment().format("HH:mm:ss DD-MM-YYYY");
        console.log("end:", endTime);

        const startTimeMoment = moment(startTimeValue, "HH:mm:ss DD-MM-YYYY", true);
        const endTimeMoment = moment(endTime, "HH:mm:ss DD-MM-YYYY", true);

        if (!startTimeMoment.isValid() || !endTimeMoment.isValid()) {
          console.warn("Invalid parsed time:", startTimeValue, endTime);
          return row;
        }

        const durationMs = endTimeMoment.diff(startTimeMoment);
        const duration = moment.duration(durationMs);
        const hours = Math.floor(duration.asHours());
        const minutes = duration.minutes();
        const formattedDuration = `${hours}h ${minutes}m`;

        console.log(`Dock-In and Dock-Out Duration: ${formattedDuration}`);


        const updatedRow = {
          gateEntryNo: row.gateEntryNo,
          vehicleNo: row.vehicleNo,
          totalInvoices: row.totalInvoices,
          duration: formattedDuration,
          endTime: endTime, // Set the end time
          textbox: invoiceCount || "", // Get the textbox value for the invoice
          dockedInvoice: invoice,
          isDockedOut: true,
          transporterName: row.transporterName,
          grrStatus: row.grrStatus,
          materialCategory: row.materialCategory,
          remarks: row.Remark,
          loadingUnloading: row.loadingUnloading,
          tripId: row.tripId,
          userDockOut: parsedUserData?.username,
        };

        console.log("updated row a ", updatedRow);
        console.log(`Dock-In and Dock-Out Duration: ${hours}h ${minutes}m`);
        submitDockOutAPI(updatedRow);

        return {
          ...row,
          [`${invoice}End`]: endTime,
          [`${invoice}_endTime`]: endTime,
          [`${invoice}_duration`]: formattedDuration,
          [`${invoice}_isCompleted`]: true, // Mark as completed
          isAnyDockedIn: false, // Allow choosing another location after completion
          dockedInvoice: null, // Reset docked invoice
          transporterName: row.transporterName,
          grrStatus: row.grrStatus,
          materialCategory: row.materialCategory,
          remarks: row.Remark,
          loadingUnloading: row.loadingUnloading,
          tripId: row.tripId,
          totalInvoices: row.totalInvoices,
          isDockInEnabled: true,
          isDockOutEnabled: false,
        };
      }
      return row;
    })
    );
  };

  const submitDockOutAPI = async (data) => {
    try {
      console.log(data.endTime)
      const response = await axios.post("https://koelpravesh.kirloskar.com:5100/submit_dock_out", {
        gateEntryNo: data.gateEntryNo,
        vehicleNo: data.vehicleNo,
        dockedInvoice: data.dockedInvoice,
        endTime: data.endTime,
        duration: data.duration,
        tripId: data.tripId,
        totalInvoices: data.totalInvoices,
        textbox: data.textbox,
        remarks: data.remarks || "",
        userDockOut: parsedUserData?.username,
        loadingUnloading: data.loadingUnloading,
      },
        {
          headers: {
            "Content-Type": "application/json",
          },
        });

      if (response.status === 201) {
        console.log("Dock-out successful:", response.data);
        alert("Dock-out recorded successfully!");
      }
    } catch (error) {
      if (error.response) {
        // Server responded with an error
        console.error("Backend Error:", error.response.data);

        // Show backend error message if available
        const backendError =
          error.response.data.error ||
          error.response.data.message ||
          "Failed to record dock-out. Please try again.";

        alert(` ${backendError}`);
      } else if (error.request) {
        //  Request made but no response
        console.error("No Response:", error.request);
        alert("No response from server. Please check your network connection.");
      } else {
        //  Unexpected error
        console.error("Unexpected Error:", error.message);
        alert(`Unexpected Error: ${error.message}`);
      }
    }
  };
  //     else {
  //       console.error("Dock-out failed:", response.data);
  //       alert("Failed to record dock-out. Please try again.");
  //     }
  //   } catch (error) {
  //     console.error("Error submitting dock-out:", error.response?.data || error.message);
  //     alert("Failed to record dock-out. Please try again.");
  //   }
  // };




  // const isDockInDisabled = (record) => {
  //   const locationSum =
  //     (Number(record.LMHP_textbox) || 0) +
  //     (Number(record.HHP_textbox) || 0) +
  //     (Number(record.Genset_textbox) || 0) +
  //     (Number(record.RWH_textbox) || 0) +
  //     (Number(record.EStore_textbox) || 0) +
  //     (Number(record.Other_textbox) || 0);

  //   if (locationSum > Number(record.totalInvoices)) {
  //     // Show warning only once per row
  //     if (!record.warningShown) {
  //       message.warning(
  //         `Row ${record.key}: Total Invoices have been reached or exceeded. Dock-In is stopped!`
  //       );
  //       record.warningShown = true; // Set flag to prevent duplicate messages
  //     }
  //     return true; // Disable Dock-In button
  //   } else {
  //     record.warningShown = false; // Reset flag when condition is not met
  //   }

  //   return false; // Keep Dock-In enabled
  // };

  // console.log("Active Dock State:", activeDockState);

  const handleInputChange = (key, field, value) => {
    setData(prevData =>
      prevData.map(row =>
        row.key === key ? { ...row, [field]: value } : row
      )
    );
  };



  // const handleEdit = (key) => {
  //   setData((prevData) =>
  //     prevData.map((item) =>
  //       item.key === key ? { ...item, isDisabled: !item.isDisabled } : item
  //     )
  //   );
  // };
  const columns = [
    // {
    //   title: <strong>Edit</strong>,
    //   dataIndex: "edit",
    //   width: 20,
    //   key: "edit",
    //   render: (_, record) => (
    //     <EditOutlined
    //       className="text-gray-500 text-2xl cursor-pointer"
    //       onClick={() => handleEdit(record.key)}
    //     />
    //   ),
    //  },
    {
      title: <strong>Sr No</strong>,
      dataIndex: "srNo",
      align: "center",
      width: 10,
      key: "srNo",
      fixed: "left",
    },
    {
      title: <strong>Vehicle No</strong>,
      dataIndex: "vehicleNo",
      fixed: "left",
      align: "center",
      width: 150,
      key: "vehicleNo",
      render: (_, record) => (
        <Input
          value={record.vehicleNo}
          onChange={(e) =>
            handleInputChange(record.key, "vehicleNo", e.target.value)
          }

          disabled={true}
        />
      ),
    },
    {
      title: <strong>Vehicle Type</strong>,
      dataIndex: "vehicleType",
      key: "vehicleType",
      align: "center",
      width: 150,
      render: (_, record) => (
        <Input
          type="text"
          value={record.vehicleType}
          onChange={(e) =>
            handleInputChange(record.key, "vehicleType", e.target.value)
          }
          disabled={true}
        />
      ),
    },
    {
      title: <strong>Entry Date</strong>,
      dataIndex: "entryDate",
      align: "center",
      width: 150,
      key: "entryDate",
      render: (_, record) => (
        <Input
          type="text"
          value={record.entryDate}
          onChange={(e) =>
            handleInputChange(record.key, "entryDate", e.target.value)
          }

          disabled={true}
        />
      ),
    },

    {
      title: <strong>Gate Entry Number</strong>,
      dataIndex: "gateEntryNo",
      align: "center",
      width: 150,
      key: "gateEntryNo",
      render: (_, record) => (
        <Input
          type="text"
          value={record.gateEntryNo}
          onChange={(e) => {
            const value = e.target.value;
            if (/^\d*$/.test(value)) {
              handleInputChange(record.key, "gateEntryNo", value);
            } else {
              // alert(" Gate Entry Number must contain numbers only!");
            }
          }}

          disabled={record.isDisabled}
        />
      ),
    },
    {
      title: <strong>Trip ID</strong>,
      dataIndex: "tripId",
      align: "center",
      width: 150,
      key: "tripId",
      render: (_, record) => (
        <Input
          type="text"
          value={record.tripId}
          onChange={(e) =>
            handleInputChange(record.key, "tripId", e.target.value)
          }

          disabled={true}
        />
      ),
    },
    {
      title: <strong>Driver Mobile Number</strong>,
      dataIndex: "driverMobileNumber",
      align: "center",
      width: 130,
      key: "driverMobileNumber",
      render: (_, record) => (
        <Input
          value={record.driverMobileNumber}
          onChange={(e) =>
            handleInputChange(record.key, "driverMobileNumber", e.target.value)
          }

          disabled={true}
        />
      ),
    },
    {
      title: <strong>Transporter Name</strong>,
      dataIndex: "transporterName",
      align: "center",
      width: 150,
      key: "transporterName",
      render: (_, record) => (
        <Input
          value={record.transporterName}
          onChange={(e) =>
            handleInputChange(record.key, "transporterName", e.target.value)
          }

          disabled={true}
        />
      ),
    },
    {
      title: <strong>GRR Status</strong>,
      dataIndex: "grrStatus",
      align: "center",
      width: 100,
      key: "grrStatus",
      render: (status) => (
        <Tag color={status === "Completed" ? "green" : "red"}>{status}</Tag>
      ),
    },
    {
      title: <strong>Total Invoices</strong>,
      dataIndex: "totalInvoices",
      align: "center",
      width: 100,
      key: "totalInvoices",
      render: (_, record) => {
        const locations = ["LMHP", "HHP", "Genset", "RM Store", "RWH", "EStore", "Other"];

        // Calculate total sum of location textboxes
        const totalInputSum = locations.reduce(
          (sum, loc) => {
            const inputValue = record[`${loc}_textbox`] !== undefined
              ? Number(record[`${loc}_textbox`])
              : Number(record[`${loc.replaceAll(' ', '')}Invoices`] || 0);
            return sum + inputValue;
          }, 0);


        // console.log(totalInputSum)
        const totalInvoices = Number(record.totalInvoices);
        // console.log(totalInvoices)
        // console.log("totalInputSum calculation:", locations.map(loc => `${loc}: ${record[`${loc}_textbox`]}`));



        return (
          <div style={{ position: "relative" }}>
            <Input type="text" defaultValue={record.totalInvoices}
              onChange={(e) => {
                const value = e.target.value;
                if (/^\d*$/.test(value)) {
                  handleInputChange(record.key, "totalInvoices", value);
                } else {
                  // alert("Total Invoices must be numbers only!");
                }
              }}
              disabled={false} />
            {record.totalInvoices !== "" && !isNaN(Number(totalInvoices)) && (
              <span style={{ color: "black", fontWeight: "bold", marginLeft: "10px" }}>
                {totalInputSum === Number(totalInvoices)
                  ? "✅ Equal to Total Invoices"
                  : totalInputSum > Number(totalInvoices)
                    ? "⚠️ Exceeds Total Invoices"
                    : ""}

              </span>
            )}
          </div>
        );
      },
    },

    {
      title: <strong>Loading/Unloading</strong>,
      dataIndex: "loadingUnloading",
      align: "center",
      width: 150,
      key: "loadingUnloading",
      render: (_, record) => (
        <Input value={record.loadingUnloading} disabled={true} />
      ),
    },
    // { title: <strong>Bill Category</strong>, dataIndex: "billCategory", align: "center", width: 150, key: "billCategory", render: (_, record) => (<Select value={record.billCategory || "Billable"} style={{ width: "100%" }} onChange={(value) => { setData(prevData => prevData.map(row => row.key === record.key ? { ...row, billCategory: value } : row)); }} > <Option value="Billable">Billable</Option> <Option value="Non-Billable">Non-Billable</Option> </Select>), },
    {
      title: <strong>Material Category</strong>,
      dataIndex: "materialCategory",
      align: "center",
      width: 150,
      key: "materialCategory",
      render: (_, record) => {
        return (
          <Select
            defaultValue={record.materialCategory || "select"}
            disabled={record.isDisabled}
            style={{ width: "100%" }}
            onChange={(value) => {
              setData(prevData =>
                prevData.map(row => {
                  if (row.key === record.key) {
                    return { ...row, materialCategory: value };
                  }
                  return row;
                })
              );
            }}
          >
            <Option value="Raw Material & Indirect Material">
              Raw Material & Indirect Material
            </Option>
            <Option value="Oil, Petrol, Diesel, Chemicals">
              Oil, Petrol, Diesel, Chemicals
            </Option>
            <Option value="Finished Goods">Finished Goods</Option>
            <Option value="Gas All-LPG,Co2,O2">Gas All-LPG, Co2, O2</Option>
            <Option value="Hazardous Waste">Hazardous Waste</Option>

            <Option value="Scrap Material">Scrap Material</Option>
            <Option value="Spare Parts">Spare Parts</Option>
            <Option value="Skid/Bin/Pallet Dispatch">Skid/Bin/Pallet Dispatch</Option>
            <Option value="Inter Plant/Supplier Dispatch">Inter Plant/Supplier Dispatch</Option>
            <Option value="Other">Other</Option>

          </Select>
        );
      },
    },
    //   {
    //    title: "Invoice Type",
    //    dataIndex: "invoiceType",
    //    align: "center",
    //    width: 150,
    //    key: "invoiceType",
    //    render: (_, record) => {
    //      // Function to check if an invoice is completed
    //      const isInvoiceCompleted = (field) =>
    //        record[`${field}_startTime`] && record[`${field}_endTime`];

    //      // Check if all four invoices are completed
    //      const allInvoicesCompleted =
    //      isInvoiceCompleted("LMHP") &&
    //        isInvoiceCompleted("HHP") &&
    //        isInvoiceCompleted("Genset") &&
    //        isInvoiceCompleted("RWH") &&
    //        isInvoiceCompleted("EStore") &&
    //        isInvoiceCompleted("Other");

    //      return (
    //        <Select
    //          style={{ width: "100%" }}
    //          placeholder="Select Invoice"
    //          value={record.dockedInvoice || undefined}
    //          onChange={(value) => {
    //            setData((prevData) =>
    //              prevData.map((row) =>
    //                row.key === record.key
    //                  ? { ...row, dockedInvoice: value }
    //                  : row
    //              )
    //            );
    //    }}
    //         disabled={allInvoicesCompleted} // Disable only when all invoices are completed
    //        >
    //          <Select.Option value="LMHP">LMHP</Select.Option>
    //          <Select.Option value="HHP">HHP</Select.Option>
    //          <Select.Option value="Genset">Genset</Select.Option>
    //          <Select.Option value="RWH">RWH</Select.Option>
    //          <Select.Option value="EStore">EStore</Select.Option>
    //          <Select.Option value="Other">Other</Select.Option>
    //        </Select>
    //      );
    //    },
    //  },
    {
      title: <strong>Location</strong>,
      dataIndex: "location",
      align: "center",
      key: "location",
      width: 400,
      render: (_, record) => {
        // Function to calculate duration
        const calculateDuration = (startTime, endTime) => {
          if (!startTime || !endTime) return "0h 0m";
          const start = moment(startTime, "HH:mm:ss", true);
          const end = moment(endTime, "HH:mm:ss", true);
          if (!start.isValid() || !end.isValid()) return "Invalid Time";
          const duration = moment.duration(end.diff(start));
          return `${Math.floor(duration.asHours())}h ${duration.minutes()}m`;
        };

        // Filtering logic for DockIn and DockOut at location level
        //  console.log("record",record)
        const shouldShowLocation = (field) => {
          // console.log("record",record[`${field}`])

          const hasTextboxValue = record[`${field}_textbox`]; // Check if a value is entered in the textbox
          const hasStartTime = !!record[`${field}_startTime`] || record[`${field}Start`] ||
            !!record[`${field.replaceAll(" ", "")}_startTime`] || !!record[`${field.replaceAll(" ", "")}Start`]; // Check if DockIn has been done
          const hasEndTime = !!record[`${field}_endTime`] || record[`${field}End`] ||
            !!record[`${field.replaceAll(" ", "")}_endTime`] || !!record[`${field.replaceAll(" ", "")}End`];
          const isCurrentSelected = record.dockedInvoice === field;


          if (filterStatus === "DockIn")
            return (!hasTextboxValue || hasTextboxValue === "") && !hasStartTime && !hasEndTime || isCurrentSelected; // Only show locations where DockIn is pending
          if (filterStatus === "DockOut") return hasStartTime && !hasEndTime;  // Only show locations where DockOut is pending
          return true; // Show all when "All" is selected
        };


        const renderLocationField = (field) => {
          if (!shouldShowLocation(field)) return null; // Hide non-matching locations


          const isCompleted = record[`${field}_isCompleted`] ?? false;
          const isCurrentSelected = record.dockedInvoice === field;
          const hasActiveInvoice = record.isAnyDockedIn && !isCompleted;
          const showDuration = isCompleted; // Show duration only when DockOut is clicked
          const startValue = record[`${field.replaceAll(' ', '')}Start`] || record[`${field.replaceAll(' ', '')}_startTime`] || null;
          const endValue = record[`${field.replaceAll(' ', '')}End`] || record[`${field.replaceAll(' ', '')}_endTime`] || null;
          const hasStartAndEndTime = !!startValue && !!endValue;
          return (
            <div
              key={field}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "5px",
              }}
            >
              {/* Textbox - Initially enabled, disabled when completed */}
              <Input
                style={{ width: "80px", textAlign: "center" }}
                defaultValue={record[`${field.replaceAll(' ', '')}Invoices`] !== "0" ? record[`${field.replaceAll(' ', '')}Invoices`] : ""}
                placeholder="Enter No Of Invoices"
                title="Enter No Of Invoices"
                onFocus={(e) => {
                  // if (!hasActiveInvoice) {

                  // const newValue = e.target.value;
                  const startValue = record[`${field.replaceAll(' ', '')}Start`] || record[`${field.replaceAll(' ', '')}_startTime`] || null;
                  const endValue = record[`${field.replaceAll(' ', '')}End`] || record[`${field.replaceAll(' ', '')}_endTime`] || null;

                  const hasStartTime = !!startValue;
                  const hasEndTime = !!endValue;



                  // handleInputChange(record.key, `${field}_textbox`, newValue);

                  setData((prevData) =>
                    prevData.map((row) => {
                      if (row.key === record.key) {

                        let isDockInEnabled = false;
                        let isDockOutEnabled = false;
                        // let isUndoEnabled = false;

                        if (!hasStartTime && !hasEndTime) {
                          // Condition 2: No Start & No End Time
                          isDockInEnabled = true;
                          isDockOutEnabled = false;
                          // isUndoEnabled = true;
                        }
                        else if (hasStartTime && !hasEndTime) {
                          // Condition 3: Start time exists but no end time
                          isDockInEnabled = false;
                          isDockOutEnabled = true;
                          // isUndoEnabled = true;
                        }
                        else if (hasStartTime && hasEndTime) {
                          // Condition 1: Both times present
                          isDockInEnabled = true;
                          isDockOutEnabled = false;
                          // isUndoEnabled = true; 
                        }


                        return {
                          ...row,
                          dockedInvoice: field,
                          isAnyDockedIn: hasStartTime ? true : false,
                          isDockInEnabled,
                          isDockOutEnabled,
                          // isUndoEnabled,
                        };
                      }
                      return row;
                      // row.key === record.key ? { ...row, dockedInvoice: field, isAnyDockedIn: !!hasStartTime} : row
                    })
                  );
                }
                }
                onChange={(e) => {
                  const newValue = e.target.value;
                  if (/^\d*$/.test(newValue)) {
                    handleInputChange(record.key, `${field}_textbox`, newValue);
                  } else {
                    // alert("Only numbers are allowed for 'Number Of Invoices'!");
                  }
                }}
                disabled={hasStartAndEndTime}
              />


              {/* Invoice Label with Color Change */}
              <span
                style={{
                  color: isCompleted ? "green" : isCurrentSelected ? "green" : "red",
                  fontWeight: "bold",
                  // cursor: "pointer",
                }}

              // onClick={() => {
              //   console.log("Clicked on invoice field:", field); 
              //   handleInvoiceClick(record.key, field.replace(/\s/g, ''))}}
              >
                {field}
              </span>





              {/* Start Time */}
              {/* {console.log("cheching statrt time",record[`${field}`])} */}
              <Input
                style={{ width: "120px" }}
                // value={
                //   record[field] === 1 && record[`${field}_startTime`] !== "-" 
                //     ? record[`${field}_startTime`] 
                //     : ""
                // }
                value={
                  record[`${field}_startTime`] ||
                  record[`${field.replaceAll(' ', '')}_startTime`] ||
                  record[`${field}Start`] ||
                  record[`${field.replaceAll(' ', '')}Start`] ||
                  ""
                }

                // value={record.Other ===1 && record[field] === 1 ? record.otherS : ""}
                placeholder="Start Time"
                disabled={!isCurrentSelected}
              />

              {/* End Time */}
              <Input
                style={{ width: "120px" }}
                // value={record[field] === 1 ? record.endTime : ""}
                // value={
                //   record[field] === 1
                //     ? record[`${field}_endTime`] || record[`${field}End`] || ""
                //     : ""
                // }
                value={
                  record[`${field}_endTime`] ||
                  record[`${field.replaceAll(' ', '')}_endTime`] ||
                  record[`${field}End`] ||
                  record[`${field.replaceAll(' ', '')}End`] ||
                  ""
                }

                placeholder="End Time"
                disabled={!isCurrentSelected}
              />

              {/* Duration Calculation - Initially Hidden, Visible on DockOut */}
              {
                (() => {
                  // const calculateDuration = (start, end) => {
                  //   if (!start || !end) return "";

                  //   const startTime = new Date(`1970-01-01T${start}`);
                  //   const endTime = new Date(`1970-01-01T${end}`);

                  //   if (endTime < startTime) {
                  //     endTime.setDate(endTime.getDate() + 1);
                  //   }

                  //   const durationMs = endTime - startTime;
                  //   const hours = Math.floor(durationMs / (1000 * 60 * 60));
                  //   const minutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));

                  //   return `${hours}h ${minutes}m`;
                  // };
                  const calculateDuration = (start, end) => {
                    if (!start || !end) return "";

                    const startTime = moment(start, "HH:mm:ss DD-MM-YYYY", true);
                    const endTime = moment(end, "HH:mm:ss DD-MM-YYYY", true);

                    if (!startTime.isValid() || !endTime.isValid()) return "";

                    const duration = moment.duration(endTime.diff(startTime));
                    const hours = Math.floor(duration.asHours());
                    const minutes = duration.minutes();

                    return `${hours}h ${minutes}m`;
                  };


                  return (
                    <span style={{ color: "blue" }}>
                      {calculateDuration(
                        record[`${field}_startTime`] ||
                        record[`${field.replaceAll(' ', '')}_startTime`] ||
                        record[`${field}Start`] ||
                        record[`${field.replaceAll(' ', '')}Start`] ||
                        "",

                        record[`${field}_endTime`] ||
                        record[`${field.replaceAll(' ', '')}_endTime`] ||
                        record[`${field}End`] ||
                        record[`${field.replaceAll(' ', '')}End`] ||
                        ""
                      )}
                    </span>
                  );
                })()}


            </div>
          );
        };

        return (
          <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
            {["LMHP", "HHP", "Genset", "RM Store", "RWH", "EStore", "Other"].map(renderLocationField)}
          </div>
        );
      },
    },
    {
      title: <strong>Duration</strong>,
      dataIndex: "duration",
      align: "center",
      width: 150,
      key: "duration",
      render: (_, record) => {
      
        const calculateDuration = (startTime, endTime) => {
          // console.log("🔍 Raw Start/End Times", { startTime, endTime });

          if (!startTime || !endTime) return 0;

          const start = moment(startTime, "HH:mm:ss DD-MM-YYYY", true);
          const end = moment(endTime, "HH:mm:ss DD-MM-YYYY", true);

          if (!start.isValid() || !end.isValid()) return 0;

          const duration = moment.duration(end.diff(start));
          return duration.asMinutes();
        };
        // console.log("12",record["EStoreStart"])

      
        const totalMinutes =
          calculateDuration(record["LMHP_startTime"], record["LMHP_endTime"]) +
          calculateDuration(record["HHP_startTime"], record["HHP_endTime"]) +
          calculateDuration(record["Genset_startTime"], record["Genset_endTime"]) +
          calculateDuration(record["RMStore_startTime"], record["RMStore_endTime"]) +
          calculateDuration(record["RWH_startTime"], record["RWH_endTime"]) +
          calculateDuration(record["EStore_startTime"], record["EStore_endTime"]) +
          calculateDuration(record["Other_startTime"], record["Other_endTime"]);

        console.log("Total minutes:", totalMinutes);



        const hours = Math.floor(totalMinutes / 60);
        const minutes = Math.round(totalMinutes % 60); // Ensure whole number

        return (
          <span style={{ color: "blue" }}>
            {hours}h {minutes > 0 ? `${minutes}m` : "0m"}
          </span>
        );
      },
    },
    {
      title: <strong>Actions</strong>,
      dataIndex: "actions",
      align: "center",
      width: 200,
      key: "actions",
      fixed: "right",
      render: (_, record) => (
        <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
          {/* Dock In Button */}
          <Button
            type="primary"
            onClick={async () => {
              handleDockIn(record.key, record.dockedInvoice)
              setTimeout(() => {
                fetchData();  
              }, 1000);
            }}
            disabled={
              // !record.dockedInvoice || record.isAnyDockedIn
              // // !(activeDockState.key === record.key && activeDockState.dockInEnabled)
              !record.isDockInEnabled
            }
          //disabled={isDockInDisabled(record)}
          >
            Dock In
          </Button>

          {/* Dock Out Button */}
          <Button
            type="primary"
            onClick={async () => {
              await handleDockOut(record.key, record.dockedInvoice) /*|| isDockInDisabled(record)*/
              fetchData()
            }}
            disabled={
              // !record.isAnyDockedIn
              //  !(activeDockState.key === record.key && activeDockState.dockOutEnabled)
              !record.isDockOutEnabled
            }
          >
            Dock Out
          </Button>
          <Button
            onClick={() => handleUndo(record.key)}
            disabled={!history[record.key] || history[record.key].length === 0}
          // disabled={true}
          // !record.isUndoEnabled
          >
            Undo
          </Button>
        </div>
      ),
    },
    // {
    //   title: <strong>Undo</strong>,
    //   dataIndex: "undo",
    //   align: "center",
    //   width: 150,
    //   key: "undo",
    //   render: (_, record) => (
    //     <Button
    //       onClick={() => handleUndo(record.key)}
    //       disabled={!history[record.key] || history[record.key].length === 0}
    //     >
    //       Undo
    //     </Button>
    //   ),
    // },
    {
      title: <strong>Remark</strong>,
      dataIndex: "Remark",
      align: "center",
      width: 150,
      key: "Remark",
      render: (_, record) => (
        <TextArea
          rows={3}
          value={record.Remark}
          onChange={(e) =>
            handleInputChange(record.key, "Remark", e.target.value)
          }
          disabled={record.isDisabled}
        />
      ),
    },
  ];
  // console.log("Filtered Data:", filteredData);
  return (
    <>
      <DockNavbar />
      <div>
        <Form form={form} className="px-20 ">
          {/* <h3 className="text-center text-4xl font-semibold mb-4">
            Dock In / Dock Out
          </h3> */}

          <div className="container flex items-center gap-2 mt-4 p-5">
            <div style={{ border: "2px solid black", padding: 10, display: "flex", borderRadius: 8, width: "100%", maxWidth: "1000px", gap: 8 }}>
              <Input
                placeholder="Search Vehicle Number"
                value={vehicleNoSearch}
                onChange={(e) => {
                  const value = e.target.value;
                  if (/^[a-zA-Z0-9]*$/.test(value)) {
                    setVehicleNoSearch(value);
                  } else {
                    // alert(" Special characters are not allowed!");
                  }
                }}
              />
              <Input
                placeholder="Search Gate Entry Number"
                value={gateEntryNoSearch}
                onChange={(e) => {
                  const value = e.target.value;
                  if (/^\d*$/.test(value)) {
                    setGateEntryNoSearch(value);
                  } else {
                    // alert("Gate Entry Number must contain numbers only!");
                  }
                }}
              />
              <Input
                placeholder="Search Transporter Name"
                value={transporterNameSearch}
                onChange={(e) => setTransporterNameSearch(e.target.value)}
              />
            </div>
            <div style={{ border: "2px solid black", padding: 10, display: "flex", borderRadius: 8, width: "100%", maxWidth: "600px", gap: 8 }}>
              <Button
                style={{ marginLeft: 8, flex: 1 }}
                onClick={() => setFilterStatus("DockIn")}
                type={filterStatus === "DockIn" ? "primary" : "default"}
                disabled={false}
              >
                Pending For DockIn
              </Button>
              <Button
                style={{ marginLeft: 8, flex: 1 }}
                onClick={() => setFilterStatus("DockOut")}
                type={filterStatus === "DockOut" ? "primary" : "default"}
                disabled={false}
              >
                Pending For DockOut
              </Button>
              <Button
                style={{ marginLeft: 8, flex: 1 }}
                onClick={() => setFilterStatus("All")}
                type={filterStatus === "All" ? "primary" : "default"}
              >
                All
              </Button>
              <DatePicker
                style={{ marginLeft: 8, flex: 4 }}
                format="DD-MM-YYYY"
                onChange={(date, dateString) => setSelectedDate(dateString)}
                placeholder="Entry Date"
                disabled={false}
              />
            </div>
            <div style={{ border: "2px solid black", padding: 10, display: "flex", borderRadius: 8, width: "20%", maxWidth: "600px", gap: 8 }}>
              <Button
                style={{ backgroundColor: "#d9d9d9", border: "1px solid #ccc", color: "#000", width: "150px" }}
                onClick={() => setExportModalVisible(true)}
              >
                Export to Excel
              </Button>

              <Modal
                title="Export DOCK-IN/OUT Report"
                open={exportModalVisible}
                onOk={handleExport}
                onCancel={() => setExportModalVisible(false)}
                okText="Export"
              >
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                  <label>From Date:</label>
                  <DatePicker value={fromDate} onChange={(date) => setFromDate(date)} format="YYYY-MM-DD" />
                  <label>To Date:</label>
                  <DatePicker value={toDate} onChange={(date) => setToDate(date)} format="YYYY-MM-DD" />
                </div>
              </Modal>
            </div>



            {/* <Select style={{ width: "100%" }} placeholder="Select Invoice">
  {["LMHP", "HHP", "Genset", "RWH", "EStore", "Other"].map((type) => (
    <Select.Option key={type} value={type}>
      {type}
    </Select.Option>
  ))}
</Select> */}

          </div>
          {showDockIn && (
            <Table
              className="border p-4 h-[70vh] overflow-y-scroll "
              columns={columns}
              size="small"
              pagination={{ pageSize: 3 }}
              dataSource={filteredData}
              rowClassName={(record) =>
                selectedKeys.has(record.key) ? "selected-row" : ""
              }
              scroll={{ x: "max-content" }}
              bordered
            />
          )}
        </Form>
      </div>
    </>
  );
};

export default DocIn;