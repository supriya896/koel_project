defVar --name jnlp_files --type List --innertype String
defVar --name jnlp_file --type String
defVar --name succes --type Boolean
defVar --name security_window_first --type Window
defVar --name security_window --type Window
defVar --name security_window_success --type Boolean
defVar --name erp_window --type Window
defVar --name erp_window_success --type Boolean
defVar --name myexcel --type Excel
defVar --name mytable --type DataTable
defVar --name row --type Numeric
defVar --name column --type Numeric
defVar --name run_output --type String
defVar --name error_dos --type String
defVar --name exit_win --type Window
defVar --name time --type DateTime
webStart --name exception_browser --type "Chrome" --userprofilepreferences "AutomationOptimized" --downloadpath "C:\\Users\\v-cipl064\\Desktop\\jnlp"
webNavigate --url "https://knode1.koel.co.in:8443/OA_HTML/AppsLocalLogin.jsp"
webWaitElement --selector "XPath" --xpath "/html/body/div[2]/div/form/div[1]/input" --timeout "00:01:40"
webSet --value "KOELPRAVESH.GATEENTRY" --selector "XPath" --xpath "/html/body/div[2]/div/form/div[1]/input"
webSet --value "India@123" --selector "XPath" --xpath "/html/body/div[2]/div/form/div[3]/input"
webClick --selector "XPath" --xpath "/html/body/div[2]/div/div[1]/button[1]"
webWaitElement --selector "XPath" --xpath "/html/body/div[3]/form/span[2]/div[3]/div/div[1]/div/div[3]/div[1]/div[2]/table[2]/tbody/tr/td/div/table/tbody/tr/td[1]/table/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr/td/ul/li[1]/a/div[2]" --timeout "00:01:40"
webClick --selector "XPath" --xpath "/html/body/div[3]/form/span[2]/div[3]/div/div[1]/div/div[3]/div[1]/div[2]/table[2]/tbody/tr/td/div/table/tbody/tr/td[1]/table/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr/td/ul/li[1]/a/div[2]"
webClick --selector "XPath" --xpath "/html/body/div[3]/form/span[2]/div[3]/div/div[1]/div/div[3]/div[1]/div[2]/table[2]/tbody/tr/td/div/table/tbody/tr/td[1]/table/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr/td/ul/li/ul/li[2]/a/div[2]"
delay --timeout "00:00:08"
getFiles --path "C:\\Users\\v-cipl064\\Desktop\\jnlp" --ignorecase  --orderbylastmodification  jnlp_files=value
get --collection "${jnlp_files}" --index 1 jnlp_file=value
logMessage --message "${jnlp_file}" --type "Info"
powerShell --apartmentState "MTA" --script "javaws \"${jnlp_file}\"\r\n" succes=success
waitProcess --mode "Start" --by "Name" --name "Oracle Applications - KIRAN" --sessionsearch "AllSessions"
waitWindow --title "Security Warning" --recursive  --safesearch  --timeout "00:05:00" security_window_first=value
findWindow --title "Security Warning" --safesearch  security_window_first=value
attachWindow --window ${security_window_first}
delay --timeout "00:00:00.5000000"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/panel[2]/panel[2]/push_button[1]"
waitWindow --title "Security Warning" --safesearch  --timeout "00:05:00" security_window=value
findWindow --title "Security Warning" --safesearch  security_window=value security_window_success=success
attachWindow --window ${security_window}
delay --timeout "00:00:00.5000000"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/panel[2]/panel[2]/panel[2]/check_box[1]"
delay --timeout "00:00:01"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/panel[2]/panel[2]/panel[2]/panel[1]/push_button[1]"
waitWindow --title "Oracle Applications - KIRAN" --safesearch  --timeout "00:05:00" erp_window=value
findWindow --title "Oracle Applications - KIRAN" --safesearch  erp_window=value erp_window_success=success
attachWindow --window ${erp_window}
delay --timeout "00:00:02"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[2]/panel[1]/menu_bar[1]/menu[3]"
keyboard --type "KeyDown" --key "Down"
keyboard --type "KeyDown" --key "Return"
//click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[8]/internal_frame[1]/panel[1]/panel[1]/panel[1]/panel[2]"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[2]/panel[1]/menu_bar[1]/menu[3]"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[2]/panel[1]/menu_bar[1]/menu[3]/menu_item[8]"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[1]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/push_button[1]"
setValue --value "KOEL BOT" --setValueType "Automatic" --algorithm "Default" --matchcondition "Equals" --selector "XPath" --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[1]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/text[2]"
keyboard --type "KeyDown" --key "Tab"
setValue --value "01-MAY-2025" --setValueType "Automatic" --algorithm "Default" --matchcondition "Equals" --selector "XPath" --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[1]/internal_frame[1]/panel[1]/panel[3]/scroll_pane[3]/viewport[1]/panel[1]/panel[1]/text[1]"
getCurrentDateAndTime --localorutc "LocalTime" --getcurrentdateonly  time=value
setValue --value "${time}" --setValueType "Automatic" --algorithm "Default" --matchcondition "Equals" --selector "XPath" --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[1]/internal_frame[1]/panel[1]/panel[3]/scroll_pane[3]/viewport[1]/panel[1]/panel[2]/text[1]"
setValue --value M71 --setValueType "Automatic" --algorithm "Default" --matchcondition "Equals" --selector "XPath" --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[1]/internal_frame[1]/panel[1]/panel[3]/scroll_pane[3]/viewport[1]/panel[1]/panel[3]/text[1]"
keyboard --type "KeyDown" --key "Tab"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[1]/internal_frame[1]/panel[1]/panel[1]/panel[1]/panel[2]/push_button[1]"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[1]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/push_button[8]"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[1]/internal_frame[1]/panel[1]/panel[1]/panel[1]/panel[2]/push_button[2]"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[1]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/panel[1]/radio_button[1]"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[1]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/push_button[4]"
//click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[27]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[3]/viewport[1]/panel[1]/push_button[1]"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[1]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/push_button[4]"
delay --timeout "00:00:10"
//click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[27]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[3]/viewport[1]/panel[1]/text[1]"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[30]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[3]/viewport[1]/panel[1]/push_button[1]"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[30]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[3]/viewport[1]/panel[1]/push_button[1]"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[30]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[3]/viewport[1]/panel[1]/push_button[1]"
delay --timeout "00:00:08"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[30]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[3]/viewport[1]/panel[1]/push_button[1]"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[30]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[3]/viewport[1]/panel[1]/push_button[1]"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[30]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[3]/viewport[1]/panel[1]/push_button[1]"
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[30]/panel[1]/scroll_pane[1]/viewport[1]/panel[1]/scroll_pane[3]/viewport[1]/panel[1]/push_button[12]"
delay --timeout "00:00:08"
runDOSCommand --command "python \"C:\\python_script.py\"" run_output=output error_dos=error
logMessage --message "${run_output}" --type "Info"
findWindow --title "Oracle Applications - KIRAN" --safesearch  erp_window=value erp_window_success=success
attachWindow --window ${erp_window}
closeWindow --window ${erp_window}
//waitWindow --title Caution --id 30 --classname "internal frame" --processname Idle --safesearch
findWindow --title Caution --safesearch  exit_win=value
//attachWindow --window ${exit_win}
click --selector "XPath" --controlsimilarity 100 --xpath "/root/root_pane[1]/layered_pane[1]/panel[1]/frame[1]/panel[2]/panel[1]/scroll_pane[1]/viewport[1]/desktop_pane[1]/internal_frame[30]/internal_frame[1]/panel[1]/panel[1]/panel[1]/panel[2]/push_button[1]"

webClose --name exception_browser
//excelOpen --file "C:\\Users\\v-cipl064\\Downloads\\KOEL_BOT_Pending_ASN_Report_280425.xls" myexcel=value
//excelGetTable --file ${myexcel} --getfirstsheet  --entiretable  mytable=value row=rows column=columns
//postgreConnect --connectionstring "PostgreSQLConnect(\r\n    host: \"192.168.62.200\",\r\n    port: 5432,\r\n    database: \"openasn_data\",              // Replace with your DB name\r\n    username: \"postgres\",                  // Replace with your DB user\r\n    password: \"admin\",             // Replace with your DB password\r\n    connection => pgConnection\r\n)"