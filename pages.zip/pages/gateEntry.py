from operator import or_
from flask import Flask, request, jsonify
from sqlalchemy import desc
import json
import pytz
from flask_cors import CORS
from config import Config
from datetime import datetime, timedelta

from models import Document, GateEntryDetails, MdrDetails, MdrMaster, TripStatus, db, get_ist_time, DockInOutDetails, DockInOutMaster

from sqlalchemy import or_, and_

app = Flask(__name__)
app.config.from_object(Config)
# CORS(app, resources={r"/api/*": {"origins": ["exp://localhost:8081"]}})
CORS(app)


db.init_app(app)

def get_ist_time():
    return datetime.now(pytz.utc).astimezone(pytz.timezone('Asia/Kolkata'))






@app.route("/submit_loading", methods=["POST"])
def submit_loading():
    try:
        # Parse JSON data from the POST request
        data = request.get_json()

        # Extract required fields
        gate_entry_number = data.get("gate_entry_number")
        trip_id = data.get("trip_id")
        gate_entry_status = data.get("gate_entry_status")

        # Validate the fields
        if not gate_entry_number or not trip_id or gate_entry_status is None:
            return jsonify({"error": "Invalid input. All fields are required."}), 400

        # Fetch the document record
        document = Document.query.filter_by(Trip_id=trip_id).first()

        if not document:
            return jsonify({"error": "Document with the given Trip_id not found."}), 404

        # Update document table
        document.gate_entry_number = gate_entry_number
        db.session.commit()

        # Check if a TripStatus entry already exists for this trip_id and location
        existing_trip_status = TripStatus.query.filter_by(trip_id=trip_id, location=gate_entry_status).first()

        if existing_trip_status:
            # Update the existing entry's time and other fields as needed
            existing_trip_status.time = get_ist_time()  # Update the timestamp
            db.session.commit()
        else:
            # Prepare data for a new TripStatus entry
            vehicle_number = document.vehicle_number
            print("v"+vehicle_number)
            driver_mobile_number = document.driver_mobile_number
            driver_license_number = document.driver_license_number

            # Create a new TripStatus entry
            new_trip_status = TripStatus(
                trip_id=trip_id,
                vehicle_number=vehicle_number,
                driver_mobile_number=driver_mobile_number,
                driver_license_number=driver_license_number,
                location=gate_entry_status,
                time=get_ist_time()  # Set the current timestamp
            )

            # Add the new entry to the session and commit to the database
            db.session.add(new_trip_status)
            db.session.commit()

        # Respond with success
        return jsonify({
            "message": "Loading entry submitted successfully.",
            "data": {
                "gate_entry_number": gate_entry_number,
                "trip_id": trip_id,
                "gate_entry_status": gate_entry_status,
            }
        }), 200

    except Exception as e:
        # Handle unexpected errors
        print(str(e))
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500

@app.route("/submit_invoice", methods=['POST'])
def submit_invoice():
    try:
        data = request.get_json()

        # Extract data from request
        gate_entry_number = data.get("gate_entry_number")
        shipment_number = data.get("shipment_number")
        invoice_number = data.get("invoice_number")
        vendor_code = data.get("vendor_code")
        vendor_name = data.get("vendor_name")
        invoice_date = data.get("invoice_date")

        # Validate required fields
        if not gate_entry_number or not shipment_number:
            return jsonify({"error": "gate_entry_number and shipment_number are required"}), 400

        # Check if the gate_entry_number exists in the Document table
        document = Document.query.filter_by(gate_entry_number=gate_entry_number).first()

        if not document:
            return jsonify({"error": "No document found with the provided gate_entry_number"}), 404

        # Create new GateEntryDetails record
        gate_entry = GateEntryDetails(
            gate_entry_number=gate_entry_number,
            shipment_number=shipment_number,
            invoice_number=invoice_number,
            vendor_code=vendor_code,
            vendor_name=vendor_name,
            invoice_date=invoice_date,
            document_trip_id=document.Trip_id  # Linking to the Document
        )

        # Add to session and commit to DB
        db.session.add(gate_entry)
        db.session.commit()

        return jsonify({"message": "Invoice details submitted successfully", "gate_entry_id": gate_entry.id}), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
    


@app.route('/get_document', methods=['GET'])
def get_document():
    # Get vehicle_number from query parameter
    vehicle_number = request.args.get('vehicle_number').upper()
 
    if not vehicle_number:
        return jsonify({"error": "vehicle_number is required"}), 400
 
    # Query the Document table for the latest record related to the vehicle_number
    latest_document = (Document.query
                       .filter_by(vehicle_number=vehicle_number)  # Filter by vehicle_number
                       .order_by(Document.timestamp.desc())  # Order by timestamp (latest first)
                       .first())  # Get the first (latest) record
 
    if not latest_document:
        return jsonify({"error": "No document found for the given vehicle_number"}), 404
   
    driver_data = json.loads(latest_document.extracted_text_driver)  # Parse the JSON string into a dictionary
    driver_name = driver_data.get('name')  # Extract the driver_name
    dl_number = driver_data.get('dl_number')  # Extract the driver_name
    driver_data = json.loads(latest_document.extracted_text_vehicle)  # Parse the JSON string into a dictionary
    puc_status = latest_document.is_puc_valid
    gate_entry_number = latest_document.gate_entry_number

    if puc_status == 'true':
        puc_status_display = "Ok"
    else:
        puc_status_display = "Not Ok"
   
    # Convert the result to a dictionary for JSON response
    document_data = {
        "trip_id":latest_document.Trip_id,
        "driver_mobile_number": latest_document.driver_mobile_number,
        "vehicle_number": latest_document.vehicle_number,
        "num_of_people": latest_document.num_of_people,
        "transporter_name": latest_document.transporter_name,
        "other_transporter_name": latest_document.other_transporter_name,
        "driver_name": driver_name,
        "vehicle_type":latest_document.vehicle_type,
        "loading_unloading":latest_document.loading_or_unloading,
        "puc_status": puc_status_display,
        "dl_number": dl_number,
        "gate_entry_number": gate_entry_number,
    }
 
    return jsonify({'data':document_data})

@app.route("/", methods=["GET"])
def new():
    return jsonify({'data': "hello world"})

with app.app_context():
    db.create_all()

# Function to safely parse date strings
def parse_date(date_str):
    if date_str:
        try:
            return datetime.strptime(date_str, "%Y-%m-%d").date()  # Converts string to date
        except ValueError as e:
            print("Date Parsing Error:", e)
            return None
    return None

# @app.route("/submit_mdr", methods=["POST"])
# def submit_mdr():
#     try:
#         data = request.json

#         if not data:
#             return jsonify({"error": "No data received"}), 400

#         # Extracting Values
#         invoice_number = data.get("invoice_number")
#         mdr_number = data.get("mdr_number")
#         invoice_date = parse_date(data.get("invoice_date", ""))
#         mdr_date = parse_date(data.get("mdr_date", ""))

#         if not mdr_number or not invoice_number:
#             return jsonify({"error": "mdr number and invoice number required"}), 404
        

#         # Debugging: Check Types
#         print("Type of invoice_date:", type(invoice_date))
#         print("Type of mdr_date:", type(mdr_date))

#         # Check if MdrMaster entry already exists
#         existing_mdr = MdrMaster.query.filter_by(invoice_number=invoice_number).first()

#         if existing_mdr:
#             # Update existing record
#             existing_mdr.mdr_number = mdr_number
#             existing_mdr.invoice_date = invoice_date
#             existing_mdr.mdr_date = mdr_date
#             existing_mdr.vendor_code = data.get("vendor_code")
#             existing_mdr.vendor_name = data.get("vendor_name")
#             existing_mdr.transporter_name = data.get("transporter_name")
#             existing_mdr.vehicle_number = data.get("vehicle_number")
#             existing_mdr.mdr_raised_as = data.get("mdr_raised_as")
#             existing_mdr.grr_mtn_sticker_number = data.get("grr_mtn_sticker_number")
#             existing_mdr.lr_field = data.get("lr_field")
#             existing_mdr.grr_number = data.get("grr_number")
#             existing_mdr.prepared_by = data.get("prepared_by")
#             existing_mdr.mdr_remarks_1 = data.get("mdr_remarks_1")
#             existing_mdr.mdr_remarks_2 = data.get("mdr_remarks_2")
#             existing_mdr.unloading_location=data.get("unloading_location"),
#             existing_mdr.email_id_cc = data.get("email_id_cc")
#             existing_mdr.email_id_to = data.get("email_id_to")

#         else:
#             # Create new MdrMaster entry
#             new_mdr = MdrMaster(
#                 invoice_number=invoice_number,
#                 invoice_date=invoice_date,
#                 mdr_number=mdr_number,
#                 mdr_date=mdr_date,
#                 vendor_code=data.get("vendor_code"),
#                 vendor_name=data.get("vendor_name"),
#                 transporter_name=data.get("transporter_name"),
#                 vehicle_number=data.get("vehicle_number"),
#                 mdr_raised_as=data.get("mdr_raised_as"),
#                 grr_mtn_sticker_number=data.get("grr_mtn_sticker_number"),
#                 lr_field=data.get("lr_field"),
#                 grr_number=data.get("grr_number"),
#                 prepared_by=data.get("prepared_by"),
#                 mdr_remarks_1=data.get("mdr_remarks_1"),
#                 mdr_remarks_2=data.get("mdr_remarks_2"),
#                 unloading_location=data.get("unloading_location"),
#                 email_id_cc=data.get("email_id_cc"),
#                 email_id_to=data.get("email_id_to"),
#             )
#             db.session.add(new_mdr)

#         # Commit MdrMaster before handling MdrDetails
#         db.session.commit()

#         # Handle MdrDetails (Delete existing and insert new)
#         MdrDetails.query.filter_by(mdr_number=mdr_number).delete()  # Delete old details

#         mdr_details_list = data.get("Table Data", [])  # Extract list of details

#         for detail in mdr_details_list:
#             new_detail = MdrDetails(
#                 mdr_number=mdr_number,
#                 invoice_number=invoice_number,
#                 invoice_date=invoice_date,
#                 item_code=detail.get("item_code"),
#                 item_description=detail.get("item_description"),
#                 item_quantity_actual=detail.get("item_quantity_actual"),
#                 quantity_as_per_challan=detail.get("quantity_as_per_challan"),
#                 excess_shortfall_quantity=detail.get("excess_shortfall_quantity"),
#                 number_of_boxes_lr=detail.get("no_of_boxes"),
#                 number_of_boxes_lr_recieved=detail.get("recieved"),
#             )
#             db.session.add(new_detail)

#         # Commit all changes
#         db.session.commit()

#         return jsonify({"message": "MDR record processed successfully", "mdr_number": mdr_number}), 201

#     except Exception as e:
#         db.session.rollback()  # Rollback in case of error
#         print("Error:", str(e))
#         return jsonify({"error": str(e)}), 500    
    

@app.route("/get_unloading_documents", methods=["GET"])
def get_unloading_documents():
    try:
        # Query the Document table for specific columns and filter by the criteria
        unloading_documents = Document.query.with_entities(
            Document.vehicle_number, 
            Document.gate_entry_number, 
            Document.transporter_name, 
            Document.loading_or_unloading, 
            Document.Trip_id,
            Document.gate_exit_status
        ).filter(
            Document.gate_exit_status.is_(None),  # ✅ Correct way to check NULL
            Document.loading_or_unloading.ilike("Unloading")  # ✅ Case-insensitive match
        ).all()



        # Check if any records are found
        if not unloading_documents:
            return jsonify({
                "error": True,
                "message": "No documents found with the given criteria"
            }), 404

        # Convert the result to a list of dictionaries with the required columns
        documents_list = [{
            "vehicleNumber": doc.vehicle_number,
            "gateEntryNumber": doc.gate_entry_number,
            "transporterName": doc.transporter_name,
            "loadingUnloading": doc.loading_or_unloading,
            "tripId": doc.Trip_id,
            "gateExitStatus": doc.gate_exit_status
        } for doc in unloading_documents]

        # Return the list of documents as JSON
        return jsonify({
            "error": False,
            "documents": documents_list
        }), 200

    except Exception as e:
        app.logger.error(f"Error fetching documents: {str(e)}")
        return jsonify({
            "error": True,
            "message": "An unexpected error occurred",
            "details": str(e)
        }), 500


@app.route("/get_dock_in_out_details", methods=["GET"])
def get_dock_in_out_details():
    try:
        dock_in_out_details = DockInOutDetails.query.with_entities(
            DockInOutDetails.vehicle_number,
            DockInOutDetails.trip_id,
            DockInOutDetails.docked_location,
            DockInOutDetails.start_time,
            DockInOutDetails.end_time
        ).filter(
            DockInOutDetails.trip_id.in_(
                Document.query.with_entities(Document.Trip_id)
                .filter(
                    Document.gate_exit_status.is_(None) &  
                    Document.loading_or_unloading.ilike("Unloading")
                ).subquery()
            )
        ).all()

        if not dock_in_out_details:
            return jsonify({
                "error": True,
                "message": "No documents found with the given criteria"
            }), 404 

        # Convert time fields to strings
        dock_in_out_details_list = [{
            "vehicleNumber": dock.vehicle_number,
            "tripId": dock.trip_id,
            "dockedLocation": dock.docked_location,
            "startTime": dock.start_time.strftime("%H:%M:%S") if dock.start_time else None,  # ✅ Convert time to string
            "endTime": dock.end_time.strftime("%H:%M:%S") if dock.end_time else None,  # ✅ Convert time to string
        } for dock in dock_in_out_details]

        return jsonify({
            "error": False,
            "dockInOutDetails": dock_in_out_details_list
        }), 200

    except Exception as e:
        app.logger.error(f"Error fetching documents: {str(e)}")
        return jsonify({
            "error": True,
            "message": "An unexpected error occurred",
            "details": str(e)
        }), 500

@app.route('/submit_dock_out', methods=['POST'])
def submit_dock_out():
    try:
        data = request.json

        if not data:
            return jsonify({"error": "No data received"}), 400

        # Extract values from request data
        trip_id = data.get("tripId")
        gate_entry_number = data.get("gateEntryNo")
        vehicle_number = data.get("vehicleNo")
        docked_location = data.get("dockedInvoice")
        end_time_str = data.get("endTime")  # Expecting format: "HH:MM:SS"
        docked_duration = data.get("duration")
        remarks = data.get("remarks")

        # Validate required fields
        if not trip_id:
            return jsonify({"error": "Trip ID is required"}), 400
        if not docked_location:
            return jsonify({"error": "Docked location is required"}), 400
        if not end_time_str:
            return jsonify({"error": "End time is required"}), 400

        # Convert end_time to datetime.time
        end_time = datetime.strptime(end_time_str, "%H:%M:%S").time()

        # Step 1: Check if `DockInOutMaster` entry exists
        master_entry = DockInOutMaster.query.filter(
            and_(
                DockInOutMaster.trip_id == trip_id,
                DockInOutMaster.vehicle_number == vehicle_number  # Ensuring correct vehicle-trip match
            )
        ).first()

        if not master_entry:
            return jsonify({'error': 'No dock-in record found for the trip id', 'trip_id': trip_id, 'vehicle_number': vehicle_number}), 400

        # Step 2: Check if `DockInOutDetails` entry exists
        detail_entry = DockInOutDetails.query.filter_by(
            trip_id=trip_id,
            docked_location=docked_location
        ).first()

        if not detail_entry:
            return jsonify({'error': 'No dock-in details found for the given trip_id and docked location', 'trip_id': trip_id, 'docked_location': docked_location}), 400
        
        if not detail_entry.start_time:
            return jsonify({'error': 'Dock-in time not found. Please dock-in first before dock-out.'}), 400

        # Step 3: Update the `end_time`, `docked_duration`, and `remarks` for the existing entry
        detail_entry.end_time = end_time
        detail_entry.docked_duration = docked_duration
        detail_entry.remarks = remarks

        # Commit changes
        db.session.commit()

        return jsonify({"message": "Dock-out record processed successfully", "trip_id": trip_id}), 201

    except Exception as e:
        db.session.rollback()
        print("Error:", str(e))
        return jsonify({"error": str(e)}), 500

    

@app.route('/submit_dock_in', methods=['POST'])
def submit_dock_in():
    try:
        data = request.json

        if not data:
            return jsonify({"error": "No data received"}), 400

        # Extract values from request data
        gate_entry_number = data.get("gateEntryNo")
        vehicle_number = data.get("vehicleNo")
        trip_id = data.get("tripId")
        transporter_name = data.get("transporterName")
        grr_status = data.get("grrStatus")
        total_invoices = data.get("totalInvoices")
        loading_unloading = data.get("loadingUnloading")
        material_category = data.get("materialCategory")
 
        docked_location = data.get("dockedInvoice")
        dock_location_invoice = data.get("textbox")
        start_time_str = data.get("startTime")  # Expecting format: "HH:MM:SS"
        docked_duration = data.get("duration")
        remarks = data.get("remarks")


        # Convert start_time to datetime.time
        start_time = datetime.strptime(start_time_str, "%H:%M:%S").time() if start_time_str else None

        # Step 1: Check if `DockInOutMaster` entry exists
        master_entry = DockInOutMaster.query.filter_by(trip_id = trip_id).first()

        if master_entry:
            # Update existing master entry
            master_entry.vehicle_number = vehicle_number
            master_entry.gate_entry_number= gate_entry_number
            master_entry.transporter_name = transporter_name
            master_entry.grr_status = grr_status
            master_entry.total_invoices = total_invoices
            master_entry.loading_unloading = loading_unloading
            master_entry.material_category = material_category
            master_entry.docked_location = docked_location
        else:
            # Create new master entry
            master_entry = DockInOutMaster(
                gate_entry_number=gate_entry_number,
                trip_id=trip_id,
                vehicle_number=vehicle_number,
                transporter_name=transporter_name,
                grr_status=grr_status,
                total_invoices=total_invoices,
                loading_unloading=loading_unloading,
                material_category=material_category,
                docked_location=docked_location
            )
            db.session.add(master_entry)

        # Commit master entry before handling details
        db.session.commit()

        # Step 2: Check if `DockInOutDetails` entry exists (same `gate_entry_number` and `docked_location`)
        detail_entry = DockInOutDetails.query.filter_by(
            trip_id=trip_id,
            docked_location=docked_location
        ).first()

        if detail_entry:
            # Update existing detail entry (reset `end_time`)
            detail_entry.gate_entry_number = gate_entry_number
            detail_entry.vehicle_number = vehicle_number
            detail_entry.dock_location_invoice = dock_location_invoice
            detail_entry.start_time = start_time
            detail_entry.end_time = None  # Reset end_time
            detail_entry.docked_duration = docked_duration
            detail_entry.remarks = remarks
        else:
            # Create new detail entry
            new_detail = DockInOutDetails(
                gate_entry_number=gate_entry_number,
                trip_id = trip_id,
                vehicle_number=vehicle_number,
                docked_location=docked_location,
                dock_location_invoice=dock_location_invoice,
                start_time=start_time,
                end_time=None,  # New entry starts with no end_time
                docked_duration=docked_duration,
                remarks=remarks
            )
            db.session.add(new_detail)

        # Commit all changes
        db.session.commit()

        return jsonify({"message": "Dock-in record processed successfully", "trip_id": trip_id,"gate_entry_number": gate_entry_number, "vehicle_number": vehicle_number}), 201

    except Exception as e:
        db.session.rollback()  # Rollback in case of error
        print("Error:", str(e))
        return jsonify({"error": str(e)}), 500


# @app.route('/submit_dock_in', methods=['POST'])
# def submit_dock_in():
#         data = request.json
#         print("Received data:", data)  # Debugging

#         return ""

# 

@app.route('/undo', methods=['POST'])
def undo():
    try:
        data = request.json
        print("Received undo request:", data) 
        
        trip_id = data.get("tripId", "").strip()  # Using tripId instead of gateEntryNo
        docked_location = data.get("dockedInvoice", "").strip()  # Location from user input
        undo_count = data.get("undoCount", 1)  # Default to 1 if not provided

        if not trip_id or not docked_location:
            return jsonify({"error": "Trip ID and Docked Location are required"}), 400

        # Step 1: Find the last entry in DockInOutDetails for the given trip_id and location
        last_detail_entry = (
            DockInOutDetails.query.filter_by(trip_id=trip_id, docked_location=docked_location)
            .order_by(DockInOutDetails.id.desc())
            .first()
        )

        if not last_detail_entry:
            return jsonify({"error": "No transactions found for the given Trip ID and Docked Location"}), 404

        # Step 2: Check conditions for undo logic
        if last_detail_entry.end_time:  
            # Case 1: If end_time is set, remove it
            last_detail_entry.end_time = None
        elif last_detail_entry.start_time and not last_detail_entry.end_time:
            # Case 2: If start_time is set but end_time is null, remove the whole entry
            db.session.delete(last_detail_entry)

            # Check if there are no remaining details for this trip_id
            remaining_details = DockInOutDetails.query.filter(
                DockInOutDetails.trip_id == trip_id, DockInOutDetails.docked_location != docked_location
            ).first()

            if not remaining_details:
                master_entry = DockInOutMaster.query.filter_by(trip_id=trip_id, docked_location=docked_location).first()
                if master_entry:
                    db.session.delete(master_entry)

        # Step 3: If undo is clicked twice, remove the row entirely from both tables
        if undo_count == 2:
            db.session.delete(last_detail_entry)

            remaining_details = DockInOutDetails.query.filter(
                DockInOutDetails.trip_id == trip_id, DockInOutDetails.docked_location != docked_location
            ).first()

            if not remaining_details:
                master_entry = DockInOutMaster.query.filter_by(trip_id=trip_id, docked_location=docked_location).first()
                if master_entry:
                    db.session.delete(master_entry)

        db.session.commit()
        return jsonify({"message": "Undo action performed successfully", "trip_id": trip_id}), 200

    except Exception as e:
        db.session.rollback()
        print("Error:", str(e))
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True, host="0.0.0.0", port=5100, ssl_context=("certificate.crt", "private.key"))

# from operator import or_
# from flask import Flask, request, jsonify
# from sqlalchemy import desc
# import json
# import pytz
# from flask_cors import CORS
# from config import Config
# from datetime import datetime, timedelta

# from flask import send_file, jsonify, request
# from io import BytesIO
# import pandas as pd
# from datetime import datetime
# from sqlalchemy.orm import joinedload
# from sqlalchemy import func


# from models import Document, GateEntryDetails, MdrDetails, MdrMaster, TripStatus, db, get_ist_time, DockInOutDetails, DockInOutMaster

# from sqlalchemy import or_, and_

# app = Flask(__name__)
# app.config.from_object(Config)
# # CORS(app, resources={r"/api/*": {"origins": ["exp://localhost:8081"]}})
# CORS(app)


# db.init_app(app)

# def get_ist_time():
#     return datetime.now(pytz.utc).astimezone(pytz.timezone('Asia/Kolkata'))






# @app.route("/submit_loading", methods=["POST"])
# def submit_loading():
#     try:
#         # Parse JSON data from the POST request
#         data = request.get_json()

#         # Extract required fields
#         gate_entry_number = data.get("gate_entry_number")
#         trip_id = data.get("trip_id")
#         gate_entry_in_time = data.get("gate_entry_in_time")
#         gate_entry_status = data.get("gate_entry_status")

#         # Validate the fields
#         if not gate_entry_number or not trip_id or gate_entry_status or not gate_entry_in_time is None:
#             return jsonify({"error": "Invalid input. All fields are required."}), 400

#         # Fetch the document record
#         document = Document.query.filter_by(Trip_id=trip_id).first()

#         if not document:
#             return jsonify({"error": "Document with the given Trip_id not found."}), 404

#         # Update document table
#         document.gate_entry_number = gate_entry_number
#         document.gate_entry_status = gate_entry_status
#         document.gate_entry_in_time = gate_entry_in_time
#         db.session.commit()

#         # Check if a TripStatus entry already exists for this trip_id and location
#         existing_trip_status = TripStatus.query.filter_by(trip_id=trip_id, location="Gate Entry"+gate_entry_status).first()

#         if existing_trip_status:
#             # Update the existing entry's time and other fields as needed
#             existing_trip_status.time = get_ist_time()  # Update the timestamp
#             db.session.commit()
#         else:
#             # Prepare data for a new TripStatus entry
#             vehicle_number = document.vehicle_number
#             driver_mobile_number = document.driver_mobile_number
#             driver_license_number = document.driver_license_number

#             # Create a new TripStatus entry
#             new_trip_status = TripStatus(
#                 trip_id=trip_id,
#                 vehicle_number=vehicle_number,
#                 driver_mobile_number=driver_mobile_number,
#                 driver_license_number=driver_license_number,
#                 location="Gate Entry"+gate_entry_status,
#                 time=get_ist_time()  # Set the current timestamp
#             )

#             # Add the new entry to the session and commit to the database
#             db.session.add(new_trip_status)
#             db.session.commit()

#         # Respond with success
#         return jsonify({
#             "message": "Loading entry submitted successfully.",
#             "data": {
#                 "gate_entry_number": gate_entry_number,
#                 "trip_id": trip_id,
#                 "gate_entry_status": gate_entry_status,
#             }
#         }), 200

#     except Exception as e:
#         # Handle unexpected errors
#         print(str(e))
#         return jsonify({"error": f"An error occurred: {str(e)}"}), 500

# @app.route("/submit_invoice", methods=['POST'])
# def submit_invoice():
#     try:
#         data = request.get_json()

#         # Extract data from request
#         gate_entry_number = data.get("gate_entry_number")
#         shipment_number = data.get("shipment_number")
#         invoice_number = data.get("invoice_number")
#         vendor_code = data.get("vendor_code")
#         vendor_name = data.get("vendor_name")
#         invoice_date = data.get("invoice_date") 

#         # Validate required fields
#         if not gate_entry_number or not shipment_number:
#             return jsonify({"error": "gate_entry_number and shipment_number are required"}), 400

#         # Check if the gate_entry_number exists in the Document table
#         document = Document.query.filter_by(gate_entry_number=gate_entry_number).first()

#         if not document:
#             return jsonify({"error": "No document found with the provided gate_entry_number"}), 404

#         # Create new GateEntryDetails record
#         gate_entry = GateEntryDetails(
#             gate_entry_number=gate_entry_number,
#             shipment_number=shipment_number,
#             invoice_number=invoice_number,
#             vendor_code=vendor_code,
#             vendor_name=vendor_name,
#             invoice_date=invoice_date,
#             document_trip_id=document.Trip_id  # Linking to the Document
#         )

#         # Add to session and commit to DB
#         db.session.add(gate_entry)
#         db.session.commit()

#         return jsonify({"message": "Invoice details submitted successfully", "gate_entry_id": gate_entry.id}), 201

#     except Exception as e:
#         db.session.rollback()
#         return jsonify({"error": str(e)}), 500
    


# @app.route('/get_document', methods=['GET'])
# def get_document():
#     # Get vehicle_number from query parameter
#     vehicle_number = request.args.get('vehicle_number').upper()
 
#     if not vehicle_number:
#         return jsonify({"error": "vehicle_number is required"}), 400
 
#     # Query the Document table for the latest record related to the vehicle_number
#     latest_document = (Document.query
#                        .filter_by(vehicle_number=vehicle_number)  # Filter by vehicle_number
#                        .order_by(Document.timestamp.desc())  # Order by timestamp (latest first)
#                        .first())  # Get the first (latest) record
 
#     if not latest_document:
#         return jsonify({"error": "No document found for the given vehicle_number"}), 404
   
#     driver_data = json.loads(latest_document.extracted_text_driver)  # Parse the JSON string into a dictionary
#     driver_name = driver_data.get('name')  # Extract the driver_name
#     dl_number = driver_data.get('dl_number')  # Extract the driver_name
#     driver_data = json.loads(latest_document.extracted_text_vehicle)  # Parse the JSON string into a dictionary
#     puc_status = latest_document.is_puc_valid
#     gate_entry_number = latest_document.gate_entry_number

#     if puc_status == 'true':
#         puc_status_display = "Ok"
#     else:
#         puc_status_display = "Not Ok"
   
#     # Convert the result to a dictionary for JSON response
#     document_data = {
#         "trip_id":latest_document.Trip_id,
#         "driver_mobile_number": latest_document.driver_mobile_number,
#         "vehicle_number": latest_document.vehicle_number,
#         "num_of_people": latest_document.num_of_people,
#         "transporter_name": latest_document.transporter_name,
#         "other_transporter_name": latest_document.other_transporter_name,
#         "driver_name": driver_name,
#         "vehicle_type":latest_document.vehicle_type,
#         "loading_unloading":latest_document.loading_or_unloading,
#         "puc_status": puc_status_display,
#         "dl_number": dl_number,
#         "gate_entry_number": gate_entry_number,
#     }
 
#     return jsonify({'data':document_data})


# @app.route('/get_gate_out_document', methods=['GET'])
# def get_gate_out_document():
#     # Get vehicle_number from query parameter
#     gate_entry_number = request.args.get('gate_entry_number')
#     # gate_entry_status = request.args.get('gate_entry_status')
 
#     if not gate_entry_number:
#         return jsonify({"error": "gate_entry_number is required"}), 400
 
#     # Query the Document table for the latest record related to the vehicle_number
#     latest_document = (Document.query
#                    .filter(Document.gate_entry_number == gate_entry_number, 
#                            Document.gate_entry_status.ilike("In Process"))  # Correct syntax for filtering
#                    .order_by(Document.timestamp.desc())  # Order by timestamp (latest first)
#                    .first())
 
#     if not latest_document:
#         return jsonify({"error": "No document found for the given gate_entry_number"}), 404
   
#     driver_data = json.loads(latest_document.extracted_text_driver)  # Parse the JSON string into a dictionary
#     driver_name = driver_data.get('name')  # Extract the driver_name
#     dl_number = driver_data.get('dl_number')  # Extract the driver_name
#     driver_data = json.loads(latest_document.extracted_text_vehicle)  # Parse the JSON string into a dictionary
#     puc_status = latest_document.is_puc_valid
#     gate_entry_number = latest_document.gate_entry_number
#     gate_entry_status = latest_document.gate_entry_status
#     gate_entry_in_time = latest_document.gate_entry_in_time

#     if puc_status == 'true':
#         puc_status_display = "Ok"
#     else:
#         puc_status_display = "Not Ok"
   
#     # Convert the result to a dictionary for JSON response
#     document_data = {
#         "trip_id":latest_document.Trip_id,
#         "driver_mobile_number": latest_document.driver_mobile_number,
#         "vehicle_number": latest_document.vehicle_number,
#         "num_of_people": latest_document.num_of_people,
#         "transporter_name": latest_document.transporter_name,
#         "other_transporter_name": latest_document.other_transporter_name,
#         "driver_name": driver_name,
#         "vehicle_type":latest_document.vehicle_type,
#         "loading_unloading":latest_document.loading_or_unloading,
#         "puc_status": puc_status_display,
#         "dl_number": dl_number,
#         "gate_entry_number": gate_entry_number,
#         "gate_entry_status": gate_entry_status,
#         "gate_entry_in_time": gate_entry_in_time,
#     }
 
#     return jsonify({'data':document_data})



# @app.route("/", methods=["GET"])
# def new():
#     return jsonify({'data': "hello world"})

# with app.app_context():
#     db.create_all()

# @app.route("/get_gate_out_details", methods=["GET"])
# def get_gate_out_details():
#     try:
#         gate_out_details = Document.query.with_entities(
#             Document.Trip_id,
#             Document.gate_entry_number,
#             Document.vehicle_number,
#             Document.gate_entry_status,
#         ).filter(
#             Document.gate_entry_status.isnot(None),
#             Document.gate_entry_status.ilike('In Process')
#         ).all()

#         if not gate_out_details:
#             return jsonify({
#                 "error": True,
#                 "message": "No gate entries found, come back again"
#             }), 404
        
#         gate_out_list = [{
#             "trip_id": gate_out.Trip_id,
#             "gate_entry_number": gate_out.gate_entry_number,
#             "vehicle_number": gate_out.vehicle_number,
#             "gate_entry_status": gate_out.gate_entry_status
#         } for gate_out in gate_out_details]

#         return jsonify({
#             "error": False,
#             "gate_out": gate_out_list,
#         }), 200
    
#     except Exception as e:
#         app.logger.error(f"Error fetching gate_entry: {str(e)}")
#         return jsonify({
#             "error": True,
#             "message": "An unexpected error occurred",
#             "details": str(e)
#         }), 500
    

# @app.route("/submit_gate_out", methods=["POST"])
# def submit_gate_out():
#     try:
#         # Parse JSON data from the POST request
#         data = request.get_json()

#         # Extract required fields
#         gate_entry_number = data.get("gate_entry_number")
#         trip_id = data.get("trip_id")
#         gate_entry_out_time = data.get("gate_entry_out_time")
#         gate_entry_status = data.get("gate_entry_status")
#         gate_entry_remarks = data.get("gate_entry_remarks")

#         # Validate the fields
#         if not gate_entry_number or not trip_id or gate_entry_status or not gate_entry_out_time or gate_entry_remarks is None:
#             return jsonify({"error": "Invalid input. All fields are required."}), 400

#         # Fetch the document record
#         document = Document.query.filter_by(Trip_id=trip_id).first()

#         if not document:
#             return jsonify({"error": "Document with the given Trip_id not found."}), 404

#         # Update document table
#         document.gate_entry_number = gate_entry_number
#         document.gate_entry_status = gate_entry_status
#         document.gate_entry_out_time = gate_entry_out_time
#         document.gate_entry_remarks = gate_entry_remarks
#         db.session.commit()

#         # Check if a TripStatus entry already exists for this trip_id and location
#         existing_trip_status = TripStatus.query.filter_by(trip_id=trip_id, location="Gate Entry"+gate_entry_status).first()

#         if existing_trip_status:
#             # Update the existing entry's time and other fields as needed
#             existing_trip_status.time = get_ist_time()  # Update the timestamp
#             db.session.commit()
#         else:
#             # Prepare data for a new TripStatus entry
#             vehicle_number = document.vehicle_number
#             driver_mobile_number = document.driver_mobile_number
#             driver_license_number = document.driver_license_number

#             # Create a new TripStatus entry
#             new_trip_status = TripStatus(
#                 trip_id=trip_id,
#                 vehicle_number=vehicle_number,
#                 driver_mobile_number=driver_mobile_number,
#                 driver_license_number=driver_license_number,
#                 location="Gate Entry"+gate_entry_status,
#                 time=get_ist_time()  # Set the current timestamp
#             )

#             # Add the new entry to the session and commit to the database
#             db.session.add(new_trip_status)
#             db.session.commit()

#         # Respond with success
#         return jsonify({
#             "message": "gate out submitted successfully.",
#             "data": {
#                 "gate_entry_number": gate_entry_number,
#                 "trip_id": trip_id,
#                 "gate_entry_status": gate_entry_status,
#             }
#         }), 200

#     except Exception as e:
#         # Handle unexpected errors
#         print(str(e))
#         return jsonify({"error": f"An error occurred: {str(e)}"}), 500
    

# # Function to safely parse date strings
# def parse_date(date_str):
#     if date_str:
#         try:
#             return datetime.strptime(date_str, "%Y-%m-%d").date()  # Converts string to date
#         except ValueError as e:
#             print("Date Parsing Error:", e)
#             return None
#     return None

# # @app.route("/submit_mdr", methods=["POST"])
# # def submit_mdr():
# #     try:
# #         data = request.json

# #         if not data:
# #             return jsonify({"error": "No data received"}), 400

# #         # Extracting Values
# #         invoice_number = data.get("invoice_number")
# #         mdr_number = data.get("mdr_number")
# #         invoice_date = parse_date(data.get("invoice_date", ""))
# #         mdr_date = parse_date(data.get("mdr_date", ""))

# #         if not mdr_number or not invoice_number:
# #             return jsonify({"error": "mdr number and invoice number required"}), 404
        

# #         # Debugging: Check Types
# #         print("Type of invoice_date:", type(invoice_date))
# #         print("Type of mdr_date:", type(mdr_date))

# #         # Check if MdrMaster entry already exists
# #         existing_mdr = MdrMaster.query.filter_by(invoice_number=invoice_number).first()

# #         if existing_mdr:
# #             # Update existing record
# #             existing_mdr.mdr_number = mdr_number
# #             existing_mdr.invoice_date = invoice_date
# #             existing_mdr.mdr_date = mdr_date
# #             existing_mdr.vendor_code = data.get("vendor_code")
# #             existing_mdr.vendor_name = data.get("vendor_name")
# #             existing_mdr.transporter_name = data.get("transporter_name")
# #             existing_mdr.vehicle_number = data.get("vehicle_number")
# #             existing_mdr.mdr_raised_as = data.get("mdr_raised_as")
# #             existing_mdr.grr_mtn_sticker_number = data.get("grr_mtn_sticker_number")
# #             existing_mdr.lr_field = data.get("lr_field")
# #             existing_mdr.grr_number = data.get("grr_number")
# #             existing_mdr.prepared_by = data.get("prepared_by")
# #             existing_mdr.mdr_remarks_1 = data.get("mdr_remarks_1")
# #             existing_mdr.mdr_remarks_2 = data.get("mdr_remarks_2")
# #             existing_mdr.unloading_location=data.get("unloading_location"),
# #             existing_mdr.email_id_cc = data.get("email_id_cc")
# #             existing_mdr.email_id_to = data.get("email_id_to")

# #         else:
# #             # Create new MdrMaster entry
# #             new_mdr = MdrMaster(
# #                 invoice_number=invoice_number,
# #                 invoice_date=invoice_date,
# #                 mdr_number=mdr_number,
# #                 mdr_date=mdr_date,
# #                 vendor_code=data.get("vendor_code"),
# #                 vendor_name=data.get("vendor_name"),
# #                 transporter_name=data.get("transporter_name"),
# #                 vehicle_number=data.get("vehicle_number"),
# #                 mdr_raised_as=data.get("mdr_raised_as"),
# #                 grr_mtn_sticker_number=data.get("grr_mtn_sticker_number"),
# #                 lr_field=data.get("lr_field"),
# #                 grr_number=data.get("grr_number"),
# #                 prepared_by=data.get("prepared_by"),
# #                 mdr_remarks_1=data.get("mdr_remarks_1"),
# #                 mdr_remarks_2=data.get("mdr_remarks_2"),
# #                 unloading_location=data.get("unloading_location"),
# #                 email_id_cc=data.get("email_id_cc"),
# #                 email_id_to=data.get("email_id_to"),
# #             )
# #             db.session.add(new_mdr)

# #         # Commit MdrMaster before handling MdrDetails
# #         db.session.commit()

# #         # Handle MdrDetails (Delete existing and insert new)
# #         MdrDetails.query.filter_by(mdr_number=mdr_number).delete()  # Delete old details

# #         mdr_details_list = data.get("Table Data", [])  # Extract list of details

# #         for detail in mdr_details_list:
# #             new_detail = MdrDetails(
# #                 mdr_number=mdr_number,
# #                 invoice_number=invoice_number,
# #                 invoice_date=invoice_date,
# #                 item_code=detail.get("item_code"),
# #                 item_description=detail.get("item_description"),
# #                 item_quantity_actual=detail.get("item_quantity_actual"),
# #                 quantity_as_per_challan=detail.get("quantity_as_per_challan"),
# #                 excess_shortfall_quantity=detail.get("excess_shortfall_quantity"),
# #                 number_of_boxes_lr=detail.get("no_of_boxes"),
# #                 number_of_boxes_lr_recieved=detail.get("recieved"),
# #             )
# #             db.session.add(new_detail)

# #         # Commit all changes
# #         db.session.commit()

# #         return jsonify({"message": "MDR record processed successfully", "mdr_number": mdr_number}), 201

# #     except Exception as e:
# #         db.session.rollback()  # Rollback in case of error
# #         print("Error:", str(e))
# #         return jsonify({"error": str(e)}), 500    
    

# @app.route("/get_unloading_documents", methods=["GET"])
# def get_unloading_documents():
#     try:
#         # Query the Document table for specific columns and filter by the criteria
#         unloading_documents = Document.query.with_entities(
#             Document.vehicle_number, 
#             Document.gate_entry_number, 
#             Document.transporter_name, 
#             Document.loading_or_unloading, 
#             Document.Trip_id,
#             Document.gate_exit_status,
#             Document.timestamp,
#             Document.total_invoices,
#         ).filter(
#             Document.gate_exit_status.is_(None),  # ✅ Correct way to check NULL
#             Document.loading_or_unloading.ilike("Unloading")  # ✅ Case-insensitive match
#         ).all()



#         # Check if any records are found
#         if not unloading_documents:
#             return jsonify({
#                 "error": True,
#                 "message": "No documents found with the given criteria"
#             }), 404

#         # Convert the result to a list of dictionaries with the required columns
#         documents_list = [{
#             "vehicleNumber": doc.vehicle_number,
#             "gateEntryNumber": doc.gate_entry_number,
#             "transporterName": doc.transporter_name,
#             "loadingUnloading": doc.loading_or_unloading,
#             "tripId": doc.Trip_id,
#             "gateExitStatus": doc.gate_exit_status,
#             "timeStamp": doc.timestamp,
#             "total_invoices": doc.total_invoices,
#         } for doc in unloading_documents]

#         # Return the list of documents as JSON
#         return jsonify({
#             "error": False,
#             "documents": documents_list
#         }), 200

#     except Exception as e:
#         app.logger.error(f"Error fetching documents: {str(e)}")
#         return jsonify({
#             "error": True,
#             "message": "An unexpected error occurred",
#             "details": str(e)
#         }), 500


# @app.route("/get_dock_in_out_details", methods=["GET"])
# def get_dock_in_out_details():
#     try:
#         dock_in_out_details = DockInOutDetails.query.with_entities(
#             DockInOutDetails.vehicle_number,
#             DockInOutDetails.trip_id,
#             DockInOutDetails.docked_location,
#             DockInOutDetails.start_time,
#             DockInOutDetails.end_time,
#             DockInOutDetails.docked_duration,
#             DockInOutDetails.dock_location_invoice
#         ).filter(
#             DockInOutDetails.trip_id.in_(
#                 Document.query.with_entities(Document.Trip_id)
#                 .filter(
#                     Document.gate_exit_status.is_(None) &  
#                     Document.loading_or_unloading.ilike("Unloading")
#                 ).subquery()
#             )
#         ).all()

#         if not dock_in_out_details:
#             return jsonify({
#                 "error": True,
#                 "message": "No documents found with the given criteria"
#             }), 404

#         # Convert time fields to strings
#         dock_in_out_details_list = [{
#             "vehicleNumber": dock.vehicle_number,
#             "tripId": dock.trip_id,
#             "dockedLocation": dock.docked_location,
#             "startTime": dock.start_time.strftime("%H:%M:%S") if dock.start_time else None,  # ✅ Convert time to string
#             "endTime": dock.end_time.strftime("%H:%M:%S") if dock.end_time else None,  # ✅ Convert time to string
#             # "duration": dock.docked_duration.strftime("%H:%M:%S") if dock.docked_duration else None,
#             "duration": dock.docked_duration,
#             "docked_invoices": dock.dock_location_invoice,
#         } for dock in dock_in_out_details]

#         return jsonify({
#             "error": False,
#             "dockInOutDetails": dock_in_out_details_list
#         }), 200

#     except Exception as e:
#         app.logger.error(f"Error fetching documents: {str(e)}")
#         return jsonify({
#             "error": True,
#             "message": "An unexpected error occurred",
#             "details": str(e)
#         }), 500

# @app.route('/submit_dock_out', methods=['POST'])
# def submit_dock_out():
#     try:
#         data = request.json
#         print(data)

#         if not data:
#             return jsonify({"error": "No data received"}), 400

#         # Extract values from request data
#         trip_id = data.get("tripId")
#         gate_entry_number = data.get("gateEntryNo")
#         vehicle_number = data.get("vehicleNo")
#         docked_location = data.get("dockedInvoice")
#         end_time_str = data.get("endTime")  # Expecting format: "HH:MM:SS"
#         docked_duration = data.get("duration")
#         remarks = data.get("remarks")
#         total_invoices = data.get("totalInvoices")

#         # Validate required fields
#         if not trip_id:
#             return jsonify({"error": "Trip ID is required"}), 400
#         if not docked_location:
#             return jsonify({"error": "Docked location is required"}), 400
#         if not end_time_str:
#             return jsonify({"error": "End time is required"}), 400

#         # Convert end_time to datetime.time
#         end_time = datetime.strptime(end_time_str, "%H:%M:%S").time()

#         # Step 1: Check if `DockInOutMaster` entry exists
#         master_entry = DockInOutMaster.query.filter(
#             and_(
#                 DockInOutMaster.trip_id == trip_id,
#                 DockInOutMaster.vehicle_number == vehicle_number  # Ensuring correct vehicle-trip match
#             )
#         ).first()

#         if not master_entry:
#             return jsonify({'error': 'No dock-in record found for the trip id', 'trip_id': trip_id, 'vehicle_number': vehicle_number}), 400

#         # Step 2: Check if `DockInOutDetails` entry exists
#         detail_entry = DockInOutDetails.query.filter_by(
#             trip_id=trip_id,
#             docked_location=docked_location
#         ).first()

#         if not detail_entry:
#             return jsonify({'error': 'No dock-in details found for the given trip_id and docked location', 'trip_id': trip_id, 'docked_location': docked_location}), 400
        
#         if not detail_entry.start_time:
#             return jsonify({'error': 'Dock-in time not found. Please dock-in first before dock-out.'}), 400

#         # Step 3: Update the `end_time`, `docked_duration`, and `remarks` for the existing entry
#         detail_entry.end_time = end_time
#         detail_entry.docked_duration = docked_duration
#         detail_entry.remarks = remarks

#         # Commit changes
#         db.session.commit()


#         existing_entry = Document.query.filter_by(Trip_id=trip_id).first()

#         if existing_entry:
#             updated = False

#             if not existing_entry.gate_entry_number:
#                 existing_entry.gate_entry_number = gate_entry_number
#                 updated = True

#             if not existing_entry.total_invoices:
#                 existing_entry.total_invoices = total_invoices
#                 updated = True

#             if updated:
#                 db.session.commit()


#         return jsonify({"message": "Dock-out record processed successfully", "trip_id": trip_id}), 201

#     except Exception as e:
#         db.session.rollback()
#         print("Error:", str(e))
#         return jsonify({"error": str(e)}), 500

    

# from sqlalchemy.exc import IntegrityError
# import psycopg2

# @app.route('/submit_dock_in', methods=['POST'])
# def submit_dock_in():
#     try:
#         data = request.json
#         # print(data)

#         if not data:
#             return jsonify({"error": "No data received"}), 400

#         # Extract values from request data
#         gate_entry_number = data.get("gateEntryNo")
#         vehicle_number = data.get("vehicleNo")
#         trip_id = data.get("tripId")
#         transporter_name = data.get("transporterName")
#         grr_status = data.get("grrStatus")
#         total_invoices = data.get("totalInvoices")
#         loading_unloading = data.get("loadingUnloading")
#         material_category = data.get("materialCategory")
 
#         docked_location = data.get("dockedInvoice")
#         dock_location_invoice = data.get("textbox")
#         start_time_str = data.get("startTime")
#         docked_duration = data.get("duration")
#         remarks = data.get("remarks")

#         print("total_invoices")

#         start_time = datetime.strptime(start_time_str, "%H:%M:%S").time() if start_time_str else None

#         # Step 1: Check if DockInOutMaster entry exists
#         master_entry = DockInOutMaster.query.filter(
#             (DockInOutMaster.trip_id == trip_id) | (DockInOutMaster.gate_entry_number == gate_entry_number)
#         ).first()

#         if master_entry:
#             master_entry.vehicle_number = vehicle_number
#             master_entry.gate_entry_number = gate_entry_number
#             master_entry.transporter_name = transporter_name
#             master_entry.grr_status = grr_status
#             master_entry.total_invoices = total_invoices
#             master_entry.loading_unloading = loading_unloading
#             master_entry.material_category = material_category
#             master_entry.docked_location = docked_location
#         else:
#             master_entry = DockInOutMaster(
#                 gate_entry_number=gate_entry_number,
#                 trip_id=trip_id,
#                 vehicle_number=vehicle_number,
#                 transporter_name=transporter_name,
#                 grr_status=grr_status,
#                 total_invoices=total_invoices,
#                 loading_unloading=loading_unloading,
#                 material_category=material_category,
#                 docked_location=docked_location
#             )
#             db.session.add(master_entry)

#         db.session.commit()

#         # Update Document table if needed
#         existing_entry = Document.query.filter_by(Trip_id=trip_id).first()

#         if existing_entry:
#             updated = False

#             if not existing_entry.gate_entry_number:
#                 existing_entry.gate_entry_number = gate_entry_number
#                 updated = True

#             if not existing_entry.total_invoices:
#                 existing_entry.total_invoices = total_invoices
#                 updated = True

#             if updated:
#                 db.session.commit()

#         # Handle DockInOutDetails
#         detail_entry = DockInOutDetails.query.filter_by(
#             trip_id=trip_id,
#             docked_location=docked_location
#         ).first()

#         if detail_entry:
#             detail_entry.gate_entry_number = gate_entry_number
#             detail_entry.vehicle_number = vehicle_number
#             detail_entry.dock_location_invoice = dock_location_invoice
#             detail_entry.start_time = start_time
#             detail_entry.end_time = None
#             detail_entry.docked_duration = docked_duration
#             detail_entry.remarks = remarks
#         else:
#             new_detail = DockInOutDetails(
#                 gate_entry_number=gate_entry_number,
#                 trip_id=trip_id,
#                 vehicle_number=vehicle_number,
#                 docked_location=docked_location,
#                 dock_location_invoice=dock_location_invoice,
#                 start_time=start_time,
#                 end_time=None,
#                 docked_duration=docked_duration,
#                 remarks=remarks
#             )
#             db.session.add(new_detail)

#         db.session.commit()

#         return jsonify({
#             "message": "Dock-in record processed successfully",
#             "trip_id": trip_id,
#             "gate_entry_number": gate_entry_number,
#             "vehicle_number": vehicle_number
#         }), 201

#     except IntegrityError as e:
#         db.session.rollback()
#         if isinstance(e.orig, psycopg2.errors.UniqueViolation):
#             return jsonify({
#                 "error": "Duplicate gate_entry_number. This gate entry number already exists."
#             }), 409
#         return jsonify({"error": "Database integrity error", "details": str(e)}), 500

#     except Exception as e:
#         db.session.rollback()
#         print("Error:", str(e))
#         return jsonify({"error": str(e)}), 500



# # @app.route('/submit_dock_in', methods=['POST'])
# # def submit_dock_in():
# #         data = request.json
# #         print("Received data:", data)  # Debugging

# #         return ""



# @app.route('/undo', methods=['POST'])
# def undo():
#     try:
#         data = request.json
#         print("Received undo request:", data) 
        
#         trip_id = data.get("tripId", "").strip()  # Using tripId instead of gateEntryNo
#         docked_location = data.get("dockedInvoice", "").strip()  # Location from user input
#         undo_count = data.get("undoCount", 1)  # Default to 1 if not provided

#         if not trip_id or not docked_location:
#             return jsonify({"error": "Trip ID and Docked Location are required"}), 400

#         # Step 1: Find the last entry in DockInOutDetails for the given trip_id and location
#         last_detail_entry = (
#             DockInOutDetails.query.filter_by(trip_id=trip_id, docked_location=docked_location)
#             .order_by(DockInOutDetails.id.desc())
#             .first()
#         )

#         if not last_detail_entry:
#             return jsonify({"error": "No transactions found for the given Trip ID and Docked Location"}), 404

#         # Step 2: Check conditions for undo logic
#         if last_detail_entry.end_time:  
#             # Case 1: If end_time is set, remove it
#             last_detail_entry.end_time = None
#         elif last_detail_entry.start_time and not last_detail_entry.end_time:
#             # Case 2: If start_time is set but end_time is null, remove the whole entry
#             db.session.delete(last_detail_entry)

#             # Check if there are no remaining details for this trip_id
#             remaining_details = DockInOutDetails.query.filter(
#                 DockInOutDetails.trip_id == trip_id, DockInOutDetails.docked_location != docked_location
#             ).first()

#             if not remaining_details:
#                 master_entry = DockInOutMaster.query.filter_by(trip_id=trip_id, docked_location=docked_location).first()
#                 if master_entry:
#                     db.session.delete(master_entry)

#         # Step 3: If undo is clicked twice, remove the row entirely from both tables
#         if undo_count == 2:
#             db.session.delete(last_detail_entry)

#             remaining_details = DockInOutDetails.query.filter(
#                 DockInOutDetails.trip_id == trip_id, DockInOutDetails.docked_location != docked_location
#             ).first()

#             if not remaining_details:
#                 master_entry = DockInOutMaster.query.filter_by(trip_id=trip_id, docked_location=docked_location).first()
#                 if master_entry:
#                     db.session.delete(master_entry)

#         db.session.commit()
#         return jsonify({"message": "Undo action performed successfully", "trip_id": trip_id}), 200

#     except Exception as e:
#         db.session.rollback()
#         print("Error:", str(e))
#         return jsonify({"error": str(e)}), 500


 
#  # //export
# @app.route("/export_dock_data", methods=["GET"])
# def export_dock_data():
#     try:
#         from_date = request.args.get("from_date")
#         to_date = request.args.get("to_date")

#         if not from_date or not to_date:
#             return jsonify({"error": "Both from_date and to_date are required."}), 400

#         from_dt = datetime.strptime(from_date, "%Y-%m-%d").date()
#         to_dt = datetime.strptime(to_date, "%Y-%m-%d").date()

#         # Use DATE() to extract date part of start_time and end_time
#         records = (
#             db.session.query(DockInOutMaster)
#             .options(joinedload(DockInOutMaster.details))
#             .filter(func.DATE(DockInOutMaster.start_time) >= from_dt, 
#                     func.DATE(DockInOutMaster.end_time) <= to_dt)
#             .all()
#         )

#         if not records:
#             return jsonify({"error": "No data found for given date range"}), 404

#         # Flatten data: master + each detail
#         data = []
#         for master in records:
#             master_dict = master.to_dict()
#             for detail in master.details:
#                 detail_dict = detail.to_dict()
#                 combined_row = {**master_dict, **detail_dict}
#                 data.append(combined_row)

#         # Convert to Excel
#         df = pd.DataFrame(data)
#         output = BytesIO()
#         df.to_excel(output, index=False)
#         output.seek(0)

#         return send_file(
#             output,
#             download_name=f"Dock_Report_{from_date}_to_{to_date}.xlsx",
#             as_attachment=True,
#             mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
#         )

#     except Exception as e:
#         print("❌ Excel Export Error:", str(e))
#         return jsonify({"error": str(e)}), 500



# # if __name__ == "__main__":
# #     with app.app_context():
# #         db.create_all()
# #     app.run(debug=True, host="0.0.0.0", port=5100, ssl_context=("certificate.crt", "private.key"))

# if __name__ == "__main__":
#     with app.app_context():
#         db.create_all()
# app.run(debug=True, host="0.0.0.0", port=5100)  # Remove ssl_context
