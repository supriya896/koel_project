import React, { useEffect, useState } from "react";
import { Button, Form, Input, List, message } from "antd";
import axios from "axios";

export default function UnloadingMaster() {
  const [form] = Form.useForm();
  const [locations, setLocations] = useState([]);

  useEffect(() => {
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    try {
      const res = await axios.get("/api/unloading-locations");
      setLocations(res.data || []);
    } catch (err) {
      message.error("Failed to load locations");
    }
  };

  const handleAdd = async (values) => {
    try {
      await axios.post("/api/unloading-locations", values);
      form.resetFields();
      fetchLocations();
      message.success("Location added");
    } catch (err) {
      message.error("Failed to add location");
    }
  };

  return (
    <>
      <h2>Unloading Location Master</h2>
      <Form form={form} layout="inline" onFinish={handleAdd}>
        <Form.Item name="location" rules={[{ required: true }]}>
          <Input placeholder="New Location" />
        </Form.Item>
        <Form.Item>
          <Button htmlType="submit" type="primary">Add</Button>
        </Form.Item>
      </Form>

      <List
        header={<b>Existing Locations</b>}
        bordered
        dataSource={locations}
        renderItem={(item) => <List.Item>{item}</List.Item>}
      />
    </>
  );
}
