import React, { useContext, useEffect, useRef, useState } from 'react';
import { Button, Form, Input, Popconfirm, Table, message } from 'antd';
import Navbar from '../components/Navbar'
import './invoice.css'
import { ArrowLeftOutlined, CheckOutlined, DeleteOutlined, PlusCircleOutlined, RobotOutlined, TableOutlined } from '@ant-design/icons';
import { useLocation, useNavigate } from 'react-router';
import exportToExcel from '../utils/exportToExcel';

const EditableContext = React.createContext(null);
const EditableRow = ({ index, ...props }) => {
    const [form] = Form.useForm();
    return (
        <Form form={form} component={false}>
            <EditableContext.Provider value={form}>
                <tr {...props} />
            </EditableContext.Provider>
        </Form>
    );
};
const EditableCell = ({
    title,
    editable,
    children,
    dataIndex,
    record,
    handleSave,
    ...restProps
}) => {
    const [editing, setEditing] = useState(false);
    const inputRef = useRef(null);
    const form = useContext(EditableContext);
    useEffect(() => {
        if (editing) {
            inputRef.current?.focus();
        }
    }, [editing]);
    const toggleEdit = () => {
        setEditing(!editing);
        form.setFieldsValue({
            [dataIndex]: record[dataIndex],
        });
    };
    const save = async () => {
        try {
            const values = await form.validateFields();
            toggleEdit();
            handleSave({
                ...record,
                ...values,
            });
        } catch (errInfo) {
            console.log('Save failed:', errInfo);
        }
    };
    let childNode = children;
    if (editable) {
        childNode = editing ? (
            <Form.Item
                style={{
                    margin: 0,
                }}
                name={dataIndex}
            >
                <Input ref={inputRef} onPressEnter={save} onBlur={save} />
            </Form.Item>
        ) : (
            <div
                className="editable-cell-value-wrap"
                style={{
                    paddingInlineEnd: 24,
                }}
                onClick={toggleEdit}
            >
                {children}
            </div>
        );
    }
    return <td {...restProps}>{childNode}</td>;
};

const Invoice = () => {
    const Navigate = useNavigate()
    const location = useLocation()
    const { data } = location.state
    const { invoice } = location.state
    const [messageApi, contextHolder] = message.useMessage();
    // console.log(typeof Number(invoice))
    const n = Number(invoice); // Replace this with the desired number of items
    const saveData = localStorage.getItem("dataStored");
    const savedData = JSON.parse(saveData)
    let fillData = []
    if (savedData) {
        console.log("len", savedData.length)
        let noOfData = n - savedData.length
        if (noOfData > 0) {
            for (let i = 0; i < savedData.length; i++) {
                fillData.push(
                    {
                        key: savedData[i].key,
                        srn: savedData[i].srn,
                        shipmentNo: savedData[i].shipmentNo,
                        invoiceNo: savedData[i].invoiceNo,
                        vendorCode: savedData[i].vendorCode,
                        directDelivery: savedData[i].directDelivery,
                        vendorName: savedData[i].vendorName,
                        other: savedData[i].other,
                        outInvoiceNo: savedData[i].outInvoiceNo,
                        invoiceDate: savedData[i].invoiceDate,
                        invoiceAmount: savedData[i].invoiceAmount
                    }
                )
            }
            for (let i = 0; i < noOfData; i++) {
                console.log("d", i)
                console.log(fillData.length + 1)
                fillData.push(
                    {
                        key: fillData.length + 1,
                        srn: fillData.length + 1,
                        shipmentNo: '',
                        invoiceNo: '',
                        vendorCode: '',
                        directDelivery: 'No',
                        vendorName: '',
                        other: '',
                        outInvoiceNo: '',
                        invoiceDate: '',
                        invoiceAmount: ''
                    }
                )
            }
        }
        else {
            for (let i = 0; i < n; i++) {
                fillData.push(
                    {
                        key: savedData[i].key,
                        srn: savedData[i].srn,
                        shipmentNo: savedData[i].shipmentNo,
                        invoiceNo: savedData[i].invoiceNo,
                        vendorCode: savedData[i].vendorCode,
                        directDelivery: savedData[i].directDelivery,
                        vendorName: savedData[i].vendorName,
                        other: savedData[i].other,
                        outInvoiceNo: savedData[i].outInvoiceNo,
                        invoiceDate: savedData[i].invoiceDate,
                        invoiceAmount: savedData[i].invoiceAmount
                    }
                )
            }
        }

        console.log("cjhec", fillData)
    } else {
        fillData = Array.from({ length: n }, (_, index) => ({
            key: `${index + 1}`,
            srn: `${index + 1}`,
            shipmentNo: '',
            invoiceNo: '',
            vendorCode: '',
            directDelivery: 'No',
            vendorName: '',
            other: '',
            outInvoiceNo: '',
            invoiceDate: '',
            invoiceAmount: ''
        }))
        console.log("first")
    }
    const initialDataSource = fillData;
    const [dataSource, setDataSource] = useState(initialDataSource);
    const [count, setCount] = useState(n + 1);

    const handleDelete = (key) => {
        // const newData = dataSource.filter((item) => item.key !== key);
        // setDataSource(newData);
        const newData = dataSource
            .filter((item) => item.key !== key) // Remove the row with the given key
            .map((item, index) => ({
                ...item,
                key: `${index + 1}`, // Reassign keys sequentially
                srn: `${index + 1}`, // Update Sr. No sequentially
            }));

        setDataSource(newData);
    };

    const defaultColumns = [
        {
            title: 'Sr. No',
            dataIndex: 'srn',
        },
        {
            title: 'Shipment No',
            dataIndex: 'shipmentNo',
            width: '10%',
            editable: true,
        },
        {
            title: 'Invoice No',
            dataIndex: 'invoiceNo',
            width: '10%',
            editable: true,
        },
        {
            title: 'Vendor Code',
            dataIndex: 'vendorCode',
            width: '10%',
            editable: true,
        },
        {
            title: 'Direct Delivery',
            dataIndex: 'directDelivery',
            width: '10%',
            editable: true,
        },
        {
            title: 'Vendor Name',
            dataIndex: 'vendorName',
            width: '10%',
            editable: true,
        },
        {
            title: 'Other',
            dataIndex: 'other',
            width: '10%',
            editable: true,
        },
        {
            title: 'Out Invoice No',
            dataIndex: 'outInvoiceNo',
            width: '10%',
            editable: true,
        },
        {
            title: 'Invoice Date',
            dataIndex: 'invoiceDate',
            width: '10%',
            editable: true,
        },
        {
            title: 'Invoice Amount',
            dataIndex: 'invoiceAmount',
            width: '10%',
            editable: true,
        },
        {
            title: 'Action',
            dataIndex: 'action',
            render: (_, record) =>
                dataSource.length >= 1 ? (
                    <Popconfirm title="Sure to delete?" onConfirm={() => handleDelete(record.key)}>
                        <a className=''><DeleteOutlined className='text-red-400 text-xl' /></a>
                    </Popconfirm>
                ) : null,
        },
    ];
    const handleAdd = () => {
        const newCount = dataSource.length + 1;
        const newData = {
            key: newCount,
            srn: newCount,
            shipmentNo: '',
            invoiceNo: '',
            vendorCode: '',
            directDelivery: 'No',
            vendorName: '',
            other: '',
            outInvoiceNo: '',
            invoiceDate: '',
            invoiceAmount: ''

        };
        setDataSource([...dataSource, newData]);
        setCount(newCount + 1);
    };
    const handleSave = (row) => {
        const newData = [...dataSource];
        const index = newData.findIndex((item) => row.key === item.key);
        const item = newData[index];
        newData.splice(index, 1, {
            ...item,
            ...row,
        });
        setDataSource(newData);
    };
    const components = {
        body: {
            row: EditableRow,
            cell: EditableCell,
        },
    };
    const columns = defaultColumns.map((col) => {
        if (!col.editable) {
            return col;
        }
        return {
            ...col,
            onCell: (record) => ({
                record,
                editable: col.editable,
                dataIndex: col.dataIndex,
                title: col.title,
                handleSave,
            }),
        };
    });

    const handleBack = () => {
        localStorage.setItem("dataStored", JSON.stringify(dataSource));
        const data = JSON.parse(localStorage.getItem("gate-form"))
        const newData = { ...data, invoices: dataSource.length }
        localStorage.setItem("gate-form", JSON.stringify(newData))
        Navigate('/gate-entry')
    }
    const handleSubmit = () => {
        let err = 0
        dataSource.map((d) => {
            if ((d.shipmentNo).trim() === '' && (d.invoiceNo).trim() === '' && (d.other).trim() === '') {
                messageApi.open({
                    type: 'error',
                    content: `Fill at least Shipment No or Invoice No or Other Field for Sr. No ${d.srn}`,
                    duration: 5
                });
                err += 1
            }
        })

        if (err == 0) {
            localStorage.removeItem("gate-form")
            localStorage.removeItem('dataStored')
            messageApi.open({
                type: 'success',
                content: 'Data Saved sucessfully',
                duration: 1
            });
            setTimeout(() => {
                Navigate('/preview', { replace: true, state: { data: data } })
            }, 1000)
        }
    }
    
    const handleExport = () => {
        exportToExcel(dataSource, "ExportedData");
    };

    return (
        <>
            {contextHolder}
            <Navbar />
            <div className='min-h-[80vh] w-[85%] bg-gray-100 mx-auto rounded-xl mt-10 px-10 pt-10 pb-2 mb-10'>
                <div className='flex w-full justify-between mb-8 items-center'>
                    <div onClick={handleBack} className='h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center cursor-pointer hover:scale-110 transition'>
                        <ArrowLeftOutlined className='text-black' />
                    </div>
                    <div className='flex flex-col items-center gap-2'>
                        <p className='text-sm text-gray-600'>Gate Entry Number</p>
                        <h1>
                            <Input type='text' disabled value={data.gateEntryNumber} placeholder='Gate Entry Number' />
                        </h1>
                    </div>
                    <div className='flex gap-3'>
                        <Button
                            onClick={handleExport}
                            type="primary"
                            className='h-10 !bg-[#138247] font-semibold' icon={<TableOutlined />} iconPosition='end'
                        >
                            Export CSV
                        </Button>
                        <Button
                            onClick={handleAdd}
                            type="primary"
                            className='h-10 !bg-[#c47c5c] font-semibold' icon={<PlusCircleOutlined />} iconPosition='end'
                        >
                            Add a row
                        </Button>
                    </div>


                </div>

                <Table
                    components={components}
                    rowClassName={() => 'editable-row'}
                    bordered
                    dataSource={dataSource}
                    columns={columns}
                    pagination={false}
                />
                <div className='flex gap-5 mb-5 mt-5'>
                    <Button htmlType="button" className='h-10 !bg-[#c47c5c] text-white hover:!text-white hover:!border-[#c47c5c]' icon={<RobotOutlined />} iconPosition='end' >
                        Start Bot
                    </Button>
                    <Button onClick={handleSubmit} type="primary" htmlType="submit" className='h-10 !bg-[#1d998b] font-semibold' icon={<CheckOutlined />} iconPosition='end'>
                        Submit
                    </Button>
                </div>


            </div>
        </>
    )
}

export default Invoice