import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import {
  Form,
  Input,
  DatePicker,
  Button,
  Checkbox,
  message,
} from "antd";
import dayjs from "dayjs";
import axios from "axios";

import GRRTable1 from "../components/GRRTable1";
import GRRTable2 from "../components/GRRTable2";
import GRRTable3 from "../components/GRRTable3";

const GRR = () => {
  const { state } = useLocation();
  const { shipmentNo, invoiceNo, invoiceDate, gateEntryNumber } = state || {};

  const [loading, setLoading] = useState(true);
  const [form] = Form.useForm();
  const [showNextPage, setShowNextPage] = useState(false);

  const [itemRows, setItemRows] = useState([]);
  const [taxRows, setTaxRows] = useState([]);
  const [taxRateRows, setTaxRateRows] = useState([]);

  useEffect(() => {
    if (!shipmentNo) {
      setLoading(false);
      return;
    }

    const fetchData = async () => {
      try {
        const res = await axios.get("http://192.168.62.199:5000/search_shipment_no", {
          params: { shipment_num: shipmentNo },
        });

        const data = res.data?.[0];

        if (!data || (Array.isArray(data) && data.length === 0)) {
          message.warning("No data found for this shipment number.");
        } else {
          const firstDataEntry = Array.isArray(data) ? data[0] : data;
          const mergedData = { ...firstDataEntry.asn_data, ...firstDataEntry.po_detail };

          console.log("Fetched and Merged Data:", mergedData);

          form.setFieldsValue({
            receiptGRR: mergedData.vsc || "",
            receiptDate: mergedData.po_date ? dayjs(mergedData.po_date) : null,
            shippedDate: mergedData.challan_date ? dayjs(mergedData.challan_date) : null,
            receivedBy: mergedData.po_buyer_name || "",
            supplier: mergedData.vendor_name || "",
            packingSlips: mergedData.shipment_num || "",
            vendorcode: mergedData.vendor_code || "",
            invoiceNo: mergedData.invoice_no || invoiceNo || "",
            invoiceDate: mergedData.invoice_date
              ? dayjs(mergedData.invoice_date)
              : invoiceDate
              ? dayjs(invoiceDate)
              : null,
            shipmentNo: mergedData.shipment_num || shipmentNo || "",
            invoiceAmount: mergedData.invoice_value || "",
            supplierInvoiceAmount: mergedData.base_val || "",
            gateEntryNumber: gateEntryNumber || "",
          });

          setItemRows(
            (mergedData.item_details || []).map((item, index) => ({
              ...item,
              key: index,
              srno: (index + 1).toString(),
            }))
          );

          setTaxRows(
            (mergedData.tax_details || []).map((tax, index) => ({
              ...tax,
              key: index,
            }))
          );

          setTaxRateRows(
            (mergedData.tax_rate_details || []).map((rate, index) => ({
              ...rate,
              key: index,
            }))
          );
        }
      } catch (error) {
        console.error("Error fetching shipment data:", error);
        message.error("Failed to load shipment data.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [shipmentNo, form]);

  const handleNext = () => setShowNextPage(true);
  const handleBack = () => setShowNextPage(false);

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      console.log("Submitted GRR:", { ...values, itemRows, taxRows, taxRateRows });
      message.success("GRR submitted successfully.");
    } catch {
      message.error("Please complete all required fields.");
    }
  };

  return (
    <div className="w-[85%] mx-auto mt-10 mb-20 bg-gray-100 p-10 rounded-xl">
      <Form form={form} layout="vertical">
        {!showNextPage ? (
          <>
            <h2 className="text-xl font-semibold mb-4">GRR - General Information</h2>
            <div className="grid grid-cols-3 gap-6">
              <Form.Item label="Receipt (GRR)" name="receiptGRR">
                <Input disabled />
              </Form.Item>
              <Form.Item label="Receipt Date" name="receiptDate">
                <DatePicker className="w-full" disabled />
              </Form.Item>
              <Form.Item label="Shipped Date" name="shippedDate">
                <DatePicker className="w-full" disabled />
              </Form.Item>
              <Form.Item label="Received By" name="receivedBy">
                <Input disabled />
              </Form.Item>
              <Form.Item label="Supplier" name="supplier">
                <Input disabled />
              </Form.Item>
              <Form.Item label="Packing Slips" name="packingSlips">
                <Input disabled />
              </Form.Item>
              <Form.Item label="Vendor Code" name="vendorcode">
                <Input disabled />
              </Form.Item>
              <Form.Item label="Invoice No" name="invoiceNo">
                <Input disabled />
              </Form.Item>
              <Form.Item label="Invoice Date" name="invoiceDate">
                <DatePicker className="w-full" disabled />
              </Form.Item>
              <Form.Item label="Shipment No" name="shipmentNo">
                <Input disabled />
              </Form.Item>
              <Form.Item label="Invoice Amount" name="invoiceAmount">
                <Input disabled />
              </Form.Item>
              <Form.Item label="Supplier Invoice Amount" name="supplierInvoiceAmount">
                <Input disabled />
              </Form.Item>
              <Form.Item label="Gate Entry No" name="gateEntryNumber">
                <Input disabled />
              </Form.Item>
              <Form.Item label="Security Entry Date" name="securityEntryDate">
                <DatePicker className="w-full" />
              </Form.Item>
              <Form.Item className="col-span-3" label="Comments" name="comments">
                <Input.TextArea rows={2} />
              </Form.Item>
            </div>

            <GRRTable1 dataSource={itemRows} setDataSource={setItemRows} />

            <div className="text-center mt-8">
              <Button type="primary" className="bg-[#1d998b]" onClick={handleNext}>
                Next
              </Button>
            </div>
          </>
        ) : (
          <>
            <GRRTable2 dataSource={taxRows} setDataSource={setTaxRows} />
            <GRRTable3 dataSource={taxRateRows} setDataSource={setTaxRateRows} />

            <h2 className="text-xl font-semibold mt-10 mb-4">Amount Summary</h2>
            <div className="grid grid-cols-3 gap-6">
              <Form.Item label="Amount" name="amount">
                <Input />
              </Form.Item>
              <Form.Item label="Tax Amount" name="taxAmount">
                <Input />
              </Form.Item>
              <Form.Item label="Total Amount" name="totalAmount">
                <Input />
              </Form.Item>
              <Form.Item label="Supplier Invoice Number" name="supplierInvoiceNumber">
                <Input />
              </Form.Item>
              <Form.Item label="Supplier Invoice Date" name="supplierInvoiceDate">
                <DatePicker className="w-full" />
              </Form.Item>
              <Form.Item
                label="Confirm Taxes *"
                name="confirmTaxes"
                valuePropName="checked"
                rules={[
                  {
                    validator: (_, value) =>
                      value ? Promise.resolve() : Promise.reject("Please confirm taxes."),
                  },
                ]}
              >
                <Checkbox />
              </Form.Item>
            </div>

            <div className="text-center mt-10 space-x-4">
              <Button onClick={handleBack}>Back</Button>
              <Button type="primary" className="bg-[#1677ff]" onClick={handleSubmit}>
                Submit GRR
              </Button>
            </div>
          </>
        )}
      </Form>
    </div>
  );
};

export default GRR;
