from operator import or_
from flask import Flask, request, jsonify
from sqlalchemy import desc
import json
import pytz
from flask_cors import CORS
from config import Config
from datetime import datetime, timedelta
from auth import auth_bp
from flask_jwt_extended import JWTManager
from models import GateOutDetails, db, UserGate
from flask_jwt_extended import create_access_token

from flask import send_file
import pandas as pd
from io import BytesIO
import io
from sqlalchemy.orm import joinedload
from sqlalchemy import func



from models import Document, GateEntryDetails, MdrDetails, MdrMaster, OpenAsnData, TripStatus, db, get_ist_time, DockInOutDetails, DockInOutMaster

from sqlalchemy import or_, and_

app = Flask(__name__)
app.config.from_object(Config)
app.register_blueprint(auth_bp, url_prefix='/auth')
# CORS(app, resources={r"/api/*": {"origins": ["exp://localhost:8081"]}})
CORS(app)

db.init_app(app)
jwt = JWTManager(app)



def get_ist_time():
    return datetime.now(pytz.utc).astimezone(pytz.timezone('Asia/Kolkata'))




@app.route("/submit_loading", methods=["POST"])
def submit_loading():
    try:
        # Parse JSON data from the POST request
        data = request.get_json()

        # Extract required fields
        gate_entry_number = data.get("gate_entry_number")
        trip_id = data.get("trip_id")
        gate_entry_in_time = data.get("gate_entry_in_time")
        gate_entry_status = data.get("gate_entry_status")
        # gate_entry_user_name = data.get("gate_entry_user_name")

        # Validate the fields
        if not gate_entry_number or not trip_id or gate_entry_status or not gate_entry_in_time is None:
            return jsonify({"error": "Invalid input. All fields are required."}), 400

        # Fetch the document record
        document = Document.query.filter_by(Trip_id=trip_id).first()

        if not document:
            return jsonify({"error": "Document with the given Trip_id not found."}), 404

        # Update document table
        document.gate_entry_number = gate_entry_number
        document.gate_entry_status = gate_entry_status
        document.gate_entry_in_time = gate_entry_in_time
        # document.gate_entry_user_name = gate_entry_user_name
        db.session.commit()

        # Check if a TripStatus entry already exists for this trip_id and location
        existing_trip_status = TripStatus.query.filter_by(trip_id=trip_id, location="Gate Entry"+gate_entry_status).first()

        if existing_trip_status:
            # Update the existing entry's time and other fields as needed
            existing_trip_status.time = get_ist_time()  # Update the timestamp
            db.session.commit()
        else:
            # Prepare data for a new TripStatus entry
            vehicle_number = document.vehicle_number
            driver_mobile_number = document.driver_mobile_number
            driver_license_number = document.driver_license_number

            # Create a new TripStatus entry
            new_trip_status = TripStatus(
                trip_id=trip_id,
                vehicle_number=vehicle_number,
                driver_mobile_number=driver_mobile_number,
                driver_license_number=driver_license_number,
                location="Gate Entry"+gate_entry_status,
                time=get_ist_time()  # Set the current timestamp
            )

            # Add the new entry to the session and commit to the database
            db.session.add(new_trip_status)
            db.session.commit()

        # Respond with success
        return jsonify({
            "message": "Loading entry submitted successfully.",
            "data": {
                "gate_entry_number": gate_entry_number,
                "trip_id": trip_id,
                "gate_entry_status": gate_entry_status,
            }
        }), 200

    except Exception as e:
        # Handle unexpected errors
        print(str(e))
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500
    
@app.route("/submit_gate_out", methods=["POST"])
def submit_gateout():
    print(">>> This is the T gate out API <<<")
    try:
        # Parse JSON data from the POST request
        data = request.get_json()

        # Extract required fields
        gate_entry_number = data.get("gate_entry_number")
        trip_id = data.get("trip_id")       
        gate_out_time = data.get("gate_out_time")
        gate_entry_status = data.get("gate_entry_status")
        gate_out_remarks = data.get("gate_out_remarks")
        # gate_out_user_name = data.get("gate_out_user_name")

        # Validate the fields
        if not gate_entry_number or not trip_id or gate_entry_status or not gate_out_time is None:
            return jsonify({"error": "Invalid input. All fields are required."}), 400

        # Fetch the document record
        document = Document.query.filter_by(Trip_id=trip_id).first()

        if not document:
            return jsonify({"error": "Document with the given Trip_id not found."}), 404

        # Update document table
        document.gate_entry_number = gate_entry_number
        document.gate_entry_status = gate_entry_status
        document.gate_out_time = gate_out_time
        document.gate_out_remarks = gate_out_remarks
        # document.gate_out_user_name = gate_out_user_name
        db.session.commit()

        # Check if a TripStatus entry already exists for this trip_id and location
        existing_trip_status = TripStatus.query.filter_by(trip_id=trip_id, location="Gate Out"+gate_entry_status).first()

        if existing_trip_status:
            # Update the existing entry's time and other fields as needed
            existing_trip_status.time = get_ist_time()  # Update the timestamp
            db.session.commit()
        else:
            # Prepare data for a new TripStatus entry
            vehicle_number = document.vehicle_number
            driver_mobile_number = document.driver_mobile_number
            driver_license_number = document.driver_license_number

            # Create a new TripStatus entry
            new_trip_status = TripStatus(
                trip_id=trip_id,
                vehicle_number=vehicle_number,
                driver_mobile_number=driver_mobile_number,
                driver_license_number=driver_license_number,
                location="Gate Out"+gate_entry_status,
                time=get_ist_time()  # Set the current timestamp
            )

            # Add the new entry to the session and commit to the database
            db.session.add(new_trip_status)
            db.session.commit()

        # Respond with success
        return jsonify({
            "message": "Gate Out submitted successfully.",
            "data": {
                "gate_entry_number": gate_entry_number,
                "trip_id": trip_id,
                "gate_entry_status": gate_entry_status,
                "gate_out_time": gate_out_time,
                "gate_out_remarks": gate_out_remarks,
            }
        }), 200

    except Exception as e:
        # Handle unexpected errors
        print(str(e))
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500

@app.route("/submit_invoice", methods=['POST'])
def submit_invoice():
    try:
        data = request.get_json()

        # Extract data from request
        gate_entry_number = data.get("gate_entry_number")
        shipment_number = data.get("shipment_number")
        invoice_number = data.get("invoice_number")
        vendor_code = data.get("vendor_code")
        vendor_name = data.get("vendor_name")
        invoice_date = data.get("invoice_date")

        # Validate required fields
        if not gate_entry_number or not shipment_number:
            return jsonify({"error": "gate_entry_number and shipment_number are required"}), 400

        # Check if the gate_entry_number exists in the Document table
        document = Document.query.filter_by(gate_entry_number=gate_entry_number).first()

        if not document:
            return jsonify({"error": "No document found with the provided gate_entry_number"}), 404

        # Create new GateEntryDetails record
        gate_entry = GateEntryDetails(
            gate_entry_number=gate_entry_number,
            shipment_number=shipment_number,
            invoice_number=invoice_number,
            vendor_code=vendor_code,
            vendor_name=vendor_name,
            invoice_date=invoice_date,
            document_trip_id=document.Trip_id  # Linking to the Document
        )

        # Add to session and commit to DB
        db.session.add(gate_entry)
        db.session.commit()

        return jsonify({"message": "Invoice details submitted successfully", "gate_entry_id": gate_entry.id}), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
    
@app.route("/submit_gate_out_invoice", methods=['POST'])
def submit_gateout_invoice():
    try:
        data = request.get_json()

        # Extract data from request
        gate_entry_number = data.get("gate_entry_number")
        invoice_number = data.get("invoice_number")
        out_invoice_date = data.get("out_invoice_date")
        
        print(gate_entry_number,invoice_number,out_invoice_date)
        # Validate required fields
        if not gate_entry_number or not invoice_number:
            return jsonify({"error": "gate_entry_number and shipment_number are required"}), 400

        # Check if the gate_entry_number exists in the Document table
        document = Document.query.filter_by(gate_entry_number=gate_entry_number).first()

        if not document:
            return jsonify({"error": "No document found with the provided gate_entry_number"}), 404

        # Create new GateEntryDetails record
        gate_out = GateOutDetails(
            gate_entry_number=gate_entry_number,
            invoice_number=invoice_number,
            out_invoice_date=out_invoice_date,
            document_trip_id=document.Trip_id  # Linking to the Document
        )

        # Add to session and commit to DB
        db.session.add(gate_out)
        db.session.commit()

        return jsonify({"message": "Invoice details submitted successfully", "gate_entry_id": gate_out.id}), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500
    

@app.route('/get_document', methods=['GET'])
def get_document():
    # Get vehicle_number from query parameter
    vehicle_number = request.args.get('vehicle_number').upper()
 
    if not vehicle_number:
        return jsonify({"error": "vehicle_number is required"}), 400
 
    # Query the Document table for the latest record related to the vehicle_number
    latest_document = (Document.query
                       .filter(Document.vehicle_number == vehicle_number)
                       .order_by(Document.timestamp.desc())
                       .first())

    if not latest_document:
        return jsonify({"error": "No document found for the given vehicle_number"}), 404

    # Check if gate_entry_number is null or empty
    if latest_document.gate_entry_number:
        return jsonify({"error": "Gate entry already done for this document"}), 400
   
    driver_data = json.loads(latest_document.extracted_text_driver)  # Parse the JSON string into a dictionary
    driver_name = driver_data.get('name')  # Extract the driver_name
    dl_number = driver_data.get('dl_number')  # Extract the driver_name
    driver_data = json.loads(latest_document.extracted_text_vehicle)  # Parse the JSON string into a dictionary
    puc_status = latest_document.is_puc_valid
    gate_entry_number = latest_document.gate_entry_number

    if puc_status == 'true':
        puc_status_display = "Ok"
    else:
        puc_status_display = "Not Ok"
   
    # Convert the result to a dictionary for JSON response
    document_data = {
        "trip_id":latest_document.Trip_id,
        "driver_mobile_number": latest_document.driver_mobile_number,
        "vehicle_number": latest_document.vehicle_number,
        "num_of_people": latest_document.num_of_people,
        "transporter_name": latest_document.transporter_name,
        "other_transporter_name": latest_document.other_transporter_name,
        "driver_name": driver_name,
        "vehicle_type":latest_document.vehicle_type,
        "loading_unloading":latest_document.loading_or_unloading,
        "puc_status": puc_status_display,
        "dl_number": dl_number,
        "gate_entry_number": gate_entry_number,
    }
 
    return jsonify({'data':document_data})

@app.route('/get_all_shipments', methods=['GET'])
def get_all_shipments():
    try:
        # Fetch distinct shipment numbers from the table
        shipments = db.session.query(OpenAsnData.shipment_num).distinct().all()

        # Flatten the list of tuples to a list of strings
        shipment_list = [s[0] for s in shipments if s[0] is not None]

        return jsonify({
            "shipment_numbers": shipment_list,
            "count": len(shipment_list)
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

from sqlalchemy import and_, not_, or_

from datetime import datetime, timedelta
from sqlalchemy import and_

from datetime import datetime, timedelta
from sqlalchemy import and_
import pytz

from datetime import datetime, timedelta
from sqlalchemy import and_
import pytz

@app.route('/check_invoice', methods=['GET'])
def check_invoice():
    try:
        invoice_number = request.args.get('invoice_number', '').strip()

        if not invoice_number:
            return jsonify({"error": "invoice_number is required"}), 400

        # Step 1: Check if already in GateEntryDetails
        exists_in_gate = db.session.query(GateEntryDetails).filter(
            GateEntryDetails.shipment_number.ilike(f"%{invoice_number}%")
        ).first()

        if not exists_in_gate:
            record = OpenAsnData.query.filter(
                and_(
                    OpenAsnData.shipment_num.ilike(f"%{invoice_number}%"),
                    OpenAsnData.is_used == False
                )
            ).first()

            if record and record.challan_date:
                ist = pytz.timezone("Asia/Kolkata")

                # --- Make sure challan_date is timezone-aware ---
                challan_date = record.challan_date
                if challan_date.tzinfo is None:
                    challan_date = ist.localize(challan_date)

                # --- Get current IST time ---
                current_time = datetime.now(ist)

                # --- Compute total difference ---
                time_diff = current_time - challan_date
                diff_minutes = time_diff.total_seconds() / 60

                # --- Condition: more than 35 minutes difference (any day) ---
                if diff_minutes >= 35:
                    return jsonify({
                        "exists": True,
                        "data": record.to_dict(),
                        # "debug": {
                        #     "current_time": current_time.strftime("%Y-%m-%d %H:%M:%S"),
                        #     "challan_date": challan_date.strftime("%Y-%m-%d %H:%M:%S"),
                        #     "difference_minutes": round(diff_minutes, 2)
                        # }
                    }), 200
                else:
                    return jsonify({
                        "exists": False,
                        "message": f"Challan date is less than 35 minutes old ({int(diff_minutes)} mins)",
                        # "debug": {
                        #     "current_time": current_time.strftime("%Y-%m-%d %H:%M:%S"),
                        #     "challan_date": challan_date.strftime("%Y-%m-%d %H:%M:%S"),
                        #     "difference_minutes": round(diff_minutes, 2)
                        # }
                    }), 400

        # Either invoice not found or already used
        return jsonify({
            "exists": False,
            "message": "Invoice not found or already exists in gate entry"
        }), 404

    except Exception as e:
        return jsonify({"error": str(e)}), 500



    

@app.route('/check_invoice_gateentry', methods=['GET'])
def check_invoice_gateentry():
    try:
        invoice_number = request.args.get('invoice_number', '').strip()
        if not invoice_number:
            return jsonify({"error": "invoice_number is required"}), 400

        # ✅ Always check in OpenAsnData, regardless of gate entry
        record = OpenAsnData.query.filter(
            OpenAsnData.shipment_num == invoice_number
        ).first()

        if record:
            return jsonify({
                "exists": True,
                "data": {
                    "organization_name": record.organization_name,
                    "location_code": record.location_code,
                    "vendor_code": record.vendor_code,
                    "vendor_name": record.vendor_name,
                    "po_num": record.po_num,
                    "line_num": record.line_num,
                    "po_dt": record.po_dt,
                    "po_buyer_name": record.po_buyer_name,
                    "po_buyer_email": record.po_buyer_email,
                    "shipment_num": record.shipment_num,
                    "challan_date": record.challan_date,
                    "pending_days": record.pending_days,
                    "item": record.item,
                    "item_desc": record.item_desc,
                    "asn_qty": record.asn_qty,
                    "base_val": record.base_val,
                    "item_type": record.item_type,
                    "default_subinventory": record.default_subinventory,
                    "hazard_class": record.hazard_class,
                    "tax_percent": record.tax_percent,
                    "tax_category_name": record.tax_category_name,
                    "invoice_value": record.invoice_value
                }
            }), 200

        return jsonify({
            "exists": False,
            "message": "Shipment not found in openasn_data"
        }), 404

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# @app.route('/gateout_invoices', methods=['POST'])
# def gateout_invoices():
#     try:
#         data = request.json
#         trip_id = data.get("trip_id")
#         gate_entry_no = data.get("gate_entry_number")
#         invoices_count = data.get("invoices") 
#         loading_unloading = data.get("loading_unloading", "").strip().lower()

#         if not all([trip_id, gate_entry_no, loading_unloading]):
#             return jsonify({"error": "Missing required fields"}), 400
        
#         if loading_unloading not in ["loading", "unloading"]:
#             return jsonify({"error": "Invalid loading_unloading value"}), 400
        
#         # ✅ If Loading: No need to validate
#         if loading_unloading.lower() == "loading":
#             return jsonify({"message": "No validation needed for Loading"}), 200

#         # 🔍 If Unloading: Fetch expected total_invoices
#         record = DockInOutMaster.query.filter_by(
#             trip_id=trip_id,
#             gate_entry_number=gate_entry_no
#         ).first()

#         if not record:
#             return jsonify({"error": "Trip not found for validation"}), 404

#         expected_invoices = record.total_invoices or 0

#         if int(invoices_count) == expected_invoices:
#             return jsonify({
#                 "message": "Invoice count matched",
#                 "expected": expected_invoices,
#                 "received": invoices_count
#             }), 200
#         else:
#             return jsonify({
#                 "error": "Invoice count mismatch",
#                 "expected": expected_invoices,
#                 "received": invoices_count
#             }), 400

#     except Exception as e:
#         return jsonify({"error": str(e)}), 500



@app.route('/get_gate_out_document', methods=['GET'])
def get_gate_out_document():
    # Get vehicle_number from query parameter
    gate_entry_number = request.args.get('gate_entry_number')
    # gate_entry_status = request.args.get('gate_entry_status')
 
    if not gate_entry_number:
        return jsonify({"error": "gate_entry_number is required"}), 400
 
    # Query the Document table for the latest record related to the vehicle_number
    latest_document = (Document.query
                   .filter(Document.gate_entry_number == gate_entry_number, 
                           Document.gate_entry_status.ilike("In Process"))  # Correct syntax for filtering
                   .order_by(Document.timestamp.desc())  # Order by timestamp (latest first)
                   .first())
 
    if not latest_document:
        return jsonify({"error": "No document found for the given gate_entry_number"}), 404
   
    driver_data = json.loads(latest_document.extracted_text_driver)  # Parse the JSON string into a dictionary
    driver_name = driver_data.get('name')  # Extract the driver_name
    dl_number = driver_data.get('dl_number')  # Extract the driver_name
    driver_data = json.loads(latest_document.extracted_text_vehicle)  # Parse the JSON string into a dictionary
    puc_status = latest_document.is_puc_valid
    gate_entry_number = latest_document.gate_entry_number
    gate_entry_status = latest_document.gate_entry_status
    gate_entry_in_time = latest_document.gate_entry_in_time
    total_invoices = latest_document.total_invoices

    if puc_status == 'true':
        puc_status_display = "Ok"
    else:
        puc_status_display = "Not Ok"
   
    # Convert the result to a dictionary for JSON response
    document_data = {
        "trip_id":latest_document.Trip_id,
        "driver_mobile_number": latest_document.driver_mobile_number,
        "vehicle_number": latest_document.vehicle_number,
        "num_of_people": latest_document.num_of_people,
        "transporter_name": latest_document.transporter_name,
        "other_transporter_name": latest_document.other_transporter_name,
        "driver_name": driver_name,
        "vehicle_type":latest_document.vehicle_type,
        "loading_unloading":latest_document.loading_or_unloading,
        "puc_status": puc_status_display,
        "dl_number": dl_number,
        "gate_entry_number": gate_entry_number,
        "gate_entry_status": gate_entry_status,
        "gate_entry_in_time": gate_entry_in_time,
        "invoices": total_invoices,
    }
 
    return jsonify({'data':document_data})



@app.route("/", methods=["GET"])
def new():
    return jsonify({'data': "hello world"})


@app.route("/cc", methods=["GET"])
def ln():
    return jsonify({"msg": "Register GET route hit"})




with app.app_context():
    db.create_all()

@app.route("/get_gate_out_details", methods=["GET"])
def get_gate_out_details():
    try:
        gate_out_details = Document.query.with_entities(
            Document.Trip_id,
            Document.gate_entry_number,
            Document.vehicle_number,
            Document.gate_entry_status,

        ).filter(
            Document.gate_entry_status.isnot(None),
            Document.gate_entry_status.ilike('In Process'),
            # Document.gate_exit_status.ilike('EXITED')
            or_(
                    Document.gate_exit_status.is_(None),       
                    Document.gate_exit_status == "",           
                    Document.gate_exit_status != "EXITED"     
                )
        ).all()
        # if not gate_out_details:
        #     return jsonify({
        #         "error": True,
        #         "message": "No gate entries found, come back again"
        #     }), 404
        
        gate_out_list = [{
            "trip_id": gate_out.Trip_id,
            "gate_entry_number": gate_out.gate_entry_number,
            "vehicle_number": gate_out.vehicle_number,
            "gate_entry_status": gate_out.gate_entry_status
        } for gate_out in gate_out_details]

        return jsonify({
            "error": False,
            "gate_out": gate_out_list,
        }), 200
    
    except Exception as e:
        app.logger.error(f"Error fetching gate_entry: {str(e)}")
        return jsonify({
            "error": True,
            "message": "An unexpected error occurred",
            "details": str(e)
        }), 500
    

# @app.route("/submit_gate_out", methods=["POST"])
# def submit_gate_out():
#     print(">>> This is the FIRST gate out API <<<")
#     try:
#         # Parse JSON data from the POST request
#         data = request.get_json()

#         # Extract required fields
#         gate_entry_number = data.get("gate_entry_number")
#         trip_id = data.get("trip_id")
#         gate_entry_out_time = data.get("gate_entry_out_time")
#         gate_entry_status = data.get("gate_entry_status")
#         gate_entry_remarks = data.get("gate_entry_remarks")

#         # Validate the fields
#         if not gate_entry_number or not trip_id or gate_entry_status or not gate_entry_out_time or gate_entry_remarks is None:
#             return jsonify({"error": "Invalid input. All fields are required."}), 400

#         # Fetch the document record
#         document = Document.query.filter_by(Trip_id=trip_id).first()

#         if not document:
#             return jsonify({"error": "Document with the given Trip_id not found."}), 404

#         # Update document table
#         document.gate_entry_number = gate_entry_number
#         document.gate_entry_status = gate_entry_status
#         document.gate_entry_out_time = gate_entry_out_time
#         document.gate_entry_remarks = gate_entry_remarks
#         db.session.commit()

#         # Check if a TripStatus entry already exists for this trip_id and location
#         existing_trip_status = TripStatus.query.filter_by(trip_id=trip_id, location="Gate Entry"+gate_entry_status).first()

#         if existing_trip_status:
#             # Update the existing entry's time and other fields as needed
#             existing_trip_status.time = get_ist_time()  # Update the timestamp
#             db.session.commit()
#         else:
#             # Prepare data for a new TripStatus entry
#             vehicle_number = document.vehicle_number
#             driver_mobile_number = document.driver_mobile_number
#             driver_license_number = document.driver_license_number

#             # Create a new TripStatus entry
#             new_trip_status = TripStatus(
#                 trip_id=trip_id,
#                 vehicle_number=vehicle_number,
#                 driver_mobile_number=driver_mobile_number,
#                 driver_license_number=driver_license_number,
#                 location="Gate Entry"+gate_entry_status,
#                 time=get_ist_time()  # Set the current timestamp
#             )

#             # Add the new entry to the session and commit to the database
#             db.session.add(new_trip_status)
#             db.session.commit()

#         # Respond with success
#         return jsonify({
#             "message": "gate out submitted successfully.",
#             "data": {
#                 "gate_entry_number": gate_entry_number,
#                 "trip_id": trip_id,
#                 "gate_entry_status": gate_entry_status,
#             }
#         }), 200

#     except Exception as e:
#         # Handle unexpected errors
#         print(str(e))
#         return jsonify({"error": f"An error occurred: {str(e)}"}), 500
    

# Function to safely parse date strings
def parse_date(date_str):
    if date_str:
        try:
            return datetime.strptime(date_str, "%Y-%m-%d").date()  # Converts string to date
        except ValueError as e:
            print("Date Parsing Error:", e)
            return None
    return None

# @app.route("/submit_mdr", methods=["POST"])
# def submit_mdr():
#     try:
#         data = request.json

#         if not data:
#             return jsonify({"error": "No data received"}), 400

#         # Extracting Values
#         invoice_number = data.get("invoice_number")
#         mdr_number = data.get("mdr_number")
#         invoice_date = parse_date(data.get("invoice_date", ""))
#         mdr_date = parse_date(data.get("mdr_date", ""))

#         if not mdr_number or not invoice_number:
#             return jsonify({"error": "mdr number and invoice number required"}), 404
        

#         # Debugging: Check Types
#         print("Type of invoice_date:", type(invoice_date))
#         print("Type of mdr_date:", type(mdr_date))

#         # Check if MdrMaster entry already exists
#         existing_mdr = MdrMaster.query.filter_by(invoice_number=invoice_number).first()

#         if existing_mdr:
#             # Update existing record
#             existing_mdr.mdr_number = mdr_number
#             existing_mdr.invoice_date = invoice_date
#             existing_mdr.mdr_date = mdr_date
#             existing_mdr.vendor_code = data.get("vendor_code")
#             existing_mdr.vendor_name = data.get("vendor_name")
#             existing_mdr.transporter_name = data.get("transporter_name")
#             existing_mdr.vehicle_number = data.get("vehicle_number")
#             existing_mdr.mdr_raised_as = data.get("mdr_raised_as")
#             existing_mdr.grr_mtn_sticker_number = data.get("grr_mtn_sticker_number")
#             existing_mdr.lr_field = data.get("lr_field")
#             existing_mdr.grr_number = data.get("grr_number")
#             existing_mdr.prepared_by = data.get("prepared_by")
#             existing_mdr.mdr_remarks_1 = data.get("mdr_remarks_1")
#             existing_mdr.mdr_remarks_2 = data.get("mdr_remarks_2")
#             existing_mdr.unloading_location=data.get("unloading_location"),
#             existing_mdr.email_id_cc = data.get("email_id_cc")
#             existing_mdr.email_id_to = data.get("email_id_to")

#         else:
#             # Create new MdrMaster entry
#             new_mdr = MdrMaster(
#                 invoice_number=invoice_number,
#                 invoice_date=invoice_date,
#                 mdr_number=mdr_number,
#                 mdr_date=mdr_date,
#                 vendor_code=data.get("vendor_code"),
#                 vendor_name=data.get("vendor_name"),
#                 transporter_name=data.get("transporter_name"),
#                 vehicle_number=data.get("vehicle_number"),
#                 mdr_raised_as=data.get("mdr_raised_as"),
#                 grr_mtn_sticker_number=data.get("grr_mtn_sticker_number"),
#                 lr_field=data.get("lr_field"),
#                 grr_number=data.get("grr_number"),
#                 prepared_by=data.get("prepared_by"),
#                 mdr_remarks_1=data.get("mdr_remarks_1"),
#                 mdr_remarks_2=data.get("mdr_remarks_2"),
#                 unloading_location=data.get("unloading_location"),
#                 email_id_cc=data.get("email_id_cc"),
#                 email_id_to=data.get("email_id_to"),
#             )
#             db.session.add(new_mdr)

#         # Commit MdrMaster before handling MdrDetails
#         db.session.commit()

#         # Handle MdrDetails (Delete existing and insert new)
#         MdrDetails.query.filter_by(mdr_number=mdr_number).delete()  # Delete old details

#         mdr_details_list = data.get("Table Data", [])  # Extract list of details

#         for detail in mdr_details_list:
#             new_detail = MdrDetails(
#                 mdr_number=mdr_number,
#                 invoice_number=invoice_number,
#                 invoice_date=invoice_date,
#                 item_code=detail.get("item_code"),
#                 item_description=detail.get("item_description"),
#                 item_quantity_actual=detail.get("item_quantity_actual"),
#                 quantity_as_per_challan=detail.get("quantity_as_per_challan"),
#                 excess_shortfall_quantity=detail.get("excess_shortfall_quantity"),
#                 number_of_boxes_lr=detail.get("no_of_boxes"),
#                 number_of_boxes_lr_recieved=detail.get("recieved"),
#             )
#             db.session.add(new_detail)

#         # Commit all changes
#         db.session.commit()

#         return jsonify({"message": "MDR record processed successfully", "mdr_number": mdr_number}), 201

#     except Exception as e:
#         db.session.rollback()  # Rollback in case of error
#         print("Error:", str(e))
#         return jsonify({"error": str(e)}), 500    
    

@app.route("/get_unloading_documents", methods=["GET"])
def get_unloading_documents():
    try:
        # Query the Document table for specific columns and filter by the criteria
        unloading_documents = Document.query.with_entities(
            Document.vehicle_number, 
            Document.gate_entry_number, 
            Document.transporter_name, 
            Document.loading_or_unloading, 
            Document.Trip_id,
            Document.gate_exit_status,
            Document.timestamp,
            Document.total_invoices,
            Document.vehicle_type,
            Document.driver_mobile_number
        ).filter(
            Document.gate_exit_status.is_(None),  # ✅ Correct way to check NULL
            # Document.loading_or_unloading.ilike("Unloading"),  # ✅ Case-insensitive match
            # Document.loading_or_unloading.ilike("Loading"),  # ✅ Case-insensitive match
        ).all()



        # Check if any records are found
        if not unloading_documents:
            return jsonify({
                "error": True,
                "message": "No documents found with the given criteria"
            }), 404

        # Convert the result to a list of dictionaries with the required columns
        documents_list = [{
            "vehicleNumber": doc.vehicle_number,
            "gateEntryNumber": doc.gate_entry_number,
            "transporterName": doc.transporter_name,
            "loadingUnloading": doc.loading_or_unloading,
            "tripId": doc.Trip_id,
            "gateExitStatus": doc.gate_exit_status,
            "timeStamp": doc.timestamp,
            "total_invoices": doc.total_invoices,
            "vehicleType": doc.vehicle_type,
            "driverMobileNumber": doc.driver_mobile_number,
        } for doc in unloading_documents]

        # Return the list of documents as JSON
        return jsonify({
            "error": False,
            "documents": documents_list
        }), 200

    except Exception as e:
        app.logger.error(f"Error fetching documents: {str(e)}")
        return jsonify({
            "error": True,
            "message": "An unexpected error occurred",
            "details": str(e)
        }), 500


@app.route("/get_dock_in_out_details", methods=["GET"])
def get_dock_in_out_details():
    try:
        dock_in_out_details = DockInOutDetails.query.with_entities(
            DockInOutDetails.vehicle_number,
            DockInOutDetails.trip_id,
            DockInOutDetails.docked_location,
            DockInOutDetails.start_time,
            DockInOutDetails.end_time,
            DockInOutDetails.docked_duration,
            DockInOutDetails.dock_location_invoice,
            DockInOutDetails.material_category,

        ).filter(
            DockInOutDetails.trip_id.in_(
                Document.query.with_entities(Document.Trip_id)
                .filter(
                    Document.gate_exit_status.is_(None)
                    # Document.loading_or_unloading.ilike("Unloading")
                ).subquery()
            )
        ).all()

        if not dock_in_out_details:
            return jsonify({
                "error": False,
                "dockInOutDetails": []
            }), 200


        # Convert time fields to strings
        dock_in_out_details_list = [{
            "vehicleNumber": dock.vehicle_number,
            "tripId": dock.trip_id,
            "dockedLocation": dock.docked_location,
            "startTime": dock.start_time.strftime("%H:%M:%S %d-%m-%Y") if dock.start_time else None,  # ✅ Convert time to string
            "endTime": dock.end_time.strftime("%H:%M:%S %d-%m-%Y") if dock.end_time else None,  # ✅ Convert time to string
            # "duration": dock.docked_duration.strftime("%H:%M:%S") if dock.docked_duration else None,
            "duration": dock.docked_duration,
            "docked_invoices": dock.dock_location_invoice,
            "materialCategory": dock.material_category,
        } for dock in dock_in_out_details]

        return jsonify({
            "error": False,
            "dockInOutDetails": dock_in_out_details_list
        }), 200

    except Exception as e:
        app.logger.error(f"Error fetching documents: {str(e)}")
        return jsonify({
            "error": True,
            "message": "An unexpected error occurred",
            "details": str(e)
        }), 500

@app.route('/submit_dock_out', methods=['POST'])
def submit_dock_out():
    try:
        data = request.json
        # print("Keys received:", list(data.keys()))
        # print("This is out"+str(data))

        if not data:
            return jsonify({"error": "No data received"}), 400

        # Extract values from request data
        trip_id = data.get("tripId")
        gate_entry_number = data.get("gateEntryNo")
        vehicle_number = data.get("vehicleNo")
        docked_location = data.get("dockedInvoice")
        end_time_str = data.get("endTime")  # Expecting format: "HH:MM:SS"
        docked_duration = data.get("duration")
        remarks = data.get("remarks")
        try:
            total_invoices = int(data.get("textbox") or 0)
        except ValueError:
            total_invoices = 0
        user_dockout = data.get("userDockOut")  # ✅ new field from frontend
        loading_unloading = data.get("loadingUnloading")


        # Validate required fields
        if not trip_id:
            return jsonify({"error": "Trip ID is required"}), 400
        if not docked_location:
            return jsonify({"error": "Docked location is required"}), 400
        if not end_time_str:
            return jsonify({"error": "End time is required"}), 400
        
        # Step 0: Validate if vehicle already exited
        doc_entry = Document.query.filter_by(Trip_id=trip_id).first()
        if doc_entry and doc_entry.gate_exit_status == 'EXITED':
            return jsonify({
                "error": "Vehicle already exited from plant",
                "trip_id": trip_id,
                "vehicle_number": vehicle_number
            }), 400


        # Convert end_time to datetime.time
        end_time = datetime.strptime(end_time_str.strip(), "%H:%M:%S %d-%m-%Y") if end_time_str else None

        # Step 1: Check if `DockInOutMaster` entry exists
        master_entry = DockInOutMaster.query.filter(
            and_(
                DockInOutMaster.trip_id == trip_id,
                DockInOutMaster.vehicle_number == vehicle_number
            )
        ).first()

        if not master_entry:
            return jsonify({'error': 'No dock-in record found for the trip id in master', 'trip_id': trip_id, 'vehicle_number': vehicle_number}), 400

        # Step 2: Check if `DockInOutDetails` entry exists
        detail_entry = DockInOutDetails.query.filter_by(
            trip_id=trip_id,
            docked_location=docked_location
        ).first()

        if not detail_entry:
            return jsonify({'error': 'No dock-in details found for the given trip_id and docked location', 'trip_id': trip_id, 'docked_location': docked_location}), 400

        if not detail_entry.start_time:
            return jsonify({'error': 'Dock-in time not found. Please dock-in first before dock-out.'}), 400
        
        if detail_entry.gate_entry_number != gate_entry_number or master_entry.gate_entry_number != gate_entry_number:
            return jsonify({
                "error": "Gate Entry Number mismatch between Master and Details table",
                "expected_gate_entry_number": master_entry.gate_entry_number,
                "provided_gate_entry_number": gate_entry_number
            }), 400

        # Step 3: Update the `end_time`, `docked_duration`, and `remarks`
        detail_entry.end_time = end_time
        detail_entry.docked_duration = docked_duration
        detail_entry.remarks = remarks
        detail_entry.user_dockout = user_dockout  # ✅ save user who did dock-out

        # if loading_unloading == "Loading":
        if not detail_entry.dock_location_invoice or int(detail_entry.dock_location_invoice) == 0:
                total_invoices_to_add = int(total_invoices) if total_invoices else 0
                detail_entry.dock_location_invoice = str(total_invoices_to_add)

                # Update master_entry total_invoices robustly
                current_master_total = int(master_entry.total_invoices or 0)
                # print(current_master_total)
                current_doc_total = int(doc_entry.total_invoices or 0)
                master_entry.total_invoices = current_doc_total + total_invoices_to_add

                # Update document total_invoices
                doc_entry.total_invoices = current_doc_total + total_invoices_to_add



        db.session.commit()

        # # Step 4: Update Document table if necessary
        existing_entry = Document.query.filter_by(Trip_id=trip_id).first()

        if existing_entry:
            updated = False

            if not existing_entry.gate_entry_number:
                existing_entry.gate_entry_number = gate_entry_number
                updated = True

            if not existing_entry.total_invoices:
                existing_entry.total_invoices = total_invoices
                updated = True

            if updated:
                db.session.commit()

        # Step 5: Insert or update TripStatus for 'GATE OUT'
        latest_document = Document.query.filter_by(Trip_id=trip_id).first()
        if not latest_document:
            return jsonify({"error": "No document found for the given trip_id"}), 404

        driver_data = json.loads(latest_document.extracted_text_driver)
        dl_number = driver_data.get('dl_number')
        driver_mobile_number = driver_data.get('driver_mobile_number')

        existing_status = TripStatus.query.filter_by(
            trip_id=trip_id,
            location=docked_location + " Out"
        ).first()

        if existing_status:
            existing_status.time = db.func.now()
            existing_status.remark = remarks
        else:
            new_status = TripStatus(
                trip_id=trip_id,
                vehicle_number=vehicle_number,
                location=docked_location + " Out",
                driver_license_number=dl_number if dl_number else "",
                driver_mobile_number=driver_mobile_number if driver_mobile_number else "",
                time=db.func.now(),
                remark=remarks
            )
            db.session.add(new_status)

        db.session.commit()

        return jsonify({
            "message": "Dock-out record processed successfully",
            "trip_id": trip_id
        }), 201

    except Exception as e:
        db.session.rollback()
        print("Error:", str(e))
        return jsonify({"error": str(e)}), 500


    

from sqlalchemy.exc import IntegrityError
import psycopg2

@app.route('/submit_dock_in', methods=['POST'])
def submit_dock_in():
    try:
        data = request.json

        if not data:
            return jsonify({"error": "No data received"}), 400

        # -----------------------------
        # Extract values from request
        # -----------------------------
        gate_entry_number = data.get("gateEntryNo")
        vehicle_number = data.get("vehicleNo")
        trip_id = data.get("tripId")
        transporter_name = data.get("transporterName")
        grr_status = data.get("grrStatus")

        total_invoices_raw = data.get("totalInvoices")
        try:
            total_invoices = int(total_invoices_raw) if total_invoices_raw is not None else 0
        except ValueError:
            return jsonify({"error": "Invalid value for totalInvoices"}), 400

        loading_unloading = data.get("loadingUnloading")
        material_category = data.get("materialCategory")

        docked_location = data.get("dockedInvoice")
        dock_location_invoice = data.get("textbox")
        start_time_str = data.get("startTime")
        docked_duration = data.get("duration")
        remarks = data.get("remarks")
        user_dockin = data.get("userDockIn")
        vehicle_type = data.get("vehicleType")

        start_time = (
            datetime.strptime(start_time_str.strip(), "%H:%M:%S %d-%m-%Y")
            if start_time_str else None
        )

        # -----------------------------
        # Step 0: Validate vehicle exit
        # -----------------------------
        doc_entry = Document.query.filter_by(Trip_id=trip_id).first()
        if doc_entry and doc_entry.gate_exit_status == 'EXITED':
            return jsonify({
                "error": "Vehicle already exited from plant",
                "trip_id": trip_id,
                "vehicle_number": vehicle_number
            }), 400

        # =====================================================
        # ✅ FIX 1: BLOCK reused gate_entry_number (NEW)
        # =====================================================
        existing_gate_entry = DockInOutMaster.query.filter_by(
            gate_entry_number=gate_entry_number
        ).first()

        if existing_gate_entry and existing_gate_entry.trip_id != trip_id:
            return jsonify({
                "error": "Gate entry number already used",
                "gate_entry_number": gate_entry_number
            }), 409

        # -----------------------------
        # Step 1: DockInOutMaster
        # (ONLY trip_id based lookup)
        # -----------------------------
        master_entry = DockInOutMaster.query.filter(
            DockInOutMaster.trip_id == trip_id   # ✅ FIX 2: removed OR condition
        ).first()

        if master_entry:
            master_entry.vehicle_number = vehicle_number
            master_entry.gate_entry_number = gate_entry_number
            master_entry.transporter_name = transporter_name
            master_entry.grr_status = grr_status
            master_entry.total_invoices = total_invoices
            master_entry.loading_unloading = loading_unloading
            master_entry.material_category = material_category
            master_entry.docked_location = docked_location
            master_entry.vehicle_type = vehicle_type
        else:
            master_entry = DockInOutMaster(
                gate_entry_number=gate_entry_number,
                trip_id=trip_id,
                vehicle_number=vehicle_number,
                transporter_name=transporter_name,
                grr_status=grr_status,
                total_invoices=total_invoices,
                loading_unloading=loading_unloading,
                material_category=material_category,
                docked_location=docked_location,
                vehicle_type=vehicle_type
            )
            db.session.add(master_entry)

        db.session.commit()

        # -----------------------------
        # Step 2: Update Document table
        # -----------------------------
        existing_entry = Document.query.filter_by(Trip_id=trip_id).first()
        if existing_entry:
            updated = False

            if not existing_entry.gate_entry_number:
                existing_entry.gate_entry_number = gate_entry_number
                updated = True

            if not existing_entry.total_invoices:
                existing_entry.total_invoices = total_invoices
                updated = True

            if updated:
                db.session.commit()

        # -----------------------------
        # Step 3: DockInOutDetails
        # -----------------------------
        detail_entry = DockInOutDetails.query.filter_by(
            trip_id=trip_id,
            docked_location=docked_location
        ).first()

        if detail_entry:
            detail_entry.gate_entry_number = gate_entry_number
            detail_entry.vehicle_number = vehicle_number
            detail_entry.dock_location_invoice = dock_location_invoice
            detail_entry.start_time = start_time
            detail_entry.end_time = None
            detail_entry.docked_duration = docked_duration
            detail_entry.remarks = remarks
            detail_entry.user_dockin = user_dockin
            detail_entry.material_category = material_category
        else:
            new_detail = DockInOutDetails(
                gate_entry_number=gate_entry_number,
                trip_id=trip_id,
                vehicle_number=vehicle_number,
                docked_location=docked_location,
                dock_location_invoice=dock_location_invoice,
                start_time=start_time,
                end_time=None,
                docked_duration=docked_duration,
                remarks=remarks,
                user_dockin=user_dockin,
                material_category=material_category
            )
            db.session.add(new_detail)

        # -----------------------------
        # Step 4: TripStatus (Dock In)
        # -----------------------------
        existing_status = TripStatus.query.filter_by(
            trip_id=trip_id,
            location=docked_location + " In"
        ).first()

        latest_document = Document.query.filter_by(Trip_id=trip_id).first()
        if not latest_document:
            return jsonify({"error": "No document found for the given trip_id"}), 404

        driver_data = json.loads(latest_document.extracted_text_driver or "{}")
        dl_number = driver_data.get("dl_number")
        driver_mobile_number = driver_data.get("driver_mobile_number")

        if existing_status:
            existing_status.time = db.func.now()
        else:
            new_status = TripStatus(
                trip_id=trip_id,
                vehicle_number=vehicle_number,
                location=docked_location + " In",
                driver_license_number=dl_number if dl_number else "",
                driver_mobile_number=driver_mobile_number if driver_mobile_number else "",
                time=db.func.now(),
                remark=remarks,
            )
            db.session.add(new_status)

        db.session.commit()

        return jsonify({
            "message": "Dock-in record processed successfully",
            "trip_id": trip_id,
            "gate_entry_number": gate_entry_number,
            "vehicle_number": vehicle_number
        }), 201

    except IntegrityError as e:
        db.session.rollback()
        if isinstance(e.orig, psycopg2.errors.UniqueViolation):
            return jsonify({
                "error": "Duplicate gate_entry_number. This gate entry number already exists."
            }), 409
        return jsonify({
            "error": "Database integrity error",
            "details": str(e)
        }), 500

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500




# @app.route('/submit_dock_in', methods=['POST'])
# def submit_dock_in():
#         data = request.json
#         print("Received data:", data)  # Debugging

#         return ""

# 

@app.route('/undo', methods=['POST'])
def undo():
    try:
        data = request.json
        print("Received undo request:", data) 
        
        trip_id = data.get("tripId", "").strip()  
        docked_location = data.get("dockedInvoice", "").strip()

        if not trip_id or not docked_location:
            return jsonify({"error": "Trip ID and Docked Location are required"}), 400

        # ------------------------------------------------------
        # Step 1: Find last dock detail
        # ------------------------------------------------------
        last_detail_entry = (
            DockInOutDetails.query
            .filter_by(trip_id=trip_id, docked_location=docked_location)
            .order_by(DockInOutDetails.id.desc())
            .first()
        )

        if not last_detail_entry:
            return jsonify({"error": "No transactions found"}), 404

        # ------------------------------------------------------
        # Fetch master & document
        # ------------------------------------------------------
        master_entry = DockInOutMaster.query.filter_by(trip_id=trip_id).first()
        document_entry = Document.query.filter_by(Trip_id=trip_id).first()

        # ------------------------------------------------------
        # Determine Loading / Unloading
        # ------------------------------------------------------
        loading_unloading = None
        if master_entry and master_entry.loading_unloading:
            loading_unloading = master_entry.loading_unloading.lower()
        elif document_entry and document_entry.loading_or_unloading:
            loading_unloading = document_entry.loading_or_unloading.lower()

        # ------------------------------------------------------
        # Detect what is being undone
        # ------------------------------------------------------
        is_undoing_dock_out = last_detail_entry.end_time is not None
        is_undoing_dock_in = (
            last_detail_entry.start_time is not None and
            last_detail_entry.end_time is None
        )

        # ------------------------------------------------------
        # Invoice count helper
        # ------------------------------------------------------
        invoice_count = 0
        if last_detail_entry.dock_location_invoice:
            try:
                invoice_count = int(last_detail_entry.dock_location_invoice)
            except ValueError:
                invoice_count = len(
                    last_detail_entry.dock_location_invoice.split(",")
                )

        # ------------------------------------------------------
        # Decide invoice subtraction (FINAL RULE)
        # ------------------------------------------------------
        should_subtract_invoice = False

        # ONLY LOADING → invoices applied at Dock-OUT
        if loading_unloading == "loading" and is_undoing_dock_out:
            should_subtract_invoice = True

        # ------------------------------------------------------
        # Apply invoice subtraction
        # ------------------------------------------------------
        if should_subtract_invoice and invoice_count:

            if master_entry:
                master_entry.total_invoices = max(
                    (master_entry.total_invoices or 0) - invoice_count, 0
                )

            if document_entry:
                document_entry.total_invoices = max(
                    (document_entry.total_invoices or 0) - invoice_count, 0
                )

        # ------------------------------------------------------
        # Undo Dock-Out
        # ------------------------------------------------------
        if is_undoing_dock_out:

            # LOADING → clear invoice details
            if loading_unloading == "loading":
                last_detail_entry.dock_location_invoice = None

            last_detail_entry.end_time = None
            last_detail_entry.duration = None

        # ------------------------------------------------------
        # Undo Dock-In
        # ------------------------------------------------------
        elif is_undoing_dock_in:
            last_detail_entry.dock_location_invoice = None
            db.session.delete(last_detail_entry)

            remaining_details = DockInOutDetails.query.filter(
                DockInOutDetails.trip_id == trip_id,
                DockInOutDetails.docked_location != docked_location
            ).first()

            if not remaining_details and master_entry:
                db.session.delete(master_entry)

        # ------------------------------------------------------
        # TripStatus cleanup (UNCHANGED)
        # ------------------------------------------------------
        location_in = docked_location + " In"
        location_out = docked_location + " Out"

        remaining_details = (
            DockInOutDetails.query
            .filter_by(trip_id=trip_id, docked_location=docked_location)
            .order_by(DockInOutDetails.id.desc())
            .all()
        )

        if not remaining_details:
            in_status = TripStatus.query.filter_by(
                trip_id=trip_id, location=location_in
            ).first()
            out_status = TripStatus.query.filter_by(
                trip_id=trip_id, location=location_out
            ).first()

            if in_status:
                db.session.delete(in_status)
            if out_status:
                db.session.delete(out_status)

        else:
            latest = remaining_details[0]

            if latest.start_time and latest.end_time:
                pass

            elif latest.start_time and not latest.end_time:
                out_status = TripStatus.query.filter_by(
                    trip_id=trip_id, location=location_out
                ).first()
                if out_status:
                    db.session.delete(out_status)

            else:
                in_status = TripStatus.query.filter_by(
                    trip_id=trip_id, location=location_in
                ).first()
                out_status = TripStatus.query.filter_by(
                    trip_id=trip_id, location=location_out
                ).first()

                if in_status:
                    db.session.delete(in_status)
                if out_status:
                    db.session.delete(out_status)

        db.session.commit()
        return jsonify({"message": "Undo action performed successfully"}), 200

    except Exception as e:
        db.session.rollback()
        print("Error:", str(e))
        return jsonify({"error": str(e)}), 500








# @app.route("/export_dock_data", methods=["GET"])
# def export_dock_data():
#     try:
#         from_date = request.args.get("from_date")
#         to_date = request.args.get("to_date")

#         if not from_date or not to_date:
#             return jsonify({"error": "Both from_date and to_date are required."}), 400

#         from_dt = datetime.strptime(from_date, "%Y-%m-%d").date()
#         to_dt = datetime.strptime(to_date, "%Y-%m-%d").date()

#         # Query with join
#         records = (
#             db.session.query(DockInOutMaster)
#             .join(DockInOutMaster.dock_details)
#             .options(joinedload(DockInOutMaster.dock_details))
#             .filter(
#                 func.DATE(DockInOutDetails.start_time) >= from_dt,
#                 func.DATE(DockInOutDetails.end_time) <= to_dt
#             )
#             .all()
#         )

#         if not records:
#             return jsonify({"error": "No data found for given date range"}), 404

#         data = []
#         for master in records:
#             for detail in master.dock_details:
#                 if detail.start_time and detail.end_time:
#                     if from_dt <= detail.start_time.date() <= to_dt and from_dt <= detail.end_time.date() <= to_dt:
#                         row = {
#                             "Gate Entry No.": master.gate_entry_number,
#                             "Trip ID": master.trip_id,
#                             "Vehicle No.": master.vehicle_number,
#                             "Transporter": master.transporter_name,
#                             "GRR Status": master.grr_status,
#                             "Total Invoices": master.total_invoices,
#                             "Loading/Unloading": master.loading_unloading,
#                             "Material Category": detail.material_category or master.material_category,
#                             "Docked Location": detail.docked_location,
#                             "Dock Location Invoice": detail.dock_location_invoice,
#                             "Start Time": detail.start_time.strftime("%Y-%m-%d %H:%M:%S") if detail.start_time else "",
#                             "End Time": detail.end_time.strftime("%Y-%m-%d %H:%M:%S") if detail.end_time else "",
#                             "Docked Duration": detail.docked_duration,
#                             "Remarks": detail.remarks,
#                             "User Dock-In": detail.user_dockin,
#                             "User Dock-Out": detail.user_dockout,
#                         }
#                         data.append(row)

#         if not data:
#             return jsonify({"error": "No detail records found for given date range"}), 404

#         df = pd.DataFrame(data)
#         output = BytesIO()
#         df.to_excel(output, index=False)
#         output.seek(0)

#         return send_file(
#             output,
#             download_name=f"Dock_Report_{from_date}_to_{to_date}.xlsx",
#             as_attachment=True,
#             mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
#         )

#     except Exception as e:
#         import traceback
#         traceback.print_exc()
#         return jsonify({"error": str(e)}), 500


@app.route("/export_dock_data", methods=["GET"])
def export_dock_data():
    try:
        from_date = request.args.get("from_date")
        to_date = request.args.get("to_date")

        if not from_date or not to_date:
            return jsonify({"error": "Both from_date and to_date are required."}), 400

        from_dt = datetime.strptime(from_date, "%Y-%m-%d").date()
        to_dt = datetime.strptime(to_date, "%Y-%m-%d").date()

        records = (
            db.session.query(DockInOutMaster)
            .join(DockInOutMaster.dock_details)
            .options(joinedload(DockInOutMaster.dock_details))
            .filter(
                or_(
                    func.DATE(DockInOutDetails.start_time).between(from_dt, to_dt),
                    func.DATE(DockInOutDetails.end_time).between(from_dt, to_dt)
                )
            )
            .all()
        )

        if not records:
            return jsonify({"error": "No data found for given date range"}), 404

        data = []
        for master in records:
            trip_statuses = (
                db.session.query(TripStatus)
                .filter(TripStatus.trip_id == master.trip_id)
                .all()
            )

            pravesh_entry_time = None
            pravesh_exit_time = None
            gate_entry_time = None
            gate_exit_time = None

            for ts in trip_statuses:
                if ts.location == "GATE ENTRY":
                    pravesh_entry_time = ts.time
                elif ts.location == "GATE EXIT":
                    pravesh_exit_time = ts.time
                elif ts.location == "Gate EntryIn Process":
                    gate_entry_time = ts.time
                elif ts.location == "Gate OutClose":
                    gate_exit_time = ts.time

            # ✅ Calculate total Pravesh vehicle duration
            total_pravesh_vehicle_duration = ""
            total_pravesh_vehicle_duration_minutes = ""

            if pravesh_entry_time and pravesh_exit_time:
                duration = pravesh_exit_time - pravesh_entry_time
                total_minutes = int(duration.total_seconds() // 60)
                hours = total_minutes // 60
                minutes = total_minutes % 60
                total_pravesh_vehicle_duration = f"{hours} hr {minutes} min"
                total_pravesh_vehicle_duration_minutes = total_minutes

            for detail in master.dock_details:
                if detail.start_time or detail.end_time:
                    start_date = detail.start_time.date() if detail.start_time else None
                    end_date = detail.end_time.date() if detail.end_time else None

                    if (
                        (start_date and from_dt <= start_date <= to_dt)
                        or (end_date and from_dt <= end_date <= to_dt)
                    ):
                        # ✅ Convert Dock Location Invoice to number safely
                        try:
                            dock_invoice_num = int(detail.dock_location_invoice)
                        except (ValueError, TypeError):
                            dock_invoice_num = 0

                        # ✅ Convert Docked Duration (e.g. "1h 20m") → minutes
                        dock_duration_minutes = 0
                        if detail.docked_duration:
                            import re
                            match = re.match(r"(?:(\d+)h)?\s*(?:(\d+)m)?", detail.docked_duration.strip())
                            if match:
                                h = int(match.group(1)) if match.group(1) else 0
                                m = int(match.group(2)) if match.group(2) else 0
                                dock_duration_minutes = h * 60 + m

                        row = {
                            "Gate Entry No.": master.gate_entry_number,
                            "Trip ID": master.trip_id,
                            "Vehicle No.": master.vehicle_number,
                            "Vehicle Type": master.vehicle_type,
                            "Transporter": master.transporter_name,
                            "GRR Status": master.grr_status,
                            "Total Invoices": master.total_invoices,
                            "Loading/Unloading": master.loading_unloading,
                            "Material Category": detail.material_category or master.material_category,
                            "Docked Location": detail.docked_location,
                            "Dock Location Invoice": dock_invoice_num,  # ✅ Numeric
                            "Start Time": detail.start_time.strftime("%Y-%m-%d %H:%M:%S") if detail.start_time else "",
                            "End Time": detail.end_time.strftime("%Y-%m-%d %H:%M:%S") if detail.end_time else "",
                            "Docked Duration": detail.docked_duration,
                            "Docked Duration (Minutes)": dock_duration_minutes,  # ✅ Added field
                            "Remarks": detail.remarks,
                            "User Dock-In": detail.user_dockin,
                            "User Dock-Out": detail.user_dockout,

                            # Extra fields from TripStatus
                            "Pravesh Entry Time": pravesh_entry_time.strftime("%Y-%m-%d %H:%M:%S") if pravesh_entry_time else "",
                            "Pravesh Exit Time": pravesh_exit_time.strftime("%Y-%m-%d %H:%M:%S") if pravesh_exit_time else "",
                            "Gate Entry Time": gate_entry_time.strftime("%Y-%m-%d %H:%M:%S") if gate_entry_time else "",
                            "Gate Exit Time": gate_exit_time.strftime("%Y-%m-%d %H:%M:%S") if gate_exit_time else "",
                            "Total Pravesh Vehicle Duration": total_pravesh_vehicle_duration,
                            "Total Pravesh Vehicle Duration (Minutes)": total_pravesh_vehicle_duration_minutes,
                        }
                        data.append(row)

        if not data:
            return jsonify({"error": "No detail records found for given date range"}), 404

        df = pd.DataFrame(data)
        output = BytesIO()
        df.to_excel(output, index=False)
        output.seek(0)

        return send_file(
            output,
            download_name=f"Dock_Report_{from_date}_to_{to_date}.xlsx",
            as_attachment=True,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500



    

@app.route("/get_gate_out_status", methods=["GET"])
def get_gate_out_status():
    try:
        # Get gate entry number from query parameter
        gate_entry_number = request.args.get("gate_entry_number")

        if not gate_entry_number:
            return jsonify({"error": True, "message": "Gate entry number is required"}), 400

        # Fetch document record by gate_entry_number
        document = Document.query.filter_by(gate_entry_number=gate_entry_number).first()

        if not document:
            return jsonify({"error": True, "message": "No record found for the given gate entry number"}), 404

        # Prepare response data
        response_data = {
            "tripId": document.Trip_id,
            "vehicleNumber": document.vehicle_number,
            "gateExitStatus": document.gate_exit_status,
            "loadingOrUnloading": document.loading_or_unloading,
            "vehicleStatus": document.gate_entry_status,
            "inDate": document.gate_entry_in_time,
            "outDate": document.gate_out_time
        }

        return jsonify({"error": False, "data": response_data}), 200

    except Exception as e:
        app.logger.error(f"Error fetching gate entry details: {str(e)}")
        return jsonify({"error": True, "message": "An unexpected error occurred", "details": str(e)}), 500

    



@app.route('/gateout_invoices', methods=['POST'])
def gateout_invoices():
    try:
        data = request.json
        trip_id = data.get("trip_id")
        gate_entry_no = data.get("gate_entry_number")
        invoices_count = data.get("invoices") 
        loading_unloading = data.get("loading_unloading", "").strip().lower()

        if not all([trip_id, gate_entry_no, loading_unloading]):
            return jsonify({"error": "Missing required fields"}), 400
        
        if loading_unloading not in ["loading", "unloading"]:
            return jsonify({"error": "Invalid loading_unloading value"}), 400
        
        # ✅ If Loading: No need to validate
        if loading_unloading.lower() == "loading":
            return jsonify({"message": "No validation needed for Loading"}), 200

        # 🔍 If Unloading: Fetch expected total_invoices
        record = DockInOutMaster.query.filter_by(
            trip_id=trip_id,
            gate_entry_number=gate_entry_no
        ).first()

        if not record:
            return jsonify({"error": "Trip not found for validation"}), 404

        expected_invoices = record.total_invoices or 0

        if int(invoices_count) == expected_invoices:
            return jsonify({
                "message": "Invoice count matched",
                "expected": expected_invoices,
                "received": invoices_count
            }), 200
        else:
            return jsonify({
                "error": "Invoice count mismatch",
                "expected": expected_invoices,
                "received": invoices_count
            }), 400

    except Exception as e:
        return jsonify({"error": str(e)}), 500

import json

@app.route("/api/gate-pass/by-vehicle/<vehicle_number>", methods=["GET"])
def get_gate_pass_by_vehicle_number(vehicle_number):
    try:
        # 1️⃣ Fetch ONLY LIVE gate entry
        document = Document.query.filter(
            Document.vehicle_number == vehicle_number,
            Document.gate_exit_status.is_(None)
        ).first()

        if not document:
            return jsonify({
                "error": "No active gate pass found for given vehicle number"
            }), 404

        # 2️⃣ Extract driver details from JSON
        driver_name = None
        license_number = None

        if document.extracted_text_driver:
            driver_data = json.loads(document.extracted_text_driver)
            driver_name = driver_data.get("name")
            license_number = driver_data.get("dl_number")

        # 3️⃣ Prepare response
        response = {
            "gate_entry": {
                "trip_id": document.Trip_id,
                "gate_entry_number": document.gate_entry_number,
                "gate_entry_status": document.gate_entry_status,
                "vehicle_number": document.vehicle_number,
                "vehicle_status": document.loading_or_unloading,
                "transporter_name": document.transporter_name,
                "vehicle_type": document.vehicle_type,

                # ✅ extracted from JSON
                "driver_name": driver_name,
                "license_number": license_number,
                "driver_mobile_number": document.driver_mobile_number,

                # ✅ correct DB columns
                "num_of_people": document.num_of_people,
                "total_invoices": document.total_invoices,

                # ✅ replaced fields
                "timestamp": document.timestamp,
                "gate_entry_out_time": document.gate_out_time,
                "gate_entry_remarks": document.gate_out_remarks
            },
            "is_duplicate": True
        }

        return jsonify(response), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500





if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        for rule in app.url_map.iter_rules():
            print(f"{rule.endpoint}: {rule.methods} -> {rule}")
    # app.run(debug=True, host="0.0.0.0", port=5100, ssl_context=("certificate.crt", "private.key"))
    app.run(debug=True, host="0.0.0.0", port=5100, ssl_context=("kirloskarWC2025.crt", "kirloskarWC2025.key"))

