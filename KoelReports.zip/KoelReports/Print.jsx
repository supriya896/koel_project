import React, { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router";
import {
  Button,
  DatePicker,
  Divider,
  Form,
  Input,
  Select,
  Space,
  Table,
} from "antd";
import { ArrowRightOutlined, PrinterOutlined } from "@ant-design/icons";
import MDRNavbar from "../components/MDRNavbar";
import TextArea from "antd/es/input/TextArea";
import MDRTable from "../components/MDRTable";
import { useReactToPrint } from "react-to-print";
import ColumnGroup from "antd/es/table/ColumnGroup";
import Column from "antd/es/table/Column";
import dayjs from "dayjs";
import { ConfigProvider } from "antd";
import { useParams } from "react-router-dom";
import { QRCodeCanvas } from "qrcode.react";


import "./preview.module.css";

const Print = ({ params }) => {
  const [form] = Form.useForm();
  const navigate = useNavigate();
  const location = useLocation();
  const { data, tableData, invoice_date, mdr_date, showDuplicateCopy } = location.state || {};
  const contentRef = useRef(null);
  const reactToPrintFn = useReactToPrint({ contentRef });
  const dateFormat = "YYYY/MM/DD";
  const { received_images } = location.state || { received_images: [] };
  // const [qrDataUrl, setQrDataUrl] = useState("");
  const { mdr_number } = useParams(); // get from URL
  console.log(data);
  // const imagesToDisplay = Array.isArray(received_images) ? received_images.map(img => img.url) : [];
  const receivedImages = location.state?.received_images ?? [];

  console.log("Full State Received in Print Page:", location.state);
  console.log("Received Images in Print Page:", receivedImages);
  console.log("Type of receivedImages:", typeof receivedImages);
  console.log("Array Check:", Array.isArray(receivedImages));
  console.log("Length:", receivedImages.length);


  //Handleing On Enter Submit
  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === "Enter") {
        form.submit();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [form]);

  // useEffect(() => {
  //   if (!data?.mdr_number) return;

  //   const generateQrCode = async () => {
  //     try {
  //       // const qrText = `http://192.168.1.110:5173/mdr/print/${data.mdr_number}`;
  //       const qrText = `http://192.168.125.242:5100/mdr/scan/${data.mdr_number}`;
  //       const url = await QRCode.toDataURL(qrText, {
  //         errorCorrectionLevel: "H", // Higher quality
  //         width: 200,
  //       });
  //       setQrDataUrl(url);
  //     } catch (err) {
  //       console.error("QR Code Generation Error: ", err);
  //     }
  //   };
  //   generateQrCode();
  // }, [data]);

  //Submitting Form
  const onFinish = (values) => {
    console.log("Table Data ", tableData);
    console.log("Success:", values);
    //Send the values and Table Data to the backend by converting into JSON
  };

  //Form validation Error
  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };

  console.log(data);

  return (
    <>
      <MDRNavbar />
      <div
        className="min-h-[80vh] w-[95%] bg-gray-30 mx-auto rounded-xl mt-10 px-10 pt-10 pb-2 mb-10"
        ref={contentRef}
      >
        <Form
          name="basic"
          form={form}
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
          initialValues={{ ...data, invDate: dayjs(invoice_date), mdrDate: dayjs(mdr_date) }}
          disabled={true}
          autoComplete="off"
          labelCol={{
            span: 24,
          }}
          wrapperCol={{
            span: 44,
          }}
        >
          {/* <div className="flex justify-start">
  <p className="text-sm font-semibold">KGL-F-STR-G-10-02</p>
</div> */}
           {/* <div className="flex flex-col items-center text-center mb-8">
            <p className="h-12 mb-2 absolute top-0 left-0 m-4" >KGL-F-STR-G-10-02</p>
            <img src="/logo.jpg" className="text-sm font-semibold h-12 mb-2 absolute top-0 right-0 m-4" />
            {/* Logo */}

          {/* Title */}
          {/* <h3 className="text-[#1d998b] text-2xl font-semibold mb-2">
              Material Discrepancy Report
            </h3> */}

            {/* Address */}
           {/* <p className="text-xl">Kagal Plant 1: D1, 5 Star MIDC, Kagal, Dist. Kolhapur - 416 202</p>
            <p className="text-xl">CIN No.: L29120PN2009PLC13351</p>
          </div>  */} 
          <div className="flex justify-between items-start mb-8">
  {/* Left: Title & Info */}
  <div className="flex flex-col items-center text-center flex-1">
    <p className="h-12 mb-2 self-start ml-4">KGL-F-STR-G-10-02</p>
    <h3 className="text-[#1d998b] text-2xl font-semibold mb-2">
      Material Discrepancy Report
    </h3>
    <p className="text-xl">Kagal Plant 1: D1, 5 Star MIDC, Kagal, Dist. Kolhapur - 416 202</p>
    <p className="text-xl">CIN No.: L29120PN2009PLC13351</p>
  </div>

  {/* Right: Logo and QR Code */}
  <div className="flex flex-col items-end mr-4">
    <img src="/logo.jpg" className="h-12 mb-2" alt="Logo" />
    <QRCodeCanvas
      value={data?.mdr_number || ""}
      size={100}
      level="H"
      includeMargin={true}
    />
    {/* <div className="text-xs mt-1 max-w-[100px] break-words">
      {data?.mdr_number}
    </div> */}
  </div>
</div>

          <div className="flex justify-between items-start mb-8 relative">

            
            {/* Top Left Fixed Code */}
            {/* <p className="h-12 mb-2 absolute top-0 left-0 m-4">KGL-F-STR-G-10-02</p> */}

            {/* Logo - top right */}
            {/* <img
              src="/logo.jpg"
              className="h-12 absolute top-0 right-0 m-4"
              alt="Logo"
            /> */}

            {/* QR Code - right below logo with minimal spacing */}
            {/* {qrDataUrl && (
              <div className="absolute top-[44px] right-0 m-4 text-right">
                <img
                  src={qrDataUrl}
                  alt="QR Code"
                  className="w-[100px] h-[100px]"
                />
                <div className="text-xs mt-1 max-w-[100px] break-words">
                  <a
                    href={`http://192.168.125.242:5100/mdr/scan/${data?.mdr_number}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-700 underline"
                  >
                    {/* http://192.168.125.242:5100/mdr/scan/{data?.mdr_number} */}
                  {/* </a>
                </div>
              </div>
            )} */} 
</div>

            {showDuplicateCopy && (
              <div className="text-red-600 font-bold text-lg mt-2 print:text-black">
                Duplicate Copy
                
              </div>
            )}


            <div className="w-full flex flex-wrap gap-5">
              <Form.Item
                className="w-[18%]"
                label="GRR/Sticker/MTN No."
                name="grr_mtn_sticker_number"
                labelCol={{ span: 24 }}
                rules={[{ message: "Please enter a value!" }]}
              >
                <Input.TextArea autoSize={{ minRows: 1, maxRows: 5 }} className="h-auto  text-black" style={{ borderColor: "black", color: "black", backgroundColor: "white" }} />
              </Form.Item>
              <Form.Item
                className="w-[18%] "
                label="Invoice Number"
                name="invoice_number"
                labelCol={{ span: 24 }}
                rules={[{ message: "Please enter a value!" }]}
              >
                <Input.TextArea autoSize={{ minRows: 1, maxRows: 5 }} className="h-auto  text-black" style={{ borderColor: "black", color: "black", backgroundColor: "white" }} />
              </Form.Item>
              <Form.Item
                className="w-[17%]"
                label="Invoice Date"
                name="invDate"
                labelCol={{ span: 24 }}
              >
                <DatePicker
                  className="w-full h-10"
                  format="DD-MMM-YY"
                  disabled
                  style={{ borderColor: "black", color: "black", fontWeight: "bold", backgroundColor: "white" }}
                  inputReadOnly
                />            </Form.Item>
              <Form.Item
                className="w-[18%]"
                label="MDR Number"
                name="mdr_number"
                labelCol={{ span: 24 }}
                rules={[{ message: "Please enter a value!" }]}
              >
                <Input className="h-10  text-black" style={{ borderColor: "black", color: "black", fontWeight: "bold" }} />
              </Form.Item>
              <Form.Item
                className="w-[17%]"
                label="MDR Date"
                name="mdrDate"
                labelCol={{ span: 24 }}
              >
                <DatePicker
                  className="w-full h-10"
                  format="DD-MMM-YY"
                  disabled
                  style={{ borderColor: "black", color: "black", fontWeight: "bold", backgroundColor: "white" }}
                  inputReadOnly
                />            </Form.Item>
              {/* <Form.Item className='w-[25%]' label="GRR Number" name="grr_number" labelCol={{ span: 24 }} rules={[{ message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item> */}

            </div>
            <div className="w-full flex gap-10">
              <Form.Item
                label="Unloading Location"
                className="w-[30%] !bg-white"
                labelCol={{ span: 24 }}
                name="unloading_location"
                rules={[{ message: "Please select a value!" }]}
              >
                <ConfigProvider
                  theme={{
                    token: {
                      colorBgContainerDisabled: "white",
                    },
                    components: {
                      Select: {
                        colorBgContainer: "white",
                        colorText: "black",
                        colorBorder: "black",
                        optionSelectedBg: "#f0f0f0",
                      },
                    },
                  }}
                >
                  <Select
                    className="h-10 w-[100%] !border-none !bg-white text-black"
                    style={{ backgroundColor: "white !important", color: "black", fontWeight: "bold" }}
                    dropdownStyle={{ backgroundColor: "#ffffff", color: "#000000" }}
                    placeholder="Choose"
                    defaultValue={data.unloading_location}
                    options={[
                      {
                        value: "LMHP",
                        label: <span style={{ color: 'black' }}>LMHP</span>,
                      },
                      {
                        value: "HHP",
                        label: <span style={{ color: 'black' }}>HHP</span>,
                      },
                      {
                        value: "Genset",
                        label: <span style={{ color: 'black' }}>Genset</span>,
                      },
                      {
                        value: "RWH",
                        label: <span style={{ color: 'black' }}>RWH</span>,
                      },
                      {
                        value: "Extended Store",
                        label: <span style={{ color: 'black' }}>Extended Store</span>,
                      },
                      {
                        value: "RM Store",
                        label: <span style={{ color: 'black' }}>RM Store</span>,
                      },
                    ]}
                  />
                </ConfigProvider>
              </Form.Item>

              <Form.Item
                className="w-[30%]"
                label="Sub MDR Number"
                name="sub_mdr_number"
                labelCol={{ span: 24 }}
                rules={[{ message: "Please enter a value!" }]}
              >
                <Input className="h-10  text-black" style={{ borderColor: "black", color: "black", fontWeight: "bold" }} />
              </Form.Item>


              <Form.Item
                label="MDR Raised At"
                labelCol={{ span: 24 }}
                className="w-[30%] !bg-white"
                name="mdr_raised_as"
                rules={[{ message: "Please select a value!" }]}
              >
                <ConfigProvider
                  theme={{
                    token: {
                      colorBgContainerDisabled: "white",
                      colorText: "black",
                    },
                    components: {
                      Select: {
                        colorBgContainer: "white",
                        colorText: "black",
                        colorBorder: "black",
                        optionSelectedBg: "#f0f0f0",
                      },
                    },
                  }}
                >
                  <Select
                    className="h-10 w-[100%] !border-none !bg-white text-black font-bold"
                    style={{ backgroundColor: "white", color: "black", fontWeight: "bold" }}
                    dropdownStyle={{ backgroundColor: 'white !important', color: "black", fontWeight: "bold", }}
                    placeholder="Choose"
                    defaultValue={data.mdr_raised_as}
                    options={[
                      {
                        value: "Storage",
                        label: <span style={{ color: 'black' }}>Storage</span>,
                      },
                      {
                        value: "Unloading",
                        label: <span style={{ color: 'black' }}>Unloading</span>,
                      },
                    ]}
                  />
                </ConfigProvider>
              </Form.Item>
              <Form.Item
                className="w-[30%]"
                label="Vehicle Number"
                name="vehicle_number"
                labelCol={{ span: 24 }}
                rules={[{ message: "Please enter a value!" }]}
              >
                <Input className="h-10  text-black" style={{ borderColor: "black", color: "black", fontWeight: "bold" }} />
              </Form.Item>

            </div>
            <div className="w-full flex gap-10">
              <Form.Item
                className="w-[30%]"
                label="Transporter Name"
                name="transporter_name"
                labelCol={{ span: 24 }}
                rules={[{ message: "Please enter a value!" }]}
              >
                <Input className="h-10  text-black" style={{ borderColor: "black", color: "black", fontWeight: "bold" }} />
              </Form.Item>
              <Form.Item
                className="w-[30%]"
                label="Supplier Name"
                name="vendor_name"
                labelCol={{ span: 24 }}
                rules={[{ message: "Please enter a value!" }]}
              >
                <Input.TextArea autoSize={{ minRows: 1, maxRows: 3 }} className="h-auto  text-black" style={{ borderColor: "black", color: "black", backgroundColor: "white" }} />
              </Form.Item>
              <Form.Item
                className="w-[30%]"
                label="LR/Docket No"
                name="lr_field"
                labelCol={{ span: 24 }}
                rules={[{ message: "Please enter a value!" }]}
              >
                <Input className="h-10  text-black" style={{ borderColor: "black", color: "black", fontWeight: "bold" }} />
              </Form.Item>
              {/* <Form.Item className='w-[30%]' label="Vendor Namer" name="vendor_name" labelCol={{ span: 24 }} rules={[{ message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item> */}
              <Form.Item
                className="w-[30%]"
                label="Vendor Code"
                name="vendor_code"
                labelCol={{ span: 24 }}
                rules={[{ message: "Please enter a value!" }]}
              >
                <Input className="h-10  text-black" style={{ borderColor: "black", color: "black", fontWeight: "bold" }} />
              </Form.Item>
            </div>
            <div>
              <p>The following discrepancies have been observed in the supply received from you:</p>
            </div>
            <Table dataSource={tableData} pagination={false} className="mb-8 mx-4 text-black" style={{ borderColor: "black", color: "black" }}>
              <Column title="Sr No." dataIndex="srno" key="srno" />
              <Column title="Part No." dataIndex="item_code" key="item_code" />
              <Column
                title="Material Description"
                dataIndex="item_description"
                key="item_description"
              />
              {/* <Column title="Unloading Location" dataIndex="unloading_location" key="unloading_location" /> */}
              <ColumnGroup title="Quantity">
                <Column
                  title="As per Challan/Invoices"
                  dataIndex="quantity_as_per_challan"
                  key="quantity_as_per_challan"
                />
                <Column
                  title="Actually Received"
                  dataIndex="item_quantity_actual"
                  key="item_quantity_actual"
                />
                <Column
                  title={
                    <div style={{ textAlign: "center" }}>
                      Shortage
                      <br />
                      Excess
                      <br />
                      Qualitative
                    </div>
                  }
                  dataIndex="excess_shortfall_quantity"
                  key="excess_shortfall_quantity"
                  width={60}
                />
                <Column
                  title="UOM"
                  dataIndex="uom"
                  key="uom"
                />

              </ColumnGroup>
              <Column
                title="No of Boxes"
                dataIndex="number_of_boxes_lr"
                key="No_of_boxes"
              />
              <Column title="Received" dataIndex="number_of_boxes_lr_recieved" key="received" />
            </Table>
            <div className="mt-6">
              <table className="w-full border border-black text-sm text-black table-fixed">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="w-[10%] border  px-2 py-1">Sr No.</th>
                    <th className="w-[90%] border  px-2 py-1">Remark</th>
                  </tr>
                </thead>
                <tbody>
                  {tableData.map((item, index) => (
                    <tr key={index}>
                      <td className="border px-2 py-1 text-center">{item.srno}</td>
                      <td className="border px-2 py-1">{item.mdr_remarks_1}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* <div className='w-full flex gap-10'>
                        <Form.Item className='w-[30%]' label="No.of Boxes/Carton's on LR" name="number_of_boxes" labelCol={{ span: 24 }} rules={[{ message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>
                        <Form.Item className='w-[30%]' label="Received" name="number_of_boxes_lr_recieved" labelCol={{ span: 24 }} rules={[{ message: 'Please enter a value!' }]}>
                            <Input className='h-10' />
                        </Form.Item>


                    </div> */}
            <div className="w-full flex gap-10">
              <ConfigProvider
                theme={{
                  token: {
                    colorBgContainerDisabled: "white",
                  },
                }}
              >
                {/* <Form.Item
                className="w-[30%] !bg-white"
                label="MDR remarks"
                name="mdr_remarks_1"
                labelCol={{ span: 24 }}
                rules={[{ message: "Please enter a value!" }]}
              >
                <TextArea className="h-10 text-black" style={{ borderColor: "black",color:"black" }}/>
              </Form.Item> */}
                <Form.Item
                  className="w-1/2"
                  label="Email TO Buyer"
                  name="email_id_to"
                  labelCol={{ span: 24 }}
                  rules={[{ message: "Please enter a value!" }]}
                >
                  <TextArea autoSize={{ minRows: 1, maxRows: 5 }} className="h-10  text-black" style={{ borderColor: "black", color: "black" }} />
                </Form.Item>
                <Form.Item
                  className="w-1/2"
                  label="Email TO Logistic"
                  name="email_id_to_logistic"
                  labelCol={{ span: 24 }}
                  rules={[{ message: "Please enter a value!" }]}
                >
                  <TextArea autoSize={{ minRows: 1, maxRows: 5 }} className="h-10  text-black" style={{ borderColor: "black", color: "black" }} />
                </Form.Item>
                <Form.Item
                  className="w-1/2"
                  label="Email CC"
                  name="email_id_cc"
                  labelCol={{ span: 24 }}
                  rules={[{ message: "Please enter a value!" }]}
                >
                  <TextArea autoSize={{ minRows: 1, maxRows: 5 }} className="h-10  text-black" style={{ borderColor: "black", color: "black" }} />
                </Form.Item>
              </ConfigProvider>
            </div>



            <Divider />
            <Form.Item>
              <div className="w-full flex flex-row justify-between">
                <div className="flex flex-col gap-8">
                  <p className="text-center">Prepared By</p>
                  <p className="border-t-2 border-gray-700 w-[100px] text-center">
                    TA/Store
                  </p>
                </div>
                <div>
                  <p className="text-center flex flex-col mb-8">
                    Verified By Kirloskar
                  </p>
                  <div className="flex gap-8">
                    <p className="border-t-2 border-gray-700 w-[100px] text-center">
                      Buyer
                    </p>
                    <p className="border-t-2 border-gray-700 w-[100px] text-center">
                      Security
                    </p>
                  </div>
                </div>
                <div>
                  <p className="text-center flex flex-col mb-8">Verified By</p>
                  <div className="flex gap-8">
                    <p className="border-t-2 border-gray-700 w-[100px] text-center">
                      Driver
                    </p>
                    <p className="border-t-2 border-gray-700 w-[100px] text-center">
                      Transporter/Logistic
                    </p>
                  </div>
                </div>
                <div>
                  <p className="text-center flex flex-col mb-8">Approved By</p>
                  <div className="flex gap-8">
                    <p className="border-t-2 border-gray-700 w-[160px] text-center">
                      TL/GL Store
                    </p>

                  </div>
                </div>
              </div>
            </Form.Item>
            {/* <div className="uploaded-images">
    {received_images && received_images.length > 0 ? (
        received_images.map((image, index) => (
            <img 
                key={index} 
                src={URL.createObjectURL(image)} 
                alt={`Uploaded ${index + 1}`} 
                style={{ width: '200px', margin: '10px' }}
            />
        ))
    ) : (
        <p>No images uploaded</p>
    )}
</div> */}


            {/* {/* {imagesToDisplay.length > 0 ? (
  <div className="mt-6">
    {/* <h3 className="text-lg font-semibold mb-2">Uploaded Images</h3> */}
            {/* <div className="flex flex-wrap gap-4">
      {imagesToDisplay.map((imgSrc, index) => (
        imgSrc ? (
          <img
            key={index}
            src={imgSrc}
            alt={`Uploaded ${index}`}
            className="w-40 h-40 object-cover border rounded-lg"
          />
        ) : null
      ))}
    </div>
  </div>
) : (
  <p className="text-center text-gray-500">No uploaded images.</p>
)} */}

        </Form>
      </div>
      <Divider />
      {typeof window !== "undefined" && (
        <div className=" page-footer">
          <span className="print-page-number" data-mdr-number={data?.mdr_number || "1"}></span>
        </div>
      )}

      <Space className="w-[95%] flex justify-end mb-10">
        <button onClick={() => navigate("/mdr")}>Back</button>
        <Button
          type="primary"
          onClick={reactToPrintFn}
          className="h-10 !bg-[#1d998b] font-semibold"
          icon={<PrinterOutlined />}
          iconPosition="end"
        >
          Print
        </Button>
      </Space>
    </>
  );
};
export default Print;
