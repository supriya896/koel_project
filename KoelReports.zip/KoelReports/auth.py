from flask import Blueprint, request, jsonify
from models import db, UserGate
from flask_jwt_extended import create_access_token
from werkzeug.security import generate_password_hash


auth_bp = Blueprint('auth', __name__)
ALLOWED_ROLES = ['admin', 'gate_entry_user', 'mdr_user', 'dock_user', 'viewer', 'gate_out_user', 'closing_mdr','only_dock']



@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    role = data.get('role', 'admin')  # default role is 'user'

    if role not in ALLOWED_ROLES:
        return jsonify({'msg': f'Invalid role. Allowed roles are: {ALLOWED_ROLES}'}), 400

    if UserGate.query.filter_by(username=username).first():
        return jsonify({'msg': 'Username already exists'}), 400

    user = UserGate(username=username, role=role)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()

    return jsonify({'msg': 'User registered successfully'}), 201

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    user = UserGate.query.filter_by(username=username).first()
    if user and user.check_password(password):
        access_token = create_access_token(
            identity=user.username,  # must be a string
            additional_claims={'role': user.role}
        )
        return jsonify(access_token=access_token), 200

    return jsonify({'msg': 'Invalid credentials'}), 401



from flask_jwt_extended import jwt_required, get_jwt_identity,get_jwt
@auth_bp.route('/protected', methods=['GET'])
@jwt_required()
def protected():
    username = get_jwt_identity()
    claims = get_jwt()
    role = claims.get('role')

    return jsonify({
        'username': username,
        'role': role,
        'message': 'You have access'
    }), 200


@auth_bp.route('/reset-password', methods=['POST'])
def password_reset():
    data = request.get_json()
    username = data.get('username')
    new_password = data.get('password')

    user = UserGate.query.filter_by(username=username).first()

    if not user:
        return jsonify({'msg': 'User not found'}), 404

    user.set_password(new_password)  # ✅ correctly hashes
    db.session.commit()

    return jsonify({'msg': 'Password updated successfully'}), 200