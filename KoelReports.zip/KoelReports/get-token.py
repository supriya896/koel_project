from flask import Flask, jsonify, request
import requests
import os

app = Flask(__name__)

# API Endpoint (Token URL)
TOKEN_URL = os.getenv("TOKEN_URL", "https://192.168.62.198:8080/v1.0/token")

# Credentials (Set these in environment variables)
USERNAME = os.getenv("BOT_USERNAME", "pravesh.kagalbot@kirloskar.com")
PASSWORD = os.getenv("BOT_PASSWORD", "Kirloskar@123")

@app.route("/get-token", methods=["POST"])
def get_token():
    headers = {
        "tenantid": "6d0b16db-38e6-4fcb-9d6a-ec8f8cc5ba49",
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Apache-HttpClient/4.5.5",
        "Accept-Encoding": "gzip,deflate",
        "Authorization": "Basic Og=="  # Replace this with proper auth if needed
    }

    payload = {
        "grant_type": "password",
        "username": USERNAME,
        "password": PASSWORD,
        "culture": "en-US"
    }

    try:
        response = requests.post(TOKEN_URL, headers=headers, data=payload, verify=False)  # Ignore SSL warnings if needed
        response.raise_for_status()  # Raise error for non-200 responses
        return jsonify(response.json())  # Return token response
    except requests.exceptions.RequestException as e:
        return jsonify({"error": str(e)}), 500  # Handle errors gracefully

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5300, debug=True, ssl_context=("certificate.crt", "private.key"))