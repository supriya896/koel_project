// import React,{useEffect,useState} from 'react'
// import DashboardNav from '../components/DashboardNav'
// import { Button } from 'antd'
// import { Link } from 'react-router'
// import DashboardButton from '../components/DashboardButton'
// import axios from 'axios';

// const Dashboard = () => {
//     const [userData, setUserData] = useState(null);
//     const [loading,setLoading] = useState(true)

//     useEffect(() => {
//       const fetchProtectedData = async () => {
//         try {
//           const token = localStorage.getItem('token');

//           const res = await axios.get('https://koelpravesh.kirloskar.com:5100/auth/protected', {
//             headers: {'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json' }
            
//           });
//           console.log("fff",res)
//           setUserData(res.data);
//           localStorage.setItem('userData',JSON.stringify(res.data))
//           setLoading(false)
//         } catch (error) {
//             console.log(error)
//             setLoading(false)
//          alert('Unauthorized. Redirecting to login...');
//           localStorage.removeItem('token');
//           window.location.href = '/';
//         }
//       };
  
//       fetchProtectedData();
//     }, []);
//     //checking roles
//     const hasRole = (requiredRoles = []) => {
//       const role = userData?.role;
//       return requiredRoles.includes(role);
//     };
//     const capitalizeFirstLetter = (str) =>
//       str ? str.charAt(0).toUpperCase() + str.slice(1) : '';

//     return (
//         <div>
//             <DashboardNav />
//             <div className='h-60 w-[85%] mt-8 bg-gradient-to-r from-[#1d998b] to-[#40c5b6a1]  mx-auto flex items-center justify-between rounded-xl'>
//                 <div className='ml-20 text-white'>
//                     <h1 className='text-6xl font-bold'>Hello</h1>
//                     <h3 className='text-4xl font-light mt-4'>{capitalizeFirstLetter( userData?.username)}</h3>
//                 </div>
//                 <img src='/dashboard.svg' className='h-60 mt-10 rounded-br-xl' />
//             </div>
//             {/* Services */}
//             <div className='mt-8 w-[85%] mx-auto'>
//                 <h1 className='text-3xl font-bold leading-loose border-[#1d998b] border-b-2 w-fit border-dotted'>Systems</h1>
//                 <div className='mt-8 flex w-full justify-between'>
//                 <DashboardButton name="Gate Entry System" className="text-xl"  page={hasRole(['admin', 'gate_entry_user']) ? '/search' : '#'} />
//                     <DashboardButton name="GRR (Coming Soon)" className="text-xl" page={hasRole(['admin', 'grr_user']) ? '#' : '#'}  />
//                     <DashboardButton name="MDR" className="text-xl" page={hasRole(['admin', 'mdr_user', 'dock_user']) ? '/mdr' : '#'} />
//                     <DashboardButton name="Dock In/Out " className="text-4xl" page={hasRole(['admin', 'dock_user']) ? '/dock' : '#'}/>
//                 </div>
//                 <div className='mt-8 flex gap-16'>
//                     <DashboardButton name="Gate Out System" className="text-xl" page={hasRole(['admin', 'gate_out_user']) ? '/gate-out-search' : '#'} />
//                     <DashboardButton name="Closing MDR" className="text-xl" page={hasRole(['admin','closing_mdr']) ? '/closing-mdr' : '#'} />
//                     {/* /gate-out-search */}
                    
//                 </div>
//             </div>

//         </div>
//     )
// }

// export default Dashboard
import React, { useEffect, useState } from 'react';
import DashboardNav from '../components/DashboardNav';
import { Tabs } from 'antd';
import DashboardButton from '../components/DashboardButton';
import axios from 'axios';

const Dashboard = () => {
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProtectedData = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('https://koelpravesh.kirloskar.com:5100/auth/protected', {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        });

        setUserData(res.data);
        localStorage.setItem('userData', JSON.stringify(res.data));
        setLoading(false);
      } catch (error) {
        console.error(error);
        setLoading(false);
        alert('Unauthorized. Redirecting to login...');
        localStorage.removeItem('token');
        window.location.href = '/';
      }
    };

    fetchProtectedData();
  }, []);

  const hasRole = (requiredRoles = []) => {
    const role = userData?.role;
    return requiredRoles.includes(role);
  };

  const capitalizeFirstLetter = (str) =>
    str ? str.charAt(0).toUpperCase() + str.slice(1) : '';

  const tabItems = [
    {
      key: '1',
      label: 'Systems',
      children: (
        <div>
          {/* <h1 className='text-3xl font-bold leading-loose border-[#1d998b] border-b-2 w-fit border-dotted'>Systems</h1> */}
          <div className='mt-8 flex w-full justify-between'>
            <DashboardButton name="Gate Entry System" className="text-xl" page={hasRole(['admin', 'gate_entry_user']) ? '/search' : '#'} />
            <DashboardButton name="GRR (Coming Soon)" className="text-xl" page={hasRole(['admin', 'grr_user']) ? '#' : '#'} />
            <DashboardButton name="MDR" className="text-xl" page={hasRole(['admin', 'mdr_user','dock_user']) ? '/mdr' : '#'} />
            <DashboardButton name="Dock In/Out" className="text-4xl" page={hasRole(['admin','dock_user','only_dock']) ? '/dock' : '#'} />
          </div>
          <div className='mt-8 flex gap-16'>
            <DashboardButton name="Gate Out System" className="text-xl" page={hasRole(['admin','gate_entry_user', 'gate_out_user']) ? '/gate-out-search' : '#'} />
            <DashboardButton name="Closing MDR" className="text-xl" page={hasRole(['admin','closing_mdr']) ? '/closing-mdr' : '#'} />
          </div>
        </div>
      )
    },
    
    {
      key: '2',
      label: 'User Register',
      disabled: userData?.role !== 'admin' && userData?.role !== 'super_admin',
      children: (
        <div>
          <div className='mt-8 flex gap-16'>
            <DashboardButton name="New Register" className="text-xl" page={hasRole(['admin','super_admin']) ? '/register' : '#'} />
            {/* <DashboardButton name="Forgot Password" className="text-xl" page={hasRole(['admin']) ? '/password/reset' : '#'} /> */}
           
          </div>
        </div>
      )
    },
   {
      key: '3',
      label: 'Reports & Masters',
      disabled: userData?.role !== 'super_admin',
      children: (
        <div>
          <div className='mt-8 flex gap-16'>
            <DashboardButton name="Bill Report" className="text-xl" page={hasRole(['super_admin']) ? '/' : '#'} />
            <DashboardButton name="Efficiency Report" className="text-xl" page={hasRole(['super_admin']) ? '/' : '#'} />
            <DashboardButton name="HRS Band Report" className="text-xl" page={hasRole(['super_admin']) ? '/' : '#'} />
            <DashboardButton name="Dock Utilization Report" className="text-xl" page={hasRole(['super_admin']) ? '/' : '#'} />
            {/* <DashboardButton name="Forgot Password" className="text-xl" page={hasRole(['admin']) ? '/password/reset' : '#'} /> */}
             </div>
             <div className='mt-8 flex gap-16'>
            <DashboardButton name="Masters" className="text-xl" page={hasRole(['super_admin']) ? '/' : '#'} />
             </div>
        
        </div>
      )
    },
    
  ];

  return (
    <div>
      <DashboardNav />
      <div className='h-60 w-[85%] mt-8 bg-gradient-to-r from-[#1d998b] to-[#40c5b6a1] mx-auto flex items-center justify-between rounded-xl'>
        <div className='ml-20 text-white'>
          <h1 className='text-6xl font-bold'>Hello</h1>
          <h3 className='text-4xl font-light mt-4'>{capitalizeFirstLetter(userData?.username)}</h3>
        </div>
        <img src='/dashboard.svg' className='h-60 mt-10 rounded-br-xl' alt="dashboard" />
      </div>

      {!loading && (
        <div className='mt-8 w-[85%] mx-auto'>
          <Tabs defaultActiveKey="1" items={tabItems} size="large" tabBarGutter={60} />
        </div>
      )}
    </div>
  );
};

export default Dashboard;
