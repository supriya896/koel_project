// import React, { useEffect, useState } from "react";
// import { Button, Input, Select, List } from "antd";
// import { SearchOutlined, SyncOutlined,DashboardOutlined } from "@ant-design/icons";
// import { useNavigate,Link } from "react-router";
// import { BACKEND_URL } from "../config";
// import axios from "axios";

// const Search = () => {
//     const [loading, setLoading] = useState(false);
//     const [query, setQuery] = useState("");
//     const [vehicleNumber, setVehicleNumber] = useState("")
//     const [gate, setGate] = useState("gatein");
//     const [suggestions, setSuggestions] = useState([]);
//     const [vehicleSuccess, setVehicleSuccess] = useState(true)
//     const [errorMessage, setErrorMessage] = useState("");
//     const Navigate = useNavigate();


//     // Example list of vehicle numbers
//     const vehicleNumbers = [
//         "1234",
//         "4567",
//         "7890",
//         "4568",
//         "8901",
//         "2345",
//         "4123",
//     ];

//     const handleSubmit = async () => {
//         setLoading(true);

//             try {
//                 // Call the backend API to fetch document data
//                 const response = await axios.get(`${BACKEND_URL}/get_document`, {
//                     params: { vehicle_number: vehicleNumber }
//                 });

//                 const documentData = response.data.data;
//                 console.log(documentData)

//                 // Store the document data in localStorage
//                 localStorage.setItem("vehicleData", JSON.stringify(documentData));

//                 // Store the vehicle number in localStorage
//                 localStorage.setItem("vehicleNumber", vehicleNumber);

//                 // Reset the query and suggestions
//                 setQuery("");
//                 setSuggestions([]); // Clear suggestions
//                 Navigate("/gate-entry");

//                 // if(documentData.gate_entry_number !== null) {
//                 //     // alert("Gate Entry for this vehicle already exists, click OK to continue")
//                 //     setVehicleSuccess(false);
//                 //     setErrorMessage("Already Gate Entry Number exists, Enter through Pravesh app.");
//                 // }

//                 // // // Navigate to the next page (e.g., gate-entry)
//                 // else{
//                 // Navigate("/gate-entry"); 
//                 // }
//             } catch (error) {
//                 // Handle any errors (e.g., vehicle number not found)
//                 console.log("No document found for the given vehicle number.")
//                 setVehicleSuccess(false)
//                 setErrorMessage("OOPS! No Vehicle Number Found");
//                 // alert("No document found for the given vehicle number.")
//                 // setErrorMessage("No document found for the given vehicle number.");
//             } finally {
//                 setLoading(false);
//             }

//     };


//     const handleInputChange = (e) => {
//         const input = e.target.value;
//         setQuery(input);
//         setVehicleNumber(input);

//         if (input) {
//             const filteredSuggestions = vehicleNumbers
//                 .filter((num) => num.includes(input)) // Matches input
//                 .sort((a, b) => {
//                     // Prioritize starting matches
//                     if (a.startsWith(input) && !b.startsWith(input)) return -1;
//                     if (!a.startsWith(input) && b.startsWith(input)) return 1;
//                     return 0;
//                 });

//             setSuggestions(filteredSuggestions);
//         } else {
//             setSuggestions([]);
//         }
//     };

//     const handleSuggestionClick = (suggestion) => {
//         setQuery(suggestion);
//         setSuggestions([]); // Clear suggestions on click
//     };

//     return (
//         <>
//         <div className="w-[80%] flex justify-end  mx-auto">
//         <Link to="/dashboard" className='text-xl absolute top-10 bg-white border border-2 flex gap-3 h-14 w-18 rounded-full items-center justify-center px-4 hover:shadow-md transition-all'><p>Home</p><DashboardOutlined /></Link>

//         </div>

//         <div className="flex flex-col justify-center items-center min-h-screen gap-10">
//             <img src="/logo.jpg" className="h-24" alt="Logo" />
//             <div className="bg-[#FAFAFA] flex flex-col lg:flex-row justify-center items-center py-20 px-5 md:px-10 lg:px-16 rounded-xl gap-4 w-[80%]">
//                 <div className="relative w-full lg:w-[50%]">
//                     <Input
//                         size="large"
//                         placeholder="Search vehicle number"
//                         prefix={<SearchOutlined />}
//                         className="h-16 w-full border-none shadow"
//                         value={query}
//                         onChange={handleInputChange}
//                         onPressEnter={handleSubmit}
//                     />
//                     {suggestions.length > 0 && (
//                         <div className="absolute top-20 bg-white rounded-lg shadow-lg w-full max-h-48 overflow-y-auto z-10">
//                             <List
//                                 dataSource={suggestions}
//                                 renderItem={(item) => (
//                                     <List.Item
//                                         className="cursor-pointer hover:bg-gray-100 !px-4 py-2"
//                                         onClick={() => handleSuggestionClick(item)}
//                                     >
//                                         {item}
//                                     </List.Item>
//                                 )}
//                             />
//                         </div>
//                     )}
//                 </div>
//                 <Select
//                     defaultValue={gate}
//                     className="h-16 w-full lg:w-[15%] !border-none"
//                     onChange={(value) => setGate(value)}
//                     options={[
//                         {
//                             value: "gatein",
//                             label: "Gate In",
//                         },
//                         // {
//                         //     value: "gateout",
//                         //     label: "Gate Out",
//                         // },
//                     ]}
//                 />
//                 <Button
//                     color="default"
//                     variant="solid"
//                     className="h-16 w-full lg:w-[15%] flex items-center justify-center !bg-[#1d998b] font-semibold"
//                     onClick={handleSubmit}
//                     loading={
//                         loading && {
//                             icon: <SyncOutlined spin />,
//                         }
//                     }
//                     iconPosition="end"
//                 >
//                     Search
//                 </Button>
//             </div>

//             {/* {!vehicleSuccess?(
//             <div className="text-red-500"> 
//                 <message>OOPS! No Vehicle Number Found </message>
//             </div>) :(<message></message>)} */}


//             {!vehicleSuccess && <div className="text-red-500">{errorMessage}</div>}
//         </div>
//         </>
//     );
// };

// export default Search;


import React, { useEffect, useState } from "react";
import { Button, Input, Select, List } from "antd";
import { SearchOutlined, SyncOutlined, DashboardOutlined,PrinterOutlined  } from "@ant-design/icons";
import { useNavigate, Link } from "react-router";
import { BACKEND_URL } from "../config";
import axios from "axios";

const Search = () => {
    const [loading, setLoading] = useState(false);
    const [query, setQuery] = useState("");
    const [vehicleNumber, setVehicleNumber] = useState("")
    const [gate, setGate] = useState("gatein");
    const [suggestions, setSuggestions] = useState([]);
    const [vehicleSuccess, setVehicleSuccess] = useState(true)
    const [errorMessage, setErrorMessage] = useState("");
    const Navigate = useNavigate();


    // Example list of vehicle numbers
    const vehicleNumbers = [
        "1234",
        "4567",
        "7890",
        "4568",
        "8901",
        "2345",
        "4123",
    ];

    const handleSubmit = async () => {
        setLoading(true);

        try {
            // Call the backend API to fetch document data
            const response = await axios.get(`${BACKEND_URL}/get_document`, {
                params: { vehicle_number: vehicleNumber }
            });

            const documentData = response.data.data;
            console.log(documentData)

            // Store the document data in localStorage
            localStorage.setItem("vehicleData", JSON.stringify(documentData));

            // Store the vehicle number in localStorage
            localStorage.setItem("vehicleNumber", vehicleNumber);

            // Reset the query and suggestions
            setQuery("");
            setSuggestions([]); // Clear suggestions
            Navigate("/gate-entry");

            // if(documentData.gate_entry_number !== null) {
            //     // alert("Gate Entry for this vehicle already exists, click OK to continue")
            //     setVehicleSuccess(false);
            //     setErrorMessage("Already Gate Entry Number exists, Enter through Pravesh app.");
            // }

            // // // Navigate to the next page (e.g., gate-entry)
            // else{
            // Navigate("/gate-entry"); 
            // }
        } catch (error) {
            // Handle any errors (e.g., vehicle number not found)
            console.log("No document found for the given vehicle number.")
            setVehicleSuccess(false)
            setErrorMessage("OOPS! No Vehicle Number Found");
            // alert("No document found for the given vehicle number.")
            // setErrorMessage("No document found for the given vehicle number.");
        } finally {
            setLoading(false);
        }

    };

    const handleReprintGatePass = async () => {
        if (!vehicleNumber || !vehicleNumber.trim()) {
            setVehicleSuccess(false);
            setErrorMessage("Please enter Vehicle Number");
            return;
        }

        setLoading(true);

        try {
            // 🔴 Call LIVE gate pass API using vehicle number
            const response = await axios.get(
                `${BACKEND_URL}/api/gate-pass/by-vehicle/${vehicleNumber}`
            );

            const gateEntry = response.data.gate_entry;

            // 🔁 Map backend fields → Preview.jsx expected fields
            const previewData = {
                tripId: gateEntry.trip_id,
                gateEntryNumber: gateEntry.gate_entry_number,
                gateEntryStatus: gateEntry.gate_entry_status,
                vehicleNumber: gateEntry.vehicle_number,
                vehicleStatus: gateEntry.vehicle_status,
                transporterName: gateEntry.transporter_name,
                vehicleType: gateEntry.vehicle_type,

                driverName: gateEntry.driver_name,
                driverNumber: gateEntry.driver_mobile_number,
                licenseNumber: gateEntry.license_number,

                // ✅ FIXED FIELD NAMES
                noOfPersons: gateEntry.num_of_people,
                invoices: gateEntry.total_invoices,

                inDate: gateEntry.timestamp,
                outDate: gateEntry.gate_entry_out_time,
                remarks: gateEntry.gate_entry_remarks,
            };


            // 🔴 Navigate to Preview with DUPLICATE flag
            Navigate("/preview", {
                state: {
                    data: previewData,
                    duplicate: true
                }
            });

        } catch (error) {
            console.log("No active gate pass found for this vehicle");

            setVehicleSuccess(false);

            if (error.response?.status === 404) {
                setErrorMessage("No active gate pass found for this vehicle");
            } else {
                setErrorMessage("Failed to fetch gate pass");
            }

        } finally {
            setLoading(false);
        }
    };




    const handleInputChange = (e) => {
        const input = e.target.value;
        setQuery(input);
        setVehicleNumber(input);

        if (input) {
            const filteredSuggestions = vehicleNumbers
                .filter((num) => num.includes(input)) // Matches input
                .sort((a, b) => {
                    // Prioritize starting matches
                    if (a.startsWith(input) && !b.startsWith(input)) return -1;
                    if (!a.startsWith(input) && b.startsWith(input)) return 1;
                    return 0;
                });

            setSuggestions(filteredSuggestions);
        } else {
            setSuggestions([]);
        }
    };

    const handleSuggestionClick = (suggestion) => {
        setQuery(suggestion);
        setSuggestions([]); // Clear suggestions on click
    };

    return (
        <>
            <div className="w-[80%] flex justify-end  mx-auto">
                <Link to="/dashboard" className='text-xl absolute top-10 bg-white border border-2 flex gap-3 h-14 w-18 rounded-full items-center justify-center px-4 hover:shadow-md transition-all'><p>Home</p><DashboardOutlined /></Link>

            </div>

            <div className="flex flex-col justify-center items-center min-h-screen gap-10">
                <img src="/logo.jpg" className="h-24" alt="Logo" />
                <div className="bg-[#FAFAFA] flex flex-col lg:flex-row justify-center items-center py-20 px-5 md:px-10 lg:px-16 rounded-xl gap-4 w-[80%]">
                    <div className="relative w-full lg:w-[50%]">
                        <Input
                            size="large"
                            placeholder="Search vehicle number"
                            prefix={<SearchOutlined />}
                            className="h-16 w-full border-none shadow"
                            value={query}
                            onChange={handleInputChange}
                            onPressEnter={handleSubmit}
                        />
                        {suggestions.length > 0 && (
                            <div className="absolute top-20 bg-white rounded-lg shadow-lg w-full max-h-48 overflow-y-auto z-10">
                                <List
                                    dataSource={suggestions}
                                    renderItem={(item) => (
                                        <List.Item
                                            className="cursor-pointer hover:bg-gray-100 !px-4 py-2"
                                            onClick={() => handleSuggestionClick(item)}
                                        >
                                            {item}
                                        </List.Item>
                                    )}
                                />
                            </div>
                        )}
                    </div>
                    <Select
                        defaultValue={gate}
                        className="h-16 w-full lg:w-[15%] !border-none"
                        onChange={(value) => setGate(value)}
                        options={[
                            {
                                value: "gatein",
                                label: "Gate In",
                            },
                            // {
                            //     value: "gateout",
                            //     label: "Gate Out",
                            // },
                        ]}
                    />
                    <Button
                        color="default"
                        variant="solid"
                        className="h-16 w-full lg:w-[15%] flex items-center justify-center !bg-[#1d998b] font-semibold"
                        onClick={handleSubmit}
                        loading={
                            loading && {
                                icon: <SyncOutlined spin />,
                            }
                        }
                        iconPosition="end"
                    >
                        Search
                    </Button>
                    <Button
                        color="default"
                        variant="solid"
                        className="h-16 w-full lg:w-[15%] flex items-center justify-center !bg-[#c47c5c] font-semibold text-white"
                        icon={<PrinterOutlined  />}
                        onClick={handleReprintGatePass}
                    >
                        Reprint Gate Pass
                    </Button>

                </div>

                {/* {!vehicleSuccess?(
            <div className="text-red-500"> 
                <message>OOPS! No Vehicle Number Found </message>
            </div>) :(<message></message>)} */}


                {!vehicleSuccess && <div className="text-red-500">{errorMessage}</div>}
            </div>
        </>
    );
};

export default Search;



