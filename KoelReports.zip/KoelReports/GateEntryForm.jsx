import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router";
import axios from "axios";
import Navbar from "../components/Navbar";


import {
  Button,
  ConfigProvider,
  Divider,
  Form,
  Input,
  InputNumber,
  Modal,
  Select,
  Space,
} from "antd";
import {
  ArrowRightOutlined,
  CheckOutlined,
  CloseOutlined,
  RobotOutlined,
} from "@ant-design/icons";
import { RuleObject } from "antd/lib/form";
import { BACKEND_URL } from "../config";
import Alert from "antd/lib/alert/Alert";

const messages = [
  "Processing...",
  "Submitting to ERP",
  "Please wait, almost there...",
  "Finalizing process..."
];
const LoadingAnimation = ({ submitLoading, completed, step }) => {
  return (
    <div className="flex items-center justify-center text-black">
      {submitLoading ? (
        <div className="flex items-center gap-4 h-full text-3xl">
          <Loader2 className="animate-spin" size={40} />
          {messages[step]}
        </div>
      ) : (
        <div className="text-4xl font-bold flex items-center gap-2">
          {completed ? "Process Completed" : "Process Failed"}
          <CheckCircle className="text-green-500" size={40} />
        </div>
      )}
    </div>
  );
}; 
import { CheckCircle, Loader2 } from "lucide-react";



const GateEntryForm = ({ params }) => {
  const location = useLocation();
  const data = JSON.parse(localStorage.getItem("gate-form"));
  const [form] = Form.useForm();
  const [vehicleNumber, setvehicleNumber] = useState(
    localStorage.getItem("vehicleNumber")
  );
  const rawData = localStorage.getItem("vehicleData");
  const vehicleData = JSON.parse(rawData);
  // const statusMapping = {
  //   Unloading: "unloadingofmaterials",
  //   Loading: "loadingofmaterials",
  // };
  const parsedUserData = JSON.parse(localStorage.getItem("userData"));
console.log("user:", parsedUserData?.username);
const [userData, setUserData] = useState(parsedUserData);

  const [vehicleStatus, setVehicleStatus] = useState(
    // data ? data.vehicleStatus :  statusMapping[vehicleData.loading_unloading]
    data ? data.vehicleStatus : vehicleData.loading_unloading
  );
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [checkValues, setCheckValues] = useState([]);
  const [invoices, setInvoices] = useState();
  const [submitLoading,setSumbitLoading] = useState(false)
  const [completed, setCompleted] = useState(false);
  const [step, setStep] = useState(0);
  const allData = data
    ? data
    : {
      vehicleNumber: vehicleNumber,
      driverName: vehicleData.driver_name,
      driverNumber: vehicleData.driver_mobile_number,
      gateEntryNumber: "",
      gateEntryStatus: "",
      inDate: "",
      invoices: "",
      licenseNumber: vehicleData.dl_number,
      lrDate: "",
      lrNumber: "",
      noOfPersons: vehicleData.num_of_people,
      outDate: "",
      pucStatus: vehicleData.puc_status,
      remarks: "",
      transporterName: vehicleData.transporter_name,
      vehicleStatus: vehicleData.loading_unloading,
      vehicleType: vehicleData.vehicle_type,
      tripId: vehicleData.trip_id,
    };
  console.log(allData)
  const [finalData, setFinalData] = useState(allData);
  useEffect(() => {
    if (localStorage.getItem("gate-form")) {
      let data = JSON.parse(localStorage.getItem("gate-form"));
      setFinalData(data);
    }
  }, []);
  const Navigate = useNavigate();

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const validatePhoneNumber = async (_, value) => {
    if (!value || /^\d{10}$/.test(value)) {
      return Promise.resolve();
    }
    return Promise.reject(new Error("Phone number must be exactly 10 digits"));
  };
  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === 'Enter') {
        if (isModalOpen) {
          if (vehicleStatus.toLowerCase() === "loading") {
            handleLoadingSubmit();
          } else {
            handleUnloadingSubmit();
          }
        } else {
          form.submit();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isModalOpen, form]);


  const onFinishHandler = (values) => {
    console.log("Success:", values);

    let finalDataForm = {
      vehicleNumber: vehicleNumber,
      driverName: values.driverName,
      driverNumber: values.driverNumber,
      gateEntryNumber: values.gateEntryNumber,
      gateEntryStatus: values.gateEntryStatus,
      inDate: values.inDate,
      invoices: values.invoices,
      licenseNumber: values.licenseNumber,
      lrDate: values.lrDate,
      lrNumber: values.lrNumber,
      noOfPersons: values.noOfPersons,
      outDate: values.outDate,
      pucStatus: values.pucStatus,
      remarks: values.remarks,
      transporterName: values.transporterName,
      vehicleStatus: values.vehicleStatus,
      vehicleType: values.vehicleType,
      tripId: allData.tripId,
      gateEntryUser: parsedUserData?.username || "",
    };
    setFinalData(finalDataForm);

    setCheckValues(values);
    setInvoices(values.invoices);
    showModal();
  };
  const onFinishFailedHandler = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };
  const handleUnloadingSubmit = () => {
    localStorage.setItem("gate-form", JSON.stringify(finalData));
    Navigate("/invoice", { state: { invoice: invoices, data: finalData } });
  };

  const handleLoadingSubmit = async () => {
    setSumbitLoading(true)
    setInterval(() => {
      setStep((prev) => (prev < messages.length - 1 ? prev + 1 : prev));
    }, 8500);
    try {
      if (!finalData || Object.keys(finalData).length === 0) {
        console.error("Error: No data to send.");
        alert("Error: No data provided. Please fill in all required fields.");
        return;
      }
  
      console.log("🚀 Sending Data:", finalData);
  
      // Create FormData object
      let formData = new FormData();
      formData.append("json", JSON.stringify(finalData));
  
      // If there's an invoice file, append it (optional)
      // if (values.invoiceFile) {
      //     formData.append("invoice", values.invoiceFile);
      // }
  
      // API URL
      const API_URL = "https://koelbotgateentry.kirloskar.com:5200/trigger-bot"; // Replace with actual URL
  
      // Make POST request
      const response = await axios.post(API_URL, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
        timeout: 300000, // 5 minutes timeout (matches backend)
      });
  
      console.log("✅ API Response:", response.data);

      finalData.gateEntryNumber = response.data.gate_entry_number.trim();
      finalData.gateEntryStatus = response.data.gate_entry_status.trim();
      finalData.inDate = response.data.in_date.trim();
  
      // Handle backend errors
      if (response.data.error) {
        console.error("🚨 Backend Error:", response.data.error);
        alert(`Error: ${response.data.error}`);
        setSumbitLoading(false)
        return;
      }
  
      // ✅ Success: Handle navigation or next steps
      console.log("Bot executed successfully!");
      setSumbitLoading(false)
      setCompleted(true);
      Navigate("/preview", { replace: true, state: { data: finalData } });
  
    } catch (error) {
      // Handle network errors
      if (error.code === "ECONNABORTED") {
        // console.error("⏳ Request Timeout:", error.message);
        alert("Request Timeout: The server took too long to respond. Please try again.");
      } else if (error.response) {
        // Server responded with an error status
        // console.error("❌ Server Error:", error.response.status, error.response.data);
        // alert(`Error ${error.response.status}: ${error.response.data.error || "Something went wrong!"}`);
        alert(`${error.response.data.error || "Something went wrong!"}`);
      } else if (error.request) {
        // Request was made but no response received
        // console.error("📡 No Response from Server:", error.request);
        alert("Error: No response from server. Please check your network connection.");
      } else {
        // Something else happened
        // console.error("⚠️ Unexpected Error:", error.message);
        alert(`Unexpected Error: ${error.message}`);
      }
      setSumbitLoading(false)
    }
  };
  

  const fieldTitles = {
    driverName: "Driver Name",
    driverNumber: "Driver Number",
    gateEntryNumber: "Gate Entry Number",
    gateEntryStatus: "Gate Entry Status",
    inDate: "In Date",
    invoices: "Invoices",
    licenseNumber: "License Number",
    lrDate: "LR Date",
    lrNumber: "LR Number",
    noOfPersons: "Number of Persons",
    outDate: "Out Date",
    pucStatus: "PUC Status",
    remarks: "Remarks",
    transporterName: "Transporter Name",
    vehicleStatus: "Vehicle Status",
    vehicleType: "Vehicle Type",
  };


  const callBotAPI = async () => {
    console.log(finalData);
  };


  return (
    <>
      <Navbar />
      <div className="min-h-[80vh] w-[85%] bg-gray-100 mx-auto rounded-xl mt-10 px-10 pt-10 pb-2 mb-10">
        <Form
          form={form}
          name="basic"
          initialValues={finalData}
          onFinish={onFinishHandler}
          onFinishFailed={onFinishFailedHandler}
          autoComplete="off"
          labelCol={{
            span: 24,
          }}
          wrapperCol={{
            span: 44,
          }}
        >
          <div className="w-full flex gap-10">
            <Form.Item
              label="Vehicle Number"
              name="vehicleNumber"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              <Input className="h-10" />
            </Form.Item>
            <Form.Item label="Vehicle Status" name="vehicleStatus" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
              <Input className='h-10' onChange={(val) => setVehicleStatus(val.target.value)} value={vehicleStatus} disabled />
            </Form.Item>
            <Form.Item label="Trip ID" name="tripId" labelCol={{ span: 24 }} rules={[{ required: true, message: 'Please enter a value!' }]}>
              <Input className='h-10' onChange={(val) => setVehicleStatus(val.target.value)} value={vehicleStatus} disabled />
            </Form.Item>

          </div>
          <div className="w-full flex gap-10">
            <Form.Item
              className="w-[30%]"
              label="Gate Entry Number - to be filled by bot"
              name="gateEntryNumber"
              labelCol={{ span: 24 }}
              rules={[
                {
                  required:
                    vehicleStatus.toLowerCase() === "unloading" || "loading" ? false : true,
                  message: "Please enter a value!",
                },
              ]}
            >
              <Input className="h-10" disabled />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="Gate Entry Status - to be filled by bot"
              name="gateEntryStatus"
              labelCol={{ span: 24 }}
              rules={[
                {
                  required:
                    vehicleStatus.toLowerCase() === "unloading" || "loading" ? false : true,
                  message: "Please enter a value!",
                },
              ]}
            >
              <Input className="h-10" disabled/>
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="In Date & Time - to be filled by bot"
              name="inDate"
              labelCol={{ span: 24 }}
              rules={[
                {
                  required: false,
                  message: "Please enter a value!",
                },
              ]}
            >
              <Input className="h-10" disabled/>
            </Form.Item>
          </div>
          <div className="w-full flex gap-10">
            <Form.Item
              className="w-[30%]"
              label="Transporter Name"
              name="transporterName"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              <Input className="h-10" disabled />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="Vehicle Type"
              name="vehicleType"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              <Input className="h-10" disabled />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="PUC Status"
              name="pucStatus"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              <Input className="h-10" disabled/>
            </Form.Item>
          </div>
          <div className="w-full flex gap-10">
            <Form.Item
              className="w-[30%]"
              label="LR Number"
              name="lrNumber"
              labelCol={{ span: 24 }}
              rules={[{ required: false, message: "Please enter a value!" }]}
            >
              <Input className="h-10" disabled/>
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="LR Date"
              name="lrDate"
              labelCol={{ span: 24 }}
              rules={[{ required: false, message: "Please enter a value!" }]}
            >
              <Input className="h-10"disabled />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="Driver Name"
              name="driverName"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              <Input className="h-10" disabled/>
            </Form.Item>
          </div>
          <div className="w-full flex gap-10">
            <Form.Item
              className="w-[30%]"
              label="Driver Mobile Number"
              name="driverNumber"
              labelCol={{ span: 24 }}
              rules={[
                {
                  required: true,
                  message: "Phone number needs to be 10 digits!",
                },
                { validator: validatePhoneNumber },
              ]}
            >
              <Input className="!h-10" maxLength={10} disabled />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="License Number"
              name="licenseNumber"
              labelCol={{ span: 24 }}
              rules={[{ required: true, message: "Please enter a value!" }]}
            >
              <Input className="h-10" disabled/>
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="No of Persons"
              name="noOfPersons"
              labelCol={{ span: 24 }}
              rules={[{ required: false, message: "Please enter a value!" }]}
            >
              <Input className="h-10" disabled />
            </Form.Item>
          </div>
          <div className="w-full flex gap-10">
            <Form.Item
              className="w-[30%]"
              label="Number of Invoices"
              name="invoices"
              labelCol={{ span: 24 }}
              rules={[
                {
                  required:
                    vehicleStatus.toLowerCase() === "loading" ? false : true,
                  message: "Please enter a value!",
                },
              ]}
            >
              <Input className="h-10 w-[100%]"
              disabled={vehicleStatus?.toLowerCase() === "loading"} />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="Remarks"
              name="remarks"
              labelCol={{ span: 24 }}
              rules={[{ required: false, message: "Please enter a value!" }]}
            >
              <Input className="h-10" />
            </Form.Item>
            <Form.Item
              className="w-[30%]"
              label="Out Date"
              name="outDate"
              labelCol={{ span: 24 }}
              rules={[{ required: false, message: "Please enter a value!" }]}
            >
              <Input className="h-10" />
            </Form.Item>
          </div>
          <Divider />
          <Form.Item>
            <Space>
              {vehicleStatus.toLowerCase() === "loading" || vehicleStatus == "" ? (
                <>
                  <Button
                    type="primary"
                    htmlType="submit"
                    className="h-10 !bg-[#1d998b] font-semibold"
                    icon={<CheckOutlined />}
                    iconPosition="end"
                  >
                    submit
                  </Button>
                </>
              ) : null}
              {vehicleStatus.toLowerCase() === "unloading" && (
                <Button
                  type="primary"
                  htmlType="submit"
                  className="h-10 !bg-[#1d998b] font-semibold"
                  icon={<ArrowRightOutlined />}
                  iconPosition="end"
                >
                  Next
                </Button>
              )}
            </Space>
          </Form.Item>
        </Form>
      </div>
      <ConfigProvider
        theme={{
          token: {
            Modal: {
              /* here is your component tokens */
              titleColor: "#1d998b",
              titleFontSize: 22,
            },
          },
        }}
      >
        <Modal
          title="Preview"
          open={isModalOpen}
          onOk={handleOk}
          onCancel={handleCancel}
          maskClosable={false}
          footer={null}
        >
          <Divider />
          <ul className="">
            {Object.entries(checkValues).map(([key, value]) => (
              <li key={key} className="mb-4">
                {value !== "" && (
                  <>
                    <strong>{fieldTitles[key] || key}: </strong>
                    {value === "loading" ? "Loading Of Materials" :
                      value === "unloading" ? "Unloading Of Materials" : value}
                  </>
                )}
              </li>
            ))}
          </ul>
          <Divider />
          <div className="w-full flex justify-end gap-6">
            <Button
              key="back"
              onClick={handleCancel}
              className="h-10"
              icon={<CloseOutlined />}
              iconPosition="end"
            >
              Cancel
            </Button>
            {vehicleStatus.toLowerCase() === "loading" ? (
              <Button
                key="submit"
                type="primary"
                className="h-10 !bg-[#1d998b] font-semibold"
                icon={<CheckOutlined />}
                iconPosition="end"
                onClick={handleLoadingSubmit}
              >
                Submit To Erp
              </Button>
            ) : (
              <Button
                type="primary"
                onClick={handleUnloadingSubmit}
                className="h-10 !bg-[#1d998b] font-semibold"
                icon={<ArrowRightOutlined />}
                iconPosition="end"
              >
                Next
              </Button>
            )}
          </div>
        </Modal>
      </ConfigProvider>
      <Modal
                title=""
                centered={true}
                open={submitLoading}
                maskClosable={false}
                footer={null}
                closeIcon={null}
      >
        <LoadingAnimation submitLoading={submitLoading} completed={completed} step={step} />
      </Modal>
    </>
  );
};

export default GateEntryForm;
