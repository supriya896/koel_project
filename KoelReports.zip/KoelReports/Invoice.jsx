import React, { useContext, useEffect, useRef, useState } from 'react';
import { Button, Form, Input, Modal, Popconfirm, Table, message } from 'antd';
import Navbar from '../components/Navbar'
import './invoice.css'
import axios from 'axios';
import { ArrowLeftOutlined, CheckOutlined, DeleteOutlined, PlusCircleOutlined, RobotOutlined, TableOutlined } from '@ant-design/icons';
import { useLocation, useNavigate } from 'react-router';
import exportToExcel from '../utils/exportToExcel';
import { BACKEND_URL } from '../config';

const EditableContext = React.createContext(null);
const EditableRow = ({ index, ...props }) => {
    const [form] = Form.useForm();
    return (
        <Form form={form} component={false}>
            <EditableContext.Provider value={form}>
                <tr {...props} />
            </EditableContext.Provider>
        </Form>
    );
};
const InputRefContext = React.createContext({});
const EditableCell = ({
    title,
    editable,
    children,
    dataIndex,
    record,
    handleSave,
    shipmentValidation,
    setShipmentValidation,
    ...restProps
}) => {
    const [editing, setEditing] = useState(false);
    const inputRef = useRef(null);
    const form = useContext(EditableContext);
    const inputRefs = useContext(InputRefContext);
    useEffect(() => {
        if (editing) {
            inputRef.current?.focus();
        }
    }, [editing]);
    const toggleEdit = () => {
        setEditing(!editing);
        form.setFieldsValue({
            [dataIndex]: record[dataIndex],
        });
    };
    const validateShipmentNo = async (value, key) => {
        if (!value) {
            setShipmentValidation(prev => {
                const updated = { ...prev };
                delete updated[key]; // Remove the validation status
                return updated;
            });
            return;
        }
        try {
            console.log(`Sending request to API with shipmentNo: ${value}`);
            const res = await fetch(`https://koelpravesh.kirloskar.com:5100/check_invoice?invoice_number=${encodeURIComponent(value)}`);
            const data = await res.json();
            console.log('Response from API for exists:', data.exists);
            const isValid = data.exists;
            // const shimpmentData = data.data

            setShipmentValidation(prev => ({
                ...prev,
                [key]: isValid ? 'true' : 'false'
            }));
        } catch (err) {
            console.error("Validation error:", err);
            setShipmentValidation(prev => ({
                ...prev,
                [key]: 'invalid'
            }));
        }
    };
    const save = async () => {
        try {
            const values = await form.validateFields();
            toggleEdit();
            handleSave({
                ...record,
                ...values,
            });

            if (dataIndex === "shipmentNo") {
                const newValue = values[dataIndex];
                if (newValue) {
                    validateShipmentNo(newValue, record.key);
                } else {
                    // Clear color if empty
                    setShipmentValidation(prev => {
                        const updated = { ...prev };
                        delete updated[record.key];
                        return updated;
                    });
                }
            }

        } catch (errInfo) {
            console.log('Save failed:', errInfo);
        }
    };
    const handleKeyDown = (e) => {
        const currentKey = Number(record.key);
        const refsForColumn = inputRefs.current[dataIndex] || {};

        if (e.key === "ArrowDown" || e.key === "Enter") {
            e.preventDefault();
            const nextInput = refsForColumn[currentKey + 1];
            if (nextInput) {
                nextInput.click();
                setTimeout(() => nextInput.focus(), 0);
            }
        }

        if (e.key === "ArrowUp") {
            e.preventDefault();
            const prevInput = refsForColumn[currentKey - 1];
            if (prevInput) {
                prevInput.click();
                setTimeout(() => prevInput.focus(), 0);
            }
        }
    };

    let childNode = children;
    if (editable) {
        const validationStatus = shipmentValidation?.[record.key];
        const isShipment = dataIndex === "shipmentNo";
        childNode = editing ? (
            <Form.Item
                style={{
                    margin: 0,
                }}
                name={dataIndex}
            >
                <Input ref={(node) => {
                    inputRef.current = node;
                    if (node) {
                        if (!inputRefs.current[dataIndex]) {
                            inputRefs.current[dataIndex] = {};
                        }
                        inputRefs.current[dataIndex][record.key] = node;
                    }
                }}
                    onPressEnter={save}
                    onBlur={save}
                    onKeyDown={(e) => handleKeyDown(e, record.key, dataIndex)}
                    data-column-key={dataIndex}
                    className={
                        isShipment && validationStatus === 'true' ? 'border-green-500' :
                            isShipment && validationStatus === 'false' ? 'border-red-500' : ''
                    }
                    style={{
                        border: isShipment && (validationStatus === 'true' || validationStatus === 'false')
                            ? '1px solid'
                            : undefined,
                        borderColor:
                            validationStatus === 'true' ? 'green' :
                                validationStatus === 'false' ? 'red' :
                                    undefined
                    }}
                />
            </Form.Item>
        ) : (
            <div
                className="editable-cell-value-wrap rounded-xl"
                style={{
                    paddingInlineEnd: 24,
                    border:
                        isShipment && validationStatus === 'true' ? '2px solid green' :
                            isShipment && validationStatus === 'false' ? '2px solid red' :
                                undefined
                }}

                onClick={toggleEdit}
                ref={(node) => {
                    if (!inputRefs.current[dataIndex]) {
                        inputRefs.current[dataIndex] = {};
                    }
                    inputRefs.current[dataIndex][record.key] = node;
                }}
            >
                {children}
            </div>
        );
    }
    return <td {...restProps}>{childNode}</td>;
};

const messages = [
    "Processing...",
    "Submitting to ERP",
    "Please wait, almost there...",
    "Finalizing process..."
];
const LoadingAnimation = ({ submitLoading, completed, step }) => {
    return (
        <div className="flex items-center justify-center text-black">
            {submitLoading ? (
                <div className="flex items-center gap-4 h-full text-3xl">
                    <Loader2 className="animate-spin" size={40} />
                    {messages[step]}
                </div>
            ) : (
                <div className="text-4xl font-bold flex items-center gap-2">
                    {completed ? "Process Completed" : "Process Failed"}
                    <CheckCircle className="text-green-500" size={40} />
                </div>
            )}
        </div>
    );
};

import { CheckCircle, Loader2 } from "lucide-react";


const Invoice = () => {
    const Navigate = useNavigate()
    const location = useLocation()
    const { data } = location.state
    const { invoice } = location.state
    const [messageApi, contextHolder] = message.useMessage();
    const [botError, setBotError] = useState('')
    const [response, setResponse] = useState('')
    const [submitLoading, setSumbitLoading] = useState(false)
    const [completed, setCompleted] = useState(false);
    const [step, setStep] = useState(0);
    const inputRefs = useRef({});
    const [shipmentValidation, setShipmentValidation] = useState({});

    // console.log(typeof Number(invoice))
    const n = Number(invoice); // Replace this with the desired number of items
    const saveData = localStorage.getItem("dataStored");
    const savedData = JSON.parse(saveData)
    let fillData = []
    if (savedData) {
        console.log("len", savedData.length)
        let noOfData = n - savedData.length
        if (noOfData > 0) {
            for (let i = 0; i < savedData.length; i++) {
                fillData.push(
                    {
                        key: savedData[i].key,
                        srn: savedData[i].srn,
                        shipmentNo: savedData[i].shipmentNo,
                        invoiceNo: savedData[i].invoiceNo,
                        vendorCode: savedData[i].vendorCode,
                        directDelivery: savedData[i].directDelivery,
                        vendorName: savedData[i].vendorName,
                        other: savedData[i].other,
                        outInvoiceNo: savedData[i].outInvoiceNo,
                        invoiceDate: savedData[i].invoiceDate,
                        invoiceAmount: savedData[i].invoiceAmount
                    }
                )
            }
            for (let i = 0; i < noOfData; i++) {
                console.log("d", i)
                console.log(fillData.length + 1)
                fillData.push(
                    {
                        key: fillData.length + 1,
                        srn: fillData.length + 1,
                        shipmentNo: '',
                        invoiceNo: '',
                        vendorCode: '',
                        directDelivery: 'No',
                        vendorName: '',
                        other: '',
                        outInvoiceNo: '',
                        invoiceDate: '',
                        invoiceAmount: ''
                    }
                )
            }
        }
        else {
            for (let i = 0; i < n; i++) {
                fillData.push(
                    {
                        key: savedData[i].key,
                        srn: savedData[i].srn,
                        shipmentNo: savedData[i].shipmentNo,
                        invoiceNo: savedData[i].invoiceNo,
                        vendorCode: savedData[i].vendorCode,
                        directDelivery: savedData[i].directDelivery,
                        vendorName: savedData[i].vendorName,
                        other: savedData[i].other,
                        outInvoiceNo: savedData[i].outInvoiceNo,
                        invoiceDate: savedData[i].invoiceDate,
                        invoiceAmount: savedData[i].invoiceAmount
                    }
                )
            }
        }

        console.log("cjhec", fillData)
    } else {
        fillData = Array.from({ length: n }, (_, index) => ({
            key: `${index + 1}`,
            srn: `${index + 1}`,
            shipmentNo: '',
            invoiceNo: '',
            vendorCode: '',
            directDelivery: 'No',
            vendorName: '',
            other: '',
            outInvoiceNo: '',
            invoiceDate: '',
            invoiceAmount: ''
        }))
        console.log("first")
    }
    const initialDataSource = fillData;
    const [dataSource, setDataSource] = useState(initialDataSource);
    const [count, setCount] = useState(n + 1);

    const handleDelete = (key) => {
        // const newData = dataSource.filter((item) => item.key !== key);
        // setDataSource(newData);
        const newData = dataSource
            .filter((item) => item.key !== key) // Remove the row with the given key
            .map((item, index) => ({
                ...item,
                key: `${index + 1}`, // Reassign keys sequentially
                srn: `${index + 1}`, // Update Sr. No sequentially
            }));

        setDataSource(newData);
    };

    const defaultColumns = [
        {
            title: 'Sr. No',
            dataIndex: 'srn',
        },
        {
            title: 'Shipment No',
            dataIndex: 'shipmentNo',
            width: '10%',
            editable: true,
        },
        {
            title: 'Invoice No',
            dataIndex: 'invoiceNo',
            width: '10%',
            editable: true,
        },
        {
            title: 'Vendor Code',
            dataIndex: 'vendorCode',
            width: '10%',
            editable: true,
        },
        {
            title: 'Direct Delivery',
            dataIndex: 'directDelivery',
            width: '10%',
            editable: true,
        },
        {
            title: 'Vendor Name',
            dataIndex: 'vendorName',
            width: '10%',
            editable: true,
        },
        {
            title: 'Other',
            dataIndex: 'other',
            width: '10%',
            editable: true,
        },
        {
            title: 'Out Invoice No',
            dataIndex: 'outInvoiceNo',
            width: '10%',
            editable: true,
        },
        {
            title: 'Invoice Date',
            dataIndex: 'invoiceDate',
            width: '10%',
            editable: true,
        },
        {
            title: 'Invoice Amount',
            dataIndex: 'invoiceAmount',
            width: '10%',
            editable: true,
        },
        {
            title: 'Action',
            dataIndex: 'action',
            render: (_, record) =>
                dataSource.length >= 1 ? (
                    <Popconfirm title="Sure to delete?" onConfirm={() => handleDelete(record.key)}>
                        <a className=''><DeleteOutlined className='text-red-400 text-xl' /></a>
                    </Popconfirm>
                ) : null,
        },
    ];
    const handleAdd = () => {
        const newCount = dataSource.length + 1;
        const newData = {
            key: newCount,
            srn: newCount,
            shipmentNo: '',
            invoiceNo: '',
            vendorCode: '',
            directDelivery: 'No',
            vendorName: '',
            other: '',
            outInvoiceNo: '',
            invoiceDate: '',
            invoiceAmount: ''

        };
        setDataSource([...dataSource, newData]);
        setCount(newCount + 1);
    };
    const handleSave = (row) => {
        const newData = [...dataSource];
        const index = newData.findIndex((item) => row.key === item.key);
        const item = newData[index];

        if (row.shipmentNo) {
            const splitedData = row.shipmentNo.split('/');

            if (splitedData.length === 4) {

                row.invoiceNo = `${splitedData[0]}/${splitedData[1]}`; // 12/34
                row.vendorCode = splitedData[2] || ''; // 56
                row.invoiceDate = splitedData[3] || ''; // 78
            } else if (splitedData.length === 3) {
                // Case: 3 parts → "11/22/33"
                row.invoiceNo = splitedData[0] || ''; // 11
                row.vendorCode = splitedData[1] || ''; // 22
                row.invoiceDate = splitedData[2] || ''; // 33
            } else {
                // If the format is incorrect, set values to empty strings
                row.invoiceNo = '';
                row.vendorCode = '';
                row.invoiceDate = '';
            }
        }
        newData.splice(index, 1, {
            ...item,
            ...row,
        });
        setDataSource(newData);
    };
    const components = {
        body: {
            row: EditableRow,
            cell: EditableCell,
        },
    };
    const columns = defaultColumns.map((col) => {
        if (!col.editable) {
            return col;
        }
        return {
            ...col,
            onCell: (record) => ({
                record,
                editable: col.editable,
                dataIndex: col.dataIndex,
                title: col.title,
                handleSave,
                shipmentValidation,
                setShipmentValidation,
            }),
        };
    });

    const handleBack = () => {
        localStorage.setItem("dataStored", JSON.stringify(dataSource));
        const data = JSON.parse(localStorage.getItem("gate-form"))
        const newData = { ...data, invoices: dataSource.length }
        localStorage.setItem("gate-form", JSON.stringify(newData))
        Navigate('/gate-entry')
    }

    const handleSubmit = async () => {
        setSumbitLoading(true)
        setInterval(() => {
            setStep((prev) => (prev < messages.length - 1 ? prev + 1 : prev));
        }, 8500);

        console.log("called api")
        let err = 0;
        dataSource.forEach((d) => {
            if ((d.shipmentNo).trim() === '' && (d.other).trim() === '') {
                messageApi.open({
                    type: 'error',
                    content: `Fill at least Shipment No or Other Field for Sr. No ${d.srn}`,
                    duration: 5
                });
                err += 1;
            }
        });
        let invalidShipments = Object.entries(shipmentValidation).filter(
            ([_, status]) => status === 'false'
          );

          if (invalidShipments.length > 0) {
            messageApi.open({
              type: 'error',
              content: `Some shipment numbers are invalid. Please fix them.`,
              duration: 5
            });
            setSumbitLoading(false);
            return;
          }
        const shipmentNos = dataSource
            .map((d) => d.shipmentNo?.trim())
            .filter((sn) => sn && sn !== ""); // remove empty values

        const duplicates = shipmentNos.filter(
            (item, index) => shipmentNos.indexOf(item) !== index
        );

        if (duplicates.length > 0) {
            const uniqueDuplicates = [...new Set(duplicates)];

            messageApi.open({
                type: "error",
                content: `Duplicate shipment numbers found: ${uniqueDuplicates.join(", ")}`,
                duration: 5,
            });

            setSumbitLoading(false);
            return; 
        }

        // Stop execution if validation fails
        if (err > 0) {
            setSumbitLoading(false);
            return;
        }

        try {
            console.log("🚀 Generating Excel File...");
            const excelFile = handleExport();

            if (!excelFile) {
                console.error("❌ Error: Excel file not generated.");
                alert("Error: Could not generate Excel file. Please try again.");
                return;
            }

            console.log("✅ Excel File Generated:", excelFile);

            // Prepare FormData (JSON + Excel)
            let formData = new FormData();
            formData.append("json", JSON.stringify(data));
            formData.append("invoice", excelFile); // Attach exported Excel file

            console.log("📤 Sending to API...");

            // Call API with a timeout of 300 seconds
            const response = await sendDataToAPI(formData, 300000); // 300 sec = 5 min

            if (!response) {
                console.error("❌ API Timeout: No response received.");
                setSumbitLoading(false)
                alert("Error: Server took too long to respond. Please try again.");
                return;
            }

            console.log("✅ API Success:", response.data);
            data.gateEntryNumber = response.data.gate_entry_number.trim();
            data.gateEntryStatus = response.data.gate_entry_status.trim();
            data.inDate = response.data.in_date.trim();
            setSumbitLoading(false)
            setCompleted(true);
            Navigate("/preview", {
                replace: true, state: {
                    data: data,
                    invoiceData: dataSource
                }
            });

        } catch (error) {
            console.error("❌ Error in Submit:", error);
            if (error.response) {
                // Server responded with an error status
                // console.error("❌ Server Error:", error.response.status, error.response.data);
                // alert(`Error ${error.response.status}: ${error.response.data.error || "Something went wrong!"}`);
                alert(`${error.response.data.error || "Something went wrong!"}`);
            }

            else

                alert("Something went wrong! Please try again.");
            setSumbitLoading(false)
        } finally {
            setSumbitLoading(false)
        }
    };



    const sendDataToAPI = async (formData, timeout) => {
        console.log("api called")
        try {
            console.log("📤 Preparing API Request...");
            formData.forEach((value, key) => console.log(`${key}:`, value));

            const API_URL = "https://koelbotgateentry.kirloskar.com:5200/trigger-bot";

            const response = await axios.post(API_URL, formData, {
                headers: { "Content-Type": "multipart/form-data" },
                timeout: timeout, // 300000 ms = 5 minutes
            });

            console.log("✅ API Response:", response.data);
            // alert(response)

            if (response.data.error) {
                console.error("🚨 Backend Error:", response.data.error);
                alert(`Error: ${response.data.error}`);
                return null;
            }

            return response; // Success

        } catch (error) {
            if (error.code === "ECONNABORTED") {
                console.error("⏳ API Timeout:", error.message);
                alert("Error: Request timeout. The server took too long to respond.");
            } else if (error.response) {
                console.error("❌ Server Error:", error.response.status, error.response.data);
                alert(`Error ${error.response.status}: ${error.response.data.error || "Something went wrong!"}`);
            } else if (error.request) {
                console.error("📡 No Response from Server:", error.request);
                alert("Error: No response from server. Please check your network connection.");
            } else {
                console.error("⚠️ Unexpected Error:", error.message);
                alert(`Unexpected Error: ${error.message}`);
            }

            return null; // Failure
        }
    };



    console.log(submitLoading)




    const handleExport = () => {
        return exportToExcel(dataSource, data.vehicleNumber.toUpperCase());
    };


    return (
        <>
            {contextHolder}
            <Navbar />
            <div className='min-h-[80vh] w-[85%] bg-gray-100 mx-auto rounded-xl mt-10 px-10 pt-10 pb-2 mb-10'>
                <div className='flex w-full justify-between mb-8 items-center'>
                    <div onClick={handleBack} className='h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center cursor-pointer hover:scale-110 transition'>
                        <ArrowLeftOutlined className='text-black' />
                    </div>
                    <div className='flex flex-col items-center gap-2'>
                        <p className='text-sm text-gray-600'>Gate Entry Number</p>
                        <h1>
                            <Input type='text' disabled value={data.gateEntryNumber} placeholder='Gate Entry Number' />
                        </h1>
                    </div>
                    <div className='flex gap-3'>
                        {/* <Button
                            onClick={handleExport}
                            type="primary"
                            className='h-10 !bg-[#138247] font-semibold' icon={<TableOutlined />} iconPosition='end'
                        >
                            Export CSV
                        </Button> */}
                        <Button
                            onClick={handleAdd}
                            type="primary"
                            className='h-10 !bg-[#c47c5c] font-semibold' icon={<PlusCircleOutlined />} iconPosition='end'
                        >
                            Add a row
                        </Button>
                    </div>


                </div>
                <InputRefContext.Provider value={inputRefs}>
                    <Table
                        components={components}
                        rowClassName={() => 'editable-row'}
                        bordered
                        dataSource={dataSource}
                        columns={columns}
                        pagination={false}
                        className='h-[50vh] overflow-y-scroll'
                    />
                </InputRefContext.Provider>
                <div className='flex gap-5 mb-5 mt-5'>
                    <Button onClick={handleSubmit} type="primary" htmlType="submit" className='h-10 !bg-[#1d998b] font-semibold' icon={<CheckOutlined />} iconPosition='end'>
                        Submit To Erp
                    </Button>
                </div>


            </div>
            <Modal
                title=""
                centered={true}
                open={submitLoading}
                maskClosable={false}
                footer={null}
                closeIcon={null}
            >
                <LoadingAnimation submitLoading={submitLoading} completed={completed} step={step} />
            </Modal>
        </>
    )
}

export default Invoice